---
description: Request a WTP184 GCC 4.9.3 optimized stripped release build with the selected packages/lib runtime set, without deployment
argument-hint: "[--dry-run] [--clean] [--message <text>]"
disable-model-invocation: true
context: fork
agent: wtp184-plan
background: false
---

Route this as a WTP184 request through the project's canonical workflow.

Requested canonical pipeline action: `release_build` (GCC/G++ 4.9.3 with the CentOS 7 sysroot; optimized, stripped build/package using the hash-validated selected runtime-library set from `/home/daigd/packages/lib`, including `libstdc++.so.6.0.26` and package-local `libgcc_s.so.1`; no sync or deployment). Generic `build` resolves to this same release profile.

Optional user instructions:

$ARGUMENTS

Use the existing WTP184 plan/server-session/server-operator contracts. This slash invocation requests the operation; it is not approval of any required generated plan. Treat `--dry-run` only as a request to preview resolution, never as authorization for the real build. Do not execute shell through this command file.
