---
description: Request synchronization of the current WTP184 LATEST artifact and metadata
argument-hint: "[optional context]"
disable-model-invocation: true
context: fork
agent: wtp184-plan
background: false
---

Route this as a WTP184 request through the project's canonical workflow.

Requested canonical pipeline action: `sync` (sync current local `LATEST` and metadata only; no deployment).

Optional user instructions:

$ARGUMENTS

Use the existing WTP184 plan/server-session/server-operator contracts. This slash invocation requests the operation; it is not approval of any required generated plan. Do not execute shell through this command file.
