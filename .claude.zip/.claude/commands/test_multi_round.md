---
description: Request one bounded WTP184 serial multi-round histories comparison case
argument-hint: "[case-id] [--dry-run] [optional context]"
disable-model-invocation: true
context: fork
agent: wtp184-plan
background: false
---

Route this as a WTP184 request through the project's canonical workflow.

Requested canonical pipeline action: `test_multi_round` (one serial histories case comparing the configured baseline and dev endpoints with forced non-stream history payloads).

Optional user instructions, including an optional case ID:

$ARGUMENTS

Use the existing WTP184 plan/server-session/server-operator/stress-test contracts. Default to the pipeline's bounded case only when no case ID is supplied; do not reinterpret this as the full multigroup matrix. This slash invocation requests the test; it is not approval of any required generated plan. Treat `--dry-run` only as a preview request. Do not execute shell through this command file.
