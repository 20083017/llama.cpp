---
description: Request a WTP184 release build followed by sync deployment and verification
argument-hint: "[--dry-run] [--clean] [--message <text>]"
disable-model-invocation: true
context: fork
agent: wtp184-plan
background: false
---

Route this as a WTP184 request through the project's canonical workflow.

Requested canonical pipeline action: `release_all` (optimized stripped release build/package followed by the existing deploy pipeline, which includes sync and verification).

Optional user instructions:

$ARGUMENTS

Use the existing WTP184 plan/server-session/server-operator contracts. This slash invocation requests the operation; it is not approval of any required generated plan. Treat `--dry-run` only as a preview request and do not add a duplicate sync. Do not execute shell through this command file.
