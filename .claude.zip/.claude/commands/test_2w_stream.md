---
description: Request the bounded exact-once 20,000-row WTP184 streaming SSE test
argument-hint: "[--dry-run] [concurrency=<1-64>] [optional context]"
disable-model-invocation: true
context: fork
agent: wtp184-plan
background: false
---

Route this as a WTP184 request through the project's canonical workflow.

Requested canonical pipeline action: `test_2w_stream` (20,000 CSV rows exactly once with `stream=true`, bounded SSE assertions, existing limits and no automatic request retry).

Optional user instructions:

$ARGUMENTS

Use the existing WTP184 plan/server-session/server-operator/stress-test contracts and report semantic accounting rather than exit status alone. This slash invocation requests the workload; it is not approval of any required generated plan. Treat `--dry-run` only as a preview request. Do not execute shell through this command file.
