---
description: Request a WTP184 ASan build of //cu:server without sync or deployment
argument-hint: "[--dry-run] [--clean] [--message <text>]"
disable-model-invocation: true
context: fork
agent: wtp184-plan
background: false
---

Route this as a WTP184 request through the project's canonical workflow.

Requested canonical pipeline action: `asan_build` (ASan build/package only; no sync or deployment).

Optional user instructions:

$ARGUMENTS

Use the existing WTP184 plan/server-session/server-operator contracts. This slash invocation requests the operation; it is not approval of any required generated plan. Treat `--dry-run` only as a request to preview resolution, never as authorization for the real build. Do not execute shell through this command file.
