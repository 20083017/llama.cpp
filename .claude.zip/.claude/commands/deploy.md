---
description: Request deployment of the current WTP184 LATEST artifact with sync and verification
argument-hint: "[optional context]"
disable-model-invocation: true
context: fork
agent: wtp184-plan
background: false
---

Route this as a WTP184 request through the project's canonical workflow.

Requested canonical pipeline action: `deploy` (sync current `LATEST`, deploy it to the managed dev slot, and verify postconditions).

Optional user instructions:

$ARGUMENTS

Use the existing WTP184 plan/server-session/server-operator contracts. This slash invocation requests the operation; it is not approval of any required generated plan. Do not add a duplicate sync before `deploy`, and do not execute shell through this command file.
