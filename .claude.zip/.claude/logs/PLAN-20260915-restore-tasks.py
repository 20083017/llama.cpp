#!/usr/bin/env python3
"""Restore all manifest-recorded tasks/** objects from quarantine backup."""

from __future__ import print_function

import argparse
import hashlib
import json
import os
import stat
import subprocess
import sys
import time


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--backup-root", required=True)
    parser.add_argument("--expected-revision", required=True)
    return parser.parse_args()


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(value):
    return hashlib.sha256(value.encode("utf-8", "surrogateescape")).hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", errors="strict") as stream:
        header = stream.readline().rstrip("\n").split("\t")
        rows = []
        for raw in stream:
            if not raw.strip():
                continue
            values = raw.rstrip("\n").split("\t")
            if len(values) != len(header):
                raise RuntimeError("invalid TSV row: " + path)
            rows.append(dict(zip(header, values)))
    return header, rows


def row_text(header, rows):
    return "\t".join(header) + "\n" + "".join("\t".join(row[key] for key in header) + "\n" for row in rows)


def verify_object(root, row):
    path = os.path.join(root, row["path"])
    if not os.path.lexists(path):
        raise RuntimeError("missing object: " + path)
    observed = os.lstat(path)
    kind = row["type"]
    if kind == "file" and not stat.S_ISREG(observed.st_mode):
        raise RuntimeError("type mismatch: " + path)
    if kind == "symlink" and not stat.S_ISLNK(observed.st_mode):
        raise RuntimeError("type mismatch: " + path)
    if stat.S_IMODE(observed.st_mode) != int(row["mode"], 8):
        raise RuntimeError("mode mismatch: " + path)
    if kind == "file":
        if observed.st_size != int(row["size"]):
            raise RuntimeError("size mismatch: " + path)
        identity = sha256_file(path)
    elif kind == "symlink":
        identity = sha256_text(os.readlink(path))
    else:
        identity = "-"
    if identity != row["identity_sha256"]:
        raise RuntimeError("identity mismatch: " + path)


def write_new(path, content, mode=0o600):
    if os.path.lexists(path):
        raise RuntimeError("refusing overwrite: " + path)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        data = content.encode("utf-8", "surrogateescape")
        offset = 0
        while offset < len(data):
            offset += os.write(descriptor, data[offset:])
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def append_sync(descriptor, line):
    data = line.encode("utf-8", "surrogateescape")
    offset = 0
    while offset < len(data):
        offset += os.write(descriptor, data[offset:])
    os.fsync(descriptor)


def main():
    args = parse_args()
    repo = os.path.realpath(args.repo)
    backup = os.path.realpath(args.backup_root)
    evidence = os.path.join(backup, ".wtp184-manifest")
    phase1 = os.path.join(evidence, "phase1")
    revision = subprocess.check_output(["git", "-C", repo, "rev-parse", "HEAD"]).decode("ascii").strip()
    if revision != args.expected_revision:
        raise RuntimeError("revision drift")
    if subprocess.check_output(["git", "-C", repo, "diff", "--cached", "--name-only"]).strip():
        raise RuntimeError("superproject index is not clean")
    third_party = os.path.join(repo, "third_party")
    if subprocess.check_output(["git", "-C", third_party, "diff", "--cached", "--name-only"]).strip():
        raise RuntimeError("third-party index is not clean")
    if os.stat(repo).st_dev != os.stat(backup).st_dev:
        raise RuntimeError("backup and workspace are on different devices")

    header, candidates = read_tsv(os.path.join(phase1, "candidate-files.tsv"))
    keep_header, keep = read_tsv(os.path.join(phase1, "keep-files.tsv"))
    rollback_header, rollback = read_tsv(os.path.join(evidence, "rollback.tsv"))
    task_rows = sorted((row for row in candidates if row["path"].startswith("tasks/")), key=lambda row: row["path"])
    if len(task_rows) != 73:
        raise RuntimeError("expected 73 task objects, found %d" % len(task_rows))
    task_bytes = sum(int(row["size"]) for row in task_rows)
    if task_bytes != 377567:
        raise RuntimeError("unexpected task bytes: %d" % task_bytes)

    script_row = next((row for row in keep if row["path"] == "build_task_libs.sh"), None)
    if script_row is None:
        raise RuntimeError("build_task_libs.sh missing from keep manifest")
    verify_object(repo, script_row)

    for row in task_rows:
        active = os.path.join(repo, row["path"])
        if os.path.lexists(active):
            raise RuntimeError("active task path already exists: " + row["path"])
        verify_object(backup, row)

    debug_sources = set(line.strip() for line in open(os.path.join(phase1, "debug-compile-sources.txt"), encoding="utf-8") if line.strip())
    release_sources = set(line.strip() for line in open(os.path.join(phase1, "release-compile-sources.txt"), encoding="utf-8") if line.strip())
    if debug_sources != release_sources or len(debug_sources) != 694:
        raise RuntimeError("configured source evidence changed or invalid")
    if any(path.startswith("tasks/") or path.startswith("external/tasks/") for path in debug_sources):
        raise RuntimeError("configured server source set contains tasks path")

    journal_path = os.path.join(evidence, "task-restoration-journal.tsv")
    journal_fd = os.open(journal_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    completed = 0
    try:
        append_sync(journal_fd, "state\tbackup_relative\tworkspace_relative\ttype\n")
        for row in task_rows:
            relative = row["path"]
            source = os.path.join(backup, relative)
            destination = os.path.join(repo, relative)
            if os.path.lexists(destination):
                raise RuntimeError("restore destination exists: " + relative)
            os.makedirs(os.path.dirname(destination), mode=0o755, exist_ok=True)
            append_sync(journal_fd, "INTENT\t%s\t%s\t%s\n" % (relative, relative, row["type"]))
            os.rename(source, destination)
            append_sync(journal_fd, "DONE\t%s\t%s\t%s\n" % (relative, relative, row["type"]))
            completed += 1
    finally:
        os.close(journal_fd)

    for row in task_rows:
        verify_object(repo, row)
        if os.path.lexists(os.path.join(backup, row["path"])):
            raise RuntimeError("restored task remains in backup: " + row["path"])
    verify_object(repo, script_row)

    task_status = subprocess.check_output(["git", "-C", repo, "status", "--porcelain=v1", "--", "tasks", "build_task_libs.sh"]).decode("utf-8", "replace")
    if task_status.strip():
        raise RuntimeError("tasks/build_task_libs still differ after restoration: " + task_status.strip())

    task_paths = set(row["path"] for row in task_rows)
    active_candidates = [row for row in candidates if row["path"] not in task_paths]
    restored_keep = []
    for row in task_rows:
        copy = dict(row)
        copy["reason"] = "USER_RESTORED_TASK"
        restored_keep.append(copy)
    post_keep = sorted(keep + restored_keep, key=lambda row: row["path"])
    active_rollback = [row for row in rollback if not row["workspace_relative"].startswith("tasks/")]

    write_new(os.path.join(evidence, "restored-task-files.tsv"), row_text(header, task_rows))
    write_new(os.path.join(evidence, "post-task-keep-files.tsv"), row_text(keep_header, post_keep))
    write_new(os.path.join(evidence, "post-task-candidate-files.tsv"), row_text(header, active_candidates))
    write_new(os.path.join(evidence, "post-task-active-rollback.tsv"), row_text(rollback_header, active_rollback))

    summary = {
        "revision": revision,
        "restored_objects": completed,
        "restored_bytes": task_bytes,
        "build_task_libs_preserved": True,
        "configured_source_count": len(debug_sources),
        "configured_tasks_source_count": 0,
        "post_keep_objects": len(post_keep),
        "post_candidate_objects": len(active_candidates),
        "post_active_rollback_entries": len(active_rollback),
        "restoration_journal_sha256": sha256_file(journal_path),
        "restored_task_manifest_sha256": sha256_file(os.path.join(evidence, "restored-task-files.tsv")),
        "active_rollback_sha256": sha256_file(os.path.join(evidence, "post-task-active-rollback.tsv")),
        "completed_at_epoch": int(time.time()),
    }
    write_new(os.path.join(evidence, "task-restoration-completion.json"), json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("task restoration failed: %s" % error, file=sys.stderr)
        sys.exit(1)
