#!/usr/bin/env python3
"""Validate all preconditions for WTP184 quarantine rollback."""
from __future__ import print_function

import csv
import hashlib
import os
import stat
import subprocess

P = "/home/daigd/dialogue"
T = P + "/third_party"
B = "/home/daigd/backups/wtp184-cu-server-only/20260915T160434-d232778d8484"
E = B + "/.wtp184-manifest"
PARENT_HEAD = "d232778d84846848c44c0d2632db741172a022d6"
NESTED_HEAD = "b607f465e12ef92c48d8d9cf061f80b7a3a8e188"
NESTED_TARGET = "43bcd72f484d0b0f2b88d5f8da7f90315b6c124d"
SAFETY_BRANCH = "archive/cu-server-prune-20260915-b607f465"
JOURNAL = "rollback-restoration-journal.tsv"
COMPLETION = "rollback-restoration-completion.json"
HASHES = {
    "rollback.tsv": "943f853b40839ed14c8e3ec0121a5d4bf7f73c3aa87a8c65fea2d5608be9f428",
    "move-journal.tsv": "2ee02f44149e621e240fdc9393c678f3d63f755a3da20242d49b3b8bea05b801",
    "task-restoration-journal.tsv": "7b42155d44fef2436428351cc4ff426e2c33709c51c2a5ef2749fb0370843c90",
    "restored-task-files.tsv": "264b1c005620389858e83d10ff92bdad236884cff3d11c17938607269b5205a5",
    "post-task-active-rollback.tsv": "5168796173ffef033b4fcdb2a5fe57a10e94df7a923bebd09ca8752985dbcab7",
    "post-task-candidate-files.tsv": "fe3b7cf31a7cdadb6b4590969c2c83987849ed686e009d75c53d0414254d38fc",
    "post-task-keep-files.tsv": "03ccf29f00fd6391088e108864ad4a70c4cad3516d6a9285d7808dde16279ef6",
}
UNTRACKED = {
    "audit_clu_source_binary_py36.sh": "cf25190f26bef8bea5699780878cc4104750f3b51f339843d141e07884e2bb99",
    "diff_clu_trees.sh": "25ffb8bd7dcb04afeb11f425de8a58095e7141bfeb9f7ddc4b558e94cbf544b7",
    "fast_clu_drift_audit.sh": "95776979ffbf0cd848e2774d9856e08e0db1339478efc583d5e285d859a076cb",
}


def fail(message):
    raise RuntimeError(message)


def git(repo, *args):
    env = dict(os.environ)
    env["LC_ALL"] = "C"
    env["GIT_OPTIONAL_LOCKS"] = "0"
    command = ["git", "-c", "core.fsmonitor=false", "-c", "core.hooksPath=/dev/null", "-C", repo]
    return subprocess.check_output(command + list(args), env=env)


def sha_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha_link(path):
    return hashlib.sha256(os.readlink(path).encode("utf-8", "surrogateescape")).hexdigest()


def read_tsv(name):
    with open(os.path.join(E, name), encoding="utf-8", errors="strict") as stream:
        header = stream.readline().rstrip("\n").split("\t")
        rows = []
        for raw in stream:
            if not raw.strip():
                continue
            values = raw.rstrip("\n").split("\t")
            if len(values) != len(header):
                fail("invalid TSV row in %s" % name)
            rows.append(dict(zip(header, values)))
    return header, rows


def validate_relative(path):
    if not path or os.path.isabs(path) or "\x00" in path:
        fail("unsafe relative path: %r" % path)
    normalized = os.path.normpath(path)
    if normalized != path or normalized == ".." or normalized.startswith("../"):
        fail("unsafe normalized path: %r" % path)


def verify_object(root, row):
    path = os.path.join(root, row["path"])
    if not os.path.lexists(path):
        fail("missing object: %s" % path)
    observed = os.lstat(path)
    kind = row["type"]
    if kind == "file":
        if not stat.S_ISREG(observed.st_mode):
            fail("type mismatch: %s" % path)
        if observed.st_size != int(row["size"]):
            fail("size mismatch: %s" % path)
        identity = sha_file(path)
    elif kind == "symlink":
        if not stat.S_ISLNK(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = sha_link(path)
    elif kind == "dir":
        if not stat.S_ISDIR(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = "-"
    else:
        fail("unknown type %s for %s" % (kind, path))
    if stat.S_IMODE(observed.st_mode) != int(row["mode"], 8):
        fail("mode mismatch: %s" % path)
    if identity != row["identity_sha256"]:
        fail("identity mismatch: %s" % path)


def zpaths(data):
    return [item.decode("utf-8", "surrogateescape") for item in data.split(b"\0") if item]


def main():
    for name, expected in HASHES.items():
        path = os.path.join(E, name)
        if not os.path.isfile(path) or sha_file(path) != expected:
            fail("manifest hash mismatch: %s" % name)
    if stat.S_IMODE(os.stat(B).st_mode) != 0o700 or stat.S_IMODE(os.stat(E).st_mode) != 0o700:
        fail("backup/evidence mode mismatch")
    if os.path.lexists(os.path.join(E, JOURNAL)) or os.path.lexists(os.path.join(E, COMPLETION)):
        fail("rollback journal/completion already exists")
    if os.stat(P).st_dev != os.stat(B).st_dev:
        fail("workspace and backup are on different filesystems")

    if git(P, "rev-parse", "HEAD").decode().strip() != PARENT_HEAD:
        fail("parent HEAD drift")
    if git(P, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip() != "fix/turn-ownership-20260914":
        fail("parent branch drift")
    if git(T, "rev-parse", "HEAD").decode().strip() != NESTED_HEAD:
        fail("nested HEAD drift")
    if git(T, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip() != "fix/cu-server-prune-20260915":
        fail("nested branch drift")
    if git(T, "rev-parse", NESTED_HEAD + "^").decode().strip() != NESTED_TARGET:
        fail("nested reset target mismatch")
    if subprocess.call(["git", "-C", T, "show-ref", "--verify", "--quiet", "refs/heads/" + SAFETY_BRANCH]) == 0:
        fail("safety branch already exists")
    if git(P, "diff", "--cached", "--name-only").strip() or git(T, "diff", "--cached", "--name-only").strip():
        fail("Git index is not empty")
    if git(T, "status", "--porcelain=v1", "--untracked-files=all").strip():
        fail("nested repository is not clean before reset")

    parent_untracked = set(zpaths(git(P, "ls-files", "--others", "--exclude-standard", "-z")))
    if parent_untracked != set(UNTRACKED):
        fail("parent untracked set drift: %r" % sorted(parent_untracked))
    for path, expected in UNTRACKED.items():
        if sha_file(os.path.join(P, path)) != expected:
            fail("untracked identity drift: %s" % path)

    _, active = read_tsv("post-task-active-rollback.tsv")
    _, candidates = read_tsv("post-task-candidate-files.tsv")
    _, keeps = read_tsv("post-task-keep-files.tsv")
    _, restored = read_tsv("restored-task-files.tsv")
    if len(active) != 2243 or len(candidates) != 39094 or len(keeps) != 2075 or len(restored) != 73:
        fail("manifest row count mismatch")

    active_paths = set()
    for row in active:
        source_rel = row["backup_relative"]
        destination_rel = row["workspace_relative"]
        if source_rel != destination_rel:
            fail("non-identity rollback mapping: %s -> %s" % (source_rel, destination_rel))
        validate_relative(source_rel)
        if source_rel in active_paths:
            fail("duplicate active rollback path: %s" % source_rel)
        active_paths.add(source_rel)
        source = os.path.join(B, source_rel)
        destination = os.path.join(P, destination_rel)
        if not os.path.lexists(source):
            fail("missing rollback source: %s" % source_rel)
        if os.path.lexists(destination):
            fail("occupied rollback destination: %s" % destination_rel)
        observed = os.lstat(source)
        if row["type"] == "file" and not stat.S_ISREG(observed.st_mode):
            fail("rollback source type mismatch: %s" % source_rel)
        if row["type"] == "symlink" and not stat.S_ISLNK(observed.st_mode):
            fail("rollback source type mismatch: %s" % source_rel)
        if row["type"] == "dir" and not stat.S_ISDIR(observed.st_mode):
            fail("rollback source type mismatch: %s" % source_rel)

    sorted_active = sorted(active_paths)
    for index, path in enumerate(sorted_active[:-1]):
        if sorted_active[index + 1].startswith(path + "/"):
            fail("nested active rollback entries: %s and %s" % (path, sorted_active[index + 1]))

    coverage = dict((path, 0) for path in active_paths)
    candidate_bytes = 0
    for row in candidates:
        validate_relative(row["path"])
        if os.path.lexists(os.path.join(P, row["path"])):
            fail("candidate destination exists: %s" % row["path"])
        verify_object(B, row)
        candidate_bytes += int(row["size"])
        probe = row["path"]
        owner = None
        while True:
            if probe in active_paths:
                owner = probe
                break
            parent = os.path.dirname(probe)
            if parent == probe or not parent:
                break
            probe = parent
        if owner is None:
            fail("candidate not covered by active rollback: %s" % row["path"])
        coverage[owner] += 1
    if any(value == 0 for value in coverage.values()):
        fail("active rollback entry covers no candidate")

    for row in keeps:
        verify_object(P, row)
    for row in restored:
        verify_object(P, row)
        if os.path.lexists(os.path.join(B, row["path"])):
            fail("restored task unexpectedly remains in backup: %s" % row["path"])
    if git(P, "status", "--porcelain=v1", "--", "tasks", "build_task_libs.sh").strip():
        fail("tasks/build_task_libs status drift")

    statvfs = os.statvfs(P)
    free_bytes = statvfs.f_bavail * statvfs.f_frsize
    print("ROLLBACK_PRECHECK_OK=1")
    print("parent_head=%s" % PARENT_HEAD)
    print("nested_head=%s" % NESTED_HEAD)
    print("nested_target=%s" % NESTED_TARGET)
    print("safety_branch=%s" % SAFETY_BRANCH)
    print("active_entries=%d" % len(active))
    print("candidate_objects=%d" % len(candidates))
    print("candidate_bytes=%d" % candidate_bytes)
    print("keep_objects=%d" % len(keeps))
    print("restored_tasks=%d" % len(restored))
    print("sources_verified=%d" % len(candidates))
    print("destinations_absent=%d" % len(candidates))
    print("active_coverage=%d" % len(coverage))
    print("same_filesystem=1")
    print("journal_absent=1")
    print("completion_absent=1")
    print("excluded_untracked=3")
    print("free_bytes=%d" % free_bytes)


if __name__ == "__main__":
    main()
