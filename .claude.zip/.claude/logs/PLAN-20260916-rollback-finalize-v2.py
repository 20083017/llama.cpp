#!/usr/bin/env python3
"""Finalize an already completed WTP184 quarantine rollback without replaying it."""
from __future__ import print_function

import argparse
import csv
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

MANIFEST_HASHES = {
    "rollback.tsv": "943f853b40839ed14c8e3ec0121a5d4bf7f73c3aa87a8c65fea2d5608be9f428",
    "move-journal.tsv": "2ee02f44149e621e240fdc9393c678f3d63f755a3da20242d49b3b8bea05b801",
    "task-restoration-journal.tsv": "7b42155d44fef2436428351cc4ff426e2c33709c51c2a5ef2749fb0370843c90",
    "restored-task-files.tsv": "264b1c005620389858e83d10ff92bdad236884cff3d11c17938607269b5205a5",
    "post-task-active-rollback.tsv": "5168796173ffef033b4fcdb2a5fe57a10e94df7a923bebd09ca8752985dbcab7",
    "post-task-candidate-files.tsv": "fe3b7cf31a7cdadb6b4590969c2c83987849ed686e009d75c53d0414254d38fc",
    "post-task-keep-files.tsv": "03ccf29f00fd6391088e108864ad4a70c4cad3516d6a9285d7808dde16279ef6",
}
JOURNAL_NAME = "rollback-restoration-journal.tsv"
ACCEPTED_NAME = "rollback-accepted-untracked.tsv"
COMPLETION_NAME = "rollback-restoration-completion.json"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--backup-root", required=True)
    parser.add_argument("--expected-parent-head", required=True)
    parser.add_argument("--expected-nested-head", required=True)
    parser.add_argument("--expected-parent-branch", required=True)
    parser.add_argument("--expected-nested-branch", required=True)
    parser.add_argument("--safety-branch", required=True)
    parser.add_argument("--safety-commit", required=True)
    parser.add_argument("--accepted-untracked-count", required=True, type=int)
    parser.add_argument("--accepted-untracked-digest", required=True)
    return parser.parse_args()


def fail(message):
    raise RuntimeError(message)


def git(repo, *args):
    env = dict(os.environ)
    env["LC_ALL"] = "C"
    env["GIT_OPTIONAL_LOCKS"] = "0"
    command = ["git", "-c", "core.fsmonitor=false", "-c", "core.hooksPath=/dev/null", "-C", repo]
    return subprocess.check_output(command + list(args), env=env)


def sha_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha_link(path):
    return hashlib.sha256(os.readlink(path).encode("utf-8", "surrogateescape")).hexdigest()


def read_tsv(evidence, name):
    with open(os.path.join(evidence, name), encoding="utf-8", errors="strict") as stream:
        header = stream.readline().rstrip("\n").split("\t")
        rows = []
        for raw in stream:
            if not raw.strip():
                continue
            values = raw.rstrip("\n").split("\t")
            if len(values) != len(header):
                fail("invalid TSV row in %s" % name)
            rows.append(dict(zip(header, values)))
    return header, rows


def verify_object(root, row):
    path = os.path.join(root, row["path"])
    if not os.path.lexists(path):
        fail("missing object: %s" % path)
    observed = os.lstat(path)
    kind = row["type"]
    if kind == "file":
        if not stat.S_ISREG(observed.st_mode):
            fail("type mismatch: %s" % path)
        if observed.st_size != int(row["size"]):
            fail("size mismatch: %s" % path)
        identity = sha_file(path)
    elif kind == "symlink":
        if not stat.S_ISLNK(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = sha_link(path)
    elif kind == "dir":
        if not stat.S_ISDIR(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = "-"
    else:
        fail("unknown object type: %s" % kind)
    if stat.S_IMODE(observed.st_mode) != int(row["mode"], 8):
        fail("mode mismatch: %s" % path)
    if identity != row["identity_sha256"]:
        fail("identity mismatch: %s" % path)


def fsync_directory(path):
    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY
    descriptor = os.open(path, flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_new(path, content, mode=0o600):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        data = content.encode("utf-8", "surrogateescape")
        offset = 0
        while offset < len(data):
            offset += os.write(descriptor, data[offset:])
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    fsync_directory(os.path.dirname(path))


def status_pairs(repo):
    raw = git(repo, "diff", "--no-ext-diff", "--ignore-submodules=all", "--name-status", "-z")
    parts = [item.decode("utf-8", "surrogateescape") for item in raw.split(b"\0") if item]
    if len(parts) % 2:
        fail("invalid Git name-status encoding")
    return [(parts[index], parts[index + 1]) for index in range(0, len(parts), 2)]


def accepted_untracked(repo, nested):
    paths = sorted(
        item.decode("utf-8", "surrogateescape")
        for item in git(repo, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    )
    nested_paths = [
        item
        for item in git(nested, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    ]
    if nested_paths:
        fail("nested untracked paths are not accepted")
    rows = []
    for path in paths:
        full = os.path.join(repo, path)
        observed = os.lstat(full)
        if not stat.S_ISREG(observed.st_mode):
            fail("accepted untracked path is not a regular file: %s" % path)
        rows.append((path, "%o" % stat.S_IMODE(observed.st_mode), str(observed.st_size), sha_file(full)))
    canonical = "".join("\t".join(row) + "\n" for row in rows)
    digest = hashlib.sha256(canonical.encode("utf-8", "surrogateescape")).hexdigest()
    return rows, canonical, digest


def verify_journal(path, active):
    expected = set((row["backup_relative"], row["workspace_relative"], row["type"]) for row in active)
    sequences = {}
    with open(path, encoding="utf-8", errors="strict") as stream:
        if stream.readline().rstrip("\n") != "state\tbackup_relative\tworkspace_relative\ttype":
            fail("journal header mismatch")
        for raw in stream:
            values = raw.rstrip("\n").split("\t")
            if len(values) != 4 or values[0] not in ("INTENT", "DONE"):
                fail("invalid journal row")
            key = tuple(values[1:])
            sequences.setdefault(key, []).append(values[0])
    if set(sequences) != expected:
        fail("journal mapping set mismatch")
    if any(sequence != ["INTENT", "DONE"] for sequence in sequences.values()):
        fail("journal has incomplete/invalid sequence")
    return len(sequences)


def main():
    args = parse_args()
    repo = os.path.realpath(args.repo)
    nested = os.path.join(repo, "third_party")
    backup = os.path.realpath(args.backup_root)
    evidence = os.path.join(backup, ".wtp184-manifest")
    journal_path = os.path.join(evidence, JOURNAL_NAME)
    accepted_path = os.path.join(evidence, ACCEPTED_NAME)
    completion_path = os.path.join(evidence, COMPLETION_NAME)

    if os.path.lexists(accepted_path) or os.path.lexists(completion_path):
        fail("accepted/completion evidence already exists")
    for name, expected in MANIFEST_HASHES.items():
        if sha_file(os.path.join(evidence, name)) != expected:
            fail("manifest hash mismatch: %s" % name)
    if not os.path.isfile(journal_path) or stat.S_IMODE(os.stat(journal_path).st_mode) != 0o600:
        fail("rollback journal missing or wrong mode")

    if git(repo, "rev-parse", "HEAD").decode().strip() != args.expected_parent_head:
        fail("parent HEAD mismatch")
    if git(nested, "rev-parse", "HEAD").decode().strip() != args.expected_nested_head:
        fail("nested HEAD mismatch")
    if git(repo, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip() != args.expected_parent_branch:
        fail("parent branch mismatch")
    if git(nested, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip() != args.expected_nested_branch:
        fail("nested branch mismatch")
    if git(nested, "rev-parse", "refs/heads/" + args.safety_branch).decode().strip() != args.safety_commit:
        fail("safety branch mismatch")
    if git(repo, "diff", "--cached", "--name-only").strip() or git(nested, "diff", "--cached", "--name-only").strip():
        fail("Git index is not empty")
    if status_pairs(repo) != [("M", "build_tools/deps/clu/common/httplib.hpp")]:
        fail("parent tracked status mismatch")
    if status_pairs(nested) != [("M", "httplib/httplib.cc")]:
        fail("nested tracked status mismatch")
    if git(repo, "status", "--porcelain=v1", "--", "tasks", "build_task_libs.sh").strip():
        fail("tasks/build script status mismatch")

    _, active = read_tsv(evidence, "post-task-active-rollback.tsv")
    _, candidates = read_tsv(evidence, "post-task-candidate-files.tsv")
    _, keeps = read_tsv(evidence, "post-task-keep-files.tsv")
    _, restored = read_tsv(evidence, "restored-task-files.tsv")
    if len(active) != 2243 or len(candidates) != 39094 or len(keeps) != 2075 or len(restored) != 73:
        fail("manifest row count mismatch")
    journal_entries = verify_journal(journal_path, active)

    accepted_rows, accepted_body, accepted_digest = accepted_untracked(repo, nested)
    if len(accepted_rows) != args.accepted_untracked_count or accepted_digest != args.accepted_untracked_digest:
        fail("accepted untracked identity mismatch")

    restored_bytes = 0
    for row in candidates:
        verify_object(repo, row)
        restored_bytes += int(row["size"])
        if os.path.lexists(os.path.join(backup, row["path"])):
            fail("candidate remains in backup: %s" % row["path"])
    for row in keeps:
        verify_object(repo, row)
    for row in restored:
        verify_object(repo, row)
        if os.path.lexists(os.path.join(backup, row["path"])):
            fail("restored task remains in backup: %s" % row["path"])

    final_rows, final_body, final_digest = accepted_untracked(repo, nested)
    if final_rows != accepted_rows or final_digest != args.accepted_untracked_digest:
        fail("accepted untracked drift during finalization")

    accepted_content = "path\tmode\tsize\tidentity_sha256\n" + final_body
    write_new(accepted_path, accepted_content)
    accepted_manifest_sha = sha_file(accepted_path)

    summary = {
        "completed_at_epoch": int(time.time()),
        "parent_head": args.expected_parent_head,
        "nested_head": args.expected_nested_head,
        "nested_safety_branch": args.safety_branch,
        "nested_safety_commit": args.safety_commit,
        "restored_entries": journal_entries,
        "restored_objects": len(candidates),
        "restored_bytes": restored_bytes,
        "keep_objects_verified": len(keeps),
        "restored_tasks_verified": len(restored),
        "journal_sha256": sha_file(journal_path),
        "accepted_untracked_count": len(final_rows),
        "accepted_untracked_identity_digest": final_digest,
        "accepted_untracked_manifest_sha256": accepted_manifest_sha,
        "parent_tracked_modifications": ["build_tools/deps/clu/common/httplib.hpp"],
        "nested_tracked_modifications": ["httplib/httplib.cc"],
        "manifest_sha256": dict(MANIFEST_HASHES),
        "rename_replayed_in_v2": False,
        "git_reset_replayed_in_v2": False,
    }
    write_new(completion_path, json.dumps(summary, indent=2, sort_keys=True) + "\n")

    post_rows, _, post_digest = accepted_untracked(repo, nested)
    if post_rows != final_rows or post_digest != final_digest:
        fail("accepted untracked drift after completion write")
    if stat.S_IMODE(os.stat(accepted_path).st_mode) != 0o600 or stat.S_IMODE(os.stat(completion_path).st_mode) != 0o600:
        fail("final evidence mode mismatch")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("rollback finalization failed: %s" % error, file=sys.stderr)
        sys.exit(1)
