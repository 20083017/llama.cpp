#!/usr/bin/env python3
"""Restore a manifest-recorded WTP184 quarantine backup with durable journaling."""
from __future__ import print_function

import argparse
import csv
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

MANIFEST_HASHES = {
    "rollback.tsv": "943f853b40839ed14c8e3ec0121a5d4bf7f73c3aa87a8c65fea2d5608be9f428",
    "move-journal.tsv": "2ee02f44149e621e240fdc9393c678f3d63f755a3da20242d49b3b8bea05b801",
    "task-restoration-journal.tsv": "7b42155d44fef2436428351cc4ff426e2c33709c51c2a5ef2749fb0370843c90",
    "restored-task-files.tsv": "264b1c005620389858e83d10ff92bdad236884cff3d11c17938607269b5205a5",
    "post-task-active-rollback.tsv": "5168796173ffef033b4fcdb2a5fe57a10e94df7a923bebd09ca8752985dbcab7",
    "post-task-candidate-files.tsv": "fe3b7cf31a7cdadb6b4590969c2c83987849ed686e009d75c53d0414254d38fc",
    "post-task-keep-files.tsv": "03ccf29f00fd6391088e108864ad4a70c4cad3516d6a9285d7808dde16279ef6",
}
JOURNAL_NAME = "rollback-restoration-journal.tsv"
COMPLETION_NAME = "rollback-restoration-completion.json"
UNTRACKED = {
    "audit_clu_source_binary_py36.sh": "cf25190f26bef8bea5699780878cc4104750f3b51f339843d141e07884e2bb99",
    "audit_cu_server_dialogue_api_binaries.sh": "21c43a2be88336bc64a8055b55e27c5e3db1d7b8d0aff46fe12444b6b6449372",
    "diff_clu_trees.sh": "25ffb8bd7dcb04afeb11f425de8a58095e7141bfeb9f7ddc4b558e94cbf544b7",
    "fast_clu_drift_audit.sh": "95776979ffbf0cd848e2774d9856e08e0db1339478efc583d5e285d859a076cb",
}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--backup-root", required=True)
    parser.add_argument("--expected-parent-head", required=True)
    parser.add_argument("--expected-nested-head", required=True)
    parser.add_argument("--expected-parent-branch", required=True)
    parser.add_argument("--expected-nested-branch", required=True)
    parser.add_argument("--safety-branch", required=True)
    parser.add_argument("--safety-commit", required=True)
    return parser.parse_args()


def fail(message):
    raise RuntimeError(message)


def git(repo, *args):
    env = dict(os.environ)
    env["LC_ALL"] = "C"
    env["GIT_OPTIONAL_LOCKS"] = "0"
    command = ["git", "-c", "core.fsmonitor=false", "-c", "core.hooksPath=/dev/null", "-C", repo]
    return subprocess.check_output(command + list(args), env=env)


def sha_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha_link(path):
    return hashlib.sha256(os.readlink(path).encode("utf-8", "surrogateescape")).hexdigest()


def read_tsv(evidence, name):
    with open(os.path.join(evidence, name), encoding="utf-8", errors="strict") as stream:
        header = stream.readline().rstrip("\n").split("\t")
        rows = []
        for raw in stream:
            if not raw.strip():
                continue
            values = raw.rstrip("\n").split("\t")
            if len(values) != len(header):
                fail("invalid TSV row in %s" % name)
            rows.append(dict(zip(header, values)))
    return header, rows


def validate_relative(path):
    if not path or os.path.isabs(path) or "\x00" in path:
        fail("unsafe relative path: %r" % path)
    if os.path.normpath(path) != path or path == ".." or path.startswith("../"):
        fail("unsafe normalized path: %r" % path)


def verify_object(root, row):
    path = os.path.join(root, row["path"])
    if not os.path.lexists(path):
        fail("missing object: %s" % path)
    observed = os.lstat(path)
    kind = row["type"]
    if kind == "file":
        if not stat.S_ISREG(observed.st_mode):
            fail("type mismatch: %s" % path)
        if observed.st_size != int(row["size"]):
            fail("size mismatch: %s" % path)
        identity = sha_file(path)
    elif kind == "symlink":
        if not stat.S_ISLNK(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = sha_link(path)
    elif kind == "dir":
        if not stat.S_ISDIR(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = "-"
    else:
        fail("unknown type %s for %s" % (kind, path))
    if stat.S_IMODE(observed.st_mode) != int(row["mode"], 8):
        fail("mode mismatch: %s" % path)
    if identity != row["identity_sha256"]:
        fail("identity mismatch: %s" % path)


def safe_parent(root, relative):
    root_real = os.path.realpath(root)
    parent = os.path.dirname(os.path.join(root, relative)) or root
    os.makedirs(parent, mode=0o755, exist_ok=True)
    parent_real = os.path.realpath(parent)
    if parent_real != root_real and not parent_real.startswith(root_real + os.sep):
        fail("parent escapes root: %s" % relative)
    return parent


def fsync_directory(path):
    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY
    descriptor = os.open(path, flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def append_sync(descriptor, line):
    data = line.encode("utf-8", "surrogateescape")
    offset = 0
    while offset < len(data):
        offset += os.write(descriptor, data[offset:])
    os.fsync(descriptor)


def write_new(path, content, mode=0o600):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        data = content.encode("utf-8", "surrogateescape")
        offset = 0
        while offset < len(data):
            offset += os.write(descriptor, data[offset:])
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    fsync_directory(os.path.dirname(path))


def journal_state(path):
    if not os.path.exists(path):
        return {}, False
    states = {}
    with open(path, encoding="utf-8", errors="strict") as stream:
        header = stream.readline().rstrip("\n")
        if header != "state\tbackup_relative\tworkspace_relative\ttype":
            fail("unexpected journal header")
        for raw in stream:
            values = raw.rstrip("\n").split("\t")
            if len(values) != 4 or values[0] not in ("INTENT", "DONE"):
                fail("invalid journal row")
            state, source, destination, kind = values
            key = (source, destination, kind)
            sequence = states.setdefault(key, [])
            sequence.append(state)
            if sequence not in (["INTENT"], ["INTENT", "DONE"]):
                fail("invalid journal state sequence: %r" % (key,))
    return states, True


def status_pairs(repo):
    raw = git(repo, "diff", "--no-ext-diff", "--ignore-submodules=all", "--name-status", "-z")
    parts = [item.decode("utf-8", "surrogateescape") for item in raw.split(b"\0") if item]
    if len(parts) % 2:
        fail("invalid Git name-status encoding")
    return [(parts[index], parts[index + 1]) for index in range(0, len(parts), 2)]


def main():
    args = parse_args()
    repo = os.path.realpath(args.repo)
    nested = os.path.join(repo, "third_party")
    backup = os.path.realpath(args.backup_root)
    evidence = os.path.join(backup, ".wtp184-manifest")
    journal_path = os.path.join(evidence, JOURNAL_NAME)
    completion_path = os.path.join(evidence, COMPLETION_NAME)

    if os.path.lexists(completion_path):
        fail("rollback completion already exists")
    for name, expected in MANIFEST_HASHES.items():
        if sha_file(os.path.join(evidence, name)) != expected:
            fail("manifest hash mismatch: %s" % name)
    if os.stat(repo).st_dev != os.stat(backup).st_dev:
        fail("workspace and backup are on different filesystems")

    if git(repo, "rev-parse", "HEAD").decode().strip() != args.expected_parent_head:
        fail("parent HEAD mismatch")
    if git(repo, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip() != args.expected_parent_branch:
        fail("parent branch mismatch")
    if git(nested, "rev-parse", "HEAD").decode().strip() != args.expected_nested_head:
        fail("nested HEAD mismatch")
    if git(nested, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip() != args.expected_nested_branch:
        fail("nested branch mismatch")
    safety_ref = "refs/heads/" + args.safety_branch
    if git(nested, "rev-parse", safety_ref).decode().strip() != args.safety_commit:
        fail("safety branch mismatch")
    if git(repo, "diff", "--cached", "--name-only").strip() or git(nested, "diff", "--cached", "--name-only").strip():
        fail("Git index is not empty")

    _, active = read_tsv(evidence, "post-task-active-rollback.tsv")
    _, candidates = read_tsv(evidence, "post-task-candidate-files.tsv")
    _, keeps = read_tsv(evidence, "post-task-keep-files.tsv")
    _, restored = read_tsv(evidence, "restored-task-files.tsv")
    if len(active) != 2243 or len(candidates) != 39094 or len(keeps) != 2075 or len(restored) != 73:
        fail("manifest row count mismatch")

    states, journal_exists = journal_state(journal_path)
    expected_keys = set(
        (row["backup_relative"], row["workspace_relative"], row["type"])
        for row in active
    )
    if not set(states).issubset(expected_keys):
        fail("journal contains out-of-manifest entry")

    parent_candidate = set(row["path"] for row in candidates if not row["path"].startswith("third_party/"))
    nested_candidate = set(
        row["path"][len("third_party/") :]
        for row in candidates
        if row["path"].startswith("third_party/")
    )
    parent_pairs = status_pairs(repo)
    nested_pairs = status_pairs(nested)
    parent_deleted = set(path for code, path in parent_pairs if code == "D")
    nested_deleted = set(path for code, path in nested_pairs if code == "D")
    if not parent_deleted.issubset(parent_candidate):
        fail("unexpected parent deletion before/resume restore")
    if not nested_deleted.issubset(nested_candidate):
        fail("unexpected nested deletion before/resume restore")
    if not journal_exists and parent_deleted != parent_candidate:
        fail("parent deletion set mismatch before restore")
    if not journal_exists and nested_deleted != nested_candidate:
        fail("nested deletion set mismatch before restore")
    if set(path for code, path in parent_pairs if code == "M") != {"build_tools/deps/clu/common/httplib.hpp"}:
        fail("parent modification set mismatch before/resume restore")
    if set(path for code, path in nested_pairs if code == "M") != {"httplib/httplib.cc"}:
        fail("nested modification set mismatch before/resume restore")
    if any(code not in ("D", "M") for code, _ in parent_pairs + nested_pairs):
        fail("unexpected Git status before/resume restore")

    candidate_rows_by_owner = dict((row["workspace_relative"], []) for row in active)
    active_paths = set(candidate_rows_by_owner)
    for row in candidates:
        probe = row["path"]
        owner = None
        while True:
            if probe in active_paths:
                owner = probe
                break
            parent = os.path.dirname(probe)
            if not parent or parent == probe:
                break
            probe = parent
        if owner is None:
            fail("candidate lacks active owner: %s" % row["path"])
        candidate_rows_by_owner[owner].append(row)

    if journal_exists:
        if stat.S_IMODE(os.stat(journal_path).st_mode) != 0o600:
            fail("journal mode mismatch")
        journal_fd = os.open(journal_path, os.O_WRONLY | os.O_APPEND)
    else:
        journal_fd = os.open(journal_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        append_sync(journal_fd, "state\tbackup_relative\tworkspace_relative\ttype\n")
        fsync_directory(evidence)

    completed = 0
    resumed_intent = 0
    try:
        for row in active:
            source_rel = row["backup_relative"]
            destination_rel = row["workspace_relative"]
            kind = row["type"]
            validate_relative(source_rel)
            validate_relative(destination_rel)
            key = (source_rel, destination_rel, kind)
            sequence = states.get(key, [])
            source = os.path.join(backup, source_rel)
            destination = os.path.join(repo, destination_rel)
            source_exists = os.path.lexists(source)
            destination_exists = os.path.lexists(destination)

            if sequence == ["INTENT", "DONE"]:
                if source_exists or not destination_exists:
                    fail("DONE journal/filesystem mismatch: %s" % source_rel)
                for candidate in candidate_rows_by_owner[destination_rel]:
                    verify_object(repo, candidate)
                completed += 1
                continue

            if sequence == ["INTENT"]:
                resumed_intent += 1
                if source_exists and not destination_exists:
                    pass
                elif not source_exists and destination_exists:
                    for candidate in candidate_rows_by_owner[destination_rel]:
                        verify_object(repo, candidate)
                    append_sync(journal_fd, "DONE\t%s\t%s\t%s\n" % key)
                    completed += 1
                    continue
                else:
                    fail("ambiguous INTENT state: %s" % source_rel)
            elif sequence:
                fail("unexpected journal sequence: %s" % source_rel)
            else:
                if not source_exists or destination_exists:
                    fail("pending source/destination mismatch: %s" % source_rel)
                append_sync(journal_fd, "INTENT\t%s\t%s\t%s\n" % key)

            source_parent = os.path.dirname(source) or backup
            destination_parent = safe_parent(repo, destination_rel)
            os.rename(source, destination)
            fsync_directory(source_parent)
            if os.path.realpath(destination_parent) != os.path.realpath(source_parent):
                fsync_directory(destination_parent)
            append_sync(journal_fd, "DONE\t%s\t%s\t%s\n" % key)
            completed += 1
    finally:
        os.close(journal_fd)

    if completed != len(active):
        fail("incomplete rollback entry count: %d" % completed)

    candidate_bytes = 0
    for row in candidates:
        verify_object(repo, row)
        candidate_bytes += int(row["size"])
        if os.path.lexists(os.path.join(backup, row["path"])):
            fail("candidate remains in backup: %s" % row["path"])
    for row in keeps:
        verify_object(repo, row)
    for row in restored:
        verify_object(repo, row)
        if os.path.lexists(os.path.join(backup, row["path"])):
            fail("restored task remains in backup: %s" % row["path"])

    if status_pairs(repo) != [("M", "build_tools/deps/clu/common/httplib.hpp")]:
        fail("unexpected parent tracked diff after restore: %r" % status_pairs(repo))
    if status_pairs(nested) != [("M", "httplib/httplib.cc")]:
        fail("unexpected nested tracked diff after restore: %r" % status_pairs(nested))
    if git(repo, "diff", "--cached", "--name-only").strip() or git(nested, "diff", "--cached", "--name-only").strip():
        fail("Git index residue after restore")
    if git(repo, "status", "--porcelain=v1", "--", "tasks", "build_task_libs.sh").strip():
        fail("tasks/build script status after restore")

    parent_untracked = set(
        item.decode("utf-8", "surrogateescape")
        for item in git(repo, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    )
    nested_untracked = [
        item
        for item in git(nested, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    ]
    if parent_untracked != set(UNTRACKED) or nested_untracked:
        fail("untracked set after restore is unexpected")
    for path, expected in UNTRACKED.items():
        if sha_file(os.path.join(repo, path)) != expected:
            fail("excluded untracked identity drift: %s" % path)
    for name, expected in MANIFEST_HASHES.items():
        if sha_file(os.path.join(evidence, name)) != expected:
            fail("manifest changed during restore: %s" % name)

    summary = {
        "completed_at_epoch": int(time.time()),
        "parent_head": args.expected_parent_head,
        "nested_head": args.expected_nested_head,
        "nested_safety_branch": args.safety_branch,
        "nested_safety_commit": args.safety_commit,
        "restored_entries": completed,
        "restored_objects": len(candidates),
        "restored_bytes": candidate_bytes,
        "keep_objects_verified": len(keeps),
        "restored_tasks_verified": len(restored),
        "resumed_intent_entries": resumed_intent,
        "journal_sha256": sha_file(journal_path),
        "manifest_sha256": dict(MANIFEST_HASHES),
        "parent_tracked_modifications": ["build_tools/deps/clu/common/httplib.hpp"],
        "nested_tracked_modifications": ["httplib/httplib.cc"],
        "excluded_untracked": sorted(UNTRACKED),
    }
    write_new(completion_path, json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("rollback restoration failed: %s" % error, file=sys.stderr)
        sys.exit(1)
