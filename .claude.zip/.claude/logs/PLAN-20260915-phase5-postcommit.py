#!/usr/bin/env python3
"""Validate final WTP184 nested and parent commit postconditions."""
from __future__ import print_function

import csv
import hashlib
import os
import stat
import subprocess

P = "/home/daigd/dialogue"
T = P + "/third_party"
E = "/home/daigd/backups/wtp184-cu-server-only/20260915T160434-d232778d8484/.wtp184-manifest"
PARENT_COMMIT = "8b637633b4edb5ccb11d433ed3c94e11c2aafcff"
PARENT_BASE = "d232778d84846848c44c0d2632db741172a022d6"
NESTED_COMMIT = "b607f465e12ef92c48d8d9cf061f80b7a3a8e188"
NESTED_BASE = "43bcd72f484d0b0f2b88d5f8da7f90315b6c124d"
TRAILER = "Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
UNTRACKED = {
    "audit_clu_source_binary_py36.sh": "cf25190f26bef8bea5699780878cc4104750f3b51f339843d141e07884e2bb99",
    "diff_clu_trees.sh": "25ffb8bd7dcb04afeb11f425de8a58095e7141bfeb9f7ddc4b558e94cbf544b7",
}
MANIFEST_HASHES = {
    "rollback.tsv": "943f853b40839ed14c8e3ec0121a5d4bf7f73c3aa87a8c65fea2d5608be9f428",
    "task-restoration-journal.tsv": "7b42155d44fef2436428351cc4ff426e2c33709c51c2a5ef2749fb0370843c90",
    "restored-task-files.tsv": "264b1c005620389858e83d10ff92bdad236884cff3d11c17938607269b5205a5",
    "post-task-active-rollback.tsv": "5168796173ffef033b4fcdb2a5fe57a10e94df7a923bebd09ca8752985dbcab7",
    "post-task-candidate-files.tsv": "fe3b7cf31a7cdadb6b4590969c2c83987849ed686e009d75c53d0414254d38fc",
    "post-task-keep-files.tsv": "03ccf29f00fd6391088e108864ad4a70c4cad3516d6a9285d7808dde16279ef6",
}


def fail(message):
    raise RuntimeError(message)


def git(repo, *args):
    env = dict(os.environ)
    env["LC_ALL"] = "C"
    env["GIT_OPTIONAL_LOCKS"] = "0"
    return subprocess.check_output(["git", "-C", repo] + list(args), env=env)


def sha_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def read_tsv(name):
    with open(os.path.join(E, name), encoding="utf-8", errors="strict") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def commit_name_status(repo, commit):
    raw = git(
        repo,
        "diff-tree",
        "--no-commit-id",
        "--name-status",
        "-r",
        "-z",
        commit + "^",
        commit,
    )
    parts = [item.decode("utf-8", "surrogateescape") for item in raw.split(b"\0") if item]
    if len(parts) % 2:
        fail("invalid commit name-status encoding")
    return [(parts[index], parts[index + 1]) for index in range(0, len(parts), 2)]


def main():
    if git(P, "rev-parse", "HEAD").decode("ascii").strip() != PARENT_COMMIT:
        fail("parent HEAD mismatch")
    if git(T, "rev-parse", "HEAD").decode("ascii").strip() != NESTED_COMMIT:
        fail("nested HEAD mismatch")
    if git(P, "rev-parse", "HEAD^").decode("ascii").strip() != PARENT_BASE:
        fail("parent commit parent mismatch")
    if git(T, "rev-parse", "HEAD^").decode("ascii").strip() != NESTED_BASE:
        fail("nested commit parent mismatch")
    parent_branch = git(P, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip()
    nested_branch = git(T, "symbolic-ref", "--quiet", "--short", "HEAD").decode().strip()
    if parent_branch != "fix/turn-ownership-20260914":
        fail("parent branch mismatch")
    if nested_branch != "fix/cu-server-prune-20260915":
        fail("nested branch mismatch")

    candidates = read_tsv("post-task-candidate-files.tsv")
    parent_expected = set(
        row["path"] for row in candidates if not row["path"].startswith("third_party/")
    )
    nested_expected = set(
        row["path"][len("third_party/") :]
        for row in candidates
        if row["path"].startswith("third_party/")
    )
    parent_status = commit_name_status(P, PARENT_COMMIT)
    nested_status = commit_name_status(T, NESTED_COMMIT)
    parent_deleted = set(path for code, path in parent_status if code == "D")
    nested_deleted = set(path for code, path in nested_status if code == "D")
    parent_modified = set(path for code, path in parent_status if code == "M")
    nested_modified = set(path for code, path in nested_status if code == "M")
    if parent_deleted != parent_expected or len(parent_deleted) != 417:
        fail("parent committed deletion set mismatch")
    if nested_deleted != nested_expected or len(nested_deleted) != 38677:
        fail("nested committed deletion set mismatch")
    if parent_modified != {"build_tools/deps/clu/common/httplib.hpp", "third_party"}:
        fail("parent committed modifications mismatch")
    if nested_modified != {"httplib/httplib.cc"}:
        fail("nested committed modifications mismatch")
    if len(parent_status) != 419 or len(nested_status) != 38678:
        fail("commit path counts mismatch")
    if any(code not in ("D", "M") for code, _ in parent_status + nested_status):
        fail("unexpected commit status")

    if git(P, "diff", "--name-only").strip() or git(P, "diff", "--cached", "--name-only").strip():
        fail("parent tracked/index residue")
    if git(T, "diff", "--name-only").strip() or git(T, "diff", "--cached", "--name-only").strip():
        fail("nested tracked/index residue")
    parent_untracked = set(
        item.decode("utf-8", "surrogateescape")
        for item in git(P, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    )
    nested_untracked = [
        item
        for item in git(T, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    ]
    if parent_untracked != set(UNTRACKED):
        fail("parent untracked set drift")
    if nested_untracked:
        fail("nested untracked residue")
    for path, expected in UNTRACKED.items():
        if sha_file(os.path.join(P, path)) != expected:
            fail("excluded untracked identity drift: %s" % path)

    if git(P, "status", "--porcelain=v1", "--", "tasks", "build_task_libs.sh").strip():
        fail("restored tasks/build script residue")
    if not os.path.isfile(os.path.join(P, "build_task_libs.sh")):
        fail("build_task_libs.sh missing")
    gitlink = git(P, "ls-tree", "HEAD", "third_party").decode("ascii").split()[2]
    if gitlink != NESTED_COMMIT:
        fail("committed gitlink mismatch")
    for repo, commit in ((P, PARENT_COMMIT), (T, NESTED_COMMIT)):
        body = git(repo, "show", "-s", "--format=%B", commit).decode("utf-8", "replace")
        if TRAILER not in body:
            fail("required commit trailer missing: %s" % commit)

    for name, expected in MANIFEST_HASHES.items():
        if sha_file(os.path.join(E, name)) != expected:
            fail("manifest hash drift: %s" % name)
    if stat.S_IMODE(os.stat(os.path.dirname(E)).st_mode) != 0o700:
        fail("backup root mode drift")
    if stat.S_IMODE(os.stat(E).st_mode) != 0o700:
        fail("evidence directory mode drift")
    for required in ("task-restoration-completion.json", "completion.json"):
        if not os.path.isfile(os.path.join(E, required)):
            fail("missing completion evidence: %s" % required)

    backup_present = 0
    workspace_absent = 0
    for row in candidates:
        if os.path.lexists(os.path.join(os.path.dirname(E), row["path"])):
            backup_present += 1
        if not os.path.lexists(os.path.join(P, row["path"])):
            workspace_absent += 1
    if backup_present != len(candidates) or workspace_absent != len(candidates):
        fail("candidate location postcondition mismatch")

    print("POSTCOMMIT_OK=1")
    print("parent_branch=%s" % parent_branch)
    print("parent_commit=%s" % PARENT_COMMIT)
    print("parent_paths=%d" % len(parent_status))
    print("parent_deletions=%d" % len(parent_deleted))
    print("nested_branch=%s" % nested_branch)
    print("nested_commit=%s" % NESTED_COMMIT)
    print("nested_paths=%d" % len(nested_status))
    print("nested_deletions=%d" % len(nested_deleted))
    print("gitlink=%s" % gitlink)
    print("parent_tracked_residue=0")
    print("nested_tracked_residue=0")
    print("parent_staged=0")
    print("nested_staged=0")
    print("parent_untracked_excluded=2")
    print("nested_untracked=0")
    print("tasks_clean=1")
    print("candidate_backup_present=%d" % backup_present)
    print("candidate_workspace_absent=%d" % workspace_absent)
    print("manifest_hashes_verified=%d" % len(MANIFEST_HASHES))
    print("required_trailers=2")
    print("push_performed=NO")


if __name__ == "__main__":
    main()
