# Sanitized retained invocation envelope

- Plan: `PLAN-20260915-run-debug-build` version `1`
- Evidence source: the retained `functions.Bash` tool invocation in this active Claude Code session, submitted after the plan entered `IN_PROGRESS` and before the build log was created.
- Operation count: one real build invocation.
- Build-host role: authoritative Ubuntu build host `10.1.120.40` through the configured strict WTP184 SSH contract.
- Authentication detail handling: identity and known-hosts paths are intentionally omitted; the retained tool call supplied them through the configured session contract with batch authentication, strict host-key checking, forwarding disabled and no password fallback.
- Local execution bound: `/usr/bin/timeout 7200 /usr/bin/ssh ...`
- Remote execution bound: `/usr/bin/timeout 7000`

## Exact sanitized remote command payload

```bash
set -euo pipefail
p=/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh
test "$(sha256sum "$p" | cut -d" " -f1)" = e6689fb5979bae3de2d39dde8f7694cc7dc0c269e7cfd17f5c9b519973d8aa70
test "$(git -C /home/daigd/dialogue status --porcelain=v1 | wc -l)" -eq 0
exec /usr/bin/timeout 7000 env \
  PROJECT_DIR=/home/daigd/dialogue \
  THIRD_PARTY_DIR=/home/daigd/dialogue/third_party \
  /bin/bash --noprofile --norc \
  "$p" debug_build
```

## Criterion-1 assertions directly visible in the retained payload

- Explicit authoritative project assignment: `PROJECT_DIR=/home/daigd/dialogue`.
- Explicit authoritative third-party assignment: `THIRD_PARTY_DIR=/home/daigd/dialogue/third_party`.
- Canonical pipeline path: `/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh`.
- Final action argv: exactly `debug_build`.
- `--dry-run`: absent.
- `--clean`: absent.
- Alternate workspace: absent.
- Sync/deploy/all/debug_all action: absent.

## Correlated result

- Pipeline start: `2026-09-15 11:03:06`.
- Pipeline success: `2026-09-15 11:04:27`.
- Result record: `.claude/logs/PLAN-20260915-run-debug-build-build.result` reports `command=debug_build`, `exit=0`, and the bounded full-log path.
- Full build log: `.claude/logs/PLAN-20260915-run-debug-build-build.log` contains one `COMMAND START`, one `command=debug_build`, and one `COMMAND SUCCESS: debug_build` for this invocation.
- No second build invocation was submitted under this plan.
