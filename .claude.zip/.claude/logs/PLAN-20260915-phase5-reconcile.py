#!/usr/bin/env python3
"""Read-only Phase 5 reconciliation for the authoritative WTP184 workspace."""
from __future__ import print_function

import hashlib
import os
import stat
import subprocess

P = "/home/daigd/dialogue"
T = P + "/third_party"
E = "/home/daigd/backups/wtp184-cu-server-only/20260915T160434-d232778d8484/.wtp184-manifest"
BACKUP = os.path.dirname(E)
EXPECTED_PARENT = "d232778d84846848c44c0d2632db741172a022d6"
EXPECTED_NESTED = "43bcd72f484d0b0f2b88d5f8da7f90315b6c124d"
EXPECTED_HASHES = {
    "rollback.tsv": "943f853b40839ed14c8e3ec0121a5d4bf7f73c3aa87a8c65fea2d5608be9f428",
    "task-restoration-journal.tsv": "7b42155d44fef2436428351cc4ff426e2c33709c51c2a5ef2749fb0370843c90",
    "restored-task-files.tsv": "264b1c005620389858e83d10ff92bdad236884cff3d11c17938607269b5205a5",
    "post-task-active-rollback.tsv": "5168796173ffef033b4fcdb2a5fe57a10e94df7a923bebd09ca8752985dbcab7",
}
EXPECTED_UNTRACKED = {
    "audit_clu_source_binary_py36.sh": "cf25190f26bef8bea5699780878cc4104750f3b51f339843d141e07884e2bb99",
    "diff_clu_trees.sh": "25ffb8bd7dcb04afeb11f425de8a58095e7141bfeb9f7ddc4b558e94cbf544b7",
}


def fail(message):
    raise RuntimeError(message)


def git(repo, *args):
    env = dict(os.environ)
    env["LC_ALL"] = "C"
    env["GIT_OPTIONAL_LOCKS"] = "0"
    command = [
        "git",
        "-c",
        "core.fsmonitor=false",
        "-c",
        "core.hooksPath=/dev/null",
        "-C",
        repo,
    ] + list(args)
    return subprocess.check_output(command, env=env)


def sha_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha_link(path):
    target = os.readlink(path).encode("utf-8", "surrogateescape")
    return hashlib.sha256(target).hexdigest()


def read_tsv(name):
    path = os.path.join(E, name)
    with open(path, encoding="utf-8", errors="strict") as stream:
        header = stream.readline().rstrip("\n").split("\t")
        rows = []
        for raw in stream:
            if not raw.strip():
                continue
            values = raw.rstrip("\n").split("\t")
            if len(values) != len(header):
                fail("invalid TSV row in %s" % name)
            rows.append(dict(zip(header, values)))
    return header, rows


def verify_object(root, row):
    path = os.path.join(root, row["path"])
    if not os.path.lexists(path):
        fail("missing object: %s" % path)
    observed = os.lstat(path)
    kind = row["type"]
    if kind == "file":
        if not stat.S_ISREG(observed.st_mode):
            fail("type mismatch: %s" % path)
        if observed.st_size != int(row["size"]):
            fail("size mismatch: %s" % path)
        identity = sha_file(path)
    elif kind == "symlink":
        if not stat.S_ISLNK(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = sha_link(path)
    elif kind == "dir":
        if not stat.S_ISDIR(observed.st_mode):
            fail("type mismatch: %s" % path)
        identity = "-"
    else:
        fail("unknown object type %s for %s" % (kind, path))
    if stat.S_IMODE(observed.st_mode) != int(row["mode"], 8):
        fail("mode mismatch: %s" % path)
    if identity != row["identity_sha256"]:
        fail("identity mismatch: %s" % path)


def name_status(repo):
    raw = git(
        repo,
        "diff",
        "--no-ext-diff",
        "--ignore-submodules=all",
        "--name-status",
        "-z",
    )
    parts = [
        item.decode("utf-8", "surrogateescape")
        for item in raw.split(b"\0")
        if item
    ]
    if len(parts) % 2:
        fail("unexpected name-status encoding in %s" % repo)
    return [(parts[index], parts[index + 1]) for index in range(0, len(parts), 2)]


def main():
    for name, expected in EXPECTED_HASHES.items():
        path = os.path.join(E, name)
        if not os.path.isfile(path):
            fail("missing evidence file: %s" % name)
        observed = sha_file(path)
        if observed != expected:
            fail("evidence hash drift %s: %s" % (name, observed))
    for required in (
        "task-restoration-completion.json",
        "post-task-candidate-files.tsv",
        "post-task-keep-files.tsv",
    ):
        if not os.path.isfile(os.path.join(E, required)):
            fail("missing evidence file: %s" % required)

    parent_head = git(P, "rev-parse", "HEAD").decode("ascii").strip()
    nested_head = git(T, "rev-parse", "HEAD").decode("ascii").strip()
    branch = git(P, "rev-parse", "--abbrev-ref", "HEAD").decode("utf-8").strip()
    if parent_head != EXPECTED_PARENT:
        fail("parent revision drift: %s" % parent_head)
    if nested_head != EXPECTED_NESTED:
        fail("nested revision drift: %s" % nested_head)
    if branch in ("master", "main"):
        fail("refusing commit preparation on default branch: %s" % branch)
    parent_gitlink = git(P, "ls-tree", "HEAD", "third_party").decode("ascii").split()[2]
    if parent_gitlink != EXPECTED_NESTED:
        fail("parent gitlink drift: %s" % parent_gitlink)

    if git(P, "diff", "--cached", "--name-only", "-z").strip(b"\0"):
        fail("parent index is not empty")
    if git(T, "diff", "--cached", "--name-only", "-z").strip(b"\0"):
        fail("nested index is not empty")
    parent_untracked = [
        item
        for item in git(P, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    ]
    nested_untracked = [
        item
        for item in git(T, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
        if item
    ]
    parent_untracked_paths = set(
        item.decode("utf-8", "surrogateescape") for item in parent_untracked
    )
    if parent_untracked_paths != set(EXPECTED_UNTRACKED):
        fail("unexpected parent untracked paths: %r" % sorted(parent_untracked_paths))
    for path, expected in EXPECTED_UNTRACKED.items():
        observed = sha_file(os.path.join(P, path))
        if observed != expected:
            fail("excluded untracked identity drift %s: %s" % (path, observed))
    if nested_untracked:
        fail("nested has %d untracked paths" % len(nested_untracked))

    _, candidates = read_tsv("post-task-candidate-files.tsv")
    _, keeps = read_tsv("post-task-keep-files.tsv")
    restored_header, restored = read_tsv("restored-task-files.tsv")
    original_header, original_candidates = read_tsv(
        os.path.join("phase1", "candidate-files.tsv")
    )
    rollback_header, rollback = read_tsv("rollback.tsv")
    active_header, active_rollback = read_tsv("post-task-active-rollback.tsv")
    if len(candidates) != 39094:
        fail("candidate count drift: %d" % len(candidates))
    if len(keeps) != 2075:
        fail("keep count drift: %d" % len(keeps))
    if len(restored) != 73:
        fail("restored count drift: %d" % len(restored))
    if len(active_rollback) != 2243:
        fail("active rollback count drift: %d" % len(active_rollback))

    parent_candidate = set(
        row["path"] for row in candidates if not row["path"].startswith("third_party/")
    )
    nested_candidate = set(
        row["path"][len("third_party/") :]
        for row in candidates
        if row["path"].startswith("third_party/")
    )
    if len(parent_candidate) != 417:
        fail("parent candidate split drift: %d" % len(parent_candidate))
    if len(nested_candidate) != 38677:
        fail("nested candidate split drift: %d" % len(nested_candidate))

    parent_ns = name_status(P)
    nested_ns = name_status(T)
    parent_deleted = set(path for status_code, path in parent_ns if status_code == "D")
    nested_deleted = set(path for status_code, path in nested_ns if status_code == "D")
    parent_modified = set(path for status_code, path in parent_ns if status_code == "M")
    nested_modified = set(path for status_code, path in nested_ns if status_code == "M")
    parent_other = [(code, path) for code, path in parent_ns if code not in ("D", "M")]
    nested_other = [(code, path) for code, path in nested_ns if code not in ("D", "M")]
    if parent_deleted != parent_candidate:
        fail(
            "parent deletion mismatch missing=%d extra=%d"
            % (len(parent_candidate - parent_deleted), len(parent_deleted - parent_candidate))
        )
    if nested_deleted != nested_candidate:
        fail(
            "nested deletion mismatch missing=%d extra=%d"
            % (len(nested_candidate - nested_deleted), len(nested_deleted - nested_candidate))
        )
    if parent_modified != {"build_tools/deps/clu/common/httplib.hpp"}:
        fail("unexpected parent modifications: %r" % sorted(parent_modified))
    if nested_modified != {"httplib/httplib.cc"}:
        fail("unexpected nested modifications: %r" % sorted(nested_modified))
    if parent_other or nested_other:
        fail("unexpected name status parent=%r nested=%r" % (parent_other, nested_other))

    parent_numstat = git(
        P,
        "diff",
        "--no-ext-diff",
        "--numstat",
        "--",
        "build_tools/deps/clu/common/httplib.hpp",
    ).decode("utf-8").strip()
    nested_numstat = git(
        T,
        "diff",
        "--no-ext-diff",
        "--numstat",
        "--",
        "httplib/httplib.cc",
    ).decode("utf-8").strip()
    if parent_numstat != "1\t1\tbuild_tools/deps/clu/common/httplib.hpp":
        fail("parent httplib hunk drift: %r" % parent_numstat)
    if nested_numstat != "1\t1\thttplib/httplib.cc":
        fail("nested httplib hunk drift: %r" % nested_numstat)
    parent_diff = git(
        P,
        "diff",
        "--no-ext-diff",
        "--unified=0",
        "--",
        "build_tools/deps/clu/common/httplib.hpp",
    ).decode("utf-8", "replace")
    nested_diff = git(
        T,
        "diff",
        "--no-ext-diff",
        "--unified=0",
        "--",
        "httplib/httplib.cc",
    ).decode("utf-8", "replace")
    for text, label in ((parent_diff, "parent"), (nested_diff, "nested")):
        if "[&max_workers]" not in text or "[max_workers]" not in text:
            fail("%s capture lines missing" % label)
        changed = [
            line
            for line in text.splitlines()
            if (line.startswith("+") or line.startswith("-"))
            and not line.startswith("+++")
            and not line.startswith("---")
        ]
        if len(changed) != 2:
            fail("%s httplib has %d changed lines" % (label, len(changed)))
        normalized = [line.replace("&max_workers", "max_workers") for line in changed]
        if normalized[0][1:] != normalized[1][1:]:
            fail("%s httplib change is not ampersand-only" % label)

    for row in candidates:
        if os.path.lexists(os.path.join(P, row["path"])):
            fail("candidate unexpectedly active: %s" % row["path"])
        verify_object(BACKUP, row)
    for row in keeps:
        verify_object(P, row)

    original_tasks = sorted(
        (row for row in original_candidates if row["path"].startswith("tasks/")),
        key=lambda row: row["path"],
    )
    restored_sorted = sorted(restored, key=lambda row: row["path"])
    if original_header != restored_header or original_tasks != restored_sorted:
        fail("restored-task rows differ from original task candidate rows")
    for row in restored:
        verify_object(P, row)
        if os.path.lexists(os.path.join(BACKUP, row["path"])):
            fail("restored task remains in backup: %s" % row["path"])
    expected_active = [
        row for row in rollback if not row["workspace_relative"].startswith("tasks/")
    ]
    if active_header != rollback_header or active_rollback != expected_active:
        fail("active rollback is not original minus task rows")
    if not os.path.isfile(os.path.join(P, "build_task_libs.sh")):
        fail("build_task_libs.sh missing")
    if git(P, "status", "--porcelain=v1", "--", "tasks", "build_task_libs.sh").strip():
        fail("tasks/build_task_libs are dirty")

    parent_status = git(P, "status", "--porcelain=v1", "--untracked-files=all").decode(
        "utf-8", "replace"
    ).splitlines()
    nested_status = git(T, "status", "--porcelain=v1", "--untracked-files=all").decode(
        "utf-8", "replace"
    ).splitlines()
    print("RECONCILIATION_OK=1")
    print("parent_head=%s" % parent_head)
    print("parent_branch=%s" % branch)
    print("nested_head=%s" % nested_head)
    print("parent_candidate_deletions=%d" % len(parent_candidate))
    print("nested_candidate_deletions=%d" % len(nested_candidate))
    print("parent_modified=%s" % ",".join(sorted(parent_modified)))
    print("nested_modified=%s" % ",".join(sorted(nested_modified)))
    print("parent_status_entries=%d" % len(parent_status))
    print("nested_status_entries=%d" % len(nested_status))
    print("parent_staged=0")
    print("nested_staged=0")
    print("parent_untracked_excluded=%d" % len(parent_untracked))
    print("parent_untracked_excluded_paths=%s" % ",".join(sorted(EXPECTED_UNTRACKED)))
    print("nested_untracked=0")
    print("candidate_objects_verified=%d" % len(candidates))
    print("keep_objects_verified=%d" % len(keeps))
    print("restored_tasks_verified=%d" % len(restored))
    print("active_rollback_verified=%d" % len(active_rollback))
    print(
        "post_task_candidate_sha256=%s"
        % sha_file(os.path.join(E, "post-task-candidate-files.tsv"))
    )
    print(
        "post_task_keep_sha256=%s"
        % sha_file(os.path.join(E, "post-task-keep-files.tsv"))
    )
    print("httplib_hunks=AMPERSAND_ONLY")


if __name__ == "__main__":
    main()
