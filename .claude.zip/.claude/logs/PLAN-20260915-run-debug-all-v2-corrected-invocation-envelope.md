# Corrected sanitized invocation envelope

- Plan: `PLAN-20260915-run-debug-all` version `2`
- Approval evidence: user message `approve PLAN-20260915-run-debug-all version 2` received on `2026-09-15T13:22:34+08:00`.
- Correction reason: the initial SSH wrapper exited before pipeline start because an extra, non-plan clean-status assertion rejected the pre-existing nested modification `third_party/httplib/httplib.cc`. Pipeline SHA and authoritative revisions were read-only verified. No build/package action ran in the failed wrapper.
- Operation count: this corrected call is the one real canonical `debug_build` invocation authorized by the plan.
- Build-host role: authoritative Ubuntu build host through the configured strict WTP184 SSH contract.
- Authentication details: identity and known-hosts paths intentionally omitted; the existing session configuration supplies strict host-key checking, batch public-key authentication, disabled forwarding and no password fallback.
- Local execution bound: `/usr/bin/timeout 7200 /usr/bin/ssh ...`.
- Remote execution bound: `/usr/bin/timeout 7000`.

## Exact sanitized remote payload

```bash
set -euo pipefail
p=/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh
test "$(sha256sum "$p" | cut -d" " -f1)" = e6689fb5979bae3de2d39dde8f7694cc7dc0c269e7cfd17f5c9b519973d8aa70
test "$(git -C /home/daigd/dialogue rev-parse HEAD)" = d232778d84846848c44c0d2632db741172a022d6
test "$(git -C /home/daigd/dialogue/third_party rev-parse HEAD)" = 43bcd72f484d0b0f2b88d5f8da7f90315b6c124d
exec /usr/bin/timeout 7000 env \
  PROJECT_DIR=/home/daigd/dialogue \
  THIRD_PARTY_DIR=/home/daigd/dialogue/third_party \
  /bin/bash --noprofile --norc \
  "$p" debug_build
```

## Scope assertions

- Final pipeline action is exactly `debug_build`.
- Explicit authoritative project and third-party paths are supplied.
- `--dry-run`, `--clean`, alternate workspace, sync, deploy, `all`, and `debug_all` are absent.
- The pre-existing third-party edit is not modified or claimed by this operation.
- This record does not claim success; correlate it with the retained result and build log.
