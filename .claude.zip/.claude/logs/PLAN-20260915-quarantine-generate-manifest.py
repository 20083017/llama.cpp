#!/usr/bin/env python3
"""Generate a conservative, reversible //cu:server workspace quarantine manifest."""

from __future__ import print_function

import argparse
import collections
import datetime
import hashlib
import json
import os
import re
import stat
import subprocess
import sys


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--manifest-root", required=True)
    parser.add_argument("--debug-aquery", required=True)
    parser.add_argument("--release-aquery", required=True)
    parser.add_argument("--debug-cquery", required=True)
    parser.add_argument("--release-cquery", required=True)
    parser.add_argument("--backup-parent", required=True)
    return parser.parse_args()


def run_bytes(argv):
    return subprocess.check_output(argv)


def decode_z_paths(data):
    return [item.decode("utf-8", "surrogateescape") for item in data.split(b"\0") if item]


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(value):
    return hashlib.sha256(value.encode("utf-8", "surrogateescape")).hexdigest()


def write_text(path, content):
    if os.path.exists(path):
        raise RuntimeError("refusing to overwrite manifest output: " + path)
    temporary = path + ".tmp.%d" % os.getpid()
    with open(temporary, "w", encoding="utf-8") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def parse_textproto_blocks(path, section):
    blocks = []
    current = None
    depth = 0
    with open(path, encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            line = raw.rstrip("\n")
            if current is None:
                if line == section + " {":
                    current = [line]
                    depth = 1
                continue
            current.append(line)
            depth += line.count("{") - line.count("}")
            if depth == 0:
                blocks.append(current)
                current = None
    if current is not None:
        raise RuntimeError("unterminated %s block in %s" % (section, path))
    return blocks


def field_values(block, key):
    expression = re.compile(r'^\s*' + re.escape(key) + r': "(.*)"$')
    values = []
    for line in block:
        match = expression.match(line)
        if match:
            values.append(match.group(1))
    return values


def parse_aquery(path):
    artifacts = {}
    for block in parse_textproto_blocks(path, "artifacts"):
        identifiers = field_values(block, "id")
        paths = field_values(block, "exec_path")
        if len(identifiers) == 1 and len(paths) == 1:
            artifacts[identifiers[0]] = paths[0]

    dep_sets = {}
    for block in parse_textproto_blocks(path, "dep_set_of_files"):
        identifiers = field_values(block, "id")
        if len(identifiers) != 1:
            continue
        dep_sets[identifiers[0]] = (
            field_values(block, "direct_artifact_ids"),
            field_values(block, "transitive_dep_set_ids"),
        )

    action_inputs = []
    action_outputs = []
    action_count = 0
    for block in parse_textproto_blocks(path, "actions"):
        action_count += 1
        action_inputs.extend(field_values(block, "input_dep_set_ids"))
        action_outputs.extend(field_values(block, "output_ids"))

    memo = {}

    def resolve(dep_set_id, active):
        if dep_set_id in memo:
            return memo[dep_set_id]
        if dep_set_id in active:
            raise RuntimeError("dep-set cycle: " + dep_set_id)
        active = set(active)
        active.add(dep_set_id)
        direct, transitive = dep_sets.get(dep_set_id, ([], []))
        result = set(direct)
        for child in transitive:
            result.update(resolve(child, active))
        memo[dep_set_id] = result
        return result

    input_ids = set()
    for dep_set_id in action_inputs:
        input_ids.update(resolve(dep_set_id, set()))
    input_paths = set(artifacts[item] for item in input_ids if item in artifacts)
    output_paths = set(artifacts[item] for item in action_outputs if item in artifacts)
    return {
        "action_count": action_count,
        "artifact_count": len(artifacts),
        "dep_set_count": len(dep_sets),
        "input_paths": input_paths,
        "output_paths": output_paths,
    }


def normalized_labels(path):
    labels = set()
    with open(path, encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            value = re.sub(r"\s+\([^()]*\)\s*$", "", raw.strip())
            if value.startswith(("//", "@")):
                labels.add(value)
    return labels


def discover_git_roots(repo):
    roots = {repo}
    for base, dirs, files in os.walk(repo, topdown=True, followlinks=False):
        if ".git" in dirs:
            roots.add(base)
            dirs.remove(".git")
        if ".git" in files:
            roots.add(base)
        dirs[:] = [name for name in dirs if name != ".git" and not os.path.islink(os.path.join(base, name))]
    return sorted(roots, key=lambda item: (item.count(os.sep), item))


def git_path_set(git_root, argv):
    try:
        return set(decode_z_paths(run_bytes(["git", "-C", git_root] + argv)))
    except subprocess.CalledProcessError as error:
        raise RuntimeError("git path query failed for %s: %s" % (git_root, error))


def relative_to_repo(repo, git_root, path):
    combined = os.path.normpath(os.path.join(git_root, path))
    relative = os.path.relpath(combined, repo)
    if relative == ".." or relative.startswith(".." + os.sep):
        raise RuntimeError("git path escapes workspace: " + combined)
    return relative.replace(os.sep, "/")


def collect_git_preservation(repo, git_roots):
    dirty = set()
    untracked = set()
    ignored = set()
    nested_rel = set(os.path.relpath(root, repo).replace(os.sep, "/") for root in git_roots if root != repo)
    for root in git_roots:
        for path in git_path_set(root, ["diff", "--name-only", "-z"]):
            rel = relative_to_repo(repo, root, path)
            if rel not in nested_rel:
                dirty.add(rel)
        for path in git_path_set(root, ["diff", "--cached", "--name-only", "-z"]):
            rel = relative_to_repo(repo, root, path)
            if rel not in nested_rel:
                dirty.add(rel)
        for path in git_path_set(root, ["ls-files", "--others", "--exclude-standard", "-z"]):
            untracked.add(relative_to_repo(repo, root, path))
        for path in git_path_set(root, ["ls-files", "--others", "--ignored", "--exclude-standard", "-z"]):
            ignored.add(relative_to_repo(repo, root, path))
    return dirty, untracked, ignored


def external_mappings(repo, execroot_link):
    mappings = {}
    external = os.path.join(execroot_link, "external")
    if not os.path.isdir(external):
        return mappings
    for name in os.listdir(external):
        physical = os.path.realpath(os.path.join(external, name))
        try:
            common = os.path.commonpath([repo, physical])
        except ValueError:
            continue
        if common == repo:
            mappings[name] = physical
    return mappings


def map_exec_path(repo, mappings, value):
    value = value.replace("\\", "/")
    if value.startswith("external/"):
        parts = value.split("/", 2)
        if len(parts) < 3 or parts[1] not in mappings:
            return None
        physical = os.path.normpath(os.path.join(mappings[parts[1]], parts[2]))
    elif os.path.isabs(value):
        physical = os.path.normpath(value)
    elif value.startswith("bazel-out/") or value.startswith("../"):
        return None
    else:
        physical = os.path.normpath(os.path.join(repo, value))
    try:
        if os.path.commonpath([repo, physical]) != repo:
            return None
    except ValueError:
        return None
    relative = os.path.relpath(physical, repo).replace(os.sep, "/")
    return relative


def makefile_dependencies(path):
    with open(path, encoding="utf-8", errors="replace") as stream:
        text = stream.read().replace("\\\n", " ")
    if ":" not in text:
        return []
    body = text.split(":", 1)[1]
    values = []
    for token in body.split():
        token = token.replace("\\ ", " ").replace("\\#", "#")
        if token:
            values.append(token)
    return values


def inventory_workspace(repo):
    objects = {}
    directories = set([""])
    git_control_dirs = set()
    for base, dirs, files in os.walk(repo, topdown=True, followlinks=False):
        relative_base = os.path.relpath(base, repo)
        if relative_base == ".":
            relative_base = ""
        relative_base = relative_base.replace(os.sep, "/")
        if ".git" in dirs:
            git_control_dirs.add(relative_base)
            dirs.remove(".git")
        if ".git" in files:
            git_control_dirs.add(relative_base)
            files.remove(".git")
        retained_dirs = []
        for name in dirs:
            path = os.path.join(base, name)
            rel = os.path.relpath(path, repo).replace(os.sep, "/")
            if os.path.islink(path):
                st = os.lstat(path)
                objects[rel] = ("symlink", st, os.readlink(path))
            else:
                directories.add(rel)
                retained_dirs.append(name)
        dirs[:] = retained_dirs
        for name in files:
            path = os.path.join(base, name)
            rel = os.path.relpath(path, repo).replace(os.sep, "/")
            st = os.lstat(path)
            if stat.S_ISLNK(st.st_mode):
                objects[rel] = ("symlink", st, os.readlink(path))
            elif stat.S_ISREG(st.st_mode):
                objects[rel] = ("file", st, None)
            else:
                objects[rel] = ("special", st, None)
    return objects, directories, git_control_dirs


def add_reason(reasons, path, reason):
    reasons[path].add(reason)


def parent_paths(path):
    result = []
    current = path
    while "/" in current:
        current = current.rsplit("/", 1)[0]
        result.append(current)
    return result


def main():
    args = parse_args()
    repo = os.path.realpath(args.repo)
    manifest_root = os.path.realpath(args.manifest_root)
    backup_parent = os.path.realpath(args.backup_parent)
    if os.path.commonpath([repo, manifest_root]) == repo:
        raise RuntimeError("manifest root must be outside workspace")
    if not os.path.isdir(manifest_root):
        raise RuntimeError("manifest root missing")
    if not os.path.isdir(backup_parent):
        raise RuntimeError("backup parent base missing")
    if os.stat(repo).st_dev != os.stat(backup_parent).st_dev:
        raise RuntimeError("workspace and prospective backup parent are on different devices")

    debug = parse_aquery(args.debug_aquery)
    release = parse_aquery(args.release_aquery)
    debug_labels = normalized_labels(args.debug_cquery)
    release_labels = normalized_labels(args.release_cquery)
    if debug_labels != release_labels:
        raise RuntimeError("debug/release normalized closures differ")

    mappings = external_mappings(repo, os.path.join(repo, "bazel-dialogue"))
    action_inputs = set()
    missing_inputs = set()
    for profile in (debug, release):
        for value in profile["input_paths"]:
            mapped = map_exec_path(repo, mappings, value)
            if mapped is None:
                continue
            physical = os.path.join(repo, mapped)
            if os.path.lexists(physical):
                action_inputs.add(mapped)
            else:
                missing_inputs.add(mapped)

    depfile_outputs = set()
    depfile_inputs = set()
    for profile in (debug, release):
        for value in profile["output_paths"]:
            if not value.endswith(".d") or not value.startswith("bazel-out/"):
                continue
            depfile = os.path.join(repo, value)
            if not os.path.isfile(depfile):
                continue
            depfile_outputs.add(value)
            for dependency in makefile_dependencies(depfile):
                mapped = map_exec_path(repo, mappings, dependency)
                if mapped is not None and os.path.lexists(os.path.join(repo, mapped)):
                    depfile_inputs.add(mapped)

    git_roots = discover_git_roots(repo)
    dirty, untracked, ignored = collect_git_preservation(repo, git_roots)
    objects, directories, git_control_dirs = inventory_workspace(repo)

    reasons = collections.defaultdict(set)
    for path in action_inputs:
        add_reason(reasons, path, "CONFIGURED_ACTION_INPUT")
    for path in depfile_inputs:
        add_reason(reasons, path, "COMPILER_DEPFILE_INPUT")
    for path in dirty:
        add_reason(reasons, path, "DIRTY_PATH")
    for path in untracked:
        add_reason(reasons, path, "UNTRACKED_UNCERTAIN")
    for path in ignored:
        add_reason(reasons, path, "IGNORED_UNCERTAIN")

    root_controls = {
        "WORKSPACE", ".bazelrc", ".gitignore", ".gitmodules", ".cu-dev-last-gcc",
        "run_server.sh", "build_task_libs.sh",
        "bazel-bin", "bazel-dialogue", "bazel-out", "bazel-testlogs",
    }
    for path in objects:
        basename = path.rsplit("/", 1)[-1]
        if path in root_controls:
            add_reason(reasons, path, "ROOT_BUILD_CONTROL")
        if basename in ("BUILD", "BUILD.bazel", "WORKSPACE", "WORKSPACE.bazel") or basename.endswith(".bzl"):
            add_reason(reasons, path, "BAZEL_LOADING_CONTROL")
        if basename in (".gitignore", ".gitattributes", ".gitmodules", ".bazelrc"):
            add_reason(reasons, path, "GIT_OR_BAZEL_CONTROL")
        if objects[path][0] == "symlink":
            add_reason(reasons, path, "SYMLINK_UNCERTAIN")
        if objects[path][0] == "special":
            add_reason(reasons, path, "SPECIAL_FILE_UNCERTAIN")

    # A directory action input is a tree artifact/source directory: keep every descendant.
    for path in list(reasons):
        physical = os.path.join(repo, path)
        if os.path.isdir(physical) and not os.path.islink(physical):
            prefix = path.rstrip("/") + "/"
            for candidate in objects:
                if candidate.startswith(prefix):
                    add_reason(reasons, candidate, "ACTION_INPUT_DIRECTORY_DESCENDANT")

    keep_files = set(path for path in objects if path in reasons)
    # If Git reports a directory, conservatively preserve its descendants unless it is a nested repo marker.
    nested_roots = set(os.path.relpath(root, repo).replace(os.sep, "/") for root in git_roots if root != repo)
    for path in dirty | untracked | ignored:
        if path in nested_roots:
            continue
        physical = os.path.join(repo, path)
        if os.path.isdir(physical) and not os.path.islink(physical):
            prefix = path.rstrip("/") + "/"
            for candidate in objects:
                if candidate.startswith(prefix):
                    keep_files.add(candidate)
                    add_reason(reasons, candidate, "UNCERTAIN_DIRECTORY_DESCENDANT")

    candidate_files = set(objects) - keep_files
    protected_dir_prefixes = set(git_control_dirs) | nested_roots
    keep_ancestors = set()
    for path in keep_files:
        keep_ancestors.update(parent_paths(path))
    for path in protected_dir_prefixes:
        keep_ancestors.add(path)
        keep_ancestors.update(parent_paths(path))

    selected_dirs = []
    selected_prefixes = []
    for directory in sorted((item for item in directories if item), key=lambda item: (item.count("/"), item)):
        if directory in keep_ancestors or directory in protected_dir_prefixes:
            continue
        if any(directory == prefix or directory.startswith(prefix + "/") for prefix in selected_prefixes):
            continue
        prefix = directory + "/"
        if any(root == directory or root.startswith(prefix) for root in protected_dir_prefixes):
            continue
        selected_dirs.append(directory)
        selected_prefixes.append(directory)

    selected_dir_set = set(selected_dirs)
    covered_candidates = set()
    for path in candidate_files:
        if any(parent in selected_dir_set for parent in parent_paths(path)):
            covered_candidates.add(path)
    selected_files = sorted(candidate_files - covered_candidates)
    move_entries = [(path, "dir") for path in selected_dirs] + [(path, objects[path][0]) for path in selected_files]
    move_entries.sort()

    for path in list(objects) + [item[0] for item in move_entries]:
        if "\n" in path or "\t" in path or path.startswith("/") or path == ".." or path.startswith("../"):
            raise RuntimeError("unsafe manifest path: %r" % path)

    candidate_rows = []
    candidate_row_by_path = {}
    total_candidate_bytes = 0
    for path in sorted(candidate_files):
        kind, st, target = objects[path]
        if kind == "file":
            identity = sha256_file(os.path.join(repo, path))
            size = st.st_size
        elif kind == "symlink":
            identity = sha256_text(target)
            size = len(target.encode("utf-8", "surrogateescape"))
        else:
            identity = "-"
            size = st.st_size
        total_candidate_bytes += size
        row = "%s\t%s\t%o\t%d\t%s\tMOVE_CANDIDATE" % (path, kind, stat.S_IMODE(st.st_mode), size, identity)
        candidate_rows.append(row)
        candidate_row_by_path[path] = row

    keep_rows = []
    for path in sorted(keep_files):
        kind, st, target = objects[path]
        if kind == "file":
            identity = sha256_file(os.path.join(repo, path))
            size = st.st_size
        elif kind == "symlink":
            identity = sha256_text(target)
            size = len(target.encode("utf-8", "surrogateescape"))
        else:
            identity = "-"
            size = st.st_size
        keep_rows.append("%s\t%s\t%o\t%d\t%s\t%s" % (path, kind, stat.S_IMODE(st.st_mode), size, identity, ",".join(sorted(reasons[path]))))

    members_by_directory = dict((directory, []) for directory in selected_dirs)
    for member in candidate_files:
        for parent in parent_paths(member):
            if parent in selected_dir_set:
                members_by_directory[parent].append(member)
                break

    entry_rows = []
    for path, kind in move_entries:
        if kind == "dir":
            members = sorted(members_by_directory[path])
        else:
            members = [path]
        aggregate = hashlib.sha256()
        entry_bytes = 0
        for member in members:
            row = candidate_row_by_path[member]
            aggregate.update((row + "\n").encode("utf-8", "surrogateescape"))
            entry_bytes += objects[member][1].st_size if objects[member][0] == "file" else 0
        entry_rows.append("%s\t%s\t%d\t%d\t%s" % (path, kind, len(members), entry_bytes, aggregate.hexdigest()))

    stamp = datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
    revision = run_bytes(["git", "-C", repo, "rev-parse", "HEAD"]).decode("ascii").strip()
    proposed_backup = os.path.join(args.backup_parent, "backups", "wtp184-cu-server-only", "%s-%s" % (stamp, revision[:12]))
    if os.path.exists(proposed_backup):
        raise RuntimeError("proposed backup already exists")

    header = "path\ttype\tmode\tsize\tidentity_sha256\treason\n"
    write_text(os.path.join(manifest_root, "keep-files.tsv"), header + "\n".join(keep_rows) + "\n")
    write_text(os.path.join(manifest_root, "candidate-files.tsv"), header + "\n".join(candidate_rows) + "\n")
    write_text(os.path.join(manifest_root, "move-entries.tsv"), "path\ttype\tmember_count\tregular_bytes\tmembers_digest\n" + "\n".join(entry_rows) + "\n")
    write_text(os.path.join(manifest_root, "action-inputs.txt"), "\n".join(sorted(action_inputs)) + "\n")
    write_text(os.path.join(manifest_root, "depfile-inputs.txt"), "\n".join(sorted(depfile_inputs)) + "\n")
    write_text(os.path.join(manifest_root, "depfile-outputs.txt"), "\n".join(sorted(depfile_outputs)) + "\n")
    write_text(os.path.join(manifest_root, "dirty-paths.txt"), "\n".join(sorted(dirty)) + "\n")
    write_text(os.path.join(manifest_root, "untracked-paths.txt"), "\n".join(sorted(untracked)) + "\n")
    write_text(os.path.join(manifest_root, "ignored-paths.txt"), "\n".join(sorted(ignored)) + "\n")
    write_text(os.path.join(manifest_root, "missing-source-inputs.txt"), "\n".join(sorted(missing_inputs)) + "\n")
    write_text(os.path.join(manifest_root, "external-mappings.tsv"), "repo\tphysical\n" + "\n".join("%s\t%s" % item for item in sorted(mappings.items())) + "\n")
    write_text(os.path.join(manifest_root, "proposed-backup.txt"), proposed_backup + "\n")

    manifest_hashes = []
    for name in ("keep-files.tsv", "candidate-files.tsv", "move-entries.tsv", "action-inputs.txt", "depfile-inputs.txt"):
        manifest_hashes.append("%s  %s" % (sha256_file(os.path.join(manifest_root, name)), name))
    write_text(os.path.join(manifest_root, "manifest-sha256.txt"), "\n".join(manifest_hashes) + "\n")

    summary = {
        "revision": revision,
        "debug_labels": len(debug_labels),
        "release_labels": len(release_labels),
        "label_sets_equal": debug_labels == release_labels,
        "debug_actions": debug["action_count"],
        "release_actions": release["action_count"],
        "action_inputs_kept": len(action_inputs),
        "depfile_inputs_kept": len(depfile_inputs),
        "depfiles_read": len(depfile_outputs),
        "workspace_objects": len(objects),
        "keep_files": len(keep_files),
        "candidate_files": len(candidate_files),
        "candidate_regular_and_symlink_bytes": total_candidate_bytes,
        "move_entries": len(move_entries),
        "move_directories": len(selected_dirs),
        "move_individual_objects": len(selected_files),
        "dirty_paths": sorted(dirty),
        "untracked_paths_count": len(untracked),
        "ignored_paths_count": len(ignored),
        "git_roots": git_roots,
        "missing_source_inputs_count": len(missing_inputs),
        "proposed_backup": proposed_backup,
        "same_device": os.stat(repo).st_dev == os.stat(backup_parent).st_dev,
    }
    write_text(os.path.join(manifest_root, "summary.json"), json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("manifest generation failed: %s" % error, file=sys.stderr)
        sys.exit(1)
