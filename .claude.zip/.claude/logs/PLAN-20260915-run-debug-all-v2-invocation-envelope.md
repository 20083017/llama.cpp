# Sanitized retained invocation envelope

- Plan: `PLAN-20260915-run-debug-all` version `2`
- Approval evidence: user message `approve PLAN-20260915-run-debug-all version 2` received on `2026-09-15T13:22:34+08:00`.
- Operation count authorized: one real canonical `debug_build` invocation.
- Build-host role: authoritative Ubuntu build host through the configured strict WTP184 SSH contract.
- Authentication details: identity and known-hosts paths intentionally omitted; they are loaded from the existing local session configuration with batch public-key authentication, strict host-key checking, all forwarding disabled and no password fallback.
- Local execution bound: `/usr/bin/timeout 7200 /usr/bin/ssh ...`
- Remote execution bound: `/usr/bin/timeout 7000`.

## Exact sanitized remote payload

```bash
set -euo pipefail
p=/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh
test "$(sha256sum "$p" | cut -d" " -f1)" = e6689fb5979bae3de2d39dde8f7694cc7dc0c269e7cfd17f5c9b519973d8aa70
test "$(git -C /home/daigd/dialogue status --porcelain=v1 | wc -l)" -eq 0
exec /usr/bin/timeout 7000 env \
  PROJECT_DIR=/home/daigd/dialogue \
  THIRD_PARTY_DIR=/home/daigd/dialogue/third_party \
  /bin/bash --noprofile --norc \
  "$p" debug_build
```

## Scope assertions

- Final pipeline action is exactly `debug_build`.
- Explicit authoritative project and third-party paths are supplied.
- `--dry-run`, `--clean`, alternate workspace, sync, deploy, `all`, and `debug_all` are absent.
- This record does not claim success; correlate it with the retained result and build log after the invocation exits.
