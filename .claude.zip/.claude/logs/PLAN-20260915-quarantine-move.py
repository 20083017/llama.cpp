#!/usr/bin/env python3
"""Execute a guarded manifest-driven workspace quarantine using same-filesystem renames."""

from __future__ import print_function

import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import time


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--manifest-root", required=True)
    parser.add_argument("--backup-root", required=True)
    parser.add_argument("--expected-revision", required=True)
    parser.add_argument("--expected-move-manifest-sha256", required=True)
    return parser.parse_args()


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(value):
    return hashlib.sha256(value.encode("utf-8", "surrogateescape")).hexdigest()


def run_text(argv):
    return subprocess.check_output(argv).decode("utf-8", "surrogateescape")


def read_tsv(path):
    rows = []
    with open(path, encoding="utf-8", errors="strict") as stream:
        header = stream.readline().rstrip("\n").split("\t")
        for raw in stream:
            if raw.strip():
                values = raw.rstrip("\n").split("\t")
                if len(values) != len(header):
                    raise RuntimeError("invalid TSV row in %s" % path)
                rows.append(dict(zip(header, values)))
    return rows


def inventory_workspace(repo):
    objects = {}
    for base, dirs, files in os.walk(repo, topdown=True, followlinks=False):
        if ".git" in dirs:
            dirs.remove(".git")
        if ".git" in files:
            files.remove(".git")
        retained = []
        for name in dirs:
            path = os.path.join(base, name)
            rel = os.path.relpath(path, repo).replace(os.sep, "/")
            if os.path.islink(path):
                objects[rel] = "symlink"
            else:
                retained.append(name)
        dirs[:] = retained
        for name in files:
            path = os.path.join(base, name)
            rel = os.path.relpath(path, repo).replace(os.sep, "/")
            mode = os.lstat(path).st_mode
            if stat.S_ISLNK(mode):
                objects[rel] = "symlink"
            elif stat.S_ISREG(mode):
                objects[rel] = "file"
            else:
                objects[rel] = "special"
    return objects


def verify_object(root, row):
    path = os.path.join(root, row["path"])
    if not os.path.lexists(path):
        raise RuntimeError("manifest object missing: " + row["path"])
    observed = os.lstat(path)
    kind = row["type"]
    if kind == "file" and not stat.S_ISREG(observed.st_mode):
        raise RuntimeError("type drift for " + row["path"])
    if kind == "symlink" and not stat.S_ISLNK(observed.st_mode):
        raise RuntimeError("type drift for " + row["path"])
    if kind == "special" and (stat.S_ISREG(observed.st_mode) or stat.S_ISLNK(observed.st_mode)):
        raise RuntimeError("type drift for " + row["path"])
    if stat.S_IMODE(observed.st_mode) != int(row["mode"], 8):
        raise RuntimeError("mode drift for " + row["path"])
    if kind == "file":
        if observed.st_size != int(row["size"]):
            raise RuntimeError("size drift for " + row["path"])
        identity = sha256_file(path)
    elif kind == "symlink":
        identity = sha256_text(os.readlink(path))
    else:
        identity = "-"
    if identity != row["identity_sha256"]:
        raise RuntimeError("identity drift for " + row["path"])


def write_new(path, content, mode=0o600):
    if os.path.lexists(path):
        raise RuntimeError("refusing overwrite: " + path)
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, mode=0o700, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        data = content.encode("utf-8", "surrogateescape")
        offset = 0
        while offset < len(data):
            offset += os.write(descriptor, data[offset:])
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def append_journal(descriptor, line):
    data = line.encode("utf-8", "surrogateescape")
    offset = 0
    while offset < len(data):
        offset += os.write(descriptor, data[offset:])
    os.fsync(descriptor)


def safe_relative(path):
    return path and not path.startswith("/") and path != ".." and not path.startswith("../") and "\n" not in path and "\t" not in path


def main():
    args = parse_args()
    repo = os.path.realpath(args.repo)
    manifest_root = os.path.realpath(args.manifest_root)
    backup_root = os.path.abspath(args.backup_root)
    if os.path.commonpath([repo, manifest_root]) == repo:
        raise RuntimeError("manifest root is inside workspace")
    if os.path.commonpath([repo, backup_root]) == repo:
        raise RuntimeError("backup root is inside workspace")
    if os.path.lexists(backup_root):
        raise RuntimeError("backup root already exists")
    if run_text(["git", "-C", repo, "rev-parse", "HEAD"]).strip() != args.expected_revision:
        raise RuntimeError("revision drift")

    move_manifest = os.path.join(manifest_root, "move-entries.tsv")
    if sha256_file(move_manifest) != args.expected_move_manifest_sha256:
        raise RuntimeError("move manifest hash mismatch")
    keep_rows = read_tsv(os.path.join(manifest_root, "keep-files.tsv"))
    candidate_rows = read_tsv(os.path.join(manifest_root, "candidate-files.tsv"))
    move_rows = read_tsv(move_manifest)
    keep_paths = set(row["path"] for row in keep_rows)
    candidate_paths = set(row["path"] for row in candidate_rows)
    move_paths = [row["path"] for row in move_rows]
    if keep_paths & candidate_paths:
        raise RuntimeError("keep/candidate overlap")
    if len(move_paths) != len(set(move_paths)):
        raise RuntimeError("duplicate move entry")
    for path in keep_paths | candidate_paths | set(move_paths):
        if not safe_relative(path):
            raise RuntimeError("unsafe path: %r" % path)

    ordered_moves = sorted(move_paths)
    for index, path in enumerate(ordered_moves[:-1]):
        if ordered_moves[index + 1].startswith(path + "/"):
            raise RuntimeError("nested move entries")

    expected_status = open(os.path.join(manifest_root, "superproject-status.txt"), encoding="utf-8").read()
    current_status = run_text(["git", "-C", repo, "status", "--porcelain=v1"])
    if current_status != expected_status:
        raise RuntimeError("Git status drift since manifest generation")

    current_objects = inventory_workspace(repo)
    if set(current_objects) != keep_paths | candidate_paths:
        added = sorted(set(current_objects) - keep_paths - candidate_paths)
        missing = sorted((keep_paths | candidate_paths) - set(current_objects))
        raise RuntimeError("workspace inventory drift: added=%r missing=%r" % (added[:10], missing[:10]))

    # Complete identity validation occurs before backup creation or any move.
    for row in keep_rows:
        verify_object(repo, row)
    for row in candidate_rows:
        verify_object(repo, row)

    backup_parent = os.path.dirname(backup_root)
    os.makedirs(backup_parent, mode=0o700, exist_ok=True)
    if os.stat(repo).st_dev != os.stat(backup_parent).st_dev:
        raise RuntimeError("backup and workspace are not on the same filesystem")
    os.mkdir(backup_root, 0o700)
    evidence_root = os.path.join(backup_root, ".wtp184-manifest")
    os.mkdir(evidence_root, 0o700)

    for name in sorted(os.listdir(manifest_root)):
        source = os.path.join(manifest_root, name)
        if os.path.isfile(source):
            destination = os.path.join(evidence_root, "phase1", name)
            os.makedirs(os.path.dirname(destination), mode=0o700, exist_ok=True)
            if os.path.lexists(destination):
                raise RuntimeError("manifest-copy destination exists")
            shutil.copy2(source, destination)

    metadata = {
        "plan_id": "PLAN-20260915-quarantine-non-cu-server-files",
        "plan_version": 1,
        "workspace": repo,
        "revision": args.expected_revision,
        "manifest_root": manifest_root,
        "move_manifest_sha256": args.expected_move_manifest_sha256,
        "started_at_epoch": int(time.time()),
        "keep_objects": len(keep_rows),
        "candidate_objects": len(candidate_rows),
        "move_entries": len(move_rows),
        "operation": "same-filesystem os.rename; no deletion",
    }
    write_new(os.path.join(evidence_root, "backup-metadata.json"), json.dumps(metadata, indent=2, sort_keys=True) + "\n")

    journal_path = os.path.join(evidence_root, "move-journal.tsv")
    journal_fd = os.open(journal_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    rollback_lines = ["backup_relative\tworkspace_relative\ttype\n"]
    completed = 0
    try:
        append_journal(journal_fd, "state\tworkspace_relative\tbackup_relative\ttype\n")
        for row in move_rows:
            relative = row["path"]
            source = os.path.join(repo, relative)
            destination = os.path.join(backup_root, relative)
            if not os.path.lexists(source):
                raise RuntimeError("move source missing: " + relative)
            if os.path.lexists(destination):
                raise RuntimeError("move destination exists: " + relative)
            os.makedirs(os.path.dirname(destination), mode=0o700, exist_ok=True)
            append_journal(journal_fd, "INTENT\t%s\t%s\t%s\n" % (relative, relative, row["type"]))
            os.rename(source, destination)
            append_journal(journal_fd, "DONE\t%s\t%s\t%s\n" % (relative, relative, row["type"]))
            rollback_lines.append("%s\t%s\t%s\n" % (relative, relative, row["type"]))
            completed += 1
    finally:
        os.close(journal_fd)

    write_new(os.path.join(evidence_root, "rollback.tsv"), "".join(rollback_lines))

    for row in keep_rows:
        verify_object(repo, row)
    post_objects = inventory_workspace(repo)
    if set(post_objects) != keep_paths:
        added = sorted(set(post_objects) - keep_paths)
        missing = sorted(keep_paths - set(post_objects))
        raise RuntimeError("post-move workspace mismatch: added=%r missing=%r" % (added[:10], missing[:10]))
    for row in candidate_rows:
        verify_object(backup_root, row)
        if os.path.lexists(os.path.join(repo, row["path"])):
            raise RuntimeError("candidate still present in workspace: " + row["path"])

    post_status = run_text(["git", "-C", repo, "status", "--porcelain=v1"])
    write_new(os.path.join(evidence_root, "post-move-git-status.txt"), post_status)
    completion = {
        "completed_at_epoch": int(time.time()),
        "completed_move_entries": completed,
        "moved_candidate_objects": len(candidate_rows),
        "moved_candidate_bytes": sum(int(row["size"]) for row in candidate_rows),
        "remaining_workspace_objects": len(post_objects),
        "rollback_manifest_sha256": sha256_file(os.path.join(evidence_root, "rollback.tsv")),
        "journal_sha256": sha256_file(journal_path),
        "post_git_status_lines": len(post_status.splitlines()),
    }
    write_new(os.path.join(evidence_root, "completion.json"), json.dumps(completion, indent=2, sort_keys=True) + "\n")
    write_new(os.path.join(manifest_root, "executed-backup-root.txt"), backup_root + "\n")
    write_new(os.path.join(manifest_root, "phase2-completion.json"), json.dumps(completion, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"backup_root": backup_root, "completion": completion}, indent=2, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("quarantine move failed: %s" % error, file=sys.stderr)
        sys.exit(1)
