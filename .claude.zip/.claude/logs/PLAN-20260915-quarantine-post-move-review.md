# Scoped post-move review

- Plan: `PLAN-20260915-quarantine-non-cu-server-files` version `1`
- Approval: user message `Approve PLAN-20260915-quarantine-non-cu-server-files version 1` received at `2026-09-15T15:47:34+08:00`.
- Review scope: Phase 1 corrected manifests, Phase 2 move/journal/rollback/post-state and nested Git visibility.
- Verdict: `PASS`
- Unresolved `BLOCK`/`HIGH`: none.
- Review mode: read-only; no build, additional movement, source correction, Git-index mutation, sync, deployment or runtime action.

## Acceptance review

| Criterion | Result | Direct evidence |
|---|---|---|
| 1. Fresh baseline | PASS | HEAD `d232778d84846848c44c0d2632db741172a022d6`; root and nested third-party state captured. Dirty selected `build_tools/deps/clu/common/httplib.hpp` and nested `third_party/httplib/httplib.cc` were separately identified and retained. |
| 2. Debug/release configured comparison | PASS | Normalized closures are equal at 1,813 labels. Debug has 694 compile actions/unique sources; release has 1,388 PIC/non-PIC actions but the same 694 unique source/owner pairs. |
| 3. Deterministic manifests | PASS | Corrected manifest is exhaustive for 41,169 eligible workspace objects: 2,002 keep plus 39,167 move candidates; sets are disjoint. 1,636 configured action inputs and 1,426 compiler-depfile inputs are subsets of keep. No missing source input. Move manifest SHA `07849b0a1e67d0d0458dfd5e774aae3d950184fc78ce05b43fcfa0dd65c9a82f`. |
| 4. Protected paths retained | PASS | `.git` controls, all BUILD/Starlark/Git-control files, root build controls, action/depfile inputs, selected httplib header and both dirty paths remain. Initial manifest that misclassified nested `.gitignore` files was rejected before movement and replaced by corrected `-r1`. |
| 5. Backup containment | PASS | Backup `/home/daigd/backups/wtp184-cu-server-only/20260915T160434-d232778d8484` is outside Git/Bazel workspaces and on the same device `66306`; operation used same-filesystem rename with no overwrite. |
| 6. Move/journal bijection | PASS | 2,316 exact move entries cover 39,167 objects/1,041,951,945 bytes. Journal contains 2,316 paired INTENT/DONE records. All candidates are absent from workspace and present at matching backup paths; all 2,002 keep objects remain. |
| 7. Rollback | PASS | Inverse rollback manifest contains 2,316 rows; SHA `943f853b40839ed14c8e3ec0121a5d4bf7f73c3aa87a8c65fea2d5608be9f428`. Journal SHA `2ee02f44149e621e240fdc9393c678f3d63f755a3da20242d49b3b8bea05b801`. No backup cleanup occurred. |
| 8. Git visibility | PASS | Superproject reports 490 visible tracked deletions and two modifications; nested third-party reports 38,677 deletions and its preserved one modification. Both indexes have zero staged paths. No `.gitignore`, sparse-checkout, `skip-worktree`, `assume-unchanged`, staging or commit mutation concealed them. |
| 9. Operation boundary | PASS | No Bazel compile/link/build/test/clean, source correction, deletion, sync, deployment, container/service operation or runtime request occurred. Only configured `cquery`/`aquery` analysis and manifest/integrity operations ran. |
| 10. Scoped review | PASS | No unresolved `BLOCK`/`HIGH` finding. |
| 11. Remaining boundary | PASS | Build and runtime correctness remain explicitly unverified. A later user-directed build may restore/correct missing paths from the preserved backup. |

## Evidence

- Corrected remote manifest root: `/home/daigd/.wtp184-quarantine-manifests/PLAN-20260915-quarantine-non-cu-server-files-v1-r1`
- Backup evidence root: `/home/daigd/backups/wtp184-cu-server-only/20260915T160434-d232778d8484/.wtp184-manifest`
- `.claude/logs/PLAN-20260915-quarantine-phase1-r1-validation.log`
- `.claude/logs/PLAN-20260915-quarantine-phase2-move.log`
- `.claude/logs/PLAN-20260915-quarantine-phase2-postcheck.log`
- `.claude/logs/PLAN-20260915-quarantine-phase3-nested-git-status.log`

The tracked deletions are intentional and visible. The backup is outside Git, so no `.gitignore` rule is necessary or capable of hiding those deletions.
