#!/usr/bin/env bash
set -euo pipefail
repo=/home/daigd/dialogue
artifact=/home/daigd/packages/server/server-v2.20260915-132953-d232778d
pipeline=/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh
ccroot=/home/daigd/tools/wtp184-gcc493-sysroot
sysroot=/home/daigd/sysroots/wtp184-centos7
view=/home/daigd/packages/.wtp184-analysis-selected
manifest=5ebf9ba88a09932c120924e95e4d68c1a31eeea012836bea948e991c85066304
test -f "$artifact"
printf 'pipeline_sha256='; sha256sum "$pipeline" | cut -d' ' -f1
printf 'artifact_sha256='; sha256sum "$artifact" | cut -d' ' -f1
printf 'artifact_size='; stat -c '%s' "$artifact"
printf 'artifact_file='; file -b "$artifact"
printf 'debug_section_count='; readelf -SW "$artifact" | python3 -c 'import sys; print(sum(1 for x in sys.stdin if ".debug_" in x))'
printf 'symtab_count='; readelf -SW "$artifact" | python3 -c 'import sys; print(sum(1 for x in sys.stdin if ".symtab" in x))'
printf 'libasan_needed_count='; readelf -d "$artifact" | python3 -c 'import sys; print(sum(1 for x in sys.stdin if "libasan" in x))'
printf 'latest='; if [[ -L /home/daigd/packages/server/LATEST ]]; then readlink /home/daigd/packages/server/LATEST; else python3 -c 'print(open("/home/daigd/packages/server/LATEST").read().strip())'; fi
printf 'superproject_revision='; git -C "$repo" rev-parse HEAD
printf 'third_party_revision='; git -C "$repo/third_party" rev-parse HEAD
printf 'superproject_status_count='; git -C "$repo" status --porcelain=v1 | wc -l
printf 'third_party_status_count='; git -C "$repo/third_party" status --porcelain=v1 | wc -l
printf '%s\n' 'third_party_status_begin'; git -C "$repo/third_party" status --porcelain=v1; printf '%s\n' 'third_party_status_end'
printf 'profile_temp_count='; python3 -c "import glob; print(len(glob.glob('/home/daigd/packages/.wtp184-profile-libs.*')))"
printf '%s\n' 'metadata_candidates_begin'
python3 - "$artifact" <<'PY'
import glob
import os
import sys
artifact=sys.argv[1]
patterns=[artifact+'.*', os.path.join(os.path.dirname(artifact),'LATEST*'), os.path.join(os.path.dirname(artifact),'.*metadata*')]
seen=set()
for pattern in patterns:
    for path in sorted(glob.glob(pattern)):
        if path in seen or not os.path.isfile(path) or os.path.getsize(path) >= 65536:
            continue
        seen.add(path)
        print('metadata_path='+path)
        try:
            for line in open(path,errors='replace'):
                if any(line.startswith(key) for key in ('build_profile=','release_stripped=','package_profile_active=','package_library_dir=','package_manifest_sha256=','package_libstdcpp=','package_libstdcpp_sha256=','package_libgcc=','package_libgcc_sha256=','built_elf_glibc_max=','built_elf_glibcxx_max=','built_elf_cxxabi_max=','gcc_version=','gcc_target=','sha256=','size=')):
                    print(line.rstrip())
        except OSError:
            pass
PY
printf '%s\n' 'metadata_candidates_end'
export CC="$ccroot/bin/gcc" CXX="$ccroot/bin/g++" PATH="$ccroot/bin:/home/daigd/tools/gcc-4.9.3-centos7/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
common=(--cpu=k8 --host_cpu=k8 --action_env="CC=$CC" --action_env="CXX=$CXX" --action_env="PATH=$PATH" --action_env='LD_LIBRARY_PATH=' --action_env="WTP184_PACKAGE_LINKER_PREFIX=/home/daigd/packages/.wtp184-analysis-linker" --linkopt="-L$view" --linkopt="-Wl,-rpath-link,$view" --linkopt="-Wl,-rpath-link,$sysroot/usr/lib64" --linkopt="-Wl,-rpath-link,$sysroot/lib64" --linkopt=-Wl,--allow-shlib-undefined --define="wtp184_package_manifest=$manifest" --compilation_mode=dbg --strip=never --cxxopt=-fno-omit-frame-pointer --cxxopt=-O0 --cxxopt=-g)
cd "$repo"
tmp=$(mktemp /tmp/wtp184-debug-flags.XXXXXX)
trap 'rm -f -- "$tmp"' EXIT
bazel aquery 'mnemonic("CppCompile", deps(//cu:server))' --output=text "${common[@]}" >"$tmp" 2>&1
python3 - "$tmp" <<'PY'
import re
import sys
text=open(sys.argv[1],errors='replace').read()
blocks=[]
current=[]
for line in text.splitlines():
    if line.startswith("action 'Compiling "):
        if current:
            blocks.append('\n'.join(current))
        current=[line]
    elif current:
        current.append(line)
if current:
    blocks.append('\n'.join(current))
seen=0
for block in blocks:
    first=block.splitlines()[0]
    source=first.split('Compiling ',1)[1].rsplit("'",1)[0]
    if source not in ('cu/server.cc','cu/dialogue.cc'):
        continue
    flags=[]
    for token in ('-O2','-O0','-g','-fomit-frame-pointer','-fno-omit-frame-pointer'):
        for match in re.finditer(r'(?m)^    .?'+re.escape(token)+r'.?(?: \\)?$',block):
            flags.append((match.start(),token))
    for match in re.finditer(r'(?m)^    .*sanitize.*$',block):
        flags.append((match.start(),'SANITIZER:'+match.group(0).strip()))
    flags.sort()
    print('configured_action=%s flags=%s'%(source,' '.join(x[1] for x in flags)))
    seen+=1
print('configured_action_count=%d'%seen)
print('forbidden_fomit_count=%d'%text.count("'-fomit-frame-pointer'"))
print('sanitizer_flag_count=%d'%len(re.findall(r'(?m)^    .*sanitize.*$',text)))
PY
