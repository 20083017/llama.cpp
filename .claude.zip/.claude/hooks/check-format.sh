#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"

if [[ -x "$ROOT/scripts/hooks/check-clang-format.sh" ]]; then
  bash "$ROOT/scripts/hooks/check-clang-format.sh"
  exit 0
fi

if ! command -v clang-format >/dev/null 2>&1; then
  echo "clang-format not found; skipping format check"
  exit 0
fi

if git -C "$ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  mapfile -t files < <(
    git -C "$ROOT" diff --name-only -- '*.c' '*.cc' '*.cpp' '*.cxx' '*.h' '*.hh' '*.hpp'
  )
  if ((${#files[@]} > 0)); then
    clang-format --dry-run --Werror "${files[@]/#/$ROOT/}"
  fi
fi
