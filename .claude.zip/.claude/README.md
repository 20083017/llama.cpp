# Claude Setup for WTP184

## Active entry points

- Default agent: `wtp184-plan`
- Workflow: `.claude/workflows/wtp184-workflow.md`
- Linux/Bazel baseline: GCC/G++ 4.9.3 with C++11
- Server preflight: `PATH=/mingw64/bin:/usr/bin:/bin LC_ALL=C /bin/bash --noprofile --norc ~/.config/wtp184/wtp184-server-entry.sh preflight`
- Server pipeline preflight: `PATH=/mingw64/bin:/usr/bin:/bin LC_ALL=C /bin/bash --noprofile --norc ~/.config/wtp184/wtp184-server-entry.sh pipeline-preflight`

The active build-host project is `/home/daigd/dialogue`, with third-party submodule `/home/daigd/dialogue/third_party`. The current pipeline remains `/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh`; its basename/hash contract is unchanged, its combined Linux build-and-deploy action is `all`, and `//cu:server` retains the product-target role. Every pipeline execution passes `PROJECT_DIR=/home/daigd/dialogue` and `THIRD_PARTY_DIR=/home/daigd/dialogue/third_party` explicitly. `/home/daigd/workspaces` is retained reference data only. The user-local `server-session.conf` selects the local checkout and remote project without storing those choices in repository files.

The compatibility CLI name `pipeline-patch-interface` is retained but retired: it fails locally without SSH or mutation. Run build, sync, deploy, `all`, status and smoke on the build host through the unchanged remote pipeline. Pipeline work belonging to development runs only after approval of its plan; unchanged covered phases need no routine reconfirmation.

Product source already exists on the build host and must never be synchronized from the workstation. Keep workstation-to-build-host SSH, the build-host pipeline, deployment-host SSH and service ports separate. Docker core collection/GDB use `wtp184-core-debug`; single-query and CSV soak use `wtp184-stress-test`. These validated flows are allowed when requested, while their existing target, timeout, workload, output and owned-process bounds remain in force.

Active agents are `wtp184-*` plus `worktree-manager`. Active skills are the
referenced `wtp184-*` skills and the generic shell/Python skills explicitly
attached by those agents. The server launcher and adjacent session configuration
are user-local runtime resources outside the repository. Generic Bash-tool
outer-shell startup, inherited `BASH_ENV` processing, tilde/`HOME` expansion,
and dynamic-loader behavior precede the launcher and are external `PARTIAL`.
The outer command uses only the reviewed Git-for-Windows `/mingw64/bin` mount and
`/usr/bin:/bin`, and fixes `LC_ALL`, for the launcher invocation; it does not
establish a clean environment or constrain state already consumed by the outer
shell. The launcher's non-evaluating parser and strict second `env -i`
environment-allowlist handoff are the reviewed boundary. Treat local
mode or Windows DACL protection as `PARTIAL` whenever filesystem semantics cannot
prove it.

## Execution flow

The canonical workflow selects when generic rule/Skill process requirements apply.
Small, routine, understood, reversible, low-risk edits are `direct-eligible`:
read affected context, edit and return a brief result. They require no saved
plan/check files, approval prompt, mandatory test/build/review or verification
report. An obvious documentation/value correction or a localized implementation
following an established pattern may qualify. A tier label or familiarity alone
does not make a consequential change direct-eligible. Honor an explicitly requested
plan or check; runtime/domain safety controls still apply.

Larger development uses the existing `wtp184-plan` agent:

1. Save `doc/plan/<plan-id>.md`, `doc/check/<plan-id>-CHECK.md` and the compact
   `doc/check/CURRENT.md` pointer; stop at `AWAITING_USER_CONFIRMATION`.
2. The user explicitly approves the displayed ID/version, for example
   `Approve <plan-id> v1`. Record approval before implementation; the initial
   request or an agent-written status does not count as that approval.
3. Execute unchanged approved phases, updating records at phase boundaries and
   during correction/re-validation. No routine phase approval is needed.
4. On ordinary implementation errors, remain IN_PROGRESS and correct/re-validate
   under the workflow's six boundaries. No fixed correction/rerun/review count
   applies; review severity alone does not stop the plan.
5. Only a listed Material blocker sets BLOCKED and waits for the user's decision.
   After direction such as `Resume <plan-id> v1 with the recorded in-scope fix`,
   resume the recorded phase; changed scope/acceptance needs revised-plan approval.

During planning, only the orchestrator writes those artifacts; other discovery is
read-only. When an exact planning fact depends on authoritative source unavailable
or stale locally, the workflow permits bounded one-shot non-mutating SSH reads of
task-relevant source/configuration/BUILD/tests and repository state whose resolved
paths remain beneath `/home/daigd/dialogue`, through the canonical Ubuntu
server-session contract. This exception does not allow
remote edits, Git mutation, build/test, pipeline, model requests, runtime/log access,
deployment, services or CentOS access before approval. Review/calibration agents
remain read-only.

If a direct attempt edits `A.cc` and then discovers required protocol or other
file changes, stop without reverting. Capture the current tracked/untracked diff
as the pre-plan baseline, distinguish attempt hunks from unrelated/uncertain edits,
and include their review/retention/correction in the new plan. Preserve partial
edits while awaiting approval; their existence is not approval or a completed
phase. The workflow defines baseline capture and record reconciliation in detail.

Existing high-risk confirmations, remote-source authority and technical
timeout/workload/owned-process bounds remain in force. Pipeline safety rollback
or necessary owned-process cleanup can finish under the canonical exception.
Platform permission prompts are separate from plan approval. Hooks/permissions
are inspected only when observed tool behavior indicates a relevant workflow
mismatch; their existence or unverified status is not mandatory preflight.

## Architecture decision depth

The workflow's architecture design policy applies `Architecture_Design_Skill.md`
through the existing agents. A/B/C describes design impact independently of
`FAST`/`FOCUSED`/`FULL` and direct/planned execution:

| Design impact | Planner behavior |
| --- | --- |
| A: local change with the same contracts, owner and lifetime | Reuse the existing pattern; compact decision; no brainstorm or routine interview. |
| B: structure, state representation, ownership or internal-contract change | Design Card and lightweight evidence-led challenge; discuss unresolved material choices. |
| C: subsystem, pipeline, ownership-boundary, persistence/concurrency or protocol architecture upgrade | Brainstorm candidates, challenge assumptions, record Architecture Card and compatibility/migration/rollback, then plan incremental implementation. |

`wtp184-plan` owns decisions, user discussion and records. The read-only
`wtp184-architecture-calibrator` supplies scoped source/configuration evidence,
ownership/lifetime analysis and candidate or mismatch tradeoffs. It is used for
a concrete unresolved question, not as a mandatory stage for every B/C change.
Planned cards live in the existing plan and use the same approval checkpoint;
independently direct-eligible B work keeps its card inline in the response/handoff.
A card alone neither requires a plan nor makes a task direct-eligible.

Implementation and review apply the adaptation-cost checkpoint: established
mechanical conversion can remain A; new duplicate state, synchronization,
semantic translation, ownership/lifetime or fallback logic returns to the
planner before more glue is added. Compare adapting the new design, improving
the old boundary and an intentional compatibility layer. Existing approved
choices remain valid within their recorded boundaries. The workflow's partial-edit
and Material blocker rules still govern escalation.

Brainstorm and lightweight grill-me are design methods the planner can perform
inline. The local `/grill-me` command starts a full `/grilling` interview; it is
not automatically invoked for B work. An explicitly requested interview retains
its own interaction flow.

## Adopt updated agent instructions

Start a fresh session in this repository after updating the main agent source:

```powershell
claude --agent wtp184-plan
```

Keep the existing permission configuration; do not proactively inspect hooks or
switch permission modes to apply this workflow. A custom planning lifecycle does
not override native plan-mode restrictions or already-injected session messages.

For a follow-up behavioral check, submit a small routine edit and observe direct
execution without records or mandatory verification. Submit a larger development
request and observe saved plan/check/CURRENT artifacts and a stop before editing.
Approve the displayed version to continue. For architecture behavior, check that
a same-contract filter edit stays A, a history representation change produces a
B Design Card, and a pipeline/ownership redesign uses C brainstorming before an
implementation plan. An existing mechanical boundary conversion should proceed;
new synchronization or dual state should return a mismatch decision before
implementation. An already approved intentional adapter should not trigger routine
reapproval. Static document checks establish policy consistency; they do not prove
that a running Claude session has adopted it.

## Disabled legacy assets

Retired mower agents, workflow, commands, rules, device skills and scripts are
kept under `.claude/backup-disabled/mower/` for recovery and audit. That tree is
not an active Claude discovery location; do not route work to files inside it.
