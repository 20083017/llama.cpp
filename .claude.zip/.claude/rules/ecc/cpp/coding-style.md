---
paths:
  - "**/*.cpp"
  - "**/*.hpp"
  - "**/*.cc"
  - "**/*.hh"
  - "**/*.cxx"
  - "**/*.h"
  - "**/CMakeLists.txt"
---
# C++ Coding Style

> This file extends [common/coding-style.md](../common/coding-style.md) with C++-specific WTP184 requirements.

## Compiler and Language Baseline

- GCC/G++ 4.9.3 with C++11 is authoritative.
- Use a newer compiler or language standard only when the specific target's checked-in build configuration explicitly establishes it.
- Reject unsupported C++14/17 syntax and library APIs, including generic lambdas, structured bindings, `std::optional`, `std::string_view`, `std::variant`, `std::filesystem`, and standard `std::make_unique`.
- Use `auto` and `constexpr` only in forms supported by C++11 and when they improve clarity.
- Avoid newer libstdc++ behavior and warning flags unsupported by GCC/G++ 4.9.3.
- Verify compatibility with the actual compiler command when available; otherwise report it as `PARTIAL`.
- These requirements override generic modern-C++ recommendations.

## Project Compatibility

- Reuse repository ownership, threading, logging, error-handling, and naming conventions.
- Preserve ABI-sensitive public types, virtual interfaces, shared-library boundaries, and plugin/task loading.
- Prefer the existing repository style over broad reformatting or modernization.

## Resource Management

- Use RAII and make ownership explicit.
- Use `std::unique_ptr` for exclusive ownership and `std::shared_ptr` only for genuine shared ownership.
- Prefer existing C++11-compatible factories and `std::make_shared` where appropriate.
- Do not recommend standard `std::make_unique` unless the target explicitly establishes C++14 or newer; follow an existing project factory or construct `std::unique_ptr<T>(new T(...))` when required.

## Naming Conventions

- Types/Classes: `PascalCase`.
- Functions/Methods: `snake_case` or `camelCase`, following the local convention.
- Constants: `kPascalCase` or `UPPER_SNAKE_CASE`.
- Namespaces: `lowercase`.
- Member variables: follow the local trailing-underscore or `m_` convention.

## Formatting

- Preserve the repository's existing formatting.
- Run `clang-format` only when the repository configuration and requested scope support it; do not create unrelated formatting diffs.

## Reference

The `cpp-coding-standards` Skill is supplemental. This project rule takes precedence for compiler, language-version, standard-library, ABI, and repository-compatibility decisions.

## Diagnostic Logging

Use `.claude/rules/observability.md` as the single debug/release content policy,
and `.claude/rules/cpp-observability.md` for existing Timeline timing. Inherit the
workflow Development/Test Data policy; do not create a separate data-policy gate.

- Reuse existing `base/base/logging.h`/glog. Do not introduce a logger wrapper,
  manager, dependency, mutable diagnostic state or a security/parser subsystem
  for localized diagnostics.
- Debug VLOG(4)/LOGD may print full useful service JSON, query/history/semantic
  context and intermediate results. Release/default logs retain necessary
  lifecycle/selection, degradation and owned failure information, not payloads
  or routine high-frequency successful branches. LOGI/VLOG(3) is not debug-only.
- Useful diagnostics use existing correlation and concise stage/outcome/reason
  fields. Print original request JSON before the blocking call and available
  response JSON afterward, including error responses. Do not wait for envelope
  or semantic success before making the corresponding debug evidence visible.
- Do not condition ordinary debug business JSON on API-key configuration,
  capture settings or request-prefix selection. Do not scan, normalize, parse
  or re-serialize service bodies merely for logging. Keep transport credentials
  and Authorization headers separate from body diagnostics; business
  authentication behavior is unchanged.
- One terminal error belongs to its actual owner. A caller may add distinct
  stage context, not repeat the same failure through multiple channels. Use
  real ERROR/WARNING severity rather than the similarly named VLOG aliases.
- Reuse serialized data; gate diagnostic-only formatting with VLOG_IS_ON(4).
  Prefer useful snapshots to per-token/item spam. Respect the existing logger
  buffer limit and report incomplete oversized output honestly; do not add
  custom limits, chunking or capture machinery without a demonstrated need.
- Logging must not change public APIs, business/wire data, return values,
  routing/fallback, persistence, ownership, lifetime or synchronization. Preserve
  GCC/G++ 4.9.3/C++11 and actual platform/version boundaries.

### External-Boundary Diagnostic Sufficiency

For external services, protocols, plugins/resources and process boundaries:

- Release failures should identify the operation/stage, owning call when useful,
  selected backend/model/protocol, actionable reason and available transport,
  HTTP or application status. Include elapsed units and configured timeout when
  relevant. Do not require an elaborate fixed record for every ordinary branch.
- Keep transport, HTTP, envelope and content/semantic results distinct: a 2xx
  response is not semantic success, and a prepared request is not delivery.
  With no response, log the observed failure and no invented response body.
- Debug output carries original service bodies and useful intermediate results
  under the common policy. Route-selection metadata must not dump transport
  authentication/configuration; reuse an existing safe route/model identity.
- Protected capture is optional when separately useful, never required merely
  to print debug JSON. If used, preserve its existing explicit selection,
  entry/byte bounds, exclusive mode-0600 task-owned file and retention/cleanup.
  It must not disable normal debug logging or silently activate at runtime.
- Before changing delimiters, wrappers, normalization, parser fallback or
  compatibility, obtain a real failing result and prove the existing protocol
  contract. Prefer existing debug evidence; do not repair semantics for a log.
- When diagnostic validation is planned/requested, check useful debug bodies and
  release non-payload output separately, request-before-call on missing response,
  available error responses, actual controls and unchanged business behavior.
  Tests must not require full business payloads to be absent at every verbosity.
  This guidance adds no mandatory test/review gate to direct-eligible changes.
- Distinguish source, unit/build and runtime evidence. Only observed execution
  proves that the configured target emits the expected records; instruction or
  source review does not prove deployed verbosity, delivery or completeness.

## Wire-Protocol Delimiters and Unicode

- Define every structural delimiter by protocol role, Unicode codepoint and
  encoded byte sequence; never rely on visual similarity in source, logs or a
  terminal. For an ASCII/UTF-8 wire contract, `;` is U+003B byte `3B`, `:` is
  U+003A byte `3A`, and `=` is U+003D byte `3D`.
- Treat fullwidth punctuation as different data. `；` is U+FF1B bytes
  `EF BC 9B`, and `：` is U+FF1A bytes `EF BC 9A`; neither is an ASCII
  delimiter or assignment character.
- Do not silently normalize, transliterate or substitute punctuation at a wire
  boundary. Unicode normalization, wrapper stripping or compatibility aliases
  require an explicit versioned protocol decision and exact evidence.
- Give constants protocol-specific names and ownership. Do not reuse or
  globally replace a legacy fullwidth delimiter when a separate protocol uses
  ASCII. Keep parser selection explicit rather than inferring a protocol from
  punctuation found in content.
- State whether a character is structural syntax or payload text. Apply strict
  delimiter checks only at the documented structural boundary; do not reject
  natural-language payload text merely because it contains Unicode punctuation
  unless that protocol explicitly forbids it.
- Serializer/parser tests must assert exact accepted bytes and include negative
  cases for visually similar codepoints. When one response permits alternative
  assignment styles, require one uniform style and reject mixed styles without
  normalization or fallback.
