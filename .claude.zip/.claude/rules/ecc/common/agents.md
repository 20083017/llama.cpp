# Agent Orchestration

Use the existing `wtp184-plan` entry and `.claude/agents/` owners selected by
`.claude/workflows/wtp184-workflow.md`. That workflow governs WTP184 planning,
testing, review, correction and approval across generic ECC rules and attached
Skills. Generic planner/TDD/reviewer instructions are not additional agent chains.

Direct-eligible work has no mandatory planning, testing or review delegation.
Other development follows the saved-plan checkpoint and approved phase routing.
Use read-only discovery only when its question is needed; implementation children
receive the canonical approved-plan handoff. Do not delegate to an implementation
agent to bypass approval.

Use one owner per file scope and parallelize independent approved work only when
useful. Children do not delegate; avoid duplicate discovery and mandatory panels.
Return read-only findings to the orchestrator for ordinary-correction/material
classification. An early child finding or review severity is not automatically a
plan-level BLOCKED state. Inherit the workflow's partial-edit baseline and
boundary-based correction rules without adding gates or retry quotas.
