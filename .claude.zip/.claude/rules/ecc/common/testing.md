# Testing Requirements

Use `.claude/workflows/wtp184-workflow.md` for execution eligibility, approval and validation; generic testing guidance adds no gates or agent chains. Direct-eligible work has no mandatory test/build/coverage/review. Honor explicitly requested validation.

When the user requests builds or runtime tests, execute them through the appropriate owner and authorized route rather than only suggesting commands or assigning the work back to the user, unless the user explicitly chooses to run them personally. Report command, exit status and acceptance result; if execution is unavailable, explain the concrete limitation and mark the check unrun.

## Acceptance-Driven Coverage

Select the smallest relevant case, target or test that proves requested or approved acceptance. Add unit, integration or end-to-end coverage only when the affected behavior requires it. No universal coverage percentage, all-test-type matrix or Playwright requirement applies; honor coverage explicitly included in acceptance.

## Test-Driven Development

Use RED/GREEN/refactor when it fits the approved change and test infrastructure, or when requested. It is a technique, not an additional approval/verification phase. Preserve planned acceptance and avoid unrelated refactoring.

## Troubleshooting Test Failures

Return concrete failure evidence to the existing owner. Check relevant isolation, fixtures and mocks; correct implementation or genuinely incorrect tests without weakening acceptance. Continue targeted correction and validation under the canonical boundaries, not a fixed rerun count.

## Agent Support

Use existing WTP184 owners selected by the workflow. Do not automatically add generic TDD/E2E agents or duplicate equivalent validation.
