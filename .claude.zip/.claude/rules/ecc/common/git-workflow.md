# Git Workflow

## Commit Message Format

```
<type>: <description>

<optional body>
```

Types: feat, fix, refactor, docs, test, chore, perf, ci

Note: Attribution disabled globally via ~/.claude/settings.json.

## Pull Request Workflow

When creating PRs:
1. Analyze full commit history (not just latest commit)
2. Use `git diff [base-branch]...HEAD` to see all changes
3. Draft comprehensive PR summary
4. Include test plan with TODOs
5. Push with `-u` flag if new branch

## Feature Implementation Workflow

Use `wtp184-plan` and `.claude/workflows/wtp184-workflow.md` for route selection.
Direct-eligible changes proceed without a saved plan, approval checkpoint,
mandatory TDD/coverage/check or review. Larger work requires saved artifacts and
one explicit approval; use the approved phase's relevant tests and WTP184 owners.

Ordinary implementation/review findings may be corrected and re-validated within
the canonical six boundaries without another approval or fixed iteration count.
Only the listed Material blockers stop the plan for a user decision. Preserve
partial direct edits and capture their baseline when escalating to planned work;
do not stage, stash, reset or commit merely to tidy that baseline.

Git mutations belonging to development require the approved phase and existing
Git/worktree policy controls. When commit/push is requested or included in the
approved scope, use detailed conventional commit messages and the PR guidance
above; do not infer commit/push authorization from an ordinary content edit.
