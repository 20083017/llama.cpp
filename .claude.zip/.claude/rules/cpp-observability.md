# C++ Execution Observability

Use this rule for C++ stage timing and shared Android/Linux Dialogue V3 tracing.
Reuse the existing infrastructure; `.claude/rules/observability.md` owns the
logging/metrics APIs, debug/release content policy, labels and platform selection.
Inherit execution and validation policy from `.claude/workflows/wtp184-workflow.md`.

## Inspect before instrumenting

- Read `time_line.h`, `time_line.cc`, actual callers, request/response ownership,
  selected V2/V3 paths and relevant BUILD definitions in the authoritative source.
  Record source paths/revision; a workstation snapshot is only partial evidence.
- Establish the exact Timeline API, timestamp source/precision/units, interval
  semantics, creation, propagation, output, reset/destruction and thread model.
  Determine whether records measure adjacent stages, cumulative time or explicit
  spans. Do not assume start/end, outcome, thread-safety or dump APIs exist.
- Map existing Timeline, LOG/VLOG, LogReporter and Prometheus coverage before
  adding anything. Reuse stage names and owners; add only a demonstrated gap.

## One purpose per channel

| Facility | Responsibility |
| --- | --- |
| Timeline | Default for request stage durations and execution breakdown. |
| LOG / VLOG | Technical diagnostics; detailed successful traces use existing verbosity controls. |
| LogReporter | Established production events and terminal failure summaries within its existing schema. |
| PrometheusWrapper | Aggregate latency, failures, timeouts and request counts for QPS. |

Do not create a logging/timing framework, wrapper, registry or parallel stopwatch
when Timeline covers the requirement. Reuse its measured duration for an owned
aggregate metric when the actual API permits. Report a capability gap before
extending the existing implementation; never invent an API or overload a field.

## Selected V3 boundaries

Inspect these boundaries and instrument only those reached by the selected path:

1. Request received at the existing request owner.
2. History load and eligible semantic selection.
3. NLU request construction.
4. Selected backend invocation, ending at completion or observed failure/timeout;
   HTTP transport sub-stages only when HTTP actually runs.
5. NLU response parsing and semantic validation.
6. History commit, distinguishing stored, skipped, stale and failed results.
7. Dialogue response completion at the terminal owner, including early exits.

Preserve existing stage meanings. Inserting a record into an adjacent-interval
Timeline can change the next stage's duration; inspect that effect before adding
sub-stages. Identify overlapping totals and breakdowns; never double-count them.
Request construction is not network time; HTTP success is not semantic success;
returning from async dispatch or emitting a streaming chunk is not completion.

## Ownership, clocks and outcomes

- Keep Timeline state isolated per request through existing request/response
  ownership. Correlate with existing safe request/session identifiers under the
  logging rule; never add identifiers to metric labels or create a global,
  thread-local or session-reused timing accumulator.
- Carry existing ownership across async work. Prove writer ordering and lifetime
  through callbacks, timeout/cancellation and late completion; do not borrow a
  destroyed object, extend business lifetime or assume shared ownership makes
  concurrent writes safe. Use existing serialization; justify any new hot-path
  lock or blocking operation before introducing it.
- Use the existing log timestamp for wall-clock correlation and Timeline's
  monotonic clock for elapsed time where supported. Verify the implementation:
  millisecond precision alone does not imply monotonic timing. If unsupported,
  state the limitation and scope any clock correction without changing unselected
  versions/platforms.
- Close/output/clean up through the actual lifecycle API at one terminal owner
  on success, error, timeout and cancellation. Handle skipped stages honestly;
  do not record success for an unfinished operation or let late callbacks finish
  the same trace twice. Do not add a second cleanup owner.
- Failure diagnostics identify operation/stage, bounded outcome/reason, meaningful
  transport/HTTP/application error code, elapsed unit and configured timeout when
  available. Distinguish an observed timeout from a generic transport failure;
  do not infer timeout solely from elapsed time. Include actionable context using
  existing safe fields, without repeating the same error across channels.

## Compatibility, volume and verification

- Linux-V3-only changes use the existing combined guard:
  `defined(__linux__) && !defined(__ANDROID__) && defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3`.
  Confirm selected Bazel definitions/dependencies; Android also defines `__linux__`.
- Shared Android/Linux V3 diagnostics use version-only selection at common
  owners and consistent event meanings/levels; preserve business platform branches
  and do not fabricate identical stages for different backends.
- Preserve GCC 4.9.3/C++11, unselected version/platform behavior, NLU semantics, history eligibility,
  request ordering and one-in-flight-per-session. Add no dependency for tracing.
- Keep detailed Timeline output behind existing debug verbosity; avoid formatting
  or payload serialization when disabled, per-token records and unbounded storage.
  Follow the common debug/release policy: stage detail belongs at VLOG(4), not
  release/default verbosity. Keep Timeline for timing; print useful business JSON
  at its existing diagnostic boundary rather than add another payload channel.
- For requested/planned instrumentation validation, cover success, NLU error and
  timeout, history selection/commit, concurrent request isolation, async cleanup,
  and unselected version/platform preservation with the smallest relevant tests/builds. Distinguish
  source, build and runtime evidence; instruction-only edits require no C++ build.
- Report verified Timeline capabilities/limitations, changed files, actual added
  boundaries, a level-appropriate example from real APIs/output, checks run and remaining
  gaps. Label illustrative output; never present it as captured runtime evidence.
