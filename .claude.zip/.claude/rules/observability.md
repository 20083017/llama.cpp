# C++ Observability and Logging

This rule applies to WTP184 C++ feature work, bug fixes and reviews. It complements the privacy and external-boundary requirements in `.claude/rules/ecc/cpp/coding-style.md`.

For execution-stage timing, follow `.claude/rules/cpp-observability.md`: inspect and reuse the existing Timeline and its request lifecycle. This file owns the detailed logging and metrics contracts.

## Change-scoped logging review

- The current retrospective audit concerns V3 code changed after commit
  `5b9f22360a6d3f2b335730b91ced63bf2f62ea9f`, through the selected authoritative
  revision and any relevant current working-tree edits. Record the actual range;
  do not silently replace the baseline with a recent commit or a workstation copy.
- Apply both filters: code belongs to the selected V3 path, and the relevant
  logging behavior was added/modified by that delta. A changed filename alone
  does not make every old log in that file a cleanup target. Exclude unrelated
  V2-only and unchanged legacy logging from the requested correction list.
- For each future development task, inspect logging only in its added/modified
  code and directly affected boundaries. Do not re-audit the entire post-baseline
  history, module or repository on every change.
- Read unchanged callers/types/macros only as needed to establish the affected
  contract. Include an unchanged log as activated/worsened only with concrete
  delta-to-behavior evidence; merely sharing code with V3 is insufficient.
- Separate in-scope findings from legacy/out-of-scope observations. The latter
  do not authorize cleanup or block the current task without demonstrated impact.
  Review scope does not itself authorize product edits or add a mandatory review,
  test or approval gate to direct-eligible work.

## Debug and release: one content policy

Inherit the workflow Development/Test Data policy. For ordinary service/business
diagnostics, choose output by the existing effective runtime verbosity, not by
API-key presence, a capture file, a request-prefix filter or a new debug switch.
Do not introduce credential scanners, escape matchers, redaction frameworks or
logging-only parsers/re-serialization to print existing service JSON. Keep
transport authentication and Authorization headers separate from body output;
this does not remove authentication used by business requests.

| Mode | Content and API |
| --- | --- |
| Debug | VLOG(4), or its existing LOGD alias: full useful original request/response JSON, query/history/semantic context, intermediate results, branch/early-exit reasons and detailed Timeline output. |
| Release/default | LOG(INFO) for necessary initialization, selection and important lifecycle/completion; LOG(WARNING) for actual recoverable degradation; LOG(ERROR) for owned terminal failures. No body/prompt/history/semantic dumps or routine branch/stage-success traces. |

Debug is a runtime logging mode, not synonymous with a compiler debug build.
The existing Linux server maps `--log_level=debug` to FLAGS_v=4 and info to 3;
API initialization reads environment `FLAGS_v`, default 2. Therefore VLOG(3)
and LOGI are not debug-only. An optimized binary explicitly running at verbosity
4 is in debug logging mode. Inspect effective initialization/override paths;
do not add process-global verbosity mutation inside a request just for logging.

Print the original service request body before the blocking call, independently
of response arrival. Print an available response body, including error JSON,
without requiring semantic success. Do not replace full HTTP JSON with extracted
model content, a parsed semantic result or a reconstructed diagnostic object.
A prepared request is not proof of delivery; no response means failure metadata,
not fabricated response JSON. Keep one payload record per reached boundary.

Illustrative call-site shape, using existing variables and transport invocation:

```cpp
if (VLOG_IS_ON(4)) {
  VLOG(4) << "request_id=" << request_id
          << " nlu_llm_request_json=" << http_request.body;
}
// Existing transport call, with unchanged bytes and return handling.
if (VLOG_IS_ON(4) && !response.body.empty()) {
  VLOG(4) << "request_id=" << request_id
          << " nlu_llm_response_json=" << response.body;
}
```

No protected-capture setup is required for these normal debug records. Existing
optional capture can remain for compatibility, but must not gate LOG/VLOG.
Reuse already serialized bodies; gate diagnostic-only formatting at level 4.
Full useful context does not mean logging every token or creating unbounded
buffers. Respect existing logger limits and disclose them: bundled glog currently
uses a 30000-byte message buffer including prefix, so oversized JSON may truncate.
Do not promise unlimited complete records or add custom truncation/chunking,
files or a new logger without a demonstrated requirement.

Before completing an important code path, explicitly decide whether it needs:

- a stage duration or execution breakdown through the existing Timeline;
- a production release event through `LogReporter`;
- a diagnostic `LOG(...)` or `VLOG(...)` record;
- a Prometheus counter, gauge or duration observation;
- or no new instrumentation.

Do not add every channel mechanically. Each event or measurement must have one purpose and one owning boundary.

## Verified project interfaces

### Release events: `LogReporter`

The checked-in public submission API in `clu/log_reporter/log_reporter.h` is:

```cpp
LogReporter& LogReporter::Instance();
int LogReporter::Report(const LogMessage& message) const;
```

The existing Linux-server call form in `cu/handlers.cc` is:

```cpp
LogMessage message;
message.metadata.event_id = "dialog_end_process";
// Populate only fields permitted by the approved event contract.
const int result = LogReporter::Instance().Report(message);
```

Do not invent `ReportEvent`, `ReportWarning`, `ReportFailure`, logging macros, overloads or another reporter wrapper. `Report()` returns `0` when the message is accepted by the existing producer and `-1` on the wrapper's immediate failure path. Acceptance by the asynchronous Kafka producer is not delivery confirmation.

Current ownership constraints:

- `LogReporter` belongs to Linux `//cu:server` and is backed by Kafka.
- Android `//cu:libdialogue_api.so` has no `LogReporter` or Kafka dependency, caller or lifecycle.
- Initialization is process-lifetime and depends on `KAFKA_BROKER` and `KAFKA_TOPIC`; source/build presence does not prove runtime activation.
- Missing initialization is sticky for the singleton lifetime. Do not emit an additional warning for every request when one initialization owner already reported the failure.
- The producer is shared across server workers and its wrapper adds no application mutex. Do not add high-frequency concurrent reporting without proving the producer contract and bounded failure behavior.

Use `LogReporter` only for low-volume, production-important lifecycle or terminal business events whose schema and downstream consumer contract are already established. Do not use it for branch tracing, intermediate state, per-item events or debug dumps.

The legacy `LogMessage` schema contains fields capable of carrying query, request body, semantics, VIN, user and network data. New or modified events must leave sensitive fields unused unless a separately approved product/data contract explicitly requires and protects them. Do not overload unrelated schema fields to carry `reason`, `outcome` or debug text.

### Diagnostic logs: glog

Use the existing stream APIs from `base/base/logging.h`/glog:

```cpp
LOG(ERROR) << "component=nlu06b event=nlu06b_http_failure"
           << " stage=transport outcome=error reason=timeout";

LOG(WARNING) << "component=v3 event=history_store"
             << " outcome=stale reason=generation_changed";

LOG(INFO) << "component=v3 event=init_result outcome=success";

VLOG(4) << "component=v3 event=route_result outcome=success"
        << " source=nlu06b frame_count=" << frame_count;
```

Use severity by meaning:

- `LOG(ERROR)`: an actual terminal error owned by this boundary;
- `LOG(WARNING)`: recoverable degradation, stale work, fallback or rejected invalid input;
- `LOG(INFO)`: low-frequency lifecycle, configuration selection or operationally important completion;
- `VLOG(4)`: debug-only payloads, detailed branch decisions, intermediate state and high-frequency success tracing.

The project aliases are not severity aliases:

```cpp
#define LOGE VLOG(1)
#define LOGW VLOG(2)
#define LOGI VLOG(3)
#define LOGD VLOG(4)
```

Therefore `LOGE` is not `LOG(ERROR)` and `LOGW` is not `LOG(WARNING)`. Do not rely on their names when a message must survive lower verbosity.

Emit one terminal error at the boundary that owns the failure. A caller may add a separate stage result only when it contributes distinct information; do not repeat the same error text across `LogReporter`, `LOG(ERROR)` and multiple stack levels.

### Metrics: `prometheus::PrometheusWrapper`

The verified singleton exposes these methods in `third_party/prometheus/include/prometheus/prometheus_wrapper.h`:

```cpp
prometheus::PrometheusWrapper::Instance().IncrementCounter(
    name, help, labels, value);
prometheus::PrometheusWrapper::Instance().SetGauge(
    name, help, labels, value);
prometheus::PrometheusWrapper::Instance().IncGauge(
    name, help, labels);
prometheus::PrometheusWrapper::Instance().DecGauge(
    name, help, labels);
prometheus::PrometheusWrapper::Instance().ObserveHistogram(
    name, help, labels, value);
prometheus::PrometheusWrapper::Instance().ObserveSummary(
    name, help, labels, value);
```

The labels parameter is `const std::map<std::string, std::string>&`. Reuse this API directly; do not introduce a second registry, collector wrapper or mutable metrics manager.

A request-duration example following the existing naming convention is:

```cpp
const double duration_seconds =
    static_cast<double>(duration_ms) / 1000.0;
prometheus::PrometheusWrapper::Instance().ObserveHistogram(
    "http_request_latency_seconds",
    "HTTP request latency in seconds",
    labels,
    duration_seconds);
```

A bounded result counter uses fixed categories:

```cpp
std::map<std::string, std::string> labels;
labels["outcome"] = outcome;  // fixed: success|invalid_request|internal_error
labels["is_stream"] = is_stream ? "true" : "false";
prometheus::PrometheusWrapper::Instance().IncrementCounter(
    "http_request_results_total",
    "Terminal HTTP request results",
    labels);
```

Metric rules:

- counters end in `_total` and count monotonic events;
- gauges represent current values such as `_inflight` and must be decremented on every exit after an increment;
- duration histograms end in `_seconds` and receive seconds, never raw milliseconds;
- check the wrapper's existing fixed histogram buckets before adding a latency metric whose expected range exceeds them;
- request counts and terminal success/failure rates use fixed outcomes;
- timeout, retry, cache hit/miss and error-category metrics are added only at the boundary that actually owns and can distinguish those events;
- do not create retry metrics for a no-retry path or cache metrics where no cache decision occurs;
- calls before `PrometheusWrapper::Initialize()` silently record nothing; build presence is not runtime activation evidence.

Use only bounded, low-cardinality labels such as fixed `stage`, `outcome`, `reason`, `source`, `is_stream` and platform/version categories. Never use request ID, session ID, user ID, VIN, raw query, history, endpoint, model response, arbitrary domain/intent/slot, full status text or exception text as a label. Every distinct label map is retained for the process lifetime.

## Platform and version boundaries

Platform selection and dialogue-version selection are independent.

- Android NDK defines `__ANDROID__` and also defines `__linux__`.
- Native Linux defines `__linux__` without `__ANDROID__`.
- `DIALOGUE_PIPELINE_V3` distinguishes V3 from V2 on either platform.
- `ENABLE_SIMPLIFIED_NLU` is a feature switch, not a general Android discriminator.

When observability behavior must be Linux-V3-only, use the established combined form:

```cpp
#if defined(__linux__) && !defined(__ANDROID__) && \
    defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
// Linux V3 observability
#else
// Preserve the existing non-Linux-V3 behavior.
#endif
```

Do not use `__linux__` alone to exclude Android. Do not use `DIALOGUE_PIPELINE_V3` alone to distinguish platforms.

Prefer existing target ownership over unnecessary preprocessor branches. For example, `cu/handlers.cc` is already a Linux-server source, while shared V3 libraries enter both Linux and Android. Use a platform guard in shared code only when behavior or dependencies genuinely differ.

Keep the same glog source API on both platforms unless an approved contract requires otherwise. Bundled glog already routes eligible Android messages to logcat. Do not reactivate the commented `__android_log_print` macros in `base/base/logging.h`: they are varargs macros and are incompatible with current stream-style call sites. Do not globally remap `LOGE/LOGW/LOGI/LOGD` without auditing every affected call because remapping changes severity, filtering and volume, not just the sink.

Shared Android/Linux V3 diagnostics use the same event meanings and levels for
the same reached operations. Reuse version-only V3 selection at common compile
owners; do not apply the Linux-only guard to shared logging. HTTP-specific stages
remain specific to an actual HTTP backend. Keep V2 behavior outside the requested
change, and do not change business platform branches merely to align logs.

A source macro cannot replace Bazel ownership. Server-only Kafka or Prometheus dependencies must also remain excluded from Android targets. Never infer runtime activation from a macro, BUILD dependency or linked library.

## Event content and format

Prefer concise searchable key-value fields:

```text
component=<fixed> event=<fixed> stage=<fixed>
outcome=<fixed> reason=<bounded fixed category>
request_id=<bounded correlation only when available>
elapsed_ms=<integer> item_count=<integer> byte_count=<integer>
```

An owning failure should answer:

- what failed;
- where it failed;
- why it failed using a bounded reason;
- which request is affected when safe correlation exists;
- how much/how long/status category when relevant.

Apply the debug/release matrix above, not an all-level business-payload ban.
At release/default levels, keep useful bounded stage/status/reason/count fields;
move raw query, history, prompt, slot and full request/response/semantic content
to debug. Do not dump transport headers or authentication configuration alongside
service JSON. Route-selection metadata must not expose authentication embedded
in configured URLs; use an existing safe route/model identity when needed.

Request IDs may be log-correlation fields but never metric labels. The C++
external-boundary rule inherits this content policy; protected capture is optional,
not a prerequisite for ordinary debug output. Retain original JSON representation
and distinguish body, semantic result and transport metadata.

## Volume and performance

- Prefer one useful debug snapshot over repeated item-by-item dumps; avoid per-token/header spam and unbounded loops. Do not register metrics per arbitrary slot/history/token value.
- Prefer one completion event and one owned failure over repeated progress messages.
- Reuse the request-owned Timeline for stage timing, including async work under its verified lifetime/thread contract. Keep formatting call-local; add no parallel timer, request map, background thread or mutable diagnostic cache.
- Reuse existing serialized payloads. If diagnostic-only formatting is needed, perform it only behind VLOG_IS_ON(4), never on the release/default path.
- Keep logging outside held locks where possible.
- Metric APIs perform family/label lookup; stable labels are required for both memory and CPU bounds.
- Observability must not alter return values, fallback, retry, persistence, callback timing, routing or object lifetime.

## Development and review checklist

For each important feature or bug fix:

- [ ] Identify lifecycle boundaries, branch decisions, dependency calls, failure exits and latency bottlenecks.
- [ ] Choose Timeline, `LogReporter`, glog/VLOG, Prometheus or no instrumentation for each owned measurement/event.
- [ ] For Timeline changes, verify interval semantics, clock/units, request isolation, async completion and terminal cleanup under `.claude/rules/cpp-observability.md`.
- [ ] Confirm the selected API, target dependency and runtime owner already exist.
- [ ] Use real glog severity; do not confuse `LOGE/LOGW` with ERROR/WARNING.
- [ ] Ensure one terminal owner and no duplicate cross-channel event.
- [ ] Check request/success/failure counts and fixed error categories where aggregate rates matter.
- [ ] Balance every inflight gauge and use seconds for `_seconds` metrics.
- [ ] Verify every label has a bounded value set and contains no identifier or payload data.
- [ ] Verify full useful business data is available at debug without API-key/capture gates, and absent from release/default output; keep transport authentication separate and inherit the canonical data policy.
- [ ] Use `__ANDROID__` and version macros independently when a real platform/version split is required.
- [ ] Preserve Linux/Android and V2/V3 target closure, public ABI and GCC/G++ 4.9.3 C++11 compatibility.
- [ ] Validate the smallest affected Bazel target when validation is planned or requested, and report unrun runtime activation honestly.
