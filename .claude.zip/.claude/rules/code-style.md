# Code Style Rules

This file is the top-level Claude rules entry for coding style.

Use these detailed rule sets:

- `.claude/rules/ecc/common/coding-style.md`
- `.claude/rules/ecc/cpp/coding-style.md`
- `.claude/rules/cpp-observability.md` (Timeline reuse and execution-stage timing)
- `.claude/rules/observability.md`
- `.claude/rules/shell-scripting.md`
- `.claude/rules/python-tooling.md`
- `.claude/skills/cpp-coding-standards/SKILL.md` (supplemental; project and scoped C++ rules take precedence)

## Project Defaults

- Use C++11-compatible code by default; use a newer language standard only when a specific target's checked-in build configuration explicitly establishes it
- Assume GCC/G++ 4.9.3 compatibility unless a specific target's checked-in toolchain configuration explicitly establishes a newer compiler
- For compiler, language, and standard-library choices, these defaults and `.claude/rules/ecc/cpp/coding-style.md` override generic modern-C++ guidance
- Prefer existing repository style over new formatting conventions
- Use RAII for resources and make ownership explicit
- Prefer strongly typed interfaces for units, command IDs, status codes, and durations
- Keep shell and Python tooling small, explicit, bounded, and environment-driven
- Keep changes minimal and focused
