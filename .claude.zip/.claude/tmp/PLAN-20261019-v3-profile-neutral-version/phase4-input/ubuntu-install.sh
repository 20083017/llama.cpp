#!/usr/bin/env bash
set -euo pipefail
umask 077
root="$1"
[[ "$root" == /home/daigd/PLAN-20261019-v3-profile-neutral-version.phase4.* && -d "$root" && ! -L "$root" ]]
exec > "$root/phase4-install-verification.log" 2>&1
printf 'START %s PLAN-20261019-v3-profile-neutral-version v2 Phase4 ONLY\n' "$(date -Is)"
run() { printf 'COMMAND'; printf ' %q' "$@"; printf '\n'; local rc; if "$@"; then rc=0; else rc=$?; fi; printf 'EXIT %s\n' "$rc"; return "$rc"; }
[[ "$(id -un)" == daigd ]]
controller=/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh
for expected in 'TARGET_USER="${TARGET_USER:-daigd}"' 'TARGET_HOST="${TARGET_HOST:-10.1.122.21}"' 'TARGET_PORT="${TARGET_PORT:-22}"' 'SSH_IDENTITY="${SSH_IDENTITY:-}"' 'SSH_CONNECT_TIMEOUT="${SSH_CONNECT_TIMEOUT:-8}"'; do
 grep -Fxq "$expected" "$controller"
done
[[ -z "${SSH_IDENTITY:-}" && -z "${TARGET_USER:-}" && -z "${TARGET_HOST:-}" && -z "${TARGET_PORT:-}" ]]
ssh_args=(-p 22 -o ConnectTimeout=8 -o ServerAliveInterval=15 -o ServerAliveCountMax=2 -o BatchMode=yes -o StrictHostKeyChecking=yes -o PasswordAuthentication=no -o KbdInteractiveAuthentication=no -o ForwardAgent=no -o ForwardX11=no -o ClearAllForwardings=yes -o RequestTTY=no -o ControlMaster=no -o ControlPath=none -o ControlPersist=no)
transport=$(ssh -G -p 22 daigd@10.1.122.21 2>/dev/null | awk '$1=="hostname" || $1=="user" || $1=="port" || $1=="proxyjump" || $1=="proxycommand"')
printf 'CENTOS transport %s\n' "$transport"
grep -Fxq 'hostname 10.1.122.21' <<< "$transport"
grep -Fxq 'user daigd' <<< "$transport"
grep -Fxq 'port 22' <<< "$transport"
if grep -E '^proxy(jump|command) ' <<< "$transport" | grep -Ev ' none$'; then exit 40; fi
remote_root=$(timeout 40s ssh "${ssh_args[@]}" daigd@10.1.122.21 'umask 077; test "$(id -un)" = daigd && mktemp -d /home/daigd/packages/PLAN-20261019-v3-profile-neutral-version.phase4.XXXXXX')
[[ "$remote_root" =~ ^/home/daigd/packages/PLAN-20261019-v3-profile-neutral-version.phase4\.[A-Za-z0-9]+$ ]]
printf 'CENTOS_TASK_ROOT=%s\n' "$remote_root"
mkdir "$root/centos-transfer" "$root/centos-transfer/original" "$root/centos-transfer/candidate"
cp "$root/source/auto_build_offline_v3.sh.capture/auto_build_offline_v3.sh" "$root/centos-transfer/original/"
cp "$root/candidates/auto_build_offline_v3.sh" "$root/centos-transfer/candidate/"
cp "$root/phase4-input/centos-install.sh" "$root/centos-transfer/"
printf 'COMMAND tar approved helper inputs | existing Ubuntu-to-CentOS ssh tar staging\n'
tar -C "$root/centos-transfer" -cf - original candidate centos-install.sh | timeout 40s ssh "${ssh_args[@]}" daigd@10.1.122.21 "tar -xf - -C '$remote_root'"
printf 'EXIT 0\n'
run timeout 40s ssh "${ssh_args[@]}" daigd@10.1.122.21 bash "$remote_root/centos-install.sh" "$remote_root" prepare
mkdir "$root/backup" "$root/stage" "$root/dryrun-logs"
files=(cu-dev-pipeline-v17-dialogue-workspaces_offline.sh cu-dev-pipeline-v17-dialogue-workspaces.sh cu-dev-pipeline-v18-android-dialogue-api.sh)
for name in "${files[@]}"; do
 target="/home/daigd/$name"
 [[ -f "$target" && ! -L "$target" && "$(readlink -f "$target")" == "$target" ]]
 run cmp -s "$root/source/$name.capture/$name" "$target"
 run cp -p -- "$target" "$root/backup/$name"
 run cp -p -- "$target" "$root/stage/$name"
 cat "$root/candidates/$name" > "$root/stage/$name"
 run bash -n "$root/stage/$name"
 [[ "$(stat -c '%a %u %g' "$target")" == "$(stat -c '%a %u %g' "$root/stage/$name")" ]]
 printf 'UBUNTU PREPARED target=%s owner_mode=%s backup=%s\n' "$target" "$(stat -c '%a %u %g' "$target")" "$root/backup/$name"
done
installed=()
rollback() {
 rc=$?; trap - EXIT
 if ((rc != 0)); then
  printf 'FAIL exit=%s; restore only task-installed scripts\n' "$rc"
  set +e
  for ((i=${#installed[@]}-1;i>=0;i--)); do
   name="${installed[i]}"; target="/home/daigd/$name"
   if cmp -s "$target" "$root/candidates/$name"; then
    cp -p -- "$root/backup/$name" "$root/stage/$name.restore" && mv -fT -- "$root/stage/$name.restore" "$target" && printf 'UBUNTU RESTORED %s\n' "$target"
   elif cmp -s "$target" "$root/backup/$name"; then printf 'UBUNTU original already present %s\n' "$target"
   else printf 'RESTORE HOLD unrelated active delta %s\n' "$target"; fi
  done
  timeout 40s ssh "${ssh_args[@]}" daigd@10.1.122.21 bash "$remote_root/centos-install.sh" "$remote_root" restore
 fi
 printf 'END %s EXIT=%s\n' "$(date -Is)" "$rc"
 exit "$rc"
}
trap rollback EXIT
run timeout 40s ssh "${ssh_args[@]}" daigd@10.1.122.21 bash "$remote_root/centos-install.sh" "$remote_root" install
for name in "${files[@]}"; do
 target="/home/daigd/$name"; installed+=("$name")
 run mv -fT -- "$root/stage/$name" "$target"
 run bash -n "$target"
 run cmp -s "$root/candidates/$name" "$target"
 [[ "$(stat -c '%a %u %g' "$target")" == "$(stat -c '%a %u %g' "$root/backup/$name")" ]]
 printf 'UBUNTU INSTALLED target=%s owner_mode=%s\n' "$target" "$(stat -c '%a %u %g' "$target")"
done
for name in cu-dev-pipeline-v17-dialogue-workspaces.sh cu-dev-pipeline-v17-dialogue-workspaces_offline.sh; do
 for action in v3_debug_build v3_release_build v3_build; do
  printf 'DRYRUN_BEGIN %s %s\n' "$name" "$action"
  run timeout 25s env PROJECT_DIR=/home/daigd/dialogue THIRD_PARTY_DIR=/home/daigd/dialogue/third_party BUILD_LOG_DIR="$root/dryrun-logs" /bin/bash --noprofile --norc "/home/daigd/$name" "$action" --dry-run
  printf 'DRYRUN_END %s %s\n' "$name" "$action"
 done
done
for action in android_v3_debug_build android_v3_release_build; do
 printf 'DRYRUN_BEGIN android %s\n' "$action"
 run timeout 25s env LC_ALL=C PROJECT_DIR=/home/daigd/dialogue THIRD_PARTY_DIR=/home/daigd/dialogue/third_party BUILD_LOG_DIR="$root/dryrun-logs" /bin/bash --noprofile --norc /home/daigd/cu-dev-pipeline-v18-android-dialogue-api.sh "$action" --android-ndk /home/daigd/workspaces/android-ndk-r20b --android-abi arm64-v8a --android-api 21 --dry-run
 printf 'DRYRUN_END android %s\n' "$action"
done
printf 'CODE_EVIDENCE Android neutral V3 naming and profile pointers (not package execution)\n'
run sed -n '2070,2087p;2207,2211p' /home/daigd/cu-dev-pipeline-v18-android-dialogue-api.sh
printf 'PASS Phase4 installed four approved scripts; syntax and eight supported build dry-runs exited 0; no build/package/deploy/runtime execution\n'
