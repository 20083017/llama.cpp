#!/usr/bin/env bash
set -euo pipefail
umask 077
root="$1"; action="$2"
[[ "$root" == /home/daigd/packages/PLAN-20261019-v3-profile-neutral-version.phase4.* && -d "$root" && ! -L "$root" ]]
target=/home/daigd/packages/auto_build_offline_v3.sh
name=auto_build_offline_v3.sh
run() { printf 'COMMAND'; printf ' %q' "$@"; printf '\n'; "$@"; local rc=$?; printf 'EXIT %s\n' "$rc"; return "$rc"; }
case "$action" in
 prepare)
  [[ -f "$target" && ! -L "$target" && "$(readlink -f "$target")" == "$target" ]]
  run cmp -s "$root/original/$name" "$target"
  mkdir "$root/backup" "$root/stage"
  run cp -p -- "$target" "$root/backup/$name"
  run cp -p -- "$target" "$root/stage/$name"
  cat "$root/candidate/$name" > "$root/stage/$name"
  run bash -n "$root/stage/$name"
  [[ "$(stat -c '%a %u %g' "$target")" == "$(stat -c '%a %u %g' "$root/stage/$name")" ]]
  printf 'CENTOS PREPARED target=%s owner_mode=%s backup=%s\n' "$target" "$(stat -c '%a %u %g' "$target")" "$root/backup/$name"
  ;;
 install)
  : > "$root/install-intent"
  run mv -fT -- "$root/stage/$name" "$target"
  run bash -n "$target"
  run cmp -s "$root/candidate/$name" "$target"
  [[ "$(stat -c '%a %u %g' "$target")" == "$(stat -c '%a %u %g' "$root/backup/$name")" ]]
  printf 'CENTOS INSTALLED target=%s owner_mode=%s\n' "$target" "$(stat -c '%a %u %g' "$target")"
  ;;
 restore)
  if [[ -f "$root/install-intent" ]]; then
   if cmp -s "$target" "$root/candidate/$name"; then
    run cp -p -- "$root/backup/$name" "$root/stage/$name.restore"
    run mv -fT -- "$root/stage/$name.restore" "$target"
    run cmp -s "$root/backup/$name" "$target"
    printf 'CENTOS RESTORED %s\n' "$target"
   elif cmp -s "$target" "$root/backup/$name"; then printf 'CENTOS original already present\n'
   else printf 'CENTOS restore stopped: unrelated active delta\n'; exit 41; fi
  fi
  ;;
 *) exit 2;;
esac
