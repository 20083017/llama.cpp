#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d "$ROOT/tests/regression.XXXXXX")"
export PACKAGE_ROOT="$T/packages" BUILD_LOG_DIR="$T/logs" LOCAL_ARTIFACT_DIR="$T/linux" ANDROID_ARTIFACT_DIR="$T/android"
export V3_ARTIFACT_ROOT="$T/v3" PROJECT_DIR="$T/project" THIRD_PARTY_DIR="$T/third_party"
export V3_PROJECT_DIR="$T/v3-project" V3_THIRD_PARTY_DIR="$T/v3-project/third_party"
export ANDROID_NDK_HOME="$T/ndk"
mkdir -p "$T/bin" "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin"
printf '#!/usr/bin/env bash\nexit 0\n' > "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
chmod +x "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
for tool in ssh rsync docker bazel curl scp redis-cli; do
 cat > "$T/bin/$tool" <<'EOF'
#!/usr/bin/env bash
printf 'FORBIDDEN_EXTERNAL %s\n' "$0" >&2
exit 98
EOF
 chmod +x "$T/bin/$tool"
done
# Mock only host identification so Linux-only dry-run resolution is testable here.
cat > "$T/bin/uname" <<'EOF'
#!/usr/bin/env bash
case "$1" in -s) printf 'Linux
';; -m) printf 'x86_64
';; *) exit 98;; esac
EOF
chmod +x "$T/bin/uname"
export PATH="$T/bin:$PATH"
G=cu-dev-pipeline-v17-dialogue-workspaces.sh
O=cu-dev-pipeline-v17-dialogue-workspaces_offline.sh
A=cu-dev-pipeline-v18-android-dialogue-api.sh
for script in "$G" "$O" "$A"; do
 bash "$ROOT/candidates/$script" help --help > "$T/help"
 printf 'PASS help %s\n' "$script"
 actions=(build debug_build release_build asan_build)
 if [[ "$script" != "$A" ]]; then actions+=(v3_debug_build v3_release_build v3_build debug_all release_all v3_debug_deploy); fi
 if [[ "$script" == "$A" ]]; then actions+=(android_v2_debug_build android_v2_release_build android_v3_debug_build android_v3_release_build android_build); fi
 for action in "${actions[@]}"; do
  bash "$ROOT/source/$script.capture/$script" "$action" --dry-run > "$T/original"
  bash "$ROOT/candidates/$script" "$action" --dry-run > "$T/candidate"
  grep '^DRY_RUN ' "$T/original" | sed -E 's/artifact_prefix=server-v3-(debug|release)$/artifact_prefix=server-v3/' > "$T/expected"
  grep '^DRY_RUN ' "$T/candidate" > "$T/actual"
  diff -u "$T/expected" "$T/actual"
  if [[ "$action" == v3*build ]]; then grep -Fxq 'DRY_RUN artifact_prefix=server-v3' "$T/actual"; fi
  printf 'PASS original/candidate dry-run contracts %s %s\n' "$script" "$action"
 done
done
# New explicit neutral selection: combined debug/release retain per-build profile.
for action in debug_all release_all; do
 bash "$ROOT/candidates/$O" "$action" --server-version server-v3.fixture --dry-run > "$T/combined"
 grep -Fxq 'DRY_RUN artifact_prefix=server-v3' "$T/combined"
 grep -Fxq 'DRY_RUN server_version=server-v3.fixture' "$T/combined"
 printf 'PASS neutral explicit %s\n' "$action"
done
bash "$ROOT/candidates/$O" v3_debug_deploy --server-version server-v3.fixture --dry-run > "$T/deploy"
grep -Fxq 'DRY_RUN build_profile=debug' "$T/deploy"
set +e
bash "$ROOT/candidates/$O" v3_debug_deploy --server-version server-v3-release.legacy --dry-run > "$T/rejected" 2>&1
rc=$?
set -e
[[ "$rc" != 0 ]]
printf 'PASS deploy-only remains debug-only rc=%s\n' "$rc"
printf 'REGRESSION_PASS DATA=%s\n' "$T"
