#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d "$ROOT/tests/run.XXXXXX")"
export T
pass=0
ok() { pass=$((pass+1)); printf 'PASS %s\n' "$*"; }
die() { printf 'REJECT %s\n' "$*" >&2; exit 1; }
log() { :; }
sha256_file() { sha256sum "$1" | awk '{print $1}'; }
reject() {
  local rc
  set +e
  ( set -e; "$@" ) > "$T/rejection" 2>&1
  rc=$?
  set -e
  if (( rc == 0 )); then printf 'UNEXPECTED ACCEPT %s\n' "$*"; exit 1; fi
  printf 'EXPECTED_REJECT rc=%s %s\n' "$rc" "$(head -n1 "$T/rejection")"
}
G=cu-dev-pipeline-v17-dialogue-workspaces.sh
O=cu-dev-pipeline-v17-dialogue-workspaces_offline.sh
A=cu-dev-pipeline-v18-android-dialogue-api.sh
H=auto_build_offline_v3.sh
source "$ROOT/tests/$O.functions"
LOCAL_ARTIFACT_DIR="$T/linux/debug"; mkdir -p "$LOCAL_ARTIFACT_DIR"
REMOTE_ARTIFACT_DIR="$T/staging"; SERVER_VERSION=''; DEPLOY_EXPECT_PROFILE=debug; DEPLOY_EXPECT_STRIPPED=0
make_linux() {
  local name="$1" profile="${2:-debug}" strip=0
  [[ "$profile" != release ]] || strip=1
  printf '#!/bin/bash\n' > "$LOCAL_ARTIFACT_DIR/$name"; chmod +x "$LOCAL_ARTIFACT_DIR/$name"
  printf '%s\n' "$name" > "$LOCAL_ARTIFACT_DIR/LATEST"
  cat > "$LOCAL_ARTIFACT_DIR/$name.meta" <<EOF
artifact=$name
sha256=$(sha256_file "$LOCAL_ARTIFACT_DIR/$name")
size=$(stat -c '%s' "$LOCAL_ARTIFACT_DIR/$name")
bazel_target=//cu:server
build_profile=$profile
release_stripped=$strip
dialogue_pipeline_variant=v3
dialogue_pipeline_define=dialogue_pipeline_v3=true
latest_pointer=$LOCAL_ARTIFACT_DIR/LATEST
package_onnxruntime_selected=0
EOF
}
for kind in offline general; do
  if [[ "$kind" == general ]]; then source "$ROOT/tests/$G.functions"; fi
  for name in server-v3.20261019-abcdef01 server-v3-debug.legacy; do
    make_linux "$name"; validate_v3_debug_deploy_artifact; [[ "$V3_DEPLOY_PINNED_NAME" == "$name" ]]
    ok "$kind accepts $name"
  done
  name=server-v3.20261019-abcdef01
  make_linux "$name" release; reject validate_v3_debug_deploy_artifact; ok "$kind rejects release proof under same neutral name"
  for record in 'artifact=wrong' 'bazel_target=//cu:libdialogue_api.so' 'build_profile=release' 'release_stripped=1' 'dialogue_pipeline_variant=v2' 'dialogue_pipeline_define=dialogue_pipeline_v3=false' 'latest_pointer=/wrong/debug/LATEST' 'sha256=bad' 'size=999999' 'package_onnxruntime_selected=1'; do
    make_linux "$name"; key="${record%%=*}"; sed -i "s|^$key=.*|$record|" "$LOCAL_ARTIFACT_DIR/$name.meta"
    reject validate_v3_debug_deploy_artifact; ok "$kind rejects $key mismatch"
  done
  make_linux "$name"; rm -- "$LOCAL_ARTIFACT_DIR/$name.meta"; reject validate_v3_debug_deploy_artifact; ok "$kind rejects missing metadata"
  printf '../escape\n' > "$LOCAL_ARTIFACT_DIR/LATEST"; reject validate_v3_debug_deploy_artifact; ok "$kind rejects traversal"
done
source "$ROOT/tests/$O.functions"
name=server-v3.20261019-abcdef01
for bad in duplicate malformed; do
 make_linux "$name"
 if [[ "$bad" == duplicate ]]; then printf 'build_profile=debug\n' >> "$LOCAL_ARTIFACT_DIR/$name.meta"; else printf 'broken\n' > "$LOCAL_ARTIFACT_DIR/$name.meta"; fi
 reject validate_v3_debug_deploy_artifact; ok "offline rejects $bad metadata"
done
make_linux server-v2.legacy; reject validate_v3_debug_deploy_artifact; ok 'offline rejects V2 basename'
make_linux "$name"; validate_v3_debug_deploy_artifact
printf 'server-v3.other\n' > "$LOCAL_ARTIFACT_DIR/LATEST"; reject selected_deployment_name; ok 'pointer drift rejected before mutation'
make_linux "$name"; validate_v3_debug_deploy_artifact
BUILD_PIN_OUTPUT=1; DEPLOY_METADATA=1; printf 'changed' >> "$LOCAL_ARTIFACT_DIR/$name"
sed -i "s/^sha256=.*/sha256=$(sha256_file "$LOCAL_ARTIFACT_DIR/$name")/;s/^size=.*/size=$(stat -c '%s' "$LOCAL_ARTIFACT_DIR/$name")/" "$LOCAL_ARTIFACT_DIR/$name.meta"
reject prepare_selected_deployment; ok 'artifact tuple drift rejected'
for profile in debug release; do
 DEPLOY_EXPECT_PROFILE="$profile"; DEPLOY_EXPECT_STRIPPED=0; [[ "$profile" != release ]] || DEPLOY_EXPECT_STRIPPED=1
 make_linux "$name" "$profile"; validate_v3_debug_deploy_artifact; ok "combined $profile expected-profile proof retained"
done
DEPLOY_EXPECT_PROFILE=debug; DEPLOY_EXPECT_STRIPPED=0
# Actual helper CLI; Docker is fail-closed and records inspection attempts.
mkdir -p "$T/bin" "$T/helper/server" "$T/model"
cat > "$T/bin/docker" <<'EOF'
#!/usr/bin/env bash
printf '%s\n' "$*" >> "$T/docker.calls"
exit 91
EOF
chmod +x "$T/bin/docker"
export PATH="$T/bin:$PATH"
export PACKAGE_ROOT="$T/helper"
for name in server-v3.20261019-abcdef01 server-v3-debug.legacy; do
 make_linux "$name"; cp "$LOCAL_ARTIFACT_DIR/$name" "$LOCAL_ARTIFACT_DIR/$name.meta" "$PACKAGE_ROOT/server/"
 : > "$T/docker.calls"
 reject bash "$ROOT/candidates/$H" "$T/model" "$name" 9530 --expected-profile debug
 [[ -s "$T/docker.calls" ]]; ok "helper $name valid proof reaches mocked inspection"
done
: > "$T/docker.calls"
reject bash "$ROOT/candidates/$H" "$T/model" server-v3.20261019-abcdef01 9530
[[ -s "$T/docker.calls" ]]; ok 'helper neutral positional valid metadata reaches mocked inspection without optional flag'
name=server-v3.20261019-abcdef01
for record in 'build_profile=release' 'bazel_target=//cu:wrong' 'release_stripped=1' 'dialogue_pipeline_variant=v2' 'dialogue_pipeline_define=bad' 'latest_pointer=/wrong/release/LATEST' 'sha256=bad' 'size=9999' 'artifact=bad' 'package_onnxruntime_selected=1'; do
 make_linux "$name"; cp "$LOCAL_ARTIFACT_DIR/$name" "$LOCAL_ARTIFACT_DIR/$name.meta" "$PACKAGE_ROOT/server/"
 key="${record%%=*}"; sed -i "s|^$key=.*|$record|" "$PACKAGE_ROOT/server/$name.meta"
 : > "$T/docker.calls"; reject bash "$ROOT/candidates/$H" "$T/model" "$name" 9530
 [[ ! -s "$T/docker.calls" ]]; ok "helper neutral positional cannot bypass $key proof"
done
rm -- "$PACKAGE_ROOT/server/$name.meta"; : > "$T/docker.calls"
reject bash "$ROOT/candidates/$H" "$T/model" "$name" 9530
[[ ! -s "$T/docker.calls" ]]; ok 'helper neutral positional missing metadata rejects before Docker'
reject bash "$ROOT/candidates/$H" "$T/model" ../escape 9530; ok 'helper rejects traversal'
# Execute the literal remote sync heredoc locally, not through SSH.
make_linux "$name"; export REMOTE_DIR="$LOCAL_ARTIFACT_DIR" EXPECT_NAME="$name" EXPECT_V3="$name" EXPECT_PROFILE=debug EXPECT_STRIPPED=0 EXPECT_POINTER="$LOCAL_ARTIFACT_DIR/LATEST" SELECTED_EXPLICIT=''
export EXPECT_SHA="$(sha256_file "$LOCAL_ARTIFACT_DIR/$name")" EXPECT_SIZE="$(stat -c '%s' "$LOCAL_ARTIFACT_DIR/$name")"
bash "$ROOT/tests/remote-sync.sh"; ok 'actual sync proof accepts neutral debug'
EXPECT_PROFILE=release reject bash "$ROOT/tests/remote-sync.sh"; ok 'sync rejects cross-profile neutral metadata'
EXPECT_SHA=bad reject bash "$ROOT/tests/remote-sync.sh"; ok 'sync rejects SHA mismatch'
EXPECT_SIZE=999 reject bash "$ROOT/tests/remote-sync.sh"; ok 'sync rejects size mismatch'
printf 'server-v3.drift\n' > "$LOCAL_ARTIFACT_DIR/LATEST"; reject bash "$ROOT/tests/remote-sync.sh"; ok 'sync rejects pointer drift'
# Actual Android packaging uses only synthetic files and mocked tool outputs.
source "$ROOT/tests/$A.functions"
git() { if [[ "$*" == *'--abbrev-ref'* ]]; then printf 'fixture\n'; else printf 'abcdef0123456789abcdef0123456789abcdef01\n'; fi; }
date() { case "${1:-}" in '+%Y%m%d-%H%M%S') printf '20261019-140000\n';; *) command date "$@";; esac; }
validate_android_built_abi() { [[ -s "$1" ]]; }
file() { if [[ "$ANDROID_BUILD_PROFILE" == release ]]; then printf 'ELF shared object stripped\n'; else printf 'ELF shared object not stripped\n'; fi; }
readelf() { printf 'NEEDED [libc++_shared.so]\n'; }
BUILD_LOG_DIR="$T/logs"; mkdir -p "$BUILD_LOG_DIR"
PROJECT_DIR="$T/project"; ANDROID_ARTIFACT_PREFIX=libdialogue_api-android; ANDROID_ABI=arm64-v8a; ANDROID_API=21
ANDROID_NDK_HOME="$T/ndk"; mkdir -p "$ANDROID_NDK_HOME/sources/cxx-stl/llvm-libc++/libs/$ANDROID_ABI"
printf 'runtime\n' > "$ANDROID_NDK_HOME/sources/cxx-stl/llvm-libc++/libs/$ANDROID_ABI/libc++_shared.so"
printf 'Pkg.Revision = fixture\n' > "$ANDROID_NDK_HOME/source.properties"
ANDROID_BAZEL_TARGET=//cu:libdialogue_api.so; ANDROID_BAZEL_OUTPUT="$T/libdialogue_api.so"
printf 'stable library bytes\n' > "$ANDROID_BAZEL_OUTPUT"
BUILD_SERVER_IP=fixture; ANDROID_CROSSTOOL=fixture; ANDROID_HOST_CROSSTOOL=fixture; ANDROID_HOST_CC=fixture; ANDROID_HOST_CXX=fixture
ANDROID_RELEASE_STRIP_TOOL="$T/bin/strip-fixture"; printf '#!/usr/bin/env bash\nexit 0\n' > "$ANDROID_RELEASE_STRIP_TOOL"; chmod +x "$ANDROID_RELEASE_STRIP_TOOL"
MESSAGE=fixture; RELEASE_NOTE_FILE="$T/release-notes.txt"
neutral=libdialogue_api-android-v3-arm64-v8a-api21.20261019-140000-abcdef01.so
package() { package_android_artifact "$ANDROID_BAZEL_OUTPUT"; }
for action in android_v3_debug_build android_v3_release_build android_v2_debug_build android_v2_release_build android_build; do
 resolve_android_build_action "$action"; ANDROID_ARTIFACT_DIR="$T/$action"; package
 if [[ "$ANDROID_DIALOGUE_VERSION" == v3 ]]; then
   expected="$neutral"
 elif [[ "$ANDROID_COMPAT_ALIAS" == 1 ]]; then
   expected=libdialogue_api-android-arm64-v8a-api21.20261019-140000-abcdef01.so
 else
   expected="libdialogue_api-android-v2-$ANDROID_BUILD_PROFILE-arm64-v8a-api21.20261019-140000-abcdef01.so"
 fi
 [[ "$(cat "$ANDROID_ARTIFACT_DIR/LATEST-$ANDROID_DIALOGUE_VERSION-$ANDROID_BUILD_PROFILE")" == "$expected" ]]
 [[ "$(head -n1 "$ANDROID_ARTIFACT_DIR/$expected.meta")" == "artifact=$expected" ]]
 grep -Fxq "build_profile=$ANDROID_BUILD_PROFILE" "$ANDROID_ARTIFACT_DIR/$expected.meta"
 [[ "$(cat "$ANDROID_ARTIFACT_DIR/$expected")" == 'stable library bytes' ]]
 [[ -f "$ANDROID_ARTIFACT_DIR/$expected.runtime/libc++_shared.so" ]]
 if [[ "$ANDROID_COMPAT_ALIAS" == 1 ]]; then [[ "$(cat "$ANDROID_ARTIFACT_DIR/LATEST")" == "$expected" ]]; fi
 ok "actual Android package $action naming/version/profile/runtime/pointer"
 if [[ "$ANDROID_DIALOGUE_VERSION" == v2 ]]; then package; ok "$action retains same-identity overwrite behavior"; fi
done
ANDROID_ARTIFACT_DIR="$T/shared"; resolve_android_build_action android_v3_debug_build; package
printf 'old release pointer\n' > "$ANDROID_ARTIFACT_DIR/LATEST-v3-release"
before="$(sha256sum "$ANDROID_ARTIFACT_DIR/$neutral" "$ANDROID_ARTIFACT_DIR/$neutral.meta" "$ANDROID_ARTIFACT_DIR/$neutral.runtime/libc++_shared.so" "$ANDROID_ARTIFACT_DIR/LATEST-v3-debug" "$ANDROID_ARTIFACT_DIR/LATEST-v3-release")"
resolve_android_build_action android_v3_release_build; reject package
[[ "$before" == "$(sha256sum "$ANDROID_ARTIFACT_DIR/$neutral" "$ANDROID_ARTIFACT_DIR/$neutral.meta" "$ANDROID_ARTIFACT_DIR/$neutral.runtime/libc++_shared.so" "$ANDROID_ARTIFACT_DIR/LATEST-v3-debug" "$ANDROID_ARTIFACT_DIR/LATEST-v3-release")" ]]
ok 'cross-profile same-neutral-name collision preserves winner and pointers'
for profile in debug release; do
 resolve_android_build_action "android_v3_${profile}_build"
 for suffix in '' .meta .runtime; do
  for form in file symlink; do
   ANDROID_ARTIFACT_DIR="$T/occupied-$profile-${suffix:-artifact}-$form"; mkdir -p "$ANDROID_ARTIFACT_DIR"
   occupied="$ANDROID_ARTIFACT_DIR/$neutral$suffix"
   if [[ "$form" == symlink ]]; then
    # No permission changes: retain these cases for Linux if this executor lacks native links.
    if ! MSYS=winsymlinks:nativestrict ln -s "$T/absent" "$occupied" 2> "$T/symlink-error"; then
      printf 'UNRUN native symlink %s %s: %s
' "$profile" "${suffix:-artifact}" "$(head -n1 "$T/symlink-error")"
      continue
    fi
   else printf 'occupied\n' > "$occupied"; fi
   printf 'sentinel\n' > "$ANDROID_ARTIFACT_DIR/LATEST-v3-$profile"
   reject package
   [[ "$(cat "$ANDROID_ARTIFACT_DIR/LATEST-v3-$profile")" == sentinel ]]
   if [[ "$form" == symlink ]]; then [[ -L "$occupied" && "$(readlink "$occupied")" == "$T/absent" ]]; else [[ "$(cat "$occupied")" == occupied ]]; fi
   ok "$profile rejects occupied ${suffix:-artifact} $form without pointer change"
  done
 done
done
# Inject a competitor after early checks, immediately before publication.
for collision in artifact metadata runtime; do
 ANDROID_ARTIFACT_DIR="$T/race-$collision"; mkdir -p "$ANDROID_ARTIFACT_DIR"
 printf 'sentinel\n' > "$ANDROID_ARTIFACT_DIR/LATEST-v3-release"
 (
  ln() {
   local dest="${!#}"
   if [[ "$collision" == artifact && "$dest" == "$ANDROID_ARTIFACT_DIR/$neutral" ]] || [[ "$collision" == metadata && "$dest" == "$ANDROID_ARTIFACT_DIR/$neutral.meta" ]]; then
    printf 'racing winner\n' > "$dest"
   fi
   command ln "$@"
  }
  mkdir() {
   if [[ "$collision" == runtime && "${!#}" == "$ANDROID_ARTIFACT_DIR/$neutral.runtime" ]]; then
    command mkdir -p "${!#}"; printf 'racing winner\n' > "${!#}/sentinel"
   fi
   command mkdir "$@"
  }
  reject package
  [[ "$(cat "$ANDROID_ARTIFACT_DIR/LATEST-v3-release")" == sentinel ]]
  case "$collision" in
   artifact) [[ "$(cat "$ANDROID_ARTIFACT_DIR/$neutral")" == 'racing winner' ]];;
   metadata) [[ "$(cat "$ANDROID_ARTIFACT_DIR/$neutral.meta")" == 'racing winner' ]];;
   runtime) [[ "$(cat "$ANDROID_ARTIFACT_DIR/$neutral.runtime/sentinel")" == 'racing winner' ]];;
  esac
 )
 ok "atomic $collision collision preserves racing winner/pointer"
done
printf 'TOTAL_PASS=%s DATA=%s\n' "$pass" "$T"
