"""Extract actual source functions without executing capture top levels."""
from pathlib import Path
import re
r=Path(__file__).resolve().parent.parent
spec={
 'cu-dev-pipeline-v17-dialogue-workspaces.sh':['resolve_v3_build_action','select_build_profile','validate_v3_debug_deploy_artifact'],
 'cu-dev-pipeline-v17-dialogue-workspaces_offline.sh':['resolve_v3_build_action','resolve_v3_debug_deploy_action','select_build_profile','validate_v3_debug_deploy_artifact','prepare_selected_deployment','selected_deployment_name','validate_fresh_build_name'],
 'cu-dev-pipeline-v18-android-dialogue-api.sh':['resolve_android_build_action','package_android_artifact'],
 'auto_build_offline_v3.sh':['validate_profile_metadata','verify_publication_target'],
}
for n,funcs in spec.items():
 s=(r/'candidates'/n).read_text(encoding='utf-8')
 out=[]
 for f in funcs:
  m=re.search(r'^'+f+r'\(\) \{\n.*?^\}',s,re.M|re.S)
  assert m, f
  out.append(m.group())
 with (r/'tests'/f'{n}.functions').open("w", encoding="utf-8", newline="\n") as output:
  output.write('\n\n'.join(out)+'\n')
s=(r/'candidates/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh').read_text(encoding='utf-8')
for func,label in [('sync_artifacts','sync'),('verify_remote_auto_build_deploy','verify')]:
 start=s.index(func+'() {')
 block=s[s.index("<<'EOS'",start)+len("<<'EOS'"):]
 block=block[:block.index('\nEOS\n')]
 with (r/'tests'/f'remote-{label}.sh').open("w", encoding="utf-8", newline="\n") as output:
  output.write(block.lstrip('\n'))
# Execute the exact generation assignments (not a reimplementation) with fixture inputs.
for n in list(spec)[:2]:
 s=(r/'candidates'/n).read_text(encoding='utf-8')
 lines=[line.strip() for line in s.splitlines() if line.strip().startswith('name="${ARTIFACT_PREFIX}.') or line.strip().startswith('name="${BUILD_REQUESTED_NAME:-${ARTIFACT_PREFIX}.')]
 assert len(lines)==1, lines
 with (r/'tests'/f'{n}.name').open("w", encoding="utf-8", newline="\n") as output:
  output.write(lines[0]+'\n')
