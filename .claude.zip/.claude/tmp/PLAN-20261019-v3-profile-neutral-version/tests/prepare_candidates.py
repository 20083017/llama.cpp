from pathlib import Path
r=Path(__file__).resolve().parent.parent
names=['cu-dev-pipeline-v17-dialogue-workspaces.sh','cu-dev-pipeline-v17-dialogue-workspaces_offline.sh','cu-dev-pipeline-v18-android-dialogue-api.sh','auto_build_offline_v3.sh']
for n in names:
 s=(r/'source'/f'{n}.capture'/n).read_text(encoding='utf-8')
 def change(old,new):
  global s
  assert old in s, old
  s=s.replace(old,new)
 if n.startswith('cu-dev-pipeline-v17'):
  change('ARTIFACT_PREFIX="server-v3-$V3_BUILD_PROFILE"','ARTIFACT_PREFIX="server-v3"')
 if '_offline.sh' in n:
  for profile in ['${EXPECT_PROFILE}','${DEPLOY_EXPECT_PROFILE}','debug','release']:
   change('^server-v3-'+profile+'[.]','^server-v3(-'+profile+')?[.]')
  change('^server-v3-(debug|release)[.]','^server-v3(-(debug|release))?[.]')
  change('server-v3-debug.TIMESTAMP-SHA','server-v3.TIMESTAMP-SHA')
  change('server-v3-release.fresh-release','server-v3.fresh-release')
  change('release_all server version must match V3 release namespace server-v3-release.','release_all server version must be neutral server-v3.* or legacy server-v3-release.*')
  change('server version must match V3 debug namespace server-v3-debug.','server version must be neutral server-v3.* or legacy server-v3-debug.*')
 if n=='auto_build_offline_v3.sh':
  change('^server-v3-${expected_profile}[.]','^server-v3(-${expected_profile})?[.]')
  change('# Optional internal proof gate; old no-metadata positional deployments remain valid.','# Neutral V3 positional names require profile proof; legacy tagged calls retain their existing gate.')
  change('if (( publish_only )) || [[ "$seen" == *\'|--expected-profile|\'* ]]; then','if (( publish_only )) || [[ "$seen" == *\'|--expected-profile|\'* || "$server" == server-v3.* ]]; then')
 if 'v18-android' in n:
  change('  else\n    artifact_stem="${ANDROID_ARTIFACT_PREFIX}-${ANDROID_DIALOGUE_VERSION}-${ANDROID_BUILD_PROFILE}-${ANDROID_ABI}-api${ANDROID_API}"','  elif [[ "$ANDROID_DIALOGUE_VERSION" == "v3" ]]; then\n    artifact_stem="${ANDROID_ARTIFACT_PREFIX}-${ANDROID_DIALOGUE_VERSION}-${ANDROID_ABI}-api${ANDROID_API}"\n  else\n    artifact_stem="${ANDROID_ARTIFACT_PREFIX}-${ANDROID_DIALOGUE_VERSION}-${ANDROID_BUILD_PROFILE}-${ANDROID_ABI}-api${ANDROID_API}"')
  change('  mkdir -p "$ANDROID_ARTIFACT_DIR"\n\n  cp -f "$src" "$tmp"','''  mkdir -p "$ANDROID_ARTIFACT_DIR"
  if [[ "$ANDROID_DIALOGUE_VERSION" == "v3" ]]; then
    # Profiles share this root. Never replace an occupied neutral identity.
    local occupied
    for occupied in "$dst" "$dst.meta" "$dst.runtime"; do
      [[ ! -e "$occupied" && ! -L "$occupied" ]] || die "Android V3 package identity already exists: $occupied"
    done
  fi

  cp -f "$src" "$tmp"''')
  change('  mv -f "$tmp" "$dst"\n  sha="$(sha256_file "$dst")"','''  if [[ "$ANDROID_DIALOGUE_VERSION" == "v3" ]]; then
    # Atomic no-replacement publication also protects racing same-name profiles.
    if ! ln -T -- "$tmp" "$dst"; then
      rm -f -- "$tmp"
      die "Android V3 artifact publication collision: $dst"
    fi
    rm -f -- "$tmp"
  else
    mv -f "$tmp" "$dst"
  fi
  sha="$(sha256_file "$dst")"''')
  change('    mkdir -p "$runtime_dir"\n    cp -f "$libcxx_src" "$runtime_dir/libc++_shared.so"','''    if [[ "$ANDROID_DIALOGUE_VERSION" == "v3" ]]; then
      mkdir -- "$runtime_dir" || die "Android V3 runtime publication collision: $runtime_dir"
    else
      mkdir -p "$runtime_dir"
    fi
    cp -f "$libcxx_src" "$runtime_dir/libc++_shared.so"''')
  change('  mv -f "$metadata_tmp" "$dst.meta"','''  if [[ "$ANDROID_DIALOGUE_VERSION" == "v3" ]]; then
    if ! ln -T -- "$metadata_tmp" "$dst.meta"; then
      rm -f -- "$metadata_tmp"
      die "Android V3 metadata publication collision: $dst.meta"
    fi
    rm -f -- "$metadata_tmp"
  else
    mv -f "$metadata_tmp" "$dst.meta"
  fi''')
 (r/'candidates'/n).write_text(s,encoding='utf-8',newline='\n')
p=r.parents[1]/'skills/wtp184-server-session/SKILL.md'
s=p.read_text(encoding='utf-8')
s=s.replace('use V3-specific logs/artifact names/metadata,','use V3-specific logs/metadata and profile-neutral `server-v3.<timestamp>-<git>` artifact/version names in the existing debug/release folders,')
s=s.replace('Explicit matrix actions identify `v2|v3` and `debug|release` in build logs, artifact names and metadata.','Explicit matrix actions identify `v2|v3` and `debug|release` in build logs and metadata. V2 matrix artifact names retain their profile tags. V3 artifact/version names are profile-neutral: `libdialogue_api-android-v3-<ABI>-api<API>.<timestamp>-<git8>.so`; the stable library remains `libdialogue_api.so`. V3 profiles share the artifact root: an occupied artifact, `.meta` or `.runtime` identity is rejected without replacement or pointer advancement.')
p.write_text(s,encoding='utf-8',newline='\n')
