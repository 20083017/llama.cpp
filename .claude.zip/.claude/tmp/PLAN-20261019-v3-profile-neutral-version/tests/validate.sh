#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
printf 'PHASE2_VALIDATION start=%s\n' "$(date -Is)"
printf 'COMMAND python -I tests/extract_functions.py\n'
python -I "$ROOT/tests/extract_functions.py"
printf 'EXIT=0\n'
for path in "$ROOT"/candidates/*.sh "$ROOT"/tests/*.sh "$ROOT"/tests/*.functions; do
 printf 'COMMAND bash -n %s\n' "$path"
 bash -n "$path"
 printf 'EXIT=0\n'
done
if command -v shellcheck >/dev/null 2>&1; then
 printf 'COMMAND shellcheck candidates/*.sh tests/*.sh\n'
 shellcheck "$ROOT"/candidates/*.sh "$ROOT"/tests/*.sh
 printf 'EXIT=0\n'
else
 printf 'UNRUN shellcheck: not installed; no installation attempted\n'
fi
printf 'COMMAND python -I -m py_compile tests/prepare_candidates.py tests/extract_functions.py\n'
python -I -m py_compile "$ROOT/tests/prepare_candidates.py" "$ROOT/tests/extract_functions.py"
printf 'EXIT=0\n'
printf 'COMMAND bash tests/fixtures.sh\n'
bash "$ROOT/tests/fixtures.sh"
printf 'EXIT=0\n'
printf 'COMMAND bash tests/fixtures.sh [repeat with fresh task-only inputs]\n'
bash "$ROOT/tests/fixtures.sh"
printf 'EXIT=0\n'
printf 'COMMAND bash tests/additional.sh
'
bash "$ROOT/tests/additional.sh"
printf 'EXIT=0
'
printf 'COMMAND bash tests/regression.sh\n'
bash "$ROOT/tests/regression.sh"
printf 'EXIT=0\n'
printf 'PHASE2_VALIDATION end=%s\n' "$(date -Is)"
