set -Eeuo pipefail

artifact="$REMOTE_DIR/$EXPECT_NAME"
[[ -f "$artifact" ]] || { echo "VERIFY_ERROR=REMOTE_ARTIFACT_MISSING"; exit 41; }
remote_size="$(stat -c '%s' "$artifact")"
remote_sha="$(sha256sum "$artifact" | awk '{print $1}')"
echo "REMOTE_ARTIFACT=$artifact"
echo "REMOTE_SIZE=$remote_size"
echo "REMOTE_SHA256=$remote_sha"
[[ "$remote_size" == "$EXPECT_SIZE" ]] || { echo "VERIFY_ERROR=REMOTE_SIZE_MISMATCH"; exit 42; }
[[ "$remote_sha" == "$EXPECT_SHA" ]] || { echo "VERIFY_ERROR=REMOTE_SHA_MISMATCH"; exit 43; }

if docker info >/dev/null 2>&1; then
  docker_cmd=(docker)
elif command -v sudo >/dev/null 2>&1 && sudo -n docker info >/dev/null 2>&1; then
  docker_cmd=(sudo -n docker)
else
  echo "VERIFY_ERROR=DOCKER_UNAVAILABLE"
  exit 44
fi

mapfile -t rows < <("${docker_cmd[@]}" ps --filter "publish=${TEST_PORT}" --format '{{.ID}}|{{.Names}}|{{.Image}}|{{.Ports}}')
echo "VERIFY_CONTAINER_COUNT=${#rows[@]}"
printf 'VERIFY_CONTAINER=%s\n' "${rows[@]}"
(( ${#rows[@]} == 1 )) || { echo "VERIFY_ERROR=CONTAINER_COUNT"; exit 45; }

IFS='|' read -r cid cname cimage cports <<< "${rows[0]}"
[[ "$cid" =~ ^[a-f0-9]{12}$ ]] || { echo "VERIFY_ERROR=INVALID_ID"; exit 45; }
bindings="$("${docker_cmd[@]}" inspect --format '{{range $p, $bs := .HostConfig.PortBindings}}{{range $bs}}{{printf "%s:%s\n" $p .HostPort}}{{end}}{{end}}' "$cid")"
found=0
while IFS= read -r binding; do
  [[ -n "$binding" ]] || continue
  [[ "$binding" == "8080/tcp:$TEST_PORT" ]] || { echo "VERIFY_ERROR=PORT_BINDING"; exit 45; }
  found=1
done <<< "$bindings"
(( found )) || { echo "VERIFY_ERROR=PORT_BINDING_MISSING"; exit 45; }
if [[ -n "$EXPECT_V3" ]]; then
  [[ "$EXPECT_NAME" == "$EXPECT_V3" && "$EXPECT_NAME" =~ ^server-v3(-(debug|release))?[.][A-Za-z0-9._-]+$ ]] || { echo "VERIFY_ERROR=V3_NAME_MISMATCH"; exit 45; }
  ownership="$("${docker_cmd[@]}" inspect --format '{{.State.Running}}|{{index .Config.Labels "cu.dev.slot"}}|{{index .Config.Labels "cu.dev.pipeline"}}' "$cid")"
  [[ "$ownership" == "true|$TEST_PORT|v3" ]] || { echo "VERIFY_ERROR=V3_OWNERSHIP"; exit 45; }
  echo "VERIFIED_NAMESPACE=server-v3"
fi
container_size="$("${docker_cmd[@]}" exec "$cid" stat -c '%s' /usr/bin/cu-server)"
[[ "$container_size" == "$EXPECT_SIZE" ]] || { echo "VERIFY_ERROR=CONTAINER_BINARY_SIZE_MISMATCH"; exit 46; }
container_sha="$("${docker_cmd[@]}" exec "$cid" sha256sum /usr/bin/cu-server | awk '{print $1}')"
version="$("${docker_cmd[@]}" exec "$cid" sh -c 'cat /runtime/version.txt 2>/dev/null || true' | tr -d '\r\n')"
core_pattern="$("${docker_cmd[@]}" exec "$cid" cat /proc/sys/kernel/core_pattern 2>/dev/null || true)"
core_limits="$("${docker_cmd[@]}" exec "$cid" sh -c 'printf "soft=%s hard=%s" "$(ulimit -Sc)" "$(ulimit -Hc)"' 2>/dev/null || true)"

echo "CONTAINER_ID=$cid"
echo "CONTAINER_NAME=$cname"
echo "CONTAINER_IMAGE=$cimage"
echo "CONTAINER_SHA256=$container_sha"
echo "CONTAINER_VERSION=$version"
echo "CORE_PATTERN=$core_pattern"
echo "CORE_LIMITS=$core_limits"

[[ "$container_sha" == "$EXPECT_SHA" ]] || { echo "VERIFY_ERROR=CONTAINER_BINARY_SHA_MISMATCH"; exit 46; }
[[ "$version" == "$EXPECT_NAME" ]] || { echo "VERIFY_ERROR=VERSION_TXT_MISMATCH"; exit 47; }

echo "VERIFY_OK=1"