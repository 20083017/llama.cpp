#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
T="$(mktemp -d "$ROOT/tests/additional.XXXXXX")"
die() { printf 'REJECT %s\n' "$*" >&2; exit 1; }
fail() { die "$@"; }
log() { :; }
reject() {
 local rc
 set +e
 (set -e; "$@") > "$T/rejection" 2>&1
 rc=$?
 set -e
 [[ "$rc" != 0 ]] || { printf 'UNEXPECTED ACCEPT %s\n' "$*"; exit 1; }
 printf 'EXPECTED_REJECT rc=%s %s\n' "$rc" "$(head -n1 "$T/rejection")"
}
G=cu-dev-pipeline-v17-dialogue-workspaces.sh
O=cu-dev-pipeline-v17-dialogue-workspaces_offline.sh
H=auto_build_offline_v3.sh
V3_PROJECT_DIR="$T/project"; V3_THIRD_PARTY_DIR="$T/project/third_party"
V3_ARTIFACT_ROOT="$T/v3"; V3_RELEASE_NOTE_FILE="$T/notes"; BUILD_LOG_DIR="$T/logs"
BUILD_REQUESTED_NAME=''; ts=20261019-140000; git_short=abcdef01
for script in "$G" "$O"; do
 source "$ROOT/tests/$script.functions"
 for action in v3_debug_build v3_release_build v3_build; do
  resolve_v3_build_action "$action"
  source "$ROOT/tests/$script.name"
  [[ "$name" == server-v3.20261019-140000-abcdef01 ]]
  [[ "$LOCAL_ARTIFACT_DIR" == "$V3_ARTIFACT_ROOT/$V3_BUILD_PROFILE" ]]
  printf 'PASS actual Linux name assignment %s %s name=%s\n' "$script" "$action" "$name"
 done
done
ARTIFACT_PREFIX=server-v3; LOCAL_ARTIFACT_DIR="$T/fresh"; mkdir -p "$LOCAL_ARTIFACT_DIR"
validate_fresh_build_name server-v3.fresh
reject validate_fresh_build_name ../escape
reject validate_fresh_build_name server-v2.fresh
printf 'occupied\n' > "$LOCAL_ARTIFACT_DIR/server-v3.occupied.meta"
reject validate_fresh_build_name server-v3.occupied
printf 'PASS Linux fresh guards\n'
# Helper publication executes actual metadata + selected tuple + runtime identity checks.
source "$ROOT/tests/$H.functions"
mkdir -p "$T/helper/server"; cd -- "$T/helper"
expected_profile=debug; expected_stripped=0; verified_id=aaaaaaaaaaaa
owned_port_id=''; owned_port_running=''
inspect_owned_port() { owned_port_id=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa; owned_port_running=true; }
docker() {
 [[ "$1" == exec ]] || exit 98
 case "$3" in
  stat) printf '%s\n' "$expected_size";;
  sha256sum) printf '%s  /usr/bin/cu-server\n' "$expected_sha";;
  cat) printf '%s\n' "${runtime_version:-$server}";;
  *) exit 98;;
 esac
}
for server in server-v3.neutral server-v3-debug.legacy; do
 printf '#!/bin/bash\n' > "server/$server"; chmod +x "server/$server"
 expected_sha="$(sha256sum "server/$server" | awk '{print $1}')"; expected_size="$(stat -c '%s' "server/$server")"
 cat > "server/$server.meta" <<EOF
artifact=$server
sha256=$expected_sha
size=$expected_size
bazel_target=//cu:server
build_profile=debug
release_stripped=0
dialogue_pipeline_variant=v3
dialogue_pipeline_define=dialogue_pipeline_v3=true
package_onnxruntime_selected=0
latest_pointer=/fixture/debug/LATEST
EOF
 verify_publication_target
 printf 'PASS actual helper publication proof %s\n' "$server"
 runtime_version=wrong reject verify_publication_target
 old_sha="$expected_sha"; expected_sha=bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb; reject verify_publication_target; expected_sha="$old_sha"
 old_size="$expected_size"; expected_size=999; reject verify_publication_target; expected_size="$old_size"
done
# The controller's literal runtime verification heredoc, using synthetic Docker responses.
docker() {
 case "$1" in
  info) return 0;;
  ps) printf 'aaaaaaaaaaaa|fixture|image|8080/tcp\n';;
  inspect)
   if [[ "$*" == *HostConfig.PortBindings* ]]; then printf '8080/tcp:9530\n'; else printf 'true|9530|v3\n'; fi;;
  exec)
   case "$3" in
    stat) printf '%s\n' "$EXPECT_SIZE";;
    sha256sum) printf '%s  /usr/bin/cu-server\n' "$EXPECT_SHA";;
    sh) if [[ "$*" == *version.txt* ]]; then printf '%s\n' "${RUNTIME_VERSION:-$EXPECT_NAME}"; else printf 'soft=0 hard=0\n'; fi;;
    cat) printf 'core\n';;
    *) exit 98;;
   esac;;
  *) exit 98;;
 esac
}
export -f docker
export REMOTE_DIR="$T/helper/server" TEST_PORT=9530 EXPECT_NAME=server-v3.neutral EXPECT_V3=server-v3.neutral
export EXPECT_SHA="$(sha256sum "$REMOTE_DIR/$EXPECT_NAME" | awk '{print $1}')" EXPECT_SIZE="$(stat -c '%s' "$REMOTE_DIR/$EXPECT_NAME")"
bash "$ROOT/tests/remote-verify.sh"
printf 'PASS actual runtime verify neutral name and exact version\n'
RUNTIME_VERSION=wrong reject bash "$ROOT/tests/remote-verify.sh"
printf 'PASS actual runtime verify rejects version drift\n'
printf 'ADDITIONAL_PASS DATA=%s\n' "$T"
