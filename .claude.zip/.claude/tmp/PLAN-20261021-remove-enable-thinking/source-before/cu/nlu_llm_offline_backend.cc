// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_llm_offline_backend.h"

#include <cstddef>
#include <cstring>
#include <memory>
#include <string>
#include <utility>

#include "base/logging.h"
#include "cu/llm_protocol.h"

namespace nlptk {
namespace {

const int kDefaultMaxResponseBytes = 1024 * 1024;
const int kMaximumResponseBytes = 16 * 1024 * 1024;

// One invocation owns this buffer until the synchronous hook returns.
// Callbacks within an invocation are serialized by the provider contract.
struct OutputBuffer {
  explicit OutputBuffer(size_t cap) : limit(cap), failure(nullptr) {}
  const size_t limit;
  const char* failure;
  std::string text;
};

void CollectOutput(const char* chunk, void* context) noexcept {
  if (context == nullptr) return;
  OutputBuffer* output = static_cast<OutputBuffer*>(context);
  if (output->failure != nullptr) return;
  if (chunk == nullptr) {
    output->failure = "null_chunk";
    return;
  }
  // Inspect at most remaining+1 bytes, not strlen on unbounded output.
  // Chunk memory must be a valid borrowed NUL-terminated string.
  const size_t remaining = output->limit - output->text.size();
  size_t bytes = 0u;
  while (bytes <= remaining && chunk[bytes] != '\0') ++bytes;
  if (bytes > remaining) {
    output->failure = "output_too_large";
    return;
  }
  try {
    output->text.append(chunk, bytes);  // UTF8 may span chunks; parse later.
  } catch (...) {
    // No allocating diagnostic or exception escapes the callback boundary.
    output->failure = "allocation_failed";
  }
}

std::string SafeRequestId(const std::string& value) {
  std::string safe = value.substr(0u, 128u);
  for (size_t i = 0u; i < safe.size(); ++i) {
    const unsigned char byte = static_cast<unsigned char>(safe[i]);
    if (!((byte >= 'a' && byte <= 'z') || (byte >= 'A' && byte <= 'Z') ||
          (byte >= '0' && byte <= '9') || byte == '_' || byte == '-' ||
          byte == '.')) safe[i] = '_';
  }
  return safe;
}

class OfflineBackend : public NluLlmBackend {
 public:
  OfflineBackend(std::unique_ptr<LlmProtocol> protocol,
                 NluLlmInferenceBinding binding, size_t limit)
      : protocol_(std::move(protocol)), binding_(binding), limit_(limit) {}

  int Process(const NluLlmRequest& request, Json::Value* result) const override {
    if (result == nullptr) return -1;
    *result = Json::Value();
    OutputBuffer output(limit_);
    const char* stage = "input";
    const char* reason = "invalid_input";
    const char* provider_status = "not_called";
    const char* schema_detail = "not_parsed";
    try {
      Json::Value payload;
      if (protocol_->BuildRequest(request, &payload)) {
        stage = "request";
        reason = "serialization_failed";
        const std::string serialized = SerializeLlmRequest(payload);
        stage = "provider";
        reason = "provider_exception";
        provider_status = "exception";
        const int code = binding_.inference(serialized.c_str(),
            binding_.owner_context, &output, &CollectOutput);
        provider_status = code == 0 ? "success" : "error";
        if (code != 0) {
          reason = "provider_error";
        } else if (output.failure != nullptr) {
          stage = "collection";
          reason = output.failure;
        } else if (output.text.empty()) {
          stage = "collection";
          reason = "empty_output";
        } else {
          stage = "content";
          reason = "content_schema";
          const ContentParseResult parsed = protocol_->ParseResponse(output.text, result);
          schema_detail = ContentParseResultName(parsed);
          // Existing diagnostic carrier, including parse errors, as in HTTP.
          (*result)["nlu_result"] = output.text;
          if (parsed == kContentSuccess) return 0;
        }
      }
    } catch (...) {
      // Defensive containment, not async/lifetime support. A compliant provider
      // has finished all callbacks even on failure. Never publish partial text.
      *result = Json::Value();
      if (std::strcmp(stage, "provider") != 0)
        reason = "allocation_or_codec_exception";
    }
    LOG(ERROR) << "component=nlu06b_offline event=nlu06b_offline_failure"
               << " stage=" << stage << " outcome=error reason=" << reason
               << " request_id=" << SafeRequestId(request.request_id)
               << " backend=offline model=" << protocol_->model_identity()
               << " protocol=" << protocol_->protocol_identity()
               << " provider_status=" << provider_status
               << " schema_detail=" << schema_detail
               << " content_bytes=" << output.text.size()
               << " max_response_bytes=" << limit_;
    return -1;
  }

  const char* result_source() const override { return "nlu06b"; }

 private:
  const std::unique_ptr<LlmProtocol> protocol_;
  const NluLlmInferenceBinding binding_;
  const size_t limit_;
};

}  // namespace

std::unique_ptr<NluLlmBackend> CreateNluLlmOfflineBackend(
    const Json::Value& config, const std::string& base_path,
    NluLlmInferenceBinding binding) {
  if (binding.inference == nullptr || !config.isObject() ||
      config.isMember("version") || config.isMember("response_protocol") ||
      config.isMember("response_flag_prefix") || config.isMember("profile") ||
      config.isMember("profile_catalog_path"))
    return std::unique_ptr<NluLlmBackend>();
  int limit = kDefaultMaxResponseBytes;
  if (config.isMember("Offline")) {
    const Json::Value& offline = config["Offline"];
    if (!offline.isObject()) return std::unique_ptr<NluLlmBackend>();
    const Json::Value::Members names = offline.getMemberNames();
    for (size_t i = 0u; i < names.size(); ++i)
      if (names[i] != "max_response_bytes")
        return std::unique_ptr<NluLlmBackend>();
    if (offline.isMember("max_response_bytes")) {
      if (!offline["max_response_bytes"].isInt())
        return std::unique_ptr<NluLlmBackend>();
      limit = offline["max_response_bytes"].asInt();
      if (limit < 1 || limit > kMaximumResponseBytes)
        return std::unique_ptr<NluLlmBackend>();
    }
  }
  std::unique_ptr<LlmProtocol> protocol = CreateLlmProtocol(config["Model"], base_path);
  if (!protocol) return std::unique_ptr<NluLlmBackend>();
  return std::unique_ptr<NluLlmBackend>(new OfflineBackend(
      std::move(protocol), binding, static_cast<size_t>(limit)));
}

}  // namespace nlptk
