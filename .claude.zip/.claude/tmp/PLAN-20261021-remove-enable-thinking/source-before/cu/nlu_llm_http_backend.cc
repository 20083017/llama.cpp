// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_llm_http_backend.h"

#include "cu/llm_protocol.h"

#include <curl/curl.h>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <fcntl.h>
#include <limits>
#include <memory>
#include <mutex>
#include <sys/stat.h>
#include <unistd.h>
#include <string>
#include <utility>
#include <vector>

#include "base/logging.h"
#include "common/curl.h"
#include "common/utils.h"
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
#include "timeline/time_line.h"
#endif

namespace nlptk {
namespace {

const int kDefaultConnectTimeoutMs = 5000;
const int kDefaultTotalTimeoutMs = 30000;
const int kDefaultMaxResponseBytes = 1024 * 1024;
const int kMaximumResponseBytes = 16 * 1024 * 1024;
const int kMaximumTimeoutMs = 10 * 60 * 1000;
const int kMaximumDiagnosticCaptureEntries = 10000;
const int kMaximumDiagnosticCaptureContentBytes = 1024 * 1024;
const size_t kMaximumLoggedEndpointBytes = 256u;
const int kHttpResponseTooLarge = -2;
struct HttpBackendConfig {
  std::string endpoint;
  std::string api_key;
  int connect_timeout_ms;
  int total_timeout_ms;
  int max_response_bytes;
  bool diagnostic_capture_enabled;
  std::string diagnostic_capture_output_path;
  std::string diagnostic_capture_request_id_prefix;
  int diagnostic_capture_max_entries;
  int diagnostic_capture_max_content_bytes;
};

const char* HttpStatusCategory(long status_code) {
  if (status_code >= 200 && status_code < 300) {
    return "2xx";
  }
  if (status_code >= 400 && status_code < 500) {
    return "4xx";
  }
  if (status_code >= 500 && status_code < 600) {
    return "5xx";
  }
  return "other";
}

bool ReadRequiredString(const Json::Value& config, const char* name,
                        std::string* output) {
  if (output == nullptr || !config.isMember(name) ||
      !config[name].isString()) {
    return false;
  }
  *output = config[name].asString();
  return !output->empty();
}

bool ReadOptionalInt(const Json::Value& config, const char* name,
                     int default_value, int minimum, int maximum, int* output) {
  if (output == nullptr) {
    return false;
  }
  *output = default_value;
  if (!config.isMember(name)) {
    return true;
  }
  if (!config[name].isInt()) {
    return false;
  }
  const int value = config[name].asInt();
  if (value < minimum || value > maximum) {
    return false;
  }
  *output = value;
  return true;
}

bool IsDiagnosticRequestIdPrefix(const std::string& value) {
  if (value.empty() || value.size() > 64u) {
    return false;
  }
  for (size_t i = 0; i < value.size(); ++i) {
    const unsigned char current = static_cast<unsigned char>(value[i]);
    if (!std::isalnum(current) && value[i] != '_' && value[i] != '-') {
      return false;
    }
  }
  return true;
}

bool ParseConfig(const Json::Value& config, HttpBackendConfig* output) {
  if (output == nullptr || !config.isObject()) {
    return false;
  }
  HttpBackendConfig parsed;
  // Only execution-specific keys belong in OpenAIHttp. No flat/profile or
  // legacy format alias is accepted by the canonical factory signatures.
  const char* allowed[] = {"endpoint", "api_key_env", "connect_timeout_ms",
      "total_timeout_ms", "max_response_bytes", "diagnostic_capture_enabled",
      "diagnostic_capture_output_path", "diagnostic_capture_request_id_prefix",
      "diagnostic_capture_max_entries", "diagnostic_capture_max_content_bytes"};
  const Json::Value::Members names = config.getMemberNames();
  for (size_t i = 0u; i < names.size(); ++i) {
    bool known = false;
    for (size_t j = 0u; j < sizeof(allowed) / sizeof(allowed[0]); ++j)
      if (names[i] == allowed[j]) known = true;
    if (!known) return false;
  }
  const Json::Value& effective = config;
  std::string configured_endpoint;
  if (!ReadRequiredString(effective, "endpoint", &configured_endpoint))
    return false;
  if (configured_endpoint.size() >= 4 && configured_endpoint[0] == '$' &&
      configured_endpoint[1] == '{' && configured_endpoint.back() == '}') {
    parsed.endpoint = clu::GetEnv(configured_endpoint);
  } else {
    parsed.endpoint = configured_endpoint;
  }
  if (parsed.endpoint.compare(0, 7, "http://") != 0 &&
      parsed.endpoint.compare(0, 8, "https://") != 0) {
    return false;
  }

  parsed.api_key.clear();
  if (effective.isMember("api_key_env")) {
    if (!effective["api_key_env"].isString()) {
      return false;
    }
    const std::string key_name = effective["api_key_env"].asString();
    if (!key_name.empty()) {
      parsed.api_key = clu::GetEnv(key_name);
      if (parsed.api_key.empty()) {
        return false;
      }
    }
  }
  if (!ReadOptionalInt(effective, "connect_timeout_ms", kDefaultConnectTimeoutMs,
                       1, kMaximumTimeoutMs, &parsed.connect_timeout_ms) ||
      !ReadOptionalInt(effective, "total_timeout_ms", kDefaultTotalTimeoutMs, 1,
                       kMaximumTimeoutMs, &parsed.total_timeout_ms) ||
      !ReadOptionalInt(effective, "max_response_bytes", kDefaultMaxResponseBytes,
                       1, kMaximumResponseBytes,
                       &parsed.max_response_bytes)) {
    return false;
  }
  if (parsed.total_timeout_ms < parsed.connect_timeout_ms) {
    return false;
  }
  parsed.diagnostic_capture_enabled = false;
  if (effective.isMember("diagnostic_capture_enabled")) {
    if (!effective["diagnostic_capture_enabled"].isBool()) {
      return false;
    }
    parsed.diagnostic_capture_enabled =
        effective["diagnostic_capture_enabled"].asBool();
  }
  parsed.diagnostic_capture_output_path.clear();
  if (effective.isMember("diagnostic_capture_output_path")) {
    if (!effective["diagnostic_capture_output_path"].isString()) {
      return false;
    }
    parsed.diagnostic_capture_output_path =
        effective["diagnostic_capture_output_path"].asString();
  }
  parsed.diagnostic_capture_request_id_prefix.clear();
  if (effective.isMember("diagnostic_capture_request_id_prefix")) {
    if (!effective["diagnostic_capture_request_id_prefix"].isString()) {
      return false;
    }
    parsed.diagnostic_capture_request_id_prefix =
        effective["diagnostic_capture_request_id_prefix"].asString();
  }
  if (!ReadOptionalInt(effective, "diagnostic_capture_max_entries", 0, 0,
                       kMaximumDiagnosticCaptureEntries,
                       &parsed.diagnostic_capture_max_entries) ||
      !ReadOptionalInt(effective, "diagnostic_capture_max_content_bytes", 0, 0,
                       kMaximumDiagnosticCaptureContentBytes,
                       &parsed.diagnostic_capture_max_content_bytes)) {
    return false;
  }
  if (parsed.diagnostic_capture_enabled &&
      (parsed.diagnostic_capture_output_path.empty() ||
       parsed.diagnostic_capture_output_path[0] != '/' ||
       !IsDiagnosticRequestIdPrefix(
           parsed.diagnostic_capture_request_id_prefix) ||
       parsed.diagnostic_capture_max_entries <= 0 ||
       parsed.diagnostic_capture_max_content_bytes <= 0 ||
       parsed.diagnostic_capture_max_content_bytes >
           parsed.max_response_bytes)) {
    return false;
  }
  *output = parsed;
  return true;
}

bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output) {
  if (output == nullptr || text.empty()) {
    return false;
  }
  Json::CharReaderBuilder builder;
  JSONCPP_STRING errors;
  std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
  Json::Value parsed;
  if (!reader || !reader->parse(text.data(), text.data() + text.size(),
                                &parsed, &errors)) {
    return false;
  }
  *output = parsed;
  return true;
}

std::string JsonToString(const Json::Value& value) {
  return SerializeLlmRequest(value);
}

size_t BoundedUtf8PrefixSize(const std::string& value,
                             size_t maximum_bytes) {
  size_t size = std::min(value.size(), maximum_bytes);
  if (size == value.size()) {
    return size;
  }
  while (size > 0u &&
         (static_cast<unsigned char>(value[size]) & 0xc0u) == 0x80u) {
    --size;
  }
  return size;
}

std::string SanitizeLogValue(const std::string& value,
                             size_t maximum_bytes) {
  std::string sanitized =
      value.substr(0u, BoundedUtf8PrefixSize(value, maximum_bytes));
  for (size_t i = 0u; i < sanitized.size(); ++i) {
    const unsigned char current =
        static_cast<unsigned char>(sanitized[i]);
    if (std::iscntrl(current) != 0 || std::isspace(current) != 0) {
      sanitized[i] = static_cast<char>(95);
    }
  }
  return sanitized;
}

std::string SanitizeEndpointForLog(const std::string& endpoint) {
  const size_t scheme_separator = endpoint.find("://");
  if (scheme_separator == std::string::npos) {
    return "invalid_endpoint";
  }
  const size_t authority_begin = scheme_separator + 3u;
  const size_t authority_end = endpoint.find_first_of("/?#", authority_begin);
  std::string authority = endpoint.substr(
      authority_begin,
      authority_end == std::string::npos ? std::string::npos
                                         : authority_end - authority_begin);
  const size_t userinfo_separator = authority.rfind("@");
  if (userinfo_separator != std::string::npos) {
    authority.erase(0u, userinfo_separator + 1u);
  }

  std::string sanitized_endpoint =
      endpoint.substr(0u, authority_begin) + authority;
  if (authority_end != std::string::npos &&
      endpoint.compare(authority_end, 1u, "/") == 0) {
    const size_t path_end = endpoint.find_first_of("?#", authority_end);
    sanitized_endpoint.append(
        endpoint, authority_end,
        path_end == std::string::npos ? std::string::npos
                                      : path_end - authority_end);
  }
  return SanitizeLogValue(sanitized_endpoint,
                          kMaximumLoggedEndpointBytes);
}

std::string BackendIdentityForLog(const std::string& endpoint,
                                  const LlmProtocol& protocol) {
  return std::string(" endpoint_url=") + SanitizeEndpointForLog(endpoint) +
         " model=" + protocol.model_identity() +
         " response_protocol=" + protocol.protocol_identity();
}

enum DiagnosticCaptureWriteResult {
  kDiagnosticCaptureWritten = 0,
  kDiagnosticCaptureLimitReached,
  kDiagnosticCaptureWriteError,
};

#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
bool ContainsApiKey(const std::string& value, const std::string& api_key) {
  if (api_key.empty()) return false;
  const std::string encoded = JsonToString(Json::Value(api_key));
  return value.find(api_key) != std::string::npos ||
      value.find(encoded.substr(1, encoded.size() - 2)) != std::string::npos;
}

const char* TransportStage(NluLlmHttpStage stage) {
  switch (stage) {
    case NluLlmHttpStage::Input: return "input";
    case NluLlmHttpStage::Init: return "init";
    case NluLlmHttpStage::Headers: return "headers";
    case NluLlmHttpStage::Options: return "options";
    case NluLlmHttpStage::Perform: return "perform";
    case NluLlmHttpStage::Status: return "status";
    case NluLlmHttpStage::ResponseLimit: return "response_limit";
    case NluLlmHttpStage::Complete: return "complete";
    default: return "unknown";
  }
}
const char* FinishReason(const Json::Value& envelope) {
  const Json::Value& choices = envelope["choices"];
  if (!choices.isArray() || choices.size() != 1 || !choices[0u].isObject()) return "unavailable";
  const Json::Value& value = choices[0u]["finish_reason"];
  if (value.isNull()) return "unavailable";
  if (!value.isString()) return "malformed";
  const std::string reason = value.asString();
  if (reason == "stop") return "stop";
  if (reason == "length") return "length";
  if (reason == "content_filter") return "content_filter";
  if (reason == "tool_calls") return "tool_calls";
  return "other";
}
#endif

class DiagnosticCaptureWriter {
 public:
  static std::unique_ptr<DiagnosticCaptureWriter> Create(
      const HttpBackendConfig& config) {
    const std::string& path = config.diagnostic_capture_output_path;
    const size_t separator = path.find_last_of('/');
    if (separator == std::string::npos || separator + 1 >= path.size()) {
      return std::unique_ptr<DiagnosticCaptureWriter>();
    }
    const std::string parent = separator == 0u ? "/" : path.substr(0, separator);
    struct stat parent_status;
    if (stat(parent.c_str(), &parent_status) != 0 ||
        !S_ISDIR(parent_status.st_mode)) {
      return std::unique_ptr<DiagnosticCaptureWriter>();
    }
    const int descriptor = open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL |
                                 O_CLOEXEC, S_IRUSR | S_IWUSR);
    if (descriptor < 0) {
      return std::unique_ptr<DiagnosticCaptureWriter>();
    }
    return std::unique_ptr<DiagnosticCaptureWriter>(
        new DiagnosticCaptureWriter(
            descriptor, config.diagnostic_capture_request_id_prefix,
            static_cast<size_t>(config.diagnostic_capture_max_entries),
            static_cast<size_t>(
                config.diagnostic_capture_max_content_bytes)));
  }

  ~DiagnosticCaptureWriter() {
    if (descriptor_ >= 0) {
      close(descriptor_);
    }
  }

  bool Matches(const std::string& request_id) const {
    return request_id.compare(0, request_id_prefix_.size(),
                              request_id_prefix_) == 0;
  }

  DiagnosticCaptureWriteResult Write(
      const NluLlmRequest& request, const std::string& request_body,
      long http_status, size_t response_bytes,
      const std::string& content, ContentParseResult parse_result,
      const Json::Value& parsed_result) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (failed_) {
      return kDiagnosticCaptureWriteError;
    }
    if (entries_written_ >= max_entries_) {
      return kDiagnosticCaptureLimitReached;
    }

    const size_t captured_bytes =
        BoundedUtf8PrefixSize(content, max_content_bytes_);
    Json::Value record(Json::objectValue);
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    record["request_id"] = request.request_id.substr(
        0, BoundedUtf8PrefixSize(request.request_id, 256u));
    record["query"] = request.query.substr(
        0, BoundedUtf8PrefixSize(request.query, max_content_bytes_));
#else
    record["request_id"] = request.request_id;
    record["query"] = request.query;
#endif
    record["outcome"] = parse_result == kContentSuccess ? "success" : "failure";
    record["content"] = content.substr(0, captured_bytes);
    record["schema_detail"] = ContentParseResultName(parse_result);
    record["parsed_result"] = parse_result == kContentSuccess
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
                                  && captured_bytes == content.size()
#endif
                                  ? parsed_result
                                  : Json::Value();
    record["http_status"] = static_cast<Json::LargestInt>(http_status);
    record["response_bytes"] =
        static_cast<Json::LargestUInt>(response_bytes);
    record["content_bytes"] =
        static_cast<Json::LargestUInt>(content.size());
    record["captured_content_bytes"] =
        static_cast<Json::LargestUInt>(captured_bytes);
    record["truncated"] = captured_bytes != content.size();
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    // Reuse the content limit for each payload; no raw HTTP envelope or headers.
    const size_t request_bytes = BoundedUtf8PrefixSize(request_body, max_content_bytes_);
    record["request_body"] = request_body.substr(0, request_bytes);
    record["request_body_bytes"] = static_cast<Json::LargestUInt>(request_body.size());
    record["captured_request_body_bytes"] = static_cast<Json::LargestUInt>(request_bytes);
    record["request_body_truncated"] = request_bytes != request_body.size();
#else
    (void)request_body;
#endif
    const std::string line = JsonToString(record) + "\n";

    const off_t starting_offset = lseek(descriptor_, 0, SEEK_CUR);
    if (starting_offset < 0 || !WriteAll(line.data(), line.size())) {
      if (starting_offset >= 0) {
        while (ftruncate(descriptor_, starting_offset) != 0 &&
               errno == EINTR) {
        }
        while (lseek(descriptor_, starting_offset, SEEK_SET) < 0 &&
               errno == EINTR) {
        }
      }
      failed_ = true;
      return kDiagnosticCaptureWriteError;
    }
    ++entries_written_;
    return kDiagnosticCaptureWritten;
  }

 private:
  DiagnosticCaptureWriter(int descriptor, const std::string& request_id_prefix,
                          size_t max_entries, size_t max_content_bytes)
      : descriptor_(descriptor),
        request_id_prefix_(request_id_prefix),
        max_entries_(max_entries),
        max_content_bytes_(max_content_bytes),
        entries_written_(0u),
        failed_(false) {}

  bool WriteAll(const char* data, size_t size) {
    size_t offset = 0u;
    while (offset < size) {
      const ssize_t written =
          write(descriptor_, data + offset, size - offset);
      if (written < 0) {
        if (errno == EINTR) {
          continue;
        }
        return false;
      }
      if (written == 0) {
        return false;
      }
      offset += static_cast<size_t>(written);
    }
    return true;
  }

  int descriptor_;
  const std::string request_id_prefix_;
  const size_t max_entries_;
  const size_t max_content_bytes_;
  size_t entries_written_;
  bool failed_;
  std::mutex mutex_;
};

struct ResponseBuffer {
  ResponseBuffer(std::string* response_body, size_t maximum_bytes)
      : body(response_body), max_bytes(maximum_bytes), overflow(false) {}

  std::string* body;
  size_t max_bytes;
  bool overflow;
};

size_t WriteResponse(void* contents, size_t size, size_t count, void* user_data) {
  ResponseBuffer* buffer = static_cast<ResponseBuffer*>(user_data);
  if (buffer == nullptr || buffer->body == nullptr ||
      (size != 0 && count > std::numeric_limits<size_t>::max() / size)) {
    return 0;
  }
  const size_t bytes = size * count;
  if (bytes > buffer->max_bytes - buffer->body->size()) {
    buffer->overflow = true;
    return 0;
  }
  buffer->body->append(static_cast<const char*>(contents), bytes);
  return bytes;
}

class CurlGlobalReference {
 public:
  CurlGlobalReference() { clu::Curl::InitCurl(); }
  ~CurlGlobalReference() { clu::Curl::CleanupCurl(); }

 private:
  CurlGlobalReference(const CurlGlobalReference&) = delete;
  CurlGlobalReference& operator=(const CurlGlobalReference&) = delete;
};

class CurlHttpTransport : public NluLlmHttpTransport {
 public:
  CurlHttpTransport() {}

  int Post(const NluLlmHttpRequest& request,
           NluLlmHttpResponse* response) const override {
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    if (response != nullptr) {
      *response = NluLlmHttpResponse();
      response->diagnostic_stage = NluLlmHttpStage::Input;
    }
#endif
    if (response == nullptr || request.endpoint.empty() || request.body.empty() ||
        request.connect_timeout_ms <= 0 || request.total_timeout_ms <= 0 ||
        request.max_response_bytes == 0) {
      return -1;
    }
    response->status_code = 0;
    response->body.clear();
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    response->diagnostic_stage = NluLlmHttpStage::Init;
    response->native_code = CURLE_FAILED_INIT;
#endif
    CURL* handle = curl_easy_init();
    if (handle == nullptr) {
      return -1;
    }
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    response->diagnostic_stage = NluLlmHttpStage::Headers;
    response->native_code = CURLE_OUT_OF_MEMORY;
#endif
    curl_slist* headers = nullptr;
    for (const auto& header : request.headers) {
      curl_slist* appended = curl_slist_append(headers, header.c_str());
      if (appended == nullptr) {
        curl_slist_free_all(headers);
        curl_easy_cleanup(handle);
        return -1;
      }
      headers = appended;
    }

    std::string response_body;
    ResponseBuffer buffer(&response_body, request.max_response_bytes);
    bool options_ok = true;
    CURLcode option_code = CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_URL, request.endpoint.c_str())) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_POST, 1L)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_POSTFIELDS, request.body.data())) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_POSTFIELDSIZE_LARGE,
                         static_cast<curl_off_t>(request.body.size()))) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_HTTPHEADER, headers)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, WriteResponse)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_WRITEDATA, &buffer)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_NOSIGNAL, 1L)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_CONNECTTIMEOUT_MS,
                         request.connect_timeout_ms)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_TIMEOUT_MS,
                         request.total_timeout_ms)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_FOLLOWLOCATION, 0L)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_SSL_VERIFYPEER, 1L)) == CURLE_OK;
    options_ok = options_ok &&
        (option_code = curl_easy_setopt(handle, CURLOPT_SSL_VERIFYHOST, 2L)) == CURLE_OK;

    const CURLcode perform_code =
        options_ok ? curl_easy_perform(handle) : CURLE_FAILED_INIT;
    long status_code = 0;
    const CURLcode info_code =
        curl_easy_getinfo(handle, CURLINFO_RESPONSE_CODE, &status_code);
    curl_slist_free_all(headers);
    curl_easy_cleanup(handle);
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    response->status_code = status_code;
    response->native_code = static_cast<int>(
        !options_ok ? option_code : (perform_code != CURLE_OK ? perform_code : info_code));
    response->diagnostic_stage = !options_ok ? NluLlmHttpStage::Options :
        (buffer.overflow ? NluLlmHttpStage::ResponseLimit :
         (perform_code != CURLE_OK ? NluLlmHttpStage::Perform :
          (info_code != CURLE_OK ? NluLlmHttpStage::Status : NluLlmHttpStage::Complete)));
#endif
    if (buffer.overflow) {
      return kHttpResponseTooLarge;
    }
    if (perform_code != CURLE_OK || info_code != CURLE_OK) {
      return -1;
    }
    response->status_code = status_code;
    response->body.swap(response_body);
    return 0;
  }

 private:
  CurlGlobalReference curl_global_reference_;
};

class HttpBackend : public NluLlmBackend {
 public:
  HttpBackend(const HttpBackendConfig& config,
              std::unique_ptr<LlmProtocol> protocol,
              std::unique_ptr<NluLlmHttpTransport> transport,
              std::unique_ptr<DiagnosticCaptureWriter> capture_writer)
      : config_(config),
        protocol_(std::move(protocol)),
        transport_(std::move(transport)),
        capture_writer_(std::move(capture_writer)) {}

  int Process(const NluLlmRequest& request,
              Json::Value* result) const override {
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    if (result == nullptr) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure stage=input"
                 << " outcome=error reason=invalid_output request_id="
                 << SanitizeLogValue(request.request_id, 128u)
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
      return -1;
    }
    clu::Timeline& timeline = clu::Timeline::getInstance();
    timeline.record(request.request_id, "request-build-begin");
#else
    if (result == nullptr) return -1;
#endif
    *result = Json::Value();
    Json::Value payload;
    if (!protocol_->BuildRequest(request, &payload)) {
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
      timeline.record(request.request_id, "request-build-end", "error");
#endif
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=input outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u)
                 << " reason=invalid_input"
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
      return -1;
    }

    NluLlmHttpRequest http_request;
    http_request.endpoint = config_.endpoint;
    http_request.headers.push_back("Content-Type: application/json");
    if (!config_.api_key.empty()) {
      http_request.headers.push_back("Authorization: Bearer " +
                                     config_.api_key);
    }
    http_request.body = JsonToString(payload);
    http_request.connect_timeout_ms = config_.connect_timeout_ms;
    http_request.total_timeout_ms = config_.total_timeout_ms;
    http_request.max_response_bytes =
        static_cast<size_t>(config_.max_response_bytes);

#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    timeline.record(request.request_id, "request-build-end", "success");
    VLOG(4) << "component=nlu06b_http event=nlu06b_http_attempt stage=transport"
            << " outcome=attempt backend=openai_http request_id="
            << SanitizeLogValue(request.request_id, 128u)
            << BackendIdentityForLog(config_.endpoint, *protocol_)
            << " request_bytes=" << http_request.body.size()
            << " connect_timeout_ms=" << config_.connect_timeout_ms
            << " total_timeout_ms=" << config_.total_timeout_ms;
    if (VLOG_IS_ON(4) &&
        !ContainsApiKey(http_request.body, config_.api_key)) {
      VLOG(4) << "request_id="
              << (ContainsApiKey(request.request_id, config_.api_key) ? "omitted" :
                  SanitizeLogValue(request.request_id, 128u))
              << " nlu_llm_request_json=" << http_request.body;
    }
    timeline.record(request.request_id, "http-begin");
#endif
    NluLlmHttpResponse response;
    const int post_code = transport_->Post(http_request, &response);
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    const bool timed_out = response.diagnostic_stage == NluLlmHttpStage::Perform &&
                          response.native_code == CURLE_OPERATION_TIMEDOUT;
    timeline.record(request.request_id, "http-end", timed_out ? "timeout" :
                    (post_code < 0 ? "error" : "success"));
    VLOG(4) << "component=nlu06b_http event=nlu06b_http_return stage=transport"
            << " request_id=" << SanitizeLogValue(request.request_id, 128u)
            << " transport_stage=" << TransportStage(response.diagnostic_stage)
            << " native_code=" << response.native_code << " post_code=" << post_code
            << " http_status=" << response.status_code
            << " response_available=" << (response.status_code != 0 || !response.body.empty())
            << " response_bytes=" << response.body.size();
    if (VLOG_IS_ON(4) && !response.body.empty() &&
        response.body.size() <= http_request.max_response_bytes) {
      bool safe_to_log = !ContainsApiKey(response.body, config_.api_key);
      if (safe_to_log && !config_.api_key.empty()) {
        // Decode only to detect alternate JSON spellings of the configured key.
        // The emitted payload remains the original HTTP body.
        Json::Value diagnostic_envelope;
        safe_to_log = ParseJsonWithoutLogging(response.body, &diagnostic_envelope) &&
            !ContainsApiKey(JsonToString(diagnostic_envelope), config_.api_key);
      }
      const std::string request_id =
          ContainsApiKey(request.request_id, config_.api_key) ? "omitted" :
          SanitizeLogValue(request.request_id, 128u);
      if (safe_to_log) {
        VLOG(4) << "request_id=" << request_id
                << " nlu_llm_response_json=" << response.body;
      } else {
        VLOG(4) << "request_id=" << request_id
                << " nlu_llm_response_json_omitted=credential_guard";
      }
    }
#endif
    if (post_code == kHttpResponseTooLarge ||
        response.body.size() > http_request.max_response_bytes) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=response outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u) << " reason=response_too_large "
                 << "max_response_bytes=" << http_request.max_response_bytes
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
                 << " response_bytes=" << response.body.size()
                 << " http_status=" << response.status_code
                 << " native_code=" << response.native_code
                 << " transport_stage=" << TransportStage(response.diagnostic_stage)
#endif
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
      return -1;
    }
    if (post_code < 0) {
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure"
                 << " stage=transport outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u)
                 << " reason=" << (timed_out ? "timeout" : "transport")
                 << " transport_stage=" << TransportStage(response.diagnostic_stage)
                 << " native_code=" << response.native_code << " post_code=" << post_code
                 << " http_status=" << response.status_code
                 << " response_bytes=" << response.body.size()
                 << " connect_timeout_ms=" << config_.connect_timeout_ms
                 << " total_timeout_ms=" << config_.total_timeout_ms
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
#else
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=transport outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u) << " reason=transport"
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
#endif
      return -1;
    }
    if (response.status_code < 200 || response.status_code >= 300) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=http_status outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u) << " reason=http_status status_category="
                 << HttpStatusCategory(response.status_code)
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
                 << " http_status=" << response.status_code
                 << " response_bytes=" << response.body.size()
#endif
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
      return -1;
    }

#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    timeline.record(request.request_id, "envelope-begin");
#endif
    Json::Value envelope;
    const bool valid_envelope = ParseJsonWithoutLogging(response.body, &envelope);
    if (!valid_envelope) {
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
      timeline.record(request.request_id, "envelope-end", "error");
#endif
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=envelope outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u) << " reason=envelope_parse "
                 << "response_bytes=" << response.body.size()
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
                 << " http_status=" << response.status_code
#endif
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
      return -1;
    }
    if (!envelope.isObject() || !envelope.isMember("choices") ||
        !envelope["choices"].isArray() ||
        envelope["choices"].size() != 1u ||
        !envelope["choices"][0u].isObject() ||
        !envelope["choices"][0u].isMember("message") ||
        !envelope["choices"][0u]["message"].isObject() ||
        !envelope["choices"][0u]["message"].isMember("content") ||
        !envelope["choices"][0u]["message"]["content"].isString()) {
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
      timeline.record(request.request_id, "envelope-end", "error");
#endif
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=envelope outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u) << " reason=envelope_schema "
                 << "response_bytes=" << response.body.size()
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
                 << " http_status=" << response.status_code
#endif
                 << BackendIdentityForLog(config_.endpoint, *protocol_);
      return -1;
    }
    const std::string content = envelope["choices"][0u]["message"]["content"].asString();
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    timeline.record(request.request_id, "envelope-end", "success");
    timeline.record(request.request_id, "protocol-begin");
#endif
    const ContentParseResult parse_result = protocol_->ParseResponse(content, result);
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    timeline.record(request.request_id, "protocol-end", parse_result == kContentSuccess ? "success" : "error");
    VLOG(4) << "component=nlu06b_http event=nlu06b_decode_result stage=content"
              << " request_id=" << SanitizeLogValue(request.request_id, 128u)
              << " outcome=" << (parse_result == kContentSuccess ? "success" : "content_schema")
              << " finish_reason=" << FinishReason(envelope)
              << " http_status=" << response.status_code
              << " response_bytes=" << response.body.size() << " content_bytes=" << content.size()
              << BackendIdentityForLog(config_.endpoint, *protocol_);
#endif
    bool safe_capture = capture_writer_ &&
        capture_writer_->Matches(request.request_id);
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
    if (safe_capture) {
      // Preserve the original post-envelope opt-in capture eligibility.
      safe_capture = config_.endpoint.find_first_of("@?#") == std::string::npos;
      if (!config_.api_key.empty()) {
        const std::string encoded = JsonToString(Json::Value(config_.api_key));
        const std::string spelling = encoded.substr(1, encoded.size() - 2);
        safe_capture = safe_capture &&
            request.request_id.find(config_.api_key) == std::string::npos &&
            request.query.find(config_.api_key) == std::string::npos &&
            http_request.body.find(config_.api_key) == std::string::npos &&
            http_request.body.find(spelling) == std::string::npos &&
            content.find(config_.api_key) == std::string::npos;
      }
    }
#endif
    if (safe_capture) {
      const DiagnosticCaptureWriteResult capture_result =
          capture_writer_->Write(request, http_request.body, response.status_code,
                                 response.body.size(), content, parse_result,
                                 *result);
      if (capture_result == kDiagnosticCaptureWriteError) {
        LOG(ERROR) << "component=nlu06b_http "
                   << "event=nlu06b_diagnostic_capture_failure "
                   << "stage=write outcome=error request_id="
                   << SanitizeLogValue(request.request_id, 128u) << " reason=write_failed"
                   << BackendIdentityForLog(config_.endpoint, *protocol_);
      }
    }
    // Request-local diagnostics are not part of the protected parsed_result.
    // Move the original decoded JSON string only after the capture above.
    (*result)["nlu_result"].swap(
        envelope["choices"][0u]["message"]["content"]);
    if (parse_result != kContentSuccess) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=content outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u) << " backend=openai_http "
                 << "reason=content_schema schema_detail="
                 << ContentParseResultName(parse_result) +
                    BackendIdentityForLog(config_.endpoint, *protocol_)
                 << " http_status=" << response.status_code
                 << " response_bytes=" << response.body.size()
                 << " content_bytes=" << content.size();
      return -1;
    }
    return 0;
  }

  const char* result_source() const override { return "nlu06b"; }

 private:
  const HttpBackendConfig config_;
  const std::unique_ptr<LlmProtocol> protocol_;
  const std::unique_ptr<NluLlmHttpTransport> transport_;
  const std::unique_ptr<DiagnosticCaptureWriter> capture_writer_;
};

std::unique_ptr<NluLlmBackend> CreateFromConfig(
    const Json::Value& config, const std::string& base_path,
    std::unique_ptr<NluLlmHttpTransport> transport) {
  HttpBackendConfig parsed;
  if (!transport || !config.isObject() || config.isMember("version") ||
      config.isMember("response_protocol") || config.isMember("response_flag_prefix") ||
      config.isMember("profile") || config.isMember("profile_catalog_path") ||
      !ParseConfig(config["OpenAIHttp"], &parsed)) {
    return std::unique_ptr<NluLlmBackend>();
  }
  std::unique_ptr<LlmProtocol> protocol = CreateLlmProtocol(config["Model"], base_path);
  if (!protocol) return std::unique_ptr<NluLlmBackend>();
  std::unique_ptr<DiagnosticCaptureWriter> capture_writer;
  if (parsed.diagnostic_capture_enabled) {
    capture_writer = DiagnosticCaptureWriter::Create(parsed);
    if (!capture_writer) {
      return std::unique_ptr<NluLlmBackend>();
    }
  }
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
  LOG(INFO) << "component=nlu06b_http event=nlu06b_init_result"
            << " stage=complete outcome=ok backend=openai_http"
            << BackendIdentityForLog(parsed.endpoint, *protocol);
#endif
  return std::unique_ptr<NluLlmBackend>(new HttpBackend(
      parsed, std::move(protocol), std::move(transport), std::move(capture_writer)));
}

}  // namespace

std::unique_ptr<NluLlmBackend> CreateNluLlmHttpBackend(
    const Json::Value& config, const std::string& base_path) {
  return CreateFromConfig(
      config, base_path,
      std::unique_ptr<NluLlmHttpTransport>(new CurlHttpTransport()));
}

std::unique_ptr<NluLlmBackend> CreateNluLlmHttpBackend(
    const Json::Value& config) {
  return CreateNluLlmHttpBackend(config, std::string());
}

std::unique_ptr<NluLlmBackend> CreateNluLlmHttpBackend(
    const Json::Value& config, const std::string& base_path,
    std::unique_ptr<NluLlmHttpTransport> transport) {
  return CreateFromConfig(config, base_path, std::move(transport));
}

std::unique_ptr<NluLlmBackend> CreateNluLlmHttpBackend(
    const Json::Value& config,
    std::unique_ptr<NluLlmHttpTransport> transport) {
  return CreateFromConfig(config, std::string(), std::move(transport));
}

}  // namespace nlptk
