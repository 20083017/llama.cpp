// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_LLM_PROTOCOL_H_
#define CU_LLM_PROTOCOL_H_

#include <memory>
#include <string>

#include "cu/nlu_llm_backend.h"

namespace nlptk {

enum ContentParseResult {
  kContentSuccess = 0,
  kContentNullResult,
  kContentInvalidDomainField,
  kContentInvalidIntentField,
  kContentEmptyDomain,
  kContentEmptyIntent,
  kContentInvalidSlotPair,
  kContentEmptySlotName,
  kContentEmptySlotValue,
  kContentDuplicateSlot,
  kContentTrailingSlotSeparator,
  kContentInvalidWrapper,
  kContentMissingTab,
  kContentExtraTab,
};

const char* ContentParseResultName(ContentParseResult result);

// One compact JSON serialization authority for HTTP and callback requests.
std::string SerializeLlmRequest(const Json::Value& payload);

// Immutable initialization snapshot. Concurrent calls use only call-local data.
// No transport envelope, credentials, history selection or owning logs here.
class LlmProtocol {
 public:
  virtual ~LlmProtocol() {}
  // Failure clears payload; success is the exact common model-request JSON.
  virtual bool BuildRequest(const NluLlmRequest& request,
                            Json::Value* payload) const = 0;
  // Failure clears result, never publishes partial frames. Execution backends
  // own the raw nlu_result carrier (and any protected capture) after this call.
  virtual ContentParseResult ParseResponse(const std::string& content,
                                           Json::Value* result) const = 0;
  virtual std::string model_identity() const = 0;  // Control-safe, <=128 bytes.
  virtual const char* protocol_identity() const = 0;
};

// selector is NluConfig.Model. Paths resolve beneath the existing model root.
// Reads the selected catalog/profile/descriptor once; unsupported IDs fail.
std::unique_ptr<LlmProtocol> CreateLlmProtocol(
    const Json::Value& selector, const std::string& base_path);

}  // namespace nlptk

#endif  // CU_LLM_PROTOCOL_H_
