// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/dialogue_system.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <memory>
#include <string>
#include <type_traits>
#include <unistd.h>
#include <vector>

#include "base/json_helper.h"
#include "base/logging.h"
#include "cu/dialogue_v3.h"
#include "gtest/gtest.h"

// Observe the existing API instance for safe instance/manager calls. No new
// product global, accessor, lifecycle seam or unsafe Process return is needed.
extern nlptk::Dialogue* INSTANCE;

namespace nlptk {
namespace {

static_assert(std::is_same<InferenceCallback, NluLlmOutputCallback>::value,
              "Existing and additive callback function types must match");

struct ApiProvider {
  ApiProvider() : calls(0), context(nullptr) {}
  int calls;
  void* context;
  std::string request;
};

int ApiInfer(const char* request, void* owner, void* context,
             NluLlmOutputCallback callback) {
  ApiProvider* provider = static_cast<ApiProvider*>(owner);
  ++provider->calls;
  provider->context = context;
  provider->request = request;
  callback("vehicle\topen\tname=车窗", context);
  return 0;
}

int OtherApiInfer(const char* request, void* owner, void* context,
                  NluLlmOutputCallback callback) {
  return ApiInfer(request, owner, context, callback);
}

class ApiFiles {
 public:
  ApiFiles() {
    char path[] = "/tmp/wtp184_inference_api_XXXXXX";
    const char* created = mkdtemp(path);
    if (created) root = created;
    config = JsonHelper::ParseJsonFromString(R"JSON({
      "DefaultScenario":"default", "ThreadPoolSize":1,
      "LanguageUnderstanding":{"NluConfig":"nlu.json",
                               "DialogueStateTracking":{}},
      "ContextManager":{"Type":"local","interval":3600,
        "max_turn_size":2,"max_query_records":4,
        "expire_strategy":{"user_session":60,"llm_simple_cache":-1,
                           "query_records":60}},
      "DialogueManager":{"TaskManager":[],"providers":{"default":[]}},
      "HotQueriesCacheRules":[]
    })JSON");
    nlu = JsonHelper::ParseJsonFromString(R"JSON({
      "Backend":{"type":"offline"},"HotFix":{"enable":false},
      "Model":{"profile_catalog_path":"catalog.json","profile":"api-model"}
    })JSON");
    const Json::Value catalog = JsonHelper::ParseJsonFromString(R"JSON({
      "profiles":{"api-model":{"model":"synthetic-api-model",
        "system_prompt":"synthetic init fixture","protocol_path":"v3.json",
        "stream":false,"temperature":0.1,"top_p":0.9,"top_k":10,
        "max_tokens":128,"enable_thinking":false,
        "allow_multi_intent_output":false}}
    })JSON");
    const Json::Value protocol = JsonHelper::ParseJsonFromString(R"JSON({
      "protocol":"nlu_10","request_field_prefixes":["history:","query: "],
      "field_delimiter":"\t","request_slot_assignment":"=",
      "request_slot_separator":",","response_slot_assignment":"=",
      "response_slot_separator":",","response_frame_separator":";",
      "response_unknown_marker":"unknown","response_multi_marker":"multi:"
    })JSON");
    if (!root.empty()) {
      Write("catalog.json", catalog);
      Write("v3.json", protocol);
      Save();
    }
  }
  ~ApiFiles() {
    if (root.empty()) return;
    for (size_t i = 0u; i < names.size(); ++i)
      std::remove((root + "/" + names[i]).c_str());
    rmdir(root.c_str());
  }
  std::string path() const { return root + "/dialogue.json"; }
  void Save() {
    Write("dialogue.json", config);
    Write("nlu.json", nlu);
  }
  void Write(const std::string& name, const Json::Value& value) {
    if (std::find(names.begin(), names.end(), name) == names.end())
      names.push_back(name);
    std::ofstream output((root + "/" + name).c_str());
    output << JsonHelper::ToString(value);
    ASSERT_TRUE(output.good());
  }
  std::string root;
  Json::Value config;
  Json::Value nlu;
  std::vector<std::string> names;
};

class InitLogCapture : public google::LogSink {
 public:
  InitLogCapture() : destructions(0) { google::AddLogSink(this); }
  ~InitLogCapture() override { google::RemoveLogSink(this); }
  void send(google::LogSeverity, const char*, const char*, int,
            const google::LogMessageTime&, const char* message,
            size_t bytes) override {
    if (std::string(message, bytes).find("event=v3_destroy") != std::string::npos)
      ++destructions;
  }
  int destructions;
};

class DialogueSystemInferenceTest : public testing::Test {
 protected:
  ApiProvider provider;
  ApiProvider other;
  void SetUp() override { ASSERT_EQ(nullptr, INSTANCE); }
  void TearDown() override { Release(); }
};

void ExpectBoundManager(Dialogue* dialogue, ApiProvider* provider) {
  ASSERT_NE(nullptr, dialogue);
  ASSERT_TRUE(dialogue->Valid());
  ASSERT_TRUE(dialogue->nlu_0_6b_manager_);
  const int before = provider->calls;
  NluLlmRequest request;
  request.request_id = "api-fixture-request";
  request.query = "synthetic api query";
  nlu::SemanticFrames output;
  NluLlmResultInfo info;
  ASSERT_EQ(0, dialogue->nlu_0_6b_manager_->Process(request, &output, &info));
  ASSERT_EQ(1u, output.size());
  EXPECT_EQ("vehicle", output[0]->domain.value);
  EXPECT_EQ("open", output[0]->intents[0].value);
  EXPECT_EQ("nlu06b", info.result_source);
  EXPECT_EQ(before + 1, provider->calls);
  EXPECT_NE(nullptr, provider->context);
  EXPECT_NE(static_cast<void*>(provider), provider->context);
  const Json::Value payload = JsonHelper::ParseJsonFromString(provider->request);
  EXPECT_EQ("synthetic-api-model", payload["model"].asString());
}

TEST_F(DialogueSystemInferenceTest, RejectsNullInputsAndFailedCandidateIsNotPublished) {
  ApiProvider provider;
  EXPECT_FALSE(InitializeWithNlu06BInference(nullptr, &ApiInfer, &provider));
  EXPECT_FALSE(InitializeWithNlu06BInference("", &ApiInfer, &provider));
  EXPECT_FALSE(InitializeWithNlu06BInference("absent.json", nullptr, &provider));
  EXPECT_FALSE(InitializeWithNlu06BInference("/nonexistent/wtp184-api.json",
                                            &ApiInfer, &provider));
  EXPECT_EQ(nullptr, INSTANCE);
  EXPECT_EQ(0, provider.calls);
}

TEST_F(DialogueSystemInferenceTest, ApiPublishesOnlyValidCandidateAndRetainsBindingOnReinit) {
  ApiFiles files;
  ASSERT_FALSE(files.root.empty());
  // Provider resources outlive explicit Release below, including failure paths.
  const Json::Value manager_config = files.config["DialogueManager"];
  files.config["DialogueManager"] = Json::Value();  // Fail after backend init.
  files.Save();
  {
    InitLogCapture cleanup;
    EXPECT_FALSE(InitializeWithNlu06BInference(files.path().c_str(), &ApiInfer, &provider));
    EXPECT_EQ(nullptr, INSTANCE);
    EXPECT_EQ(1, cleanup.destructions);  // Unpublished candidate was destroyed.
  }
  EXPECT_EQ(0, provider.calls);
  files.config["DialogueManager"] = manager_config;
  files.Save();
  ASSERT_TRUE(InitializeWithNlu06BInference(files.path().c_str(), &ApiInfer, &provider));
  Dialogue* original = INSTANCE;
  ExpectBoundManager(INSTANCE, &provider);
  ASSERT_TRUE(InitializeWithNlu06BInference(files.path().c_str(), &ApiInfer, &provider));
  EXPECT_EQ(original, INSTANCE);
  EXPECT_FALSE(InitializeWithNlu06BInference(files.path().c_str(), &OtherApiInfer, &provider));
  EXPECT_FALSE(InitializeWithNlu06BInference(files.path().c_str(), &ApiInfer, &other));
  EXPECT_FALSE(InitializeWithNlu06BInference((files.root + "/other.json").c_str(),
                                           &ApiInfer, &provider));
  EXPECT_FALSE(InitializeWithNlu06BInference(files.path().c_str(), nullptr, &provider));
  ASSERT_EQ(original, INSTANCE);
  ASSERT_EQ(0, INSTANCE->ReInitialize());
  ExpectBoundManager(INSTANCE, &provider);
  EXPECT_EQ(0, other.calls);
  std::weak_ptr<NluLlmManager> released = INSTANCE->nlu_0_6b_manager_;
  Release();
  EXPECT_EQ(nullptr, INSTANCE);
  EXPECT_TRUE(released.expired());
}

TEST_F(DialogueSystemInferenceTest, MissingHookOldInitializerDoesNotCreateOfflineFallback) {
  ApiFiles files;
  ASSERT_FALSE(files.root.empty());
  {
    Dialogue dialogue;
    EXPECT_LT(dialogue.Initialize(files.path()), 0);
    EXPECT_FALSE(dialogue.Valid());
  }
  // New API failure must not poison the next new API attempt.
  files.nlu["Model"]["profile"] = "does-not-exist";
  files.Save();
  EXPECT_FALSE(InitializeWithNlu06BInference(files.path().c_str(), &ApiInfer, &provider));
  EXPECT_EQ(nullptr, INSTANCE);
  files.nlu["Model"]["profile"] = "api-model";
  files.Save();
  ASSERT_TRUE(InitializeWithNlu06BInference(files.path().c_str(), &ApiInfer, &provider));
  ExpectBoundManager(INSTANCE, &provider);
  Release();
}

TEST_F(DialogueSystemInferenceTest, InstanceOwnsSnapshotRatherThanCallerBindingStack) {
  ApiFiles files;
  ASSERT_FALSE(files.root.empty());
  ApiProvider provider;
  ApiProvider other;
  Dialogue::Initialize();
  Dialogue dialogue;
  {
    NluLlmInferenceBinding temporary(&ApiInfer, &provider);
    ASSERT_EQ(0, dialogue.Initialize(files.path(), temporary));
    temporary.inference = &OtherApiInfer;
    temporary.owner_context = &other;
  }
  ExpectBoundManager(&dialogue, &provider);
  EXPECT_EQ(0, dialogue.Initialize(files.path(), NluLlmInferenceBinding(&ApiInfer, &provider)));
  EXPECT_LT(dialogue.Initialize(files.path(), NluLlmInferenceBinding(&ApiInfer, &other)), 0);
  EXPECT_LT(dialogue.Initialize(files.path(), NluLlmInferenceBinding(&OtherApiInfer, &provider)), 0);
  ASSERT_EQ(0, dialogue.ReInitialize());
  ExpectBoundManager(&dialogue, &provider);
  EXPECT_EQ(0, other.calls);
}

TEST_F(DialogueSystemInferenceTest, ExistingTraditionalInstanceCannotBeRebound) {
  ApiFiles files;
  ASSERT_FALSE(files.root.empty());
  files.nlu["Backend"]["type"] = "mock";
  files.nlu["MockResponses"] = Json::Value(Json::objectValue);
  files.Save();
  ASSERT_TRUE(::Initialize(files.path().c_str()));
  ASSERT_NE(nullptr, INSTANCE);
  ASSERT_TRUE(INSTANCE->Valid());
  Dialogue* original = INSTANCE;
  EXPECT_FALSE(InitializeWithNlu06BInference(files.path().c_str(), &ApiInfer, &provider));
  EXPECT_EQ(original, INSTANCE);
  EXPECT_TRUE(INSTANCE->Valid());
  EXPECT_EQ(0, provider.calls);
}

}  // namespace
}  // namespace nlptk
