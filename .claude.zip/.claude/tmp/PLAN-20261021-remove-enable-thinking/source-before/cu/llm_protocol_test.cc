// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/llm_protocol.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <unistd.h>
#include <vector>

#include "base/json_helper.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace {

class ProtocolFiles {
 public:
  ProtocolFiles() {
    char path[] = "/tmp/wtp184_llm_protocol_XXXXXX";
    const char* created = mkdtemp(path);
    if (created != nullptr) root_ = created;
    profile = JsonHelper::ParseJsonFromString(R"JSON({
      "model":"configured-model", "system_prompt":"configured prompt",
      "protocol_path":"v3.json", "stream":false, "temperature":0.2,
      "top_p":0.8, "top_k":12, "max_tokens":256,
      "enable_thinking":true, "allow_multi_intent_output":true
    })JSON");
    descriptor = JsonHelper::ParseJsonFromString(R"JSON({
      "protocol":"nlu_10", "request_field_prefixes":["history:","query: "],
      "field_delimiter":"\t", "request_slot_assignment":"=",
      "request_slot_separator":",", "response_slot_assignment":"=",
      "response_slot_separator":",", "response_frame_separator":";",
      "response_unknown_marker":"unknown", "response_multi_marker":"multi:"
    })JSON");
    selector["profile_catalog_path"] = "catalog.json";
    selector["profile"] = "daily-driver";  // Friendly, not a wire version.
  }
  ~ProtocolFiles() {
    if (!root_.empty()) {
      std::remove((root_ + "/catalog.json").c_str());
      std::remove((root_ + "/v3.json").c_str());
      std::remove((root_ + "/escape.json").c_str());
      rmdir(root_.c_str());
    }
  }
  bool valid() const { return !root_.empty(); }
  const std::string& root() const { return root_; }
  void Save() const {
    Json::Value catalog(Json::objectValue);
    catalog["profiles"]["daily-driver"] = profile;
    std::ofstream profiles((root_ + "/catalog.json").c_str());
    profiles << JsonHelper::ToString(catalog);
    std::ofstream protocol((root_ + "/v3.json").c_str());
    protocol << JsonHelper::ToString(descriptor);
  }
  std::unique_ptr<LlmProtocol> Create() const {
    Save();
    return CreateLlmProtocol(selector, root_);
  }

  Json::Value profile;
  Json::Value descriptor;
  Json::Value selector;

 private:
  ProtocolFiles(const ProtocolFiles&) = delete;
  ProtocolFiles& operator=(const ProtocolFiles&) = delete;
  std::string root_;
};

Json::Value History(const std::string& query, const std::string& domain,
                    const std::string& intent, const Json::Value& slots) {
  Json::Value history(Json::objectValue);
  Json::Value semantic(Json::objectValue);
  semantic["query"] = query;
  semantic["domain"] = domain;
  semantic["intent"] = intent;
  semantic["slots"] = slots;
  semantic["tts"] = Json::Value(Json::objectValue);  // Never read or emitted.
  history["v3_nlu_semantics"].append(semantic);
  return history;
}

const char kThreeFrames[] =
    "intelligent_car_control\tturn_on_device\tname=空调;"
    "intelligent_car_control\tAC_control\twind_direction=面;"
    "intelligent_car_control\tturn_on_device\tname=车窗";

void ExpectThreeFrames(const Json::Value& result) {
  ASSERT_EQ(3u, result["frames"].size());
  EXPECT_FALSE(result["is_rejected"].asBool());
  EXPECT_TRUE(result["is_multi_intent"].asBool());
  EXPECT_EQ("", result["reject_reason"].asString());
  const Json::Value& frames = result["frames"];
  for (Json::ArrayIndex i = 0u; i < 3u; ++i) {
    EXPECT_EQ("intelligent_car_control", frames[i]["domain"].asString());
    ASSERT_EQ(1u, frames[i]["intents"].size());
  }
  EXPECT_EQ("turn_on_device", frames[0u]["intents"][0u].asString());
  EXPECT_EQ("AC_control", frames[1u]["intents"][0u].asString());
  EXPECT_EQ("turn_on_device", frames[2u]["intents"][0u].asString());
  EXPECT_EQ("空调", frames[0u]["slots"]["name"].asString());
  EXPECT_EQ("面", frames[1u]["slots"]["wind_direction"].asString());
  EXPECT_EQ("车窗", frames[2u]["slots"]["name"].asString());
  EXPECT_FALSE(result.isMember("nlu_result"));  // Execution owner adds raw text.
}

TEST(LlmProtocolTest, BuildsCommonPayloadAndImmutableChronologicalHistory) {
  ProtocolFiles files;
  ASSERT_TRUE(files.valid());
  std::unique_ptr<LlmProtocol> codec = files.Create();
  ASSERT_TRUE(codec);
  EXPECT_STREQ("nlu_10", codec->protocol_identity());
  EXPECT_EQ("configured-model", codec->model_identity());
  NluLlmRequest request;
  request.query = "current\t\r\nquery；";
  request.request_id = "correlation-never-sent";
  request.model_last_context["private"] = "context-never-sent";
  Json::Value payload;
  ASSERT_TRUE(codec->BuildRequest(request, &payload));
  EXPECT_EQ("history:None;query: current   query；",
            payload["messages"][1u]["content"].asString());
  Json::Value slots(Json::objectValue);
  slots["z"] = "a=b|c";
  slots["a"] = "原样：；，＝";
  request.histories.append(History("past\tquery", "music", "play", slots));
  request.histories.append(History("next", "fm", "stop", Json::Value(Json::objectValue)));
  const NluLlmRequest saved = request;
  ASSERT_TRUE(codec->BuildRequest(request, &payload));
  EXPECT_EQ("history:past query\tmusic\tplay\ta=原样：；，＝,z=a=b|c;"
            "next\tfm\tstop\t;query: current   query；",
            payload["messages"][1u]["content"].asString());
  EXPECT_EQ(saved.query, request.query);
  EXPECT_EQ(saved.histories, request.histories);
  EXPECT_EQ("configured-model", payload["model"].asString());
  ASSERT_EQ(2u, payload["messages"].size());
  EXPECT_EQ("system", payload["messages"][0u]["role"].asString());
  EXPECT_EQ("configured prompt", payload["messages"][0u]["content"].asString());
  EXPECT_EQ("user", payload["messages"][1u]["role"].asString());
  EXPECT_DOUBLE_EQ(0.2, payload["temperature"].asDouble());
  EXPECT_DOUBLE_EQ(0.8, payload["top_p"].asDouble());
  EXPECT_EQ(12, payload["top_k"].asInt());
  EXPECT_EQ(256, payload["max_tokens"].asInt());
  EXPECT_FALSE(payload["stream"].asBool());
  EXPECT_TRUE(payload["enable_thinking"].asBool());
  EXPECT_EQ(8u, payload.size());  // No headers/auth/endpoint/template duplicate.
  const std::string serialized = JsonHelper::ToString(payload);
  EXPECT_EQ(std::string::npos, serialized.find(request.request_id));
  EXPECT_EQ(std::string::npos, serialized.find("context-never-sent"));
  files.profile["model"] = "changed-on-disk";
  files.descriptor["request_history_separator"] = "~";
  files.Save();
  Json::Value again;
  ASSERT_TRUE(codec->BuildRequest(request, &again));
  EXPECT_EQ(payload, again);
  request.histories[0u]["v3_nlu_semantics"][0u]["slots"]["a"] = "bad,value";
  EXPECT_FALSE(codec->BuildRequest(request, &again));
  EXPECT_TRUE(again.isNull());
  EXPECT_FALSE(codec->BuildRequest(request, nullptr));
}

TEST(LlmProtocolTest, ExactThreeFrameGoldenZeroOrOneLeadingSeparator) {
  EXPECT_EQ(6, std::count(kThreeFrames, kThreeFrames + sizeof(kThreeFrames) - 1u, '\t'));
  EXPECT_EQ(0x09u, static_cast<unsigned char>('\t'));
  EXPECT_EQ(std::string("multi\x3A"), u8"multi:");
  EXPECT_EQ(std::string("multi\xEF\xBC\x9A"), u8"multi：");
  const char* markers[] = {"multi:", u8"multi：", "status/multi"};
  const char* orders[] = {";", ";~", "~;"};
  for (size_t m = 0u; m < 3u; ++m) {
    for (size_t order = 0u; order < 3u; ++order) {
      ProtocolFiles files;
      ASSERT_TRUE(files.valid());
      files.descriptor["response_multi_marker"] = markers[m];
      if (order != 0u) {
        files.descriptor["response_frame_separator"] = Json::Value(Json::arrayValue);
        for (const char* p = orders[order]; *p; ++p)
          files.descriptor["response_frame_separator"].append(std::string(1u, *p));
      }
      std::unique_ptr<LlmProtocol> codec = files.Create();
      ASSERT_TRUE(codec);
      for (size_t leading = 0u; leading < 2u; ++leading) {
        const std::string raw = std::string(markers[m]) + (leading ? ";" : "") + kThreeFrames;
        Json::Value result;
        ASSERT_EQ(kContentSuccess, codec->ParseResponse(raw, &result));
        ExpectThreeFrames(result);
        // The non-first alternative is usable too, with either leading form.
        if (order != 0u) {
          std::string alternate(kThreeFrames);
          std::replace(alternate.begin(), alternate.end(), ';', '~');
          ASSERT_EQ(kContentSuccess, codec->ParseResponse(
              std::string(markers[m]) + (leading ? "~" : "") + alternate, &result));
          ExpectThreeFrames(result);
        }
      }
      const std::string invalid[] = {
          std::string(markers[m]) + ";;" + kThreeFrames,
          std::string(markers[m]) + ";" + kThreeFrames + ";",
          std::string(markers[m]) + ";fm\tstop", std::string(markers[m]) + ";",
          std::string(markers[m]) + ";fm\tstop;;music\tplay",
          std::string(markers[m]) + ";fm\tstop;music\tplay\tbad",
          std::string(markers[m]) + (order == 0u ? ";;" : "~") + kThreeFrames,
          std::string(markers[(m + 1u) % 3u]) + ";" + kThreeFrames};
      for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
        Json::Value result(Json::objectValue);
        result["stale"] = true;
        EXPECT_NE(kContentSuccess, codec->ParseResponse(invalid[i], &result)) << i;
        EXPECT_TRUE(result.isNull()) << i;
      }
    }
  }
}

TEST(LlmProtocolTest, OutputGateAndWrapperErrorsRemainAtomic) {
  ProtocolFiles files;
  ASSERT_TRUE(files.valid());
  files.profile["allow_multi_intent_output"] = false;
  std::unique_ptr<LlmProtocol> codec = files.Create();
  ASSERT_TRUE(codec);
  Json::Value result;
  ASSERT_EQ(kContentSuccess, codec->ParseResponse("multi:;" + std::string(kThreeFrames), &result));
  EXPECT_TRUE(result["is_rejected"].asBool());
  EXPECT_EQ("multi_intent_disabled", result["reject_reason"].asString());
  EXPECT_TRUE(result["frames"].empty());
  EXPECT_FALSE(result["is_multi_intent"].asBool());
  ASSERT_EQ(kContentSuccess, codec->ParseResponse("<think>x</think>unknown", &result));
  EXPECT_EQ("unknown", result["reject_reason"].asString());
  const char* invalid[] = {"multi:;fm\tstop;music\tplay\tbad", "multi:;fm\tstop;unknown",
      "<think>x</think><think>y</think>fm\tstop", "<think>unclosed",
      "fm\tstop\tname=one,name=two", "fm\tstop\tname=", "fm\tstop\textra\tfield"};
  for (const char* raw : invalid) {
    EXPECT_NE(kContentSuccess, codec->ParseResponse(raw, &result));
    EXPECT_TRUE(result.isNull());
  }
  EXPECT_EQ(kContentNullResult, codec->ParseResponse("fm\tstop", nullptr));
  EXPECT_STREQ("duplicate_slot", ContentParseResultName(kContentDuplicateSlot));
}

TEST(LlmProtocolTest, RejectsRetiredSelectorsAndStaleTransportInCommonProfile) {
  ProtocolFiles files;
  ASSERT_TRUE(files.valid());
  const Json::Value valid = files.descriptor;
  const char* obsolete[] = {"version", "response_protocol", "response_flag_prefix"};
  for (const char* field : obsolete) {
    files.descriptor = valid;
    files.descriptor[field] = "nlu_10";
    EXPECT_FALSE(files.Create()) << field;
  }
  const char* ids[] = {"nlu_06b_v3", "nlu_06b_v4", "nlu_06b_v10", "pipe_v1", "tsv_v1", "nlu_11", ""};
  for (const char* id : ids) {
    files.descriptor = valid;
    files.descriptor["protocol"] = id;
    EXPECT_FALSE(files.Create()) << id;
  }
  files.descriptor = valid;
  files.descriptor.removeMember("protocol");
  files.descriptor["version"] = "nlu_10";
  EXPECT_FALSE(files.Create());
  files.descriptor = valid;
  const Json::Value common = files.profile;
  const char* stale[] = {"endpoint", "api_key_env", "connect_timeout_ms", "total_timeout_ms",
      "max_response_bytes", "diagnostic_capture_enabled", "response_protocol", "version",
      "profile", "response_flag_prefix"};
  for (const char* field : stale) {
    files.profile = common;
    files.profile[field] = "stale";
    EXPECT_FALSE(files.Create()) << field;
  }
  files.profile = common;
  const Json::Value selector = files.selector;
  files.selector["profile"] = "missing";
  EXPECT_FALSE(files.Create());
  files.selector = selector;
  files.selector["response_protocol"] = "nlu_10";
  EXPECT_FALSE(files.Create());
  files.selector = selector;
  files.selector["profile_catalog_path"] = "../catalog.json";
  EXPECT_FALSE(files.Create());
  files.selector = selector;
  files.selector["profile_catalog_path"] = std::string("catalog.json") + char(0) + "ignored";
  EXPECT_FALSE(files.Create());
  files.selector = selector;
  files.profile["protocol_path"] = std::string("v3.json") + char(0) + "ignored";
  EXPECT_FALSE(files.Create());
  files.profile["protocol_path"] = "/tmp/v3.json";
  EXPECT_FALSE(files.Create());
  ProtocolFiles outside;
  ASSERT_TRUE(outside.valid());
  outside.Save();
  ASSERT_EQ(0, symlink((outside.root() + "/v3.json").c_str(), (files.root() + "/escape.json").c_str()));
  files.profile["protocol_path"] = "escape.json";
  EXPECT_FALSE(files.Create());
}

TEST(LlmProtocolTest, CommonGenerationTypesAndRangesAreValidatedOnce) {
  ProtocolFiles files;
  ASSERT_TRUE(files.valid());
  const Json::Value common = files.profile;
  const char* required[] = {"model", "system_prompt", "stream", "temperature", "top_p",
      "top_k", "max_tokens", "enable_thinking", "allow_multi_intent_output", "protocol_path"};
  for (const char* field : required) {
    files.profile = common;
    files.profile.removeMember(field);
    EXPECT_FALSE(files.Create()) << field;
    files.profile = common;
    files.profile[field] = Json::Value();
    EXPECT_FALSE(files.Create()) << field;
  }
  const char* fields[] = {"temperature", "temperature", "top_p", "top_p", "top_k", "top_k",
      "max_tokens", "max_tokens", "stream", "enable_thinking", "model", "system_prompt"};
  const Json::Value invalid[] = {Json::Value(-0.1), Json::Value(2.1), Json::Value(0.0), Json::Value(1.1),
      Json::Value(0), Json::Value(1001), Json::Value(0), Json::Value(65537), Json::Value(true),
      Json::Value(1), Json::Value(""), Json::Value("")};
  for (size_t i = 0u; i < sizeof(fields) / sizeof(fields[0]); ++i) {
    files.profile = common;
    files.profile[fields[i]] = invalid[i];
    EXPECT_FALSE(files.Create()) << fields[i];
  }
  files.profile = common;
  files.profile["temperature"] = 0.0;
  files.profile["top_p"] = 1.0;
  files.profile["top_k"] = 1000;
  files.profile["max_tokens"] = 65536;
  EXPECT_TRUE(files.Create());
}

TEST(LlmProtocolTest, DiagnosticIdentityIsBoundedControlSafeAndNotPayload) {
  ProtocolFiles files;
  ASSERT_TRUE(files.valid());
  files.profile["model"] = "model\twith\nspaces-" + std::string(160u, 'x') + "secret-tail";
  std::unique_ptr<LlmProtocol> codec = files.Create();
  ASSERT_TRUE(codec);
  EXPECT_EQ(128u, codec->model_identity().size());
  EXPECT_EQ(0u, codec->model_identity().find("model_with_spaces-"));
  EXPECT_EQ(std::string::npos, codec->model_identity().find("secret-tail"));
  NluLlmRequest request;
  request.query = "query";
  Json::Value payload;
  ASSERT_TRUE(codec->BuildRequest(request, &payload));
  EXPECT_EQ(files.profile["model"], payload["model"]);  // Only logging is sanitized.
}

TEST(LlmProtocolTest, AssignmentCandidatesAreAlternativesAndUniformPerResponse) {
  const char* orders[] = {":", "=", ":=", "=:", "@", "@^", "^@"};
  for (size_t array = 0u; array < 2u; ++array) {
    for (const char* order : orders) {
      ProtocolFiles files;
      ASSERT_TRUE(files.valid());
      files.descriptor["response_slot_assignment"] = order;
      if (array != 0u) {
        files.descriptor["response_slot_assignment"] = Json::Value(Json::arrayValue);
        for (const char* p = order; *p; ++p)
          files.descriptor["response_slot_assignment"].append(std::string(1u, *p));
      }
      std::unique_ptr<LlmProtocol> codec = files.Create();
      ASSERT_TRUE(codec);
      for (const char* p = order; *p; ++p) {
        const std::string raw = std::string("multi:;vehicle\topen\ta") + *p + "1" + *p +
            "2|x,b" + *p + "3;music\tplay\tc" + *p + "4";
        Json::Value result;
        ASSERT_EQ(kContentSuccess, codec->ParseResponse(raw, &result));
        EXPECT_EQ(std::string("1") + *p + "2|x", result["frames"][0u]["slots"]["a"].asString());
        EXPECT_EQ("4", result["frames"][1u]["slots"]["c"].asString());
      }
      if (std::string(order).size() > 1u) {
        const std::string invalid[] = {
            std::string("vehicle\topen\ta") + order[0] + "1,b" + order[1] + "2",
            std::string("multi:;vehicle\topen\ta") + order[0] + "1;music\tplay\tb" + order[1] + "2",
            std::string("vehicle\topen\ta") + order[0] + "1" + order[1] + "2"};
        for (const std::string& raw : invalid) {
          Json::Value result;
          EXPECT_EQ(kContentInvalidSlotPair, codec->ParseResponse(raw, &result));
          EXPECT_TRUE(result.isNull());
        }
      }
    }
  }
}

TEST(LlmProtocolTest, EveryNoncollidingPrintableByteCanOwnAStructuralRole) {
  const char* roles[] = {"field_delimiter", "request_slot_assignment",
      "request_slot_separator", "response_slot_separator", "response_frame_separator",
      "response_slot_assignment", "request_history_separator"};
  ProtocolFiles files;
  ASSERT_TRUE(files.valid());
  for (size_t role = 0u; role < 7u; ++role) {
    for (int byte = 0x21; byte <= 0x7e; ++byte) {
      SCOPED_TRACE(std::string(roles[role]) + ":" + std::to_string(byte));
      files.descriptor["request_field_prefixes"][0u] = "";
      files.descriptor["request_field_prefixes"][1u] = "";
      files.descriptor["empty_history_request"]["history_field"] = "空";
      files.descriptor["empty_history_request"]["query_prefix"] = "";
      files.descriptor["response_unknown_marker"] = "未知";
      files.descriptor["response_multi_marker"] = "多项";
      int next = 0x21;
      for (size_t i = 0u; i < 7u; ++i) {
        if (i == role) {
          files.descriptor[roles[i]] = std::string(1u, static_cast<char>(byte));
        } else {
          if (next == byte) ++next;
          files.descriptor[roles[i]] = std::string(1u, static_cast<char>(next++));
        }
      }
      const char field = files.descriptor[roles[0]].asString()[0];
      const char ra = files.descriptor[roles[1]].asString()[0];
      const char rp = files.descriptor[roles[2]].asString()[0];
      const char sp = files.descriptor[roles[3]].asString()[0];
      const char frame = files.descriptor[roles[4]].asString()[0];
      const char sa = files.descriptor[roles[5]].asString()[0];
      const char history = files.descriptor[roles[6]].asString()[0];
      std::unique_ptr<LlmProtocol> codec = files.Create();
      ASSERT_TRUE(codec);
      NluLlmRequest request;
      request.query = "现在";
      Json::Value slots(Json::objectValue);
      slots["甲"] = "首";
      slots["乙"] = "尾";
      request.histories.append(History("过去", "车", "开", slots));
      Json::Value payload;
      ASSERT_TRUE(codec->BuildRequest(request, &payload));
      EXPECT_EQ(std::string("过去") + field + "车" + field + "开" + field + "乙" +
                ra + "尾" + rp + "甲" + ra + "首" + history + "现在",
                payload["messages"][1u]["content"].asString());
      for (size_t leading = 0u; leading < 2u; ++leading) {
        const std::string raw = std::string("多项") + (leading ? std::string(1u, frame) : "") +
            "车" + field + "开" + field + "甲" + sa + "首" + sp + "乙" + sa + "尾" +
            frame + "音" + field + "播" + field;
        Json::Value result;
        ASSERT_EQ(kContentSuccess, codec->ParseResponse(raw, &result));
        ASSERT_EQ(2u, result["frames"].size());
        EXPECT_EQ("首", result["frames"][0u]["slots"]["甲"].asString());
        EXPECT_EQ("尾", result["frames"][0u]["slots"]["乙"].asString());
      }
    }
  }
}

}  // namespace
}  // namespace nlptk
