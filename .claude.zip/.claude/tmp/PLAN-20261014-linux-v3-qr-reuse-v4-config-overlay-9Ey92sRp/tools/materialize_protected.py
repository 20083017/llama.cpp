#!/usr/bin/env python3
"""Materialize only the approved protected Phase2 configuration delta."""
import argparse
import copy
import json
import math
import os
from pathlib import Path
import re
import stat
import sys

BASE = Path('/home/shared/models/car_v3.0')
TX = Path('/home/daigd/.wtp184-transactions/PLAN-20261014-linux-v3-qr-reuse-v4-20261015T020027Z')
MAX_JSON = 1048576
MAX_RESOURCE = 8388608
MAX_TOTAL = 134217728


class GuardError(Exception):
    pass


def require(ok, category):
    if not ok:
        raise GuardError(category)


def unique(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, 'duplicate_key')
        obj[key] = value
    return obj


def constant(_value):
    raise GuardError('nonfinite_number')


def floating(value):
    number = float(value)
    require(math.isfinite(number), 'nonfinite_number')
    return number


def parse(raw):
    require(len(raw) <= MAX_JSON, 'json_size_limit')
    result = json.loads(raw.decode('utf-8'), object_pairs_hook=unique,
                        parse_constant=constant, parse_float=floating)
    require(type(result) is dict, 'json_object_required')
    return result


def equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def merge(base, overlay):
    for key, value in overlay.items():
        if type(value) is dict:
            if key not in base:
                base[key] = {}
            require(type(base[key]) is dict, 'merge_object_schema')
            merge(base[key], value)
        else:
            base[key] = copy.deepcopy(value)


def check_overlay(overlay, patch):
    llm_types = {'enable': bool, 'llm_url': str, 'llm_model': str,
                 'llm_max_tokens': int, 'temperature': float, 'top_p': float,
                 'llm_top_k': int, 'chat_template_kwargs': dict, 'llm_prompt': str}
    require(set(overlay) == {'rejection_cmd', 'semantic_cmd', 'llm'}, 'overlay_keys')
    require(type(overlay['rejection_cmd']) is str and overlay['rejection_cmd'] == ''
            and type(overlay['semantic_cmd']) is str and overlay['semantic_cmd'] == '',
            'overlay_commands')
    require(type(overlay['llm']) is dict and set(overlay['llm']) == set(llm_types),
            'overlay_llm_keys')
    llm = overlay['llm']
    require(all(type(llm[k]) is t for k, t in llm_types.items()), 'overlay_types')
    require(llm['enable'] is True and llm['llm_url'] != ''
            and llm['llm_model'] == 'Qwen2_5_3b_reject-4bit'
            and llm['llm_max_tokens'] == 1024 and llm['temperature'] == 0.01
            and llm['top_p'] == 0.95 and llm['llm_top_k'] == 20
            and equal(llm['chat_template_kwargs'], {'enable_thinking': False}),
            'overlay_values')
    prompt = llm['llm_prompt'].encode('utf-8')
    require(prompt.count(bytes([9])) == 8 and prompt.count(bytes([10])) == 12
            and bytes([13]) not in prompt and prompt.endswith(bytes([10]))
            and bytes([92, 116]) not in prompt and bytes([92, 110]) not in prompt,
            'prompt_byte_structure')
    require(equal(patch, {'LanguageUnderstanding': {
        'QueryRejectionConfig': 'conf/query_rejection_llm_v3.json'}}), 'root_patch_minimal')


def resource(path):
    resolved = path.resolve(strict=True)
    require(BASE in resolved.parents and resolved.is_file(), 'resource_containment_regular')
    return resolved


def bounded_read(path, bound):
    with path.open('rb') as handle:
        raw = handle.read(bound + 1)
    require(len(raw) <= bound, 'resource_size_limit')
    return raw


def metadata(path):
    st = path.stat()
    return (stat.S_IMODE(st.st_mode), st.st_uid, st.st_gid, st.st_size, st.st_mtime_ns)


def references(obj):
    refs = []

    def walk(value, key=''):
        if type(value) is dict:
            for k, v in value.items():
                walk(v, k)
        elif type(value) is list:
            for v in value:
                walk(v, key)
        elif type(value) is str:
            if key == 'SlotNormalizerConfig':
                # This exact root field is an inline normalizer command list,
                # confirmed by bounded key/type/option-shape metadata only.
                tokens = value.split()
                require(bool(tokens)
                        and re.fullmatch('[A-Za-z_][A-Za-z0-9_]*', tokens[0]) is not None
                        and any(c.isspace() for c in value)
                        and re.search(r'(?:^|\s)--[A-Za-z0-9_-]+(?:=|\s|$)', value) is not None
                        and not value.startswith(('conf/', 'rules/', 'dict/', 'data/')),
                        'inline_normalizer_command_schema')
                return
            is_ref = (key.endswith('Config') or key.endswith('Configs')
                      or key in ('rule_paths', 'dict_paths')
                      or value.startswith(('conf/', 'rules/', 'dict/', 'data/')))
            if is_ref:
                require(value != '' and '://' not in value, 'reference_schema')
                refs.append(resource(BASE / value))

    walk(obj)
    return refs


TOKEN = re.compile(r'(?<!\S)--contextual=不相关(?!\S)')


def correct_entry(entry):
    count = [0]

    def walk(value):
        if type(value) is str:
            changed, n = TOKEN.subn('--contextual-in=不相关', value)
            count[0] += n
            return changed
        if type(value) is dict:
            return {k: walk(v) for k, v in value.items()}
        if type(value) is list:
            return [walk(v) for v in value]
        return value

    result = walk(entry)
    require(count[0] == 1, 'strategy10_exact_single_token')
    return result


def check_final(final, original, overlay, corrected, expected):
    require(equal(final, expected), 'final_complete_preservation')

    def leaves(actual, selected):
        require(type(actual) is dict, 'final_overlay_object')
        for k, v in selected.items():
            require(k in actual, 'final_overlay_leaf_missing')
            if type(v) is dict:
                leaves(actual[k], v)
            else:
                require(equal(actual[k], v), 'final_overlay_leaf_values_types')

    leaves(final, overlay)
    llm = final['llm']
    require('llm_headers' not in llm, 'final_headers_not_absent')
    require(equal(final['rule'], original['rule']) and final['rule']['enable'] is True,
            'rule_preservation')
    strategies = final['reject_strategies']
    require(type(strategies) is list and len(strategies) == 13, 'final_strategy_count')
    require(all(equal(v, corrected if i == 10 else original['reject_strategies'][i])
                for i, v in enumerate(strategies)), 'strategy_order_exact_delta')
    operational = {'llm_timeout': 3000, 'max_histories_size': 5, 'retry_times': 0,
                   'retry_interval': 50, 'required_request_id': True}
    require(all(k in llm and equal(llm[k], v) for k, v in operational.items()),
            'operational_values')
    require(llm['llm_prompt'].encode('utf-8') == overlay['llm']['llm_prompt'].encode('utf-8'),
            'prompt_exact_overlay_utf8')


def owned_file(path):
    require(path.resolve(strict=True) == path and path.is_file(), 'owned_input_path')
    st = path.stat()
    require(st.st_uid == os.getuid() and stat.S_IMODE(st.st_mode) == 0o600,
            'owned_input_protection')


def publish(path, obj):
    if path.exists() or path.is_symlink():
        owned_file(path)
        require(equal(parse(bounded_read(path, MAX_JSON)), obj), 'existing_output_not_equivalent')
        return 'existing_equivalent'
    raw = (json.dumps(obj, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode('utf-8')
    require(len(raw) <= MAX_JSON, 'output_size_limit')
    tmp = path.with_name('.' + path.name + '.owned-' + str(os.getpid()))
    require(not tmp.exists() and not tmp.is_symlink(), 'owned_temp_exists')
    try:
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(str(tmp), str(path))
    finally:
        if tmp.exists():
            tmp.unlink()
    owned_file(path)
    return 'created_no_clobber'


def execute(args):
    os.umask(0o077)
    require(BASE.resolve(strict=True) == BASE, 'original_base_identity')
    require(TX.resolve(strict=True) == TX and TX.is_dir(), 'transaction_identity')
    stage = args.stage
    require(stage == TX / 'configuration' and stage.resolve(strict=True) == stage,
            'stage_identity')
    for directory in (TX, stage, args.overlay.parent, args.root_patch.parent):
        require(directory.resolve(strict=True) == directory and directory.is_dir()
                and directory.stat().st_uid == os.getuid()
                and stat.S_IMODE(directory.stat().st_mode) & 0o077 == 0,
                'owned_directory_protection')
    require(args.overlay.parent == args.root_patch.parent
            and args.overlay.parent.parent == stage
            and args.overlay.parent.name.startswith('inputs-'), 'input_scope')
    for path in (args.overlay, args.root_patch):
        owned_file(path)
    overlay = parse(bounded_read(args.overlay, MAX_JSON))
    patch = parse(bounded_read(args.root_patch, MAX_JSON))
    check_overlay(overlay, patch)
    print('PASS overlay_schema_types_model_sampling prompt_tabs=8 prompt_lf=12', flush=True)
    root_path = resource(BASE / 'dialog_configure_offline.json')
    qr_path = resource(BASE / 'conf/query_rejection_config.json')
    snapshots = {}

    def snapshot(path):
        if path not in snapshots:
            require(len(snapshots) < 256, 'reference_count_limit')
            raw = bounded_read(path, MAX_RESOURCE)
            snapshots[path] = (raw, metadata(path))
            require(sum(len(x[0]) for x in snapshots.values()) <= MAX_TOTAL, 'total_read_limit')
        return snapshots[path][0]

    root = parse(snapshot(root_path))
    original = parse(snapshot(qr_path))
    require(type(original.get('llm')) is dict, 'base_llm_object')
    # Deletion precedes every deepcopy/merge/serialization of the original QR object.
    inherited_headers_present = 'llm_headers' in original['llm']
    original['llm'].pop('llm_headers', None)
    require(inherited_headers_present, 'expected_inherited_header_key')
    print('PASS inherited_header_key_present deleted_in_memory_before_any_serialization', flush=True)
    require(all(type(original.get(k)) is str and original[k] != ''
                for k in ('rejection_cmd', 'semantic_cmd')), 'base_nonempty_commands')
    require(type(original.get('rule')) is dict and original['rule'].get('enable') is True
            and original['llm'].get('enable') is True, 'base_enabled_schema')
    require(type(original.get('reject_strategies')) is list
            and len(original['reject_strategies']) == 13, 'base_strategy_count')
    require(root.get('LanguageUnderstanding', {}).get('QueryRejectionConfig')
            == 'conf/query_rejection_config.json', 'root_original_reference')
    rule = original['rule']
    require(equal(rule.get('rule_paths'), ['rules/query_rejection_rules.txt'])
            and equal(rule.get('dict_paths'), ['rules/query_rejection_dict.txt',
                'rules/music.badcase.hotfix.dict.txt', 'rules/qq.toplist.data.txt',
                'rules/intelligent.car.control.hotfix.dict.txt']), 'rule_reference_contract')
    refs = set(references(root) + references(rule))
    for path in refs:
        snapshot(path)
    print('PASS direct_root_rule_dictionary_references regular_contained count=' + str(len(refs)), flush=True)
    corrected = correct_entry(original['reject_strategies'][10])
    final = copy.deepcopy(original)
    merge(final, overlay)
    final['llm'].pop('llm_headers', None)
    final['reject_strategies'][10] = corrected
    masked_base = copy.deepcopy(original)
    masked_final = copy.deepcopy(final)

    def mask(a, b, selected):
        for k, v in selected.items():
            if type(v) is dict:
                if k not in a:
                    require(equal(b[k], v), 'new_object_extra_descendants')
                    b.pop(k)
                else:
                    mask(a[k], b[k], v)
            else:
                a.pop(k, None)
                b.pop(k, None)

    mask(masked_base, masked_final, overlay)
    masked_final['reject_strategies'][10] = copy.deepcopy(original['reject_strategies'][10])
    require(equal(masked_base, masked_final), 'unspecified_fields_changed')
    check_final(final, original, overlay, corrected, final)
    print('PASS all_unspecified_fields_unchanged rule_subtree_unchanged history_operational_unchanged', flush=True)
    print('PASS strategies_13_ordered only_index10_literal_token_changed', flush=True)
    print('PASS final_prompt_exact_overlay_utf8 headers_absent no_extra_overlay_options', flush=True)
    for path, (raw, mode) in snapshots.items():
        require(bounded_read(path, MAX_RESOURCE) == raw and metadata(path) == mode,
                'base_resource_changed_before_publish')
    out_qr = stage / 'query_rejection_llm_v3.json'
    out_patch = stage / 'root-config.patch.json'
    for path, obj in ((out_qr, final), (out_patch, patch)):
        if path.exists() or path.is_symlink():
            owned_file(path)
            require(equal(parse(bounded_read(path, MAX_JSON)), obj), 'existing_output_not_equivalent')
    qr_result = publish(out_qr, final)
    patch_result = publish(out_patch, patch)
    staged = parse(bounded_read(out_qr, MAX_JSON))
    check_final(staged, original, overlay, corrected, final)
    require(equal(parse(bounded_read(out_patch, MAX_JSON)), patch), 'staged_patch_mismatch')
    check_overlay(overlay, parse(bounded_read(out_patch, MAX_JSON)))
    for path, (raw, mode) in snapshots.items():
        require(bounded_read(path, MAX_RESOURCE) == raw and metadata(path) == mode,
                'base_resource_changed_after_publish')
    print('PASS actual_staged_json_strict_types_exact_overlay_full_preservation', flush=True)
    print('PASS actual_staged_llm_headers_key_ABSENT_not_null', flush=True)
    print('PASS original_resource_bytes_modes_owners_unchanged memory_comparison count=' + str(len(snapshots)), flush=True)
    print('PASS root_patch_minimal original_root_never_serialized', flush=True)
    print('output=' + str(out_qr) + ' mode=0600 publish=' + qr_result, flush=True)
    print('output=' + str(out_patch) + ' mode=0600 publish=' + patch_result, flush=True)
    print('resource_base=' + str(BASE) + ' relative_refs_not_rebased', flush=True)
    print('UNRUN live_install activation Initialize HTTP model Redis runtime build tests deploy', flush=True)
    print('result=PASS', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--overlay', type=Path, required=True)
    parser.add_argument('--root-patch', type=Path, required=True)
    parser.add_argument('--stage', type=Path, required=True)
    args = parser.parse_args()
    try:
        execute(args)
    except GuardError as exc:
        print('FAIL category=' + str(exc), file=sys.stderr)
        return 1
    except (OSError, ValueError, TypeError, KeyError, RecursionError, OverflowError):
        print('FAIL category=protected_input_or_schema_error', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
