#!/usr/bin/env python3
"""Validate local Phase2 deltas only; never read a base or use the network."""
import argparse
import json
from pathlib import Path
import sys

MAX_BYTES = 32768
EXPECTED_PROMPT = (
    "你是一个车载语音助手，请对用户query依次标注标签，严格按照顺序用\t分隔标签，只返回一行结果。\n"
    "格式为：发话对象标签\t是否有意义\t句子通顺度\t多轮语义完整性\t领域相关性\t上下文关联性\t句式\t相关轮次。\n"
    "需要标注的标签及规则：\n"
    "发话对象（发话对象名称/未知）：根据query判断，只要query中没有明确的说话对象，都是未知。如果query中有名字或称呼，则说话对象为query中提及的称呼\n"
    "是否有意义（有意义/无意义）：包含嗯、呵、呢等语气词视为无意义。\n"
    "句子通顺度（通顺/不通顺）：完全混乱的句子判为不通顺。\n"
    "多轮语义完整性（完整/不完整）：结合用户历史，如果当前用户query无缺失、无指代、无隐含指代，则语义完整。\n"
    "领域相关性（基础相关/业务相关/不相关）：基础相关指的是座舱垂域下的基础指令；业务相关指的是人机闲聊指令；不相关指的是人人对话内容。\n"
    "上下文关联性（明确相关/模糊相关/不相关）：明确相关：当前用户query和之前某一轮次的query有明显指代、继承关系；模糊相关：当前用户query和之前某一轮次的query有情感表达；不相关：当前用户query和历史毫不相关。\n"
    "句式（问答/指令/其他）:如果当前query和历史相关，则需要结合用户历史和query判断句式 。如果当前query和历史无关，则根据当前query的内容判断句式。\n"
    "相关轮次(第*轮)：如果用户当前query和之前某一轮次有关联，则输出对应轮次；如果没有关联，则输出None。\n"
    "用户对话内容为：\n"
)
EXPECTED_OVERLAY = {
    "rejection_cmd": "",
    "semantic_cmd": "",
    "llm": {
        "enable": True,
        "llm_url": "http://82.157.133.222:8000/v1/chat/completions",
        "llm_model": "Qwen2_5_3b_reject-4bit",
        "llm_max_tokens": 1024,
        "temperature": 0.01,
        "top_p": 0.95,
        "llm_top_k": 20,
        "chat_template_kwargs": {"enable_thinking": False},
        "llm_prompt": EXPECTED_PROMPT,
    },
}
EXPECTED_PATCH = {
    "LanguageUnderstanding": {
        "QueryRejectionConfig": "conf/query_rejection_llm_v3.json",
    },
}


def require(condition, category):
    if not condition:
        raise ValueError(category)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate_json_key")
        result[key] = value
    return result


def reject_constant(_value):
    raise ValueError("nonfinite_json_number")


def load_json(path):
    with path.open("rb") as handle:
        raw = handle.read(MAX_BYTES + 1)
    require(len(raw) <= MAX_BYTES, "input_size_limit")
    return json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def same_values_and_types(actual, expected):
    if type(actual) is not type(expected):
        return False
    if isinstance(expected, dict):
        return (actual.keys() == expected.keys() and
                all(same_values_and_types(actual[key], expected[key])
                    for key in expected))
    return actual == expected


def validate(overlay, patch):
    require(same_values_and_types(overlay, EXPECTED_OVERLAY),
            "overlay_exact_values_types_or_keys")
    require(same_values_and_types(patch, EXPECTED_PATCH),
            "root_patch_not_minimal_or_incorrect")
    prompt = overlay["llm"]["llm_prompt"]
    encoded = prompt.encode("utf-8")
    require(encoded == EXPECTED_PROMPT.encode("utf-8"), "prompt_exact_utf8")
    require(encoded.count(b"\x09") == 8 and encoded.count(b"\x0a") == 12,
            "prompt_tab_or_newline_count")
    require(encoded.endswith(b"\x0a") and b"\x0d" not in encoded,
            "prompt_line_endings")
    require(bytes([92, 116]) not in encoded and bytes([92, 110]) not in encoded,
            "literal_escape_in_prompt")
    require("格式为：".encode("utf-8") in encoded and
            b"\xef\xbc\x9b" in encoded and
            "句式（问答/指令/其他）:".encode("utf-8") in encoded and
            "相关轮次(第*轮)：".encode("utf-8") in encoded,
            "punctuation_codepoints_or_bytes")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--overlay", required=True, type=Path)
    parser.add_argument("--root-patch", required=True, type=Path)
    args = parser.parse_args()
    try:
        validate(load_json(args.overlay), load_json(args.root_patch))
    except (OSError, UnicodeError, ValueError, RecursionError):
        # Never print parser errors, exception text, keys or supplied contents.
        print("FAIL local_delta_validation", file=sys.stderr)
        return 1
    print("PASS overlay_json_exact_keys_values_types")
    print("PASS prompt_utf8_exact tabs=8 newlines=12 punctuation_preserved")
    print("PASS legacy_commands_empty headers_absent no_extra_options")
    print("PASS root_patch_minimal")
    print("UNRUN protected_server_merge resource_placement activation inference")
    return 0


if __name__ == "__main__":
    sys.exit(main())
