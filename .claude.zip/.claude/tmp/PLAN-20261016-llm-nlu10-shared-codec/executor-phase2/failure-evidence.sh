#!/usr/bin/env bash
set -euo pipefail
python3 -I - <<'PY'
import hashlib,json,pathlib,shlex,subprocess
root=pathlib.Path('/home/daigd/dialogue')
log=pathlib.Path('/home/daigd/wtp184-validation-logs/PLAN-20261016-llm-nlu10-shared-codec-v1-phase2-nlu_0_6b_offline_backend_test-1.log')
lines=log.read_text().splitlines()
print('PRIMARY_LOG='+str(log))
print('---COMPILER ACTIONS---')
for i,line in enumerate(lines,1):
    if line.lstrip().startswith('/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc ') and ' -c cu/' in line:
        tokens=shlex.split(line.rstrip(')'))
        source=tokens[tokens.index('-c')+1]
        standards=[t for t in tokens if t.startswith('-std=')]
        print('line=%s source=%s compiler=%s standards=%s effective=%s'%(i,source,tokens[0],','.join(standards),standards[-1]))
print('---EXACT COMMAND AND TOOLCHAIN HEADER---')
for line in lines[:65]:
    if line=='BAZEL_TEST_OUTPUT': break
    print(line)
print('---FIRST ERROR CONTEXT---')
for i,line in enumerate(lines):
    if '272:76: error:' in line:
        print('\n'.join(lines[i:i+4]));break
print('---SCOPED SOURCE / BUILD---')
for rel,start,end in [('cu/nlu_0_6b_offline_backend_test.cc',258,279),('cu/BUILD',86,116)]:
    p=root/rel
    if p.is_symlink() or str(p.resolve())!=str(p) or root not in p.resolve().parents: raise RuntimeError('Scope/linked path failure')
    print('FILE='+str(p))
    for n,line in enumerate(p.read_text().splitlines(),1):
        if start<=n<=end: print('%s:%s'%(n,line))
print('ACTUAL_GCC_VERSION='+subprocess.check_output(['/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc','-dumpversion'],timeout=5).decode().strip())
print('ACTUAL_GCC_SYSROOT='+subprocess.check_output(['/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc','--print-sysroot'],timeout=5).decode().strip())
txn=pathlib.Path('/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v1-phase2-20261016T111509586383Z')
meta=json.loads((txn/'metadata.json').read_text())
index=root/'.git/index'
print('FINAL_INDEX_UNCHANGED='+str(hashlib.sha256(index.read_bytes()).hexdigest()==meta['index_sha256_before']))
print('APPLICATION_RESULT='+meta['result'])
print('---SUMMARY---')
for line in lines:
    if line.startswith('Executed ') or line.startswith('BAZEL_EXIT=') or line.startswith('[  PASSED  ]') or line.startswith('[==========]'): print(line)
PY
