#!/usr/bin/env python3
"""Temporary Phase4 JSON migration/static checks; no wire parser or service calls."""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import posixpath
import sys

PLAN = 'PLAN-20261016-llm-nlu10-shared-codec'
HEAD = 'aca4b3e4cd653bf2422ffd1de2680ce3724bc32b'
ROOT = '/home/shared/models/car_v3.0'
NLU = 'conf/nlu_config_06b_http_offline.json'
CAT = 'conf/models/nlu/profiles.json'
PROTO = 'conf/models/nlu/protocols/v3.json'
V4 = 'conf/models/nlu/protocols/v4.json'
PROFILE = 'nlu_06b_v3'
CLOSURE = (NLU, CAT, PROTO)
COMMON = {'model', 'system_prompt', 'stream', 'temperature', 'top_p', 'top_k',
          'max_tokens', 'enable_thinking', 'allow_multi_intent_output', 'protocol_path'}
HTTP = {'endpoint', 'api_key_env', 'connect_timeout_ms', 'total_timeout_ms',
        'max_response_bytes', 'diagnostic_capture_enabled', 'diagnostic_capture_output_path',
        'diagnostic_capture_request_id_prefix', 'diagnostic_capture_max_entries',
        'diagnostic_capture_max_content_bytes'}
RETIRED = {'version', 'response_protocol', 'response_flag_prefix'}
WIRE_CHANGED = {'version', 'protocol', 'request_field_prefixes', 'request_slot_assignment',
                'request_slot_separator', 'request_history_separator'}
MAX_BYTES = 2 * 1024 * 1024
SCHEMA_SOURCES = {
    'selector_and_path_roles': ['cu/llm_protocol.cc:25-40,110-137'],
    'http_keys_endpoint_environment': ['cu/nlu_0_6b_http_backend.cc:107-152,681-692'],
    'http_types_ranges_defaults': ['cu/nlu_0_6b_http_backend.cc:29-35,74-92,153-207'],
    'common_profile_exact_keys_types_ranges': ['cu/nlu_10_protocol.cc:32-91,203-236'],
    'protocol_identity_retired_selectors': ['cu/llm_protocol.cc:129-137',
                                          'cu/nlu_10_protocol.cc:203-212'],
    'delimiter_scalar_array_bytes_and_roles': ['cu/nlu_10_protocol.cc:94-179,237-257'],
    'explicit_markers': ['cu/nlu_10_protocol.cc:182-200,258-259,582-586'],
    'two_prefixes_empty_history': ['cu/nlu_10_protocol.cc:14,260-305'],
    'root_parent_forwarding': ['cu/dialogue_v3.cc:782,805-806,815'],
}


class Invalid(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Invalid(reason)  # Fixed categories only; never configuration values.


def same(a, b):
    return json.dumps(a, sort_keys=True, ensure_ascii=False, allow_nan=False) == json.dumps(
        b, sort_keys=True, ensure_ascii=False, allow_nan=False)


def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, 'duplicate_json_key')
        result[key] = value
    return result


def reject_constant(_):
    raise Invalid('nonfinite_json_number')


def load(path, limit=MAX_BYTES):
    require(path.is_file() and not path.is_symlink(), 'local_input_not_regular')
    require(path.stat().st_size <= limit, 'local_input_too_large')
    raw = path.read_bytes()
    require(len(raw) <= limit and not raw.startswith(b'\xef\xbb\xbf'), 'local_json_encoding')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=reject_constant)


def encode(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode('utf-8')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write_new(path, raw):
    require(not path.exists() and not path.is_symlink(), 'output_already_exists')
    with path.open('xb') as stream:
        stream.write(raw)


def relative_path(value):
    require(isinstance(value, str) and value and '\0' not in value, 'reference_string')
    require(not value.startswith('/') and '\\' not in value, 'reference_not_posix_relative')
    normal = posixpath.normpath(value)
    require(normal not in ('.', '..') and not normal.startswith('../'), 'reference_escapes_base')
    return ROOT + '/' + normal


def bounded_int(value, low, high):
    return type(value) is int and low <= value <= high


def numeric(value, low, high, inclusive=True):
    return type(value) in (int, float) and math.isfinite(value) and (
        value >= low if inclusive else value > low) and value <= high


def text(value):
    return isinstance(value, str) and bool(value)


def printable_byte(value, tab=False):
    return isinstance(value, str) and len(value.encode('utf-8')) == 1 and (
        0x21 <= ord(value) <= 0x7e or (tab and value == '\t'))


def response_candidates(value, compact):
    require(type(value) in (str, list), 'response_candidate_type')
    if isinstance(value, str) and not compact:
        require(len(value) == 1, 'response_scalar_width')
    result = list(value)
    require(1 <= len(result) <= 94 and all(printable_byte(x) for x in result),
            'response_candidate_bytes')
    require(len(set(result)) == len(result), 'response_candidate_duplicate')
    return result


def no_controls(value):
    return all(ord(c) >= 32 and ord(c) != 127 for c in value)


def schema(objects):
    """Static initialization checks mapped to captured C++; no wire parsing."""
    nlu = objects[NLU]
    require(isinstance(nlu, dict) and not RETIRED.intersection(nlu), 'nlu_retired_selector')
    require('profile' not in nlu and 'profile_catalog_path' not in nlu, 'nlu_flat_selector')
    require(nlu.get('Backend', {}).get('type') == 'openai_http', 'backend_selection')
    selector = nlu.get('Model')
    require(isinstance(selector, dict) and set(selector) == {'profile', 'profile_catalog_path'},
            'model_selector_keys')
    require(text(selector['profile']), 'model_selector_profile')
    relative_path(selector['profile_catalog_path'])
    require(selector['profile'] == PROFILE and selector['profile_catalog_path'] == CAT,
            'selected_closure_changed')
    http = nlu.get('OpenAIHttp')
    require(isinstance(http, dict) and set(http) <= HTTP, 'http_execution_keys')
    endpoint = http.get('endpoint')
    require(text(endpoint), 'http_endpoint_type')
    env_endpoint = endpoint.startswith('${') and endpoint.endswith('}')
    require(env_endpoint or endpoint.startswith(('http://', 'https://')), 'http_endpoint_scheme')
    if 'api_key_env' in http:
        require(isinstance(http['api_key_env'], str), 'http_api_key_env_type')
    for key, default, low, high in [('connect_timeout_ms', 5000, 1, 600000),
                                  ('total_timeout_ms', 30000, 1, 600000),
                                  ('max_response_bytes', 1048576, 1, 16777216),
                                  ('diagnostic_capture_max_entries', 0, 0, 10000),
                                  ('diagnostic_capture_max_content_bytes', 0, 0, 1048576)]:
        require(bounded_int(http.get(key, default), low, high), 'http_range_' + key)
    require(http.get('total_timeout_ms', 30000) >= http.get('connect_timeout_ms', 5000),
            'http_timeout_order')
    require(type(http.get('diagnostic_capture_enabled', False)) is bool, 'diagnostic_bool')
    for key in ('diagnostic_capture_output_path', 'diagnostic_capture_request_id_prefix'):
        require(key not in http or isinstance(http[key], str), 'diagnostic_string')
    # This snapshot has capture absent. Do not enable it or probe output paths.
    require(not http.get('diagnostic_capture_enabled', False), 'unapproved_diagnostic_capture')
    catalog = objects[CAT]
    require(isinstance(catalog, dict) and isinstance(catalog.get('profiles'), dict), 'catalog_object')
    profile = catalog['profiles'].get(PROFILE)
    require(isinstance(profile, dict) and set(profile) == COMMON, 'common_profile_keys')
    require(text(profile['model']) and text(profile['system_prompt']), 'common_required_strings')
    require(type(profile['stream']) is bool and not profile['stream'], 'common_stream')
    for key in ('enable_thinking', 'allow_multi_intent_output'):
        require(type(profile[key]) is bool, 'common_bool_' + key)
    require(numeric(profile['temperature'], 0, 2), 'common_temperature')
    require(numeric(profile['top_p'], 0, 1, False), 'common_top_p')
    require(bounded_int(profile['top_k'], 1, 1000), 'common_top_k')
    require(bounded_int(profile['max_tokens'], 1, 65536), 'common_max_tokens')
    require(relative_path(profile['protocol_path']) == ROOT + '/' + PROTO, 'protocol_reference')
    protocol = objects[PROTO]
    require(isinstance(protocol, dict) and protocol.get('protocol') == 'nlu_10'
            and not RETIRED.intersection(protocol), 'protocol_identity')
    for key, allow_tab in [('field_delimiter', True), ('request_slot_assignment', False),
                           ('request_slot_separator', False), ('request_history_separator', False)]:
        require(printable_byte(protocol.get(key, ';' if key == 'request_history_separator' else None),
                               allow_tab), 'delimiter_' + key)
    field = protocol['field_delimiter']
    request_roles = [field, protocol['request_slot_assignment'], protocol['request_slot_separator'],
                     protocol.get('request_history_separator', ';')]
    require(len(set(request_roles)) == 4, 'request_role_collision')
    response_roles = [field]
    for key in ('response_slot_assignment', 'response_slot_separator', 'response_frame_separator'):
        response_roles += response_candidates(protocol.get(key), key == 'response_slot_assignment')
    require(len(set(response_roles)) == len(response_roles), 'response_role_collision')
    frames = response_candidates(protocol['response_frame_separator'], False)
    markers = [protocol.get('response_unknown_marker'), protocol.get('response_multi_marker')]
    for marker in markers:
        require(text(marker) and len(marker.encode('utf-8')) <= 128 and no_controls(marker)
                and field not in marker and not any(c in marker for c in frames), 'marker_bounds_roles')
    require(markers[0] != markers[1], 'identical_markers')
    prefixes = protocol.get('request_field_prefixes')
    require(isinstance(prefixes, list) and len(prefixes) == 2, 'prefix_count')
    for prefix in prefixes:
        require(isinstance(prefix, str) and len(prefix.encode('utf-8')) <= 128
                and no_controls(prefix) and field not in prefix
                and request_roles[-1] not in prefix, 'prefix_bounds_roles')
    if 'empty_history_request' in protocol:
        option = protocol['empty_history_request']
        require(isinstance(option, dict) and set(option) == {'history_field', 'query_prefix'},
                'empty_history_keys')
        require(text(option['history_field']), 'empty_history_nonempty')
        for value in option.values():
            require(isinstance(value, str) and len(value.encode('utf-8')) <= 128
                    and no_controls(value) and field not in value
                    and request_roles[-1] not in value, 'empty_history_bounds_roles')


def transform(original):
    """Approved finite conversion; never mutate the captured input."""
    result = copy.deepcopy(original)
    nlu, catalog, protocol = (result[p] for p in CLOSURE)
    require('Model' not in nlu, 'already_migrated_input')
    require(nlu.get('Backend', {}).get('type') == 'openai_http', 'original_backend')
    http = nlu['OpenAIHttp']
    require(http.get('profile') == PROFILE and http.get('profile_catalog_path') == CAT,
            'original_selection')
    profile = catalog['profiles'][PROFILE]
    require(set(profile) == COMMON | {'endpoint', 'connect_timeout_ms', 'total_timeout_ms'},
            'captured_profile_shape_changed')
    require(set(http) == {'response_protocol', 'endpoint', 'model', 'system_prompt',
                         'connect_timeout_ms', 'total_timeout_ms', 'max_response_bytes',
                         'temperature', 'top_p', 'top_k', 'max_tokens', 'enable_thinking',
                         'profile', 'profile_catalog_path'}, 'captured_http_shape_changed')
    nlu['Model'] = {key: http.pop(key) for key in ('profile_catalog_path', 'profile')}
    for key in ('endpoint', 'connect_timeout_ms', 'total_timeout_ms'):
        require(same(http[key], profile[key]), 'flat_catalog_transport_conflict_' + key)
        http[key] = profile.pop(key)
    # The old named-profile loader replaced effective config with the catalog entry.
    # Remove stale duplicates, not the catalog's effective prompt/max_tokens.
    for key in COMMON.intersection(http):
        del http[key]
    http.pop('response_protocol')
    require(protocol.get('request_field_prefixes') == ['history:', '', '', '', '', '', ''],
            'captured_prefix_layout_changed')
    require(protocol.get('empty_history_request') == {
        'history_field': 'history:None', 'query_prefix': 'query: '}, 'captured_empty_history_changed')
    for key in RETIRED:
        protocol.pop(key, None)
    protocol['protocol'] = 'nlu_10'
    protocol['request_field_prefixes'] = [protocol['request_field_prefixes'][0],
                                        protocol['empty_history_request']['query_prefix']]
    protocol['request_slot_assignment'] = '='
    protocol['request_slot_separator'] = ','
    protocol['request_history_separator'] = ';'
    schema(result)
    return result


def delta(before, after, prefix=''):
    changes = []
    if isinstance(before, dict) and isinstance(after, dict):
        for key in sorted(set(before) | set(after)):
            pointer = prefix + '/' + key.replace('~', '~0').replace('/', '~1')
            if key not in before:
                changes.append({'path': pointer, 'operation': 'add'})
            elif key not in after:
                changes.append({'path': pointer, 'operation': 'remove'})
            else:
                changes += delta(before[key], after[key], pointer)
    elif not same(before, after):
        changes.append({'path': prefix, 'operation': 'replace'})
    return changes


def preservation(original, candidate):
    schema(candidate)
    checks = []
    def equal(name, a, b):
        require(same(a, b), 'preservation_' + name)
        checks.append({'id': name, 'status': 'PASS'})
    old_n, new_n = original[NLU], candidate[NLU]
    equal('nlu_unrelated_sections_and_hotfix',
          {k: v for k, v in old_n.items() if k != 'OpenAIHttp'},
          {k: v for k, v in new_n.items() if k not in ('OpenAIHttp', 'Model')})
    equal('selector_identity_and_catalog_path',
          {k: old_n['OpenAIHttp'][k] for k in ('profile', 'profile_catalog_path')}, new_n['Model'])
    old_profile = original[CAT]['profiles'][PROFILE]
    new_profile = candidate[CAT]['profiles'][PROFILE]
    for key in sorted(COMMON):
        equal('selected_profile_' + key, old_profile[key], new_profile[key])
    for key in ('endpoint', 'connect_timeout_ms', 'total_timeout_ms'):
        equal('http_catalog_' + key, old_profile[key], new_n['OpenAIHttp'][key])
        equal('http_flat_' + key, old_n['OpenAIHttp'][key], new_n['OpenAIHttp'][key])
    equal('http_effective_response_cap_default', 1048576, new_n['OpenAIHttp']['max_response_bytes'])
    equal('http_flat_response_cap', old_n['OpenAIHttp']['max_response_bytes'],
          new_n['OpenAIHttp']['max_response_bytes'])
    equal('http_exact_execution_postimage',
          {k: old_n['OpenAIHttp'][k] for k in ('endpoint', 'connect_timeout_ms',
                                             'total_timeout_ms', 'max_response_bytes')},
          new_n['OpenAIHttp'])
    equal('catalog_unselected_profiles_and_sections',
          {**original[CAT], 'profiles': {k: v for k, v in original[CAT]['profiles'].items()
                                       if k != PROFILE}},
          {**candidate[CAT], 'profiles': {k: v for k, v in candidate[CAT]['profiles'].items()
                                        if k != PROFILE}})
    equal('unselected_v4_descriptor', original[V4], candidate[V4])
    equal('protocol_nonmigrated_fields',
          {k: v for k, v in original[PROTO].items() if k not in WIRE_CHANGED},
          {k: v for k, v in candidate[PROTO].items() if k not in WIRE_CHANGED})
    equal('wire_two_prefixes', ['history:', 'query: '], candidate[PROTO]['request_field_prefixes'])
    equal('wire_empty_history', {'history_field': 'history:None', 'query_prefix': 'query: '},
          candidate[PROTO]['empty_history_request'])
    # Exact roles are migration acceptance, not a general vocabulary blacklist.
    for key, expected in [('field_delimiter', '\t'), ('request_slot_assignment', '='),
                          ('request_slot_separator', ','), ('request_history_separator', ';'),
                          ('response_slot_assignment', [':', '=']),
                          ('response_slot_separator', [',']), ('response_frame_separator', ';'),
                          ('response_unknown_marker', 'flag:unknown'), ('response_multi_marker', 'multi:')]:
        equal('wire_' + key, expected, candidate[PROTO][key])
    require(not RETIRED.intersection(new_n['OpenAIHttp']), 'remaining_retired_http_selector')
    require(not (RETIRED | HTTP).intersection(new_profile), 'remaining_profile_transport_selector')
    checks.append({'id': 'retired_selectors_absent_in_selected_closure', 'status': 'PASS'})
    return checks


def read_inputs(phase):
    evidence = load(phase / 'evidence.json', 4 * MAX_BYTES)
    roots = load(phase / 'root-referrers/evidence.json')
    policies = load(phase / 'root-referrers/policy-evidence.json')
    for packet in (evidence, roots, policies):
        require(packet['target_mutation'] == 'NONE', 'capture_target_mutation')
        for stage in packet['stages'].values():
            require(stage['exit_status'] == 0, 'capture_stage_exit')
    capture = evidence['stages']['resource_capture']['data']['data']
    require(capture['redacted_paths'] == [], 'redacted_json_gap')
    require(evidence['findings']['credential_screen']['redacted_paths'] == [], 'credential_screen_gap')
    require(capture['resource_root'] == ROOT, 'resource_root_changed')
    require(set(capture['redacted_json']) == set(CLOSURE) | {V4}, 'capture_file_closure')
    require({v['path'] for v in capture['files']} == set(CLOSURE) | {V4}, 'metadata_closure')
    source = evidence['stages']['source_contract']['data']
    require(source['identity']['head'] == HEAD, 'source_head_changed')
    require(source['identity']['scoped_status'] == '', 'captured_source_dirty')
    for path in ('cu/llm_protocol.cc', 'cu/nlu_10_protocol.cc', 'cu/nlu_0_6b_http_backend.cc'):
        metadata = next(f for f in source['files'] if f['path'] == path)
        require(digest(source['source'][path]['text'].encode('utf-8')) == metadata['sha256'],
                'captured_source_hash_mismatch')
    root_data = roots['stages']['read_roots']['data']['data']
    policy_data = policies['stages']['read_policy']['data']['data']
    for group in (root_data, policy_data):
        require(group['root_object_equal'] is True and len(group['files']) == 2, 'root_consumer_conflict')
        for record in group['files']:
            require(record['regular_file'] is True and record['symlink'] is False, 'root_file_identity')
            require(record['dialogue_base'] == ROOT and record['nlu_config_selector'] == NLU,
                    'root_selector_base_conflict')
            require(record['references'][0]['lexical_path_from_dialogue_base'] == ROOT + '/' + NLU,
                    'root_reference_conflict')
    require({f['path']: f['sha256'] for f in root_data['files']} ==
            {f['path']: f['sha256'] for f in policy_data['files']}, 'root_policy_packet_drift')
    expected_policy = {'$.ContextManager.max_turn_size': 2, '$.ContextManager.max_query_records': 15,
                       '$.ContextManager.expire_strategy.user_session': 150,
                       '$.ContextManager.expire_strategy.query_records': 15,
                       '$.ContextManager.expire_strategy.llm_simple_cache': -1,
                       '$.Nlu06B.max_history_rounds': 2, '$.Nlu06B.max_history_bytes': 65536,
                       '$.Nlu06B.allow_multi_intent_input': False,
                       '$.ContextFilter.enable': True, '$.QueryGuard.enable': True}
    for record in policy_data['files']:
        leaves = {v['json_path']: v['value'] for v in record['relevant_leaves']}
        for path, value in expected_policy.items():
            require(same(leaves.get(path), value), 'captured_policy_conflict')
    return capture, source, root_data, policy_data, expected_policy


def reference_proof(capture, candidate):
    records = []
    require(len(capture['reference_presence']) == 19, 'reference_count_changed')
    for reference in capture['reference_presence']:
        require(reference['exists'] is True and reference['isfile'] is True, 'captured_remote_missing_file')
        expected = relative_path(reference['reference'])
        resolved = reference['resolved_under_resource_root']
        require(resolved.startswith(ROOT + '/') and resolved == expected, 'remote_reference_resolution')
        old_path = reference['json_path']
        file = next((p for p in candidate if old_path.startswith(p + '/')), None)
        require(file is not None, 'reference_owner')
        pointer = old_path[len(file):]
        if file == NLU and pointer == '/OpenAIHttp/profile_catalog_path':
            pointer = '/Model/profile_catalog_path'
        value = candidate[file]
        for part in pointer[1:].split('/'):
            value = value[int(part)] if isinstance(value, list) else value[part]
        require(same(value, reference['reference']), 'candidate_reference_changed')
        records.append({**reference, 'candidate_json_path': file + pointer,
                        'evidence': 'evidence.json#/stages/resource_capture/data/data/reference_presence',
                        'status': 'PASS_CAPTURED_REMOTE_EXISTENCE'})
    return records


def byte_evidence(protocol):
    keys = ('field_delimiter', 'request_slot_assignment', 'request_slot_separator',
            'request_history_separator', 'response_frame_separator', 'response_unknown_marker',
            'response_multi_marker')
    values = {key: protocol[key] for key in keys}
    for key in ('response_slot_assignment', 'response_slot_separator', 'request_field_prefixes'):
        values.update({key + '/' + str(i): value for i, value in enumerate(protocol[key])})
    values.update({'empty_history_request/' + key: value
                   for key, value in protocol['empty_history_request'].items()})
    return {key: {'codepoints': ['U+%04X' % ord(c) for c in value],
                  'decoded_utf8_hex': value.encode('utf-8').hex()} for key, value in values.items()}


def make_manifest(phase, candidate_dir, objects, capture, source, root_data, policy_data, policies):
    preservation_checks = preservation(capture['redacted_json'], objects)
    refs = reference_proof(capture, objects)
    metadata = {item['path']: item for item in capture['files']}
    files = []
    for path in CLOSURE:
        raw = (candidate_dir / path).read_bytes()
        files.append({'resource_relative_path': path, 'candidate_path': str(candidate_dir / path),
                      'candidate_sha256': digest(raw), 'candidate_size': len(raw),
                      'original_metadata': metadata[path],
                      'original_metadata_reference': 'evidence.json#/stages/resource_capture/data/data/files',
                      'semantic_changes': delta(capture['redacted_json'][path], objects[path])})
    packet_refs = [{'path': str(phase / path), 'sha256': digest((phase / path).read_bytes())}
                   for path in ('evidence.json', 'root-referrers/evidence.json',
                                'root-referrers/policy-evidence.json')]
    root_metadata = [{k: v for k, v in f.items() if k not in ('relevant_leaves', 'references')}
                     for f in policy_data['files']]
    return {'plan_id': PLAN, 'version': 2, 'phase': '4b/local-4c-preparation',
            'status': 'STATIC_CANDIDATE_PASS_NOT_INSTALLED_NOT_REVIEWED',
            'source_head': HEAD, 'source_identity': source['identity'],
            'source_metadata': source['files'], 'evidence_packets': packet_refs,
            'redacted_paths': capture['redacted_paths'], 'resource_root': ROOT,
            'candidate_directory': str(candidate_dir), 'files': files,
            'unselected_v4_original_metadata': metadata[V4],
            'unchanged_root_metadata_and_policy_hashes': root_metadata,
            'unchanged_policy_assertions': policies, 'equality_assertions': preservation_checks,
            'source_mapped_static_schema_checks': [
                {'id': k, 'status': 'PASS_STATIC', 'source': v} for k, v in SCHEMA_SOURCES.items()],
            'recorded_remote_references': refs,
            'root_selector_evidence': {
                'packet': 'root-referrers/evidence.json#/stages/read_roots/data/data/files',
                'root_count': len(root_data['files']), 'selector_target': ROOT + '/' + NLU,
                'target_regular_file_metadata': metadata[NLU],
                'base_rule': 'root-file parent forwarded unchanged; not conf/catalog directory'},
            'wire_bytes': byte_evidence(objects[PROTO]),
            'effective_precedence': 'Handed-off old named loader replaces effective configuration with catalog; '
                                    'selected catalog prompt/max_tokens retained, flat stale duplicates removed.',
            'effective_max_tokens': objects[CAT]['profiles'][PROFILE]['max_tokens'],
            'http_response_cap': {'catalog_absent_default': 1048576,
                                  'flat_and_candidate_equal_default': True},
            'format': 'UTF-8 without BOM, indent 2, LF; semantic preservation, not original spacing',
            'privacy': 'New mode-0700 task directories; Python 3.14 Windows owner/admin directory ACL. '
                       'Private content never emitted to logs. Remote exact preimages not exported.',
            'instrumentation': 'No product instrumentation; local bounded category/count logs only.',
            'not_run': ['C++ loader initialization', 'runtime activation', 'environment resolution',
                        'fresh remote drift/existence checks', 'independent resource review', 'installation',
                        'build/Bazel', 'model/HTTP/SDK/device/service/reload/deployment'],
            'install_handoff_only': {'requires': ['independent scoped resource review',
                                                 'server-owner preimage drift/metadata checks',
                                                 'protected backups and same-filesystem staging'],
                                     'order': [PROTO, CAT, NLU],
                                     'permissions': 'Preserve original UID/GID/mode; no install performed',
                                     'rollback': 'Only replaced files still byte-equal to exact candidates'}}


def prepare(args):
    capture, source, roots, policies, expected = read_inputs(args.phase_dir)
    objects = transform(capture['redacted_json'])
    preservation(capture['redacted_json'], objects)
    reference_proof(capture, objects)
    require(args.candidate_dir.parent == args.phase_dir, 'candidate_not_direct_phase_child')
    require(not args.manifest.exists(), 'manifest_already_exists')
    args.candidate_dir.mkdir(mode=0o700)  # Fail on any pre-existing candidate directory.
    for path in CLOSURE:
        target = args.candidate_dir / path
        target.parent.mkdir(parents=True, exist_ok=True)
        write_new(target, encode(objects[path]))
    decoded = {p: load(args.candidate_dir / p) for p in CLOSURE}
    decoded[V4] = capture['redacted_json'][V4]
    manifest = make_manifest(args.phase_dir, args.candidate_dir, decoded, capture,
                             source, roots, policies, expected)
    write_new(args.manifest, encode(manifest))
    print('PASS prepare files=3 equality_assertions=%d captured_remote_refs=19 source_mapped_groups=%d' %
          (len(manifest['equality_assertions']), len(SCHEMA_SOURCES)))


def validate(args):
    capture, source, roots, policies, expected = read_inputs(args.phase_dir)
    require(args.candidate_dir.is_dir() and not args.candidate_dir.is_symlink(), 'candidate_directory_type')
    entries = list(args.candidate_dir.rglob('*'))
    require(not any(p.is_symlink() for p in entries), 'candidate_symlink')
    require({p.relative_to(args.candidate_dir).as_posix() for p in entries if p.is_file()} == set(CLOSURE),
            'candidate_file_set')
    objects = {p: load(args.candidate_dir / p) for p in CLOSURE}
    objects[V4] = capture['redacted_json'][V4]
    regenerated = transform(capture['redacted_json'])
    for path in CLOSURE:
        require(same(objects[path], regenerated[path]), 'candidate_unapproved_semantic_delta')
        require((args.candidate_dir / path).read_bytes() == encode(regenerated[path]),
                'candidate_bytes_not_reproducible')
    calculated = make_manifest(args.phase_dir, args.candidate_dir, objects, capture,
                               source, roots, policies, expected)
    require(same(load(args.manifest), calculated), 'manifest_mismatch')
    result = {'status': 'PASS_STATIC_ONLY', 'files': 3, 'selected_plus_unselected_json': 4,
              'equality_assertions': len(calculated['equality_assertions']),
              'source_mapped_groups': len(SCHEMA_SOURCES), 'captured_remote_refs': 19,
              'captured_root_selectors': 2, 'exact_reproduction_and_hashes': 'PASS',
              'manifest_sha256': digest(args.manifest.read_bytes()),
              'real_cpp_loader_initialization': 'UNRUN', 'installed': False, 'reviewed': False}
    write_new(args.result, encode(result))
    print('PASS validate files=3 selected_plus_unselected_json=4 equality_assertions=%d remote_refs=19 roots=2' %
          len(calculated['equality_assertions']))


def fixtures(args):
    profile = {'endpoint': 'https://example.invalid/v1/chat/completions', 'model': 'fixture-model',
               'protocol_path': PROTO, 'system_prompt': 'fixture：prompt；text',
               'connect_timeout_ms': 5000, 'total_timeout_ms': 30000, 'temperature': 0.1,
               'top_p': 0.9, 'top_k': 20, 'max_tokens': 128, 'enable_thinking': False,
               'stream': False, 'allow_multi_intent_output': False}
    flat = {k: profile[k] for k in ('endpoint', 'model', 'connect_timeout_ms', 'total_timeout_ms',
                                   'temperature', 'top_p', 'top_k', 'enable_thinking')}
    flat.update({'profile': PROFILE, 'profile_catalog_path': CAT, 'max_response_bytes': 1048576,
                 'max_tokens': 1024, 'system_prompt': 'stale fixture', 'response_protocol': 'tsv_v1'})
    old = {NLU: {'Backend': {'type': 'openai_http'}, 'OpenAIHttp': flat,
                 'HotFix': {'enable': True, 'rule_paths': ['rules/fixture.txt']},
                 'Unrelated': {'nested': [True, 15, 'do not modify；：']}},
           CAT: {'profiles': {PROFILE: profile, 'nlu_06b_v4': {'untouched': True},
                              'nlu_4b_v4': {'untouched': 'legacy'}}, 'other': ['keep']},
           PROTO: {'version': 'nlu_06b_v3',
                   'request_field_prefixes': ['history:', '', '', '', '', '', ''],
                   'empty_history_request': {'history_field': 'history:None', 'query_prefix': 'query: '},
                   'field_delimiter': '\t', 'request_slot_assignment': ':', 'request_slot_separator': ';',
                   'response_slot_assignment': [':', '='], 'response_slot_separator': [','],
                   'response_frame_separator': ';', 'response_unknown_marker': 'flag:unknown',
                   'response_multi_marker': 'multi:'}, V4: {'version': 'legacy'}}
    tests = []
    def test(name, action, rejected=False):
        try:
            action()
        except Invalid:
            require(rejected, 'fixture_unexpected_rejection_' + name)
        else:
            require(not rejected, 'fixture_missing_rejection_' + name)
        tests.append({'id': name, 'status': 'PASS', 'expected': 'reject' if rejected else 'accept'})
    frozen = copy.deepcopy(old)
    new = transform(old)
    test('actual_transform_and_preservation', lambda: preservation(old, new))
    test('original_not_mutated', lambda: require(same(old, frozen), 'fixture_input_mutated'))
    test('deterministic_repeated_transform', lambda: require(same(new, transform(old)), 'fixture_nondeterministic'))
    test('catalog_prompt_128_not_flat_1024', lambda: require(
        new[CAT]['profiles'][PROFILE]['max_tokens'] == 128 and
        new[CAT]['profiles'][PROFILE]['system_prompt'] == profile['system_prompt'], 'fixture_precedence'))
    test('unicode_payload_not_normalized', lambda: require(
        new[NLU]['Unrelated']['nested'][2] == 'do not modify；：' and
        new[CAT]['profiles'][PROFILE]['system_prompt'] == 'fixture：prompt；text', 'fixture_normalization'))
    test('tab_decoded_09_json_roundtrip', lambda: require(
        json.loads(encode(new[PROTO]))['field_delimiter'].encode('utf-8') == b'\x09', 'fixture_tab'))
    test('two_prefixes_unknown_multi_arrays_empty_history', lambda: preservation(old, new))
    test('already_migrated_input', lambda: transform(new), True)
    def mutation(path, value, validator=schema):
        objects = copy.deepcopy(new)
        current = objects
        for key in path[:-1]:
            current = current[key]
        current[path[-1]] = value
        validator(objects)
    cases = [
        ('literal_backslash_t', [PROTO, 'field_delimiter'], '\\t'),
        ('fullwidth_request_equals', [PROTO, 'request_slot_assignment'], '＝'),
        ('fullwidth_history_semicolon', [PROTO, 'request_history_separator'], '；'),
        ('fullwidth_response_colon', [PROTO, 'response_slot_assignment'], ['：', '=']),
        ('fullwidth_response_comma', [PROTO, 'response_slot_separator'], ['，']),
        ('response_assignment_duplicates', [PROTO, 'response_slot_assignment'], [':', ':']),
        ('response_role_collision', [PROTO, 'response_slot_separator'], [':']),
        ('request_role_collision', [PROTO, 'request_history_separator'], ','),
        ('mixed_request_assignment_candidates', [PROTO, 'request_slot_assignment'], ['=', ':']),
        ('seven_old_prefixes', [PROTO, 'request_field_prefixes'], ['history:'] + [''] * 6),
        ('prefix_control', [PROTO, 'request_field_prefixes'], ['history:', 'query:\t']),
        ('marker_control', [PROTO, 'response_unknown_marker'], 'flag:\nunknown'),
        ('marker_frame_collision', [PROTO, 'response_multi_marker'], 'multi;'),
        ('marker_same', [PROTO, 'response_multi_marker'], 'flag:unknown'),
        ('marker_utf8_byte_limit', [PROTO, 'response_multi_marker'], '字' * 43),
        ('empty_history_wrong_type', [PROTO, 'empty_history_request'], {'history_field': '', 'query_prefix': 1}),
        ('selected_profile_stale_transport', [CAT, 'profiles', PROFILE, 'endpoint'], 'https://example.invalid'),
        ('http_stale_model_key', [NLU, 'OpenAIHttp', 'model'], 'stale'),
        ('selector_extra', [NLU, 'Model', 'extra'], True),
        ('absolute_catalog', [NLU, 'Model', 'profile_catalog_path'], '/' + CAT),
        ('escaping_catalog', [NLU, 'Model', 'profile_catalog_path'], '../' + CAT),
        ('top_k_bool_not_int', [CAT, 'profiles', PROFILE, 'top_k'], True),
        ('max_tokens_over_limit', [CAT, 'profiles', PROFILE, 'max_tokens'], 65537),
        ('temperature_negative', [CAT, 'profiles', PROFILE, 'temperature'], -0.01),
        ('top_p_zero', [CAT, 'profiles', PROFILE, 'top_p'], 0),
        ('stream_true', [CAT, 'profiles', PROFILE, 'stream'], True),
        ('thinking_not_bool', [CAT, 'profiles', PROFILE, 'enable_thinking'], 0),
        ('multi_gate_not_bool', [CAT, 'profiles', PROFILE, 'allow_multi_intent_output'], 1),
        ('http_response_cap_over_limit', [NLU, 'OpenAIHttp', 'max_response_bytes'], 16777217),
        ('http_connect_zero', [NLU, 'OpenAIHttp', 'connect_timeout_ms'], 0),
        ('http_total_before_connect', [NLU, 'OpenAIHttp', 'total_timeout_ms'], 4999),
        ('http_timeout_over_limit', [NLU, 'OpenAIHttp', 'total_timeout_ms'], 600001),
    ]
    for name, path, value in cases:
        test(name, lambda path=path, value=value: mutation(path, value), True)
    for key in sorted(RETIRED):
        test('retired_protocol_' + key, lambda key=key: mutation([PROTO, key], 'retired'), True)
    for name, path, value in [
        ('unknown_marker_must_be_preserved', [PROTO, 'response_unknown_marker'], 'unknown'),
        ('fullwidth_multi_not_silently_normalized', [PROTO, 'response_multi_marker'], 'multi：'),
        ('scalar_conversion_must_not_replace_array', [PROTO, 'response_slot_assignment'], ':='),
        ('unrelated_policy_drift', [NLU, 'Unrelated', 'nested'], [False, 0]),
        ('unselected_profile_drift', [CAT, 'profiles', 'nlu_06b_v4', 'untouched'], False),
        ('unselected_protocol_drift', [V4, 'version'], 'changed')]:
        test(name, lambda path=path, value=value: mutation(
            path, value, lambda x: preservation(old, x)), True)
    conflict = copy.deepcopy(old)
    conflict[CAT]['profiles'][PROFILE]['total_timeout_ms'] += 1
    test('flat_catalog_transport_conflict', lambda: transform(conflict), True)
    test('json_duplicate_key', lambda: json.loads('{"x":1,"x":2}', object_pairs_hook=pairs), True)
    test('json_nonfinite', lambda: json.loads('{"x":NaN}', parse_constant=reject_constant), True)
    # Representations accepted by C++ remain acceptable generally, but are not substituted in candidates.
    test('generic_schema_compact_response_assignment', lambda: mutation(
        [PROTO, 'response_slot_assignment'], ':='))
    test('generic_schema_scalar_response_slot', lambda: mutation([PROTO, 'response_slot_separator'], ','))
    test('generic_schema_frame_array', lambda: mutation([PROTO, 'response_frame_separator'], [';']))
    test('generic_schema_utf8_explicit_marker_no_blacklist', lambda: mutation(
        [PROTO, 'response_multi_marker'], 'multi：'))
    test('generic_schema_range_boundary', lambda: mutation([CAT, 'profiles', PROFILE, 'max_tokens'], 65536))
    result = {'status': 'PASS', 'fixture_count': len(tests),
              'accepted': sum(t['expected'] == 'accept' for t in tests),
              'rejected_as_expected': sum(t['expected'] == 'reject' for t in tests),
              'fixtures': tests, 'wire_parser_implemented': False, 'service_or_model_calls': 0}
    write_new(args.result, encode(result))
    print('PASS fixtures=%d accepted=%d rejected_as_expected=%d' %
          (result['fixture_count'], result['accepted'], result['rejected_as_expected']))


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest='mode', required=True)
    for mode, function in [('prepare', prepare), ('validate', validate), ('fixtures', fixtures)]:
        sub = modes.add_parser(mode)
        sub.set_defaults(function=function)
        if mode != 'fixtures':
            sub.add_argument('--phase-dir', type=Path, required=True)
            sub.add_argument('--candidate-dir', type=Path, required=True)
            sub.add_argument('--manifest', type=Path, required=True)
        if mode != 'prepare':
            sub.add_argument('--result', type=Path, required=True)
    args = parser.parse_args()
    args.function(args)


if __name__ == '__main__':
    try:
        main()
    except (Invalid, OSError, KeyError, TypeError, UnicodeError, json.JSONDecodeError, StopIteration):
        error = sys.exc_info()[1]
        category = str(error) if isinstance(error, Invalid) else type(error).__name__
        print('FAIL category=' + category, file=sys.stderr)
        sys.exit(1)
