#!/usr/bin/env python3
"""Finite approved Phase4d executor; no retries or permanent tooling changes."""
import ast, base64, datetime, hashlib, json, os, pathlib, subprocess, sys
HERE=pathlib.Path(__file__).resolve().parent
PHASE=HERE.parent.parent
OUT=PHASE/'content-validation'/'install4d'
LOG=OUT/'install-validation.json'
def readjson(path): return json.loads(path.read_text(encoding='utf-8'))
def need(ok,reason):
    if not ok: raise RuntimeError(reason)
need(not LOG.exists(),'authoritative_log_already_exists')
# Reuse the exact canonical alias/trust validation from the captured control.
control=(PHASE/'tools'/'control.py').read_text(encoding='utf-8').split('\npin=hashlib.sha256',1)[0]
exec(compile(control,str(PHASE/'tools'/'control.py'),'exec'),globals())
# The reused definitions must retain our actual artifact scope.
BASE=PHASE
current_pin=hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()
need(current_pin==(PHASE/'tools'/'contract-pin.sha256').read_text(),'ubuntu_contract_drift')
e=readjson(PHASE/'evidence.json'); m=readjson(PHASE/'content-validation'/'candidate-manifest.json')
expected={
 'conf/models/nlu/protocols/v3.json':'a5c392fe6d4824bd72198f22ec3815a9e854eb727e3fc5507fa4f4370fc6af2d',
 'conf/models/nlu/profiles.json':'65437f74c094f3d05243bff79ce77c9a3fe6a56a01795bf45983a6a4c79389ab',
 'conf/nlu_config_06b_http_offline.json':'4292bd222df6f75f2200df5c0307ad180893ce36373d5c7a65bea4c370455eb0'}
need({x['resource_relative_path']:x['candidate_sha256'] for x in m['files']}==expected,'manifest_reviewed_hash_mismatch')
candidates={}
for rel,expected_hash in expected.items():
 p=PHASE/'candidate-data-v2'/rel
 need(p.is_file() and not p.is_symlink(),'candidate_not_regular')
 raw=p.read_bytes();need(hashlib.sha256(raw).hexdigest()==expected_hash,'local_reviewed_bytes_drift')
 candidates[rel]=base64.b64encode(raw).decode('ascii')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
tag='PLAN-20261016-llm-nlu10-shared-codec-v2-phase4d-'+stamp
controller=e['stages']['controller_contract']['data']
data={'files':m['files'],'candidates':candidates,
 'unchanged':[m['unselected_v4_original_metadata']]+m['unchanged_root_metadata_and_policy_hashes'],
 'policies':m['unchanged_policy_assertions'],'references':m['recorded_remote_references'],
 'source_head':m['source_head'],'source_metadata':m['source_metadata'],
 'source_callers':e['stages']['source_callers']['data']['immediate_callers'],
 'controller_path':controller['installed_controller'],'controller_lines':controller['contract_lines'],
 'centos_transaction':'/home/daigd/packages/.wtp184-transactions/'+tag,
 'ubuntu_transaction':'/home/daigd/.wtp184-transactions/'+tag}
static=(PHASE/'content-tools'/'prepare_candidates.py').read_text(encoding='utf-8')
static_prefix=static.split('\ndef read_inputs(',1)[0]
byte_node=next(n for n in ast.parse(static).body if isinstance(n,ast.FunctionDef) and n.name=='byte_evidence')
byte_code=ast.get_source_segment(static,byte_node)
payload='DATA=json.loads('+repr(json.dumps(data,ensure_ascii=True))+')\n'
centos=static_prefix+'\n'+byte_code+'\n'+payload+(HERE/'centos_transaction.py').read_text(encoding='utf-8')
bridge=(PHASE/'tools'/'bridge.py').read_text(encoding='utf-8').split("\ncommand='timeout",1)[0]
controller_pin=e['stages']['resource_capture']['data']['controller_contract_pin']
need(controller_pin=='1b0a2660b2b042c4fb2524dbba34e95951ae77c758f180698f155c8f69291a01','unexpected_controller_pin')
ubuntu='EXPECTED_PIN='+repr(controller_pin)+'\n'+bridge+'\n'+payload+'CENTOS_CODE='+repr(centos)+'\n'+(HERE/'ubuntu_transaction.py').read_text(encoding='utf-8')
for name,code in [('assembled-centos.py',centos),('assembled-ubuntu.py',ubuntu)]:
 compile(code,name,'exec')
 with (HERE/name).open('x',encoding='utf-8') as f: f.write(code)
cmd='timeout --signal=TERM --kill-after=5s 115s python3 -I -'
argv=[SSH]+OPTIONS+[ALIAS,cmd]
record={'plan_id':'PLAN-20261016-llm-nlu10-shared-codec','version':2,'phase':'4d',
 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'argv':argv,'ubuntu_transport_pin':current_pin,'controller_transport_pin':controller_pin,
 'local_reviewed_candidate_hashes':expected,'ubuntu_transaction':data['ubuntu_transaction'],
 'centos_transaction':data['centos_transaction'],'status':'FAIL'}
try:
 r=subprocess.run(argv,input=ubuntu.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=140)
 record['ubuntu_exit']=r.returncode
 need(len(r.stdout)<=524288 and len(r.stderr)<=65536,'transport_output_bound')
 with (OUT/'transport-stdout.json').open('xb') as f: f.write(r.stdout)
 with (OUT/'transport-stderr.log').open('xb') as f: f.write(r.stderr)
 record['stderr_bytes']=len(r.stderr)
 try: record['result']=json.loads(r.stdout)
 except ValueError: record['first_actionable_error']='non_json_ubuntu_output'
 if r.returncode==0 and record.get('result',{}).get('status')=='PASS': record['status']='PASS'
except BaseException as exc:
 record['first_actionable_error']=type(exc).__name__
finally:
 record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with LOG.open('x',encoding='utf-8') as f: json.dump(record,f,sort_keys=True,indent=2)
 print('status='+record['status']+' ubuntu_exit='+str(record.get('ubuntu_exit')))
 print('authoritative_log='+str(LOG))
 result=record.get('result',{})
 print('source_contract='+result.get('source_contract',{}).get('status','UNRUN'))
 c=result.get('centos',{})
 print('centos_exit='+str(result.get('centos_exit'))+' centos_status='+c.get('status','UNRUN'))
 print('first_actionable_error='+str(record.get('first_actionable_error') or result.get('first_actionable_error') or c.get('first_actionable_error') or 'NONE'))
 print('centos_transaction='+data['centos_transaction'])
 sys.exit(0 if record['status']=='PASS' else 1)
