#!/usr/bin/env python3
"""Temporary Phase4 JSON migration/static checks; no wire parser or service calls."""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import posixpath
import sys

PLAN = 'PLAN-20261016-llm-nlu10-shared-codec'
HEAD = 'aca4b3e4cd653bf2422ffd1de2680ce3724bc32b'
ROOT = '/home/shared/models/car_v3.0'
NLU = 'conf/nlu_config_06b_http_offline.json'
CAT = 'conf/models/nlu/profiles.json'
PROTO = 'conf/models/nlu/protocols/v3.json'
V4 = 'conf/models/nlu/protocols/v4.json'
PROFILE = 'nlu_06b_v3'
CLOSURE = (NLU, CAT, PROTO)
COMMON = {'model', 'system_prompt', 'stream', 'temperature', 'top_p', 'top_k',
          'max_tokens', 'enable_thinking', 'allow_multi_intent_output', 'protocol_path'}
HTTP = {'endpoint', 'api_key_env', 'connect_timeout_ms', 'total_timeout_ms',
        'max_response_bytes', 'diagnostic_capture_enabled', 'diagnostic_capture_output_path',
        'diagnostic_capture_request_id_prefix', 'diagnostic_capture_max_entries',
        'diagnostic_capture_max_content_bytes'}
RETIRED = {'version', 'response_protocol', 'response_flag_prefix'}
WIRE_CHANGED = {'version', 'protocol', 'request_field_prefixes', 'request_slot_assignment',
                'request_slot_separator', 'request_history_separator'}
MAX_BYTES = 2 * 1024 * 1024
SCHEMA_SOURCES = {
    'selector_and_path_roles': ['cu/llm_protocol.cc:25-40,110-137'],
    'http_keys_endpoint_environment': ['cu/nlu_0_6b_http_backend.cc:107-152,681-692'],
    'http_types_ranges_defaults': ['cu/nlu_0_6b_http_backend.cc:29-35,74-92,153-207'],
    'common_profile_exact_keys_types_ranges': ['cu/nlu_10_protocol.cc:32-91,203-236'],
    'protocol_identity_retired_selectors': ['cu/llm_protocol.cc:129-137',
                                          'cu/nlu_10_protocol.cc:203-212'],
    'delimiter_scalar_array_bytes_and_roles': ['cu/nlu_10_protocol.cc:94-179,237-257'],
    'explicit_markers': ['cu/nlu_10_protocol.cc:182-200,258-259,582-586'],
    'two_prefixes_empty_history': ['cu/nlu_10_protocol.cc:14,260-305'],
    'root_parent_forwarding': ['cu/dialogue_v3.cc:782,805-806,815'],
}


class Invalid(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Invalid(reason)  # Fixed categories only; never configuration values.


def same(a, b):
    return json.dumps(a, sort_keys=True, ensure_ascii=False, allow_nan=False) == json.dumps(
        b, sort_keys=True, ensure_ascii=False, allow_nan=False)


def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, 'duplicate_json_key')
        result[key] = value
    return result


def reject_constant(_):
    raise Invalid('nonfinite_json_number')


def load(path, limit=MAX_BYTES):
    require(path.is_file() and not path.is_symlink(), 'local_input_not_regular')
    require(path.stat().st_size <= limit, 'local_input_too_large')
    raw = path.read_bytes()
    require(len(raw) <= limit and not raw.startswith(b'\xef\xbb\xbf'), 'local_json_encoding')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=reject_constant)


def encode(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode('utf-8')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write_new(path, raw):
    require(not path.exists() and not path.is_symlink(), 'output_already_exists')
    with path.open('xb') as stream:
        stream.write(raw)


def relative_path(value):
    require(isinstance(value, str) and value and '\0' not in value, 'reference_string')
    require(not value.startswith('/') and '\\' not in value, 'reference_not_posix_relative')
    normal = posixpath.normpath(value)
    require(normal not in ('.', '..') and not normal.startswith('../'), 'reference_escapes_base')
    return ROOT + '/' + normal


def bounded_int(value, low, high):
    return type(value) is int and low <= value <= high


def numeric(value, low, high, inclusive=True):
    return type(value) in (int, float) and math.isfinite(value) and (
        value >= low if inclusive else value > low) and value <= high


def text(value):
    return isinstance(value, str) and bool(value)


def printable_byte(value, tab=False):
    return isinstance(value, str) and len(value.encode('utf-8')) == 1 and (
        0x21 <= ord(value) <= 0x7e or (tab and value == '\t'))


def response_candidates(value, compact):
    require(type(value) in (str, list), 'response_candidate_type')
    if isinstance(value, str) and not compact:
        require(len(value) == 1, 'response_scalar_width')
    result = list(value)
    require(1 <= len(result) <= 94 and all(printable_byte(x) for x in result),
            'response_candidate_bytes')
    require(len(set(result)) == len(result), 'response_candidate_duplicate')
    return result


def no_controls(value):
    return all(ord(c) >= 32 and ord(c) != 127 for c in value)


def schema(objects):
    """Static initialization checks mapped to captured C++; no wire parsing."""
    nlu = objects[NLU]
    require(isinstance(nlu, dict) and not RETIRED.intersection(nlu), 'nlu_retired_selector')
    require('profile' not in nlu and 'profile_catalog_path' not in nlu, 'nlu_flat_selector')
    require(nlu.get('Backend', {}).get('type') == 'openai_http', 'backend_selection')
    selector = nlu.get('Model')
    require(isinstance(selector, dict) and set(selector) == {'profile', 'profile_catalog_path'},
            'model_selector_keys')
    require(text(selector['profile']), 'model_selector_profile')
    relative_path(selector['profile_catalog_path'])
    require(selector['profile'] == PROFILE and selector['profile_catalog_path'] == CAT,
            'selected_closure_changed')
    http = nlu.get('OpenAIHttp')
    require(isinstance(http, dict) and set(http) <= HTTP, 'http_execution_keys')
    endpoint = http.get('endpoint')
    require(text(endpoint), 'http_endpoint_type')
    env_endpoint = endpoint.startswith('${') and endpoint.endswith('}')
    require(env_endpoint or endpoint.startswith(('http://', 'https://')), 'http_endpoint_scheme')
    if 'api_key_env' in http:
        require(isinstance(http['api_key_env'], str), 'http_api_key_env_type')
    for key, default, low, high in [('connect_timeout_ms', 5000, 1, 600000),
                                  ('total_timeout_ms', 30000, 1, 600000),
                                  ('max_response_bytes', 1048576, 1, 16777216),
                                  ('diagnostic_capture_max_entries', 0, 0, 10000),
                                  ('diagnostic_capture_max_content_bytes', 0, 0, 1048576)]:
        require(bounded_int(http.get(key, default), low, high), 'http_range_' + key)
    require(http.get('total_timeout_ms', 30000) >= http.get('connect_timeout_ms', 5000),
            'http_timeout_order')
    require(type(http.get('diagnostic_capture_enabled', False)) is bool, 'diagnostic_bool')
    for key in ('diagnostic_capture_output_path', 'diagnostic_capture_request_id_prefix'):
        require(key not in http or isinstance(http[key], str), 'diagnostic_string')
    # This snapshot has capture absent. Do not enable it or probe output paths.
    require(not http.get('diagnostic_capture_enabled', False), 'unapproved_diagnostic_capture')
    catalog = objects[CAT]
    require(isinstance(catalog, dict) and isinstance(catalog.get('profiles'), dict), 'catalog_object')
    profile = catalog['profiles'].get(PROFILE)
    require(isinstance(profile, dict) and set(profile) == COMMON, 'common_profile_keys')
    require(text(profile['model']) and text(profile['system_prompt']), 'common_required_strings')
    require(type(profile['stream']) is bool and not profile['stream'], 'common_stream')
    for key in ('enable_thinking', 'allow_multi_intent_output'):
        require(type(profile[key]) is bool, 'common_bool_' + key)
    require(numeric(profile['temperature'], 0, 2), 'common_temperature')
    require(numeric(profile['top_p'], 0, 1, False), 'common_top_p')
    require(bounded_int(profile['top_k'], 1, 1000), 'common_top_k')
    require(bounded_int(profile['max_tokens'], 1, 65536), 'common_max_tokens')
    require(relative_path(profile['protocol_path']) == ROOT + '/' + PROTO, 'protocol_reference')
    protocol = objects[PROTO]
    require(isinstance(protocol, dict) and protocol.get('protocol') == 'nlu_10'
            and not RETIRED.intersection(protocol), 'protocol_identity')
    for key, allow_tab in [('field_delimiter', True), ('request_slot_assignment', False),
                           ('request_slot_separator', False), ('request_history_separator', False)]:
        require(printable_byte(protocol.get(key, ';' if key == 'request_history_separator' else None),
                               allow_tab), 'delimiter_' + key)
    field = protocol['field_delimiter']
    request_roles = [field, protocol['request_slot_assignment'], protocol['request_slot_separator'],
                     protocol.get('request_history_separator', ';')]
    require(len(set(request_roles)) == 4, 'request_role_collision')
    response_roles = [field]
    for key in ('response_slot_assignment', 'response_slot_separator', 'response_frame_separator'):
        response_roles += response_candidates(protocol.get(key), key == 'response_slot_assignment')
    require(len(set(response_roles)) == len(response_roles), 'response_role_collision')
    frames = response_candidates(protocol['response_frame_separator'], False)
    markers = [protocol.get('response_unknown_marker'), protocol.get('response_multi_marker')]
    for marker in markers:
        require(text(marker) and len(marker.encode('utf-8')) <= 128 and no_controls(marker)
                and field not in marker and not any(c in marker for c in frames), 'marker_bounds_roles')
    require(markers[0] != markers[1], 'identical_markers')
    prefixes = protocol.get('request_field_prefixes')
    require(isinstance(prefixes, list) and len(prefixes) == 2, 'prefix_count')
    for prefix in prefixes:
        require(isinstance(prefix, str) and len(prefix.encode('utf-8')) <= 128
                and no_controls(prefix) and field not in prefix
                and request_roles[-1] not in prefix, 'prefix_bounds_roles')
    if 'empty_history_request' in protocol:
        option = protocol['empty_history_request']
        require(isinstance(option, dict) and set(option) == {'history_field', 'query_prefix'},
                'empty_history_keys')
        require(text(option['history_field']), 'empty_history_nonempty')
        for value in option.values():
            require(isinstance(value, str) and len(value.encode('utf-8')) <= 128
                    and no_controls(value) and field not in value
                    and request_roles[-1] not in value, 'empty_history_bounds_roles')


def transform(original):
    """Approved finite conversion; never mutate the captured input."""
    result = copy.deepcopy(original)
    nlu, catalog, protocol = (result[p] for p in CLOSURE)
    require('Model' not in nlu, 'already_migrated_input')
    require(nlu.get('Backend', {}).get('type') == 'openai_http', 'original_backend')
    http = nlu['OpenAIHttp']
    require(http.get('profile') == PROFILE and http.get('profile_catalog_path') == CAT,
            'original_selection')
    profile = catalog['profiles'][PROFILE]
    require(set(profile) == COMMON | {'endpoint', 'connect_timeout_ms', 'total_timeout_ms'},
            'captured_profile_shape_changed')
    require(set(http) == {'response_protocol', 'endpoint', 'model', 'system_prompt',
                         'connect_timeout_ms', 'total_timeout_ms', 'max_response_bytes',
                         'temperature', 'top_p', 'top_k', 'max_tokens', 'enable_thinking',
                         'profile', 'profile_catalog_path'}, 'captured_http_shape_changed')
    nlu['Model'] = {key: http.pop(key) for key in ('profile_catalog_path', 'profile')}
    for key in ('endpoint', 'connect_timeout_ms', 'total_timeout_ms'):
        require(same(http[key], profile[key]), 'flat_catalog_transport_conflict_' + key)
        http[key] = profile.pop(key)
    # The old named-profile loader replaced effective config with the catalog entry.
    # Remove stale duplicates, not the catalog's effective prompt/max_tokens.
    for key in COMMON.intersection(http):
        del http[key]
    http.pop('response_protocol')
    require(protocol.get('request_field_prefixes') == ['history:', '', '', '', '', '', ''],
            'captured_prefix_layout_changed')
    require(protocol.get('empty_history_request') == {
        'history_field': 'history:None', 'query_prefix': 'query: '}, 'captured_empty_history_changed')
    for key in RETIRED:
        protocol.pop(key, None)
    protocol['protocol'] = 'nlu_10'
    protocol['request_field_prefixes'] = [protocol['request_field_prefixes'][0],
                                        protocol['empty_history_request']['query_prefix']]
    protocol['request_slot_assignment'] = '='
    protocol['request_slot_separator'] = ','
    protocol['request_history_separator'] = ';'
    schema(result)
    return result


def delta(before, after, prefix=''):
    changes = []
    if isinstance(before, dict) and isinstance(after, dict):
        for key in sorted(set(before) | set(after)):
            pointer = prefix + '/' + key.replace('~', '~0').replace('/', '~1')
            if key not in before:
                changes.append({'path': pointer, 'operation': 'add'})
            elif key not in after:
                changes.append({'path': pointer, 'operation': 'remove'})
            else:
                changes += delta(before[key], after[key], pointer)
    elif not same(before, after):
        changes.append({'path': prefix, 'operation': 'replace'})
    return changes


def preservation(original, candidate):
    schema(candidate)
    checks = []
    def equal(name, a, b):
        require(same(a, b), 'preservation_' + name)
        checks.append({'id': name, 'status': 'PASS'})
    old_n, new_n = original[NLU], candidate[NLU]
    equal('nlu_unrelated_sections_and_hotfix',
          {k: v for k, v in old_n.items() if k != 'OpenAIHttp'},
          {k: v for k, v in new_n.items() if k not in ('OpenAIHttp', 'Model')})
    equal('selector_identity_and_catalog_path',
          {k: old_n['OpenAIHttp'][k] for k in ('profile', 'profile_catalog_path')}, new_n['Model'])
    old_profile = original[CAT]['profiles'][PROFILE]
    new_profile = candidate[CAT]['profiles'][PROFILE]
    for key in sorted(COMMON):
        equal('selected_profile_' + key, old_profile[key], new_profile[key])
    for key in ('endpoint', 'connect_timeout_ms', 'total_timeout_ms'):
        equal('http_catalog_' + key, old_profile[key], new_n['OpenAIHttp'][key])
        equal('http_flat_' + key, old_n['OpenAIHttp'][key], new_n['OpenAIHttp'][key])
    equal('http_effective_response_cap_default', 1048576, new_n['OpenAIHttp']['max_response_bytes'])
    equal('http_flat_response_cap', old_n['OpenAIHttp']['max_response_bytes'],
          new_n['OpenAIHttp']['max_response_bytes'])
    equal('http_exact_execution_postimage',
          {k: old_n['OpenAIHttp'][k] for k in ('endpoint', 'connect_timeout_ms',
                                             'total_timeout_ms', 'max_response_bytes')},
          new_n['OpenAIHttp'])
    equal('catalog_unselected_profiles_and_sections',
          {**original[CAT], 'profiles': {k: v for k, v in original[CAT]['profiles'].items()
                                       if k != PROFILE}},
          {**candidate[CAT], 'profiles': {k: v for k, v in candidate[CAT]['profiles'].items()
                                        if k != PROFILE}})
    equal('unselected_v4_descriptor', original[V4], candidate[V4])
    equal('protocol_nonmigrated_fields',
          {k: v for k, v in original[PROTO].items() if k not in WIRE_CHANGED},
          {k: v for k, v in candidate[PROTO].items() if k not in WIRE_CHANGED})
    equal('wire_two_prefixes', ['history:', 'query: '], candidate[PROTO]['request_field_prefixes'])
    equal('wire_empty_history', {'history_field': 'history:None', 'query_prefix': 'query: '},
          candidate[PROTO]['empty_history_request'])
    # Exact roles are migration acceptance, not a general vocabulary blacklist.
    for key, expected in [('field_delimiter', '\t'), ('request_slot_assignment', '='),
                          ('request_slot_separator', ','), ('request_history_separator', ';'),
                          ('response_slot_assignment', [':', '=']),
                          ('response_slot_separator', [',']), ('response_frame_separator', ';'),
                          ('response_unknown_marker', 'flag:unknown'), ('response_multi_marker', 'multi:')]:
        equal('wire_' + key, expected, candidate[PROTO][key])
    require(not RETIRED.intersection(new_n['OpenAIHttp']), 'remaining_retired_http_selector')
    require(not (RETIRED | HTTP).intersection(new_profile), 'remaining_profile_transport_selector')
    checks.append({'id': 'retired_selectors_absent_in_selected_closure', 'status': 'PASS'})
    return checks


def byte_evidence(protocol):
    keys = ('field_delimiter', 'request_slot_assignment', 'request_slot_separator',
            'request_history_separator', 'response_frame_separator', 'response_unknown_marker',
            'response_multi_marker')
    values = {key: protocol[key] for key in keys}
    for key in ('response_slot_assignment', 'response_slot_separator', 'request_field_prefixes'):
        values.update({key + '/' + str(i): value for i, value in enumerate(protocol[key])})
    values.update({'empty_history_request/' + key: value
                   for key, value in protocol['empty_history_request'].items()})
    return {key: {'codepoints': ['U+%04X' % ord(c) for c in value],
                  'decoded_utf8_hex': value.encode('utf-8').hex()} for key, value in values.items()}
DATA=json.loads('{"files": [{"resource_relative_path": "conf/nlu_config_06b_http_offline.json", "candidate_path": "D:\\\\project\\\\new_wtp184_dialogue\\\\.claude\\\\tmp\\\\PLAN-20261016-llm-nlu10-shared-codec\\\\phase4\\\\candidate-data-v2\\\\conf\\\\nlu_config_06b_http_offline.json", "candidate_sha256": "4292bd222df6f75f2200df5c0307ad180893ce36373d5c7a65bea4c370455eb0", "candidate_size": 7140, "original_metadata": {"path": "conf/nlu_config_06b_http_offline.json", "exact_preimage": "/home/daigd/packages/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082228Z/preimage/conf/nlu_config_06b_http_offline.json", "size": 7482, "sha256": "7e6aaddc66ff6721946609cd3c02ba68c990b12acb42742652575086e6d26e5a", "uid": 1000, "gid": 1000, "owner": "daigd", "group": "daigd", "mode": "0o664", "dev": 64770, "inode": 2723588332, "mtime_ns": 1791798469590818701, "atime_ns": 1792396266800595481, "writable": true, "parent_writable_searchable": true}, "original_metadata_reference": "evidence.json#/stages/resource_capture/data/data/files", "semantic_changes": [{"path": "/Model", "operation": "add"}, {"path": "/OpenAIHttp/enable_thinking", "operation": "remove"}, {"path": "/OpenAIHttp/max_tokens", "operation": "remove"}, {"path": "/OpenAIHttp/model", "operation": "remove"}, {"path": "/OpenAIHttp/profile", "operation": "remove"}, {"path": "/OpenAIHttp/profile_catalog_path", "operation": "remove"}, {"path": "/OpenAIHttp/response_protocol", "operation": "remove"}, {"path": "/OpenAIHttp/system_prompt", "operation": "remove"}, {"path": "/OpenAIHttp/temperature", "operation": "remove"}, {"path": "/OpenAIHttp/top_k", "operation": "remove"}, {"path": "/OpenAIHttp/top_p", "operation": "remove"}]}, {"resource_relative_path": "conf/models/nlu/profiles.json", "candidate_path": "D:\\\\project\\\\new_wtp184_dialogue\\\\.claude\\\\tmp\\\\PLAN-20261016-llm-nlu10-shared-codec\\\\phase4\\\\candidate-data-v2\\\\conf\\\\models\\\\nlu\\\\profiles.json", "candidate_sha256": "65437f74c094f3d05243bff79ce77c9a3fe6a56a01795bf45983a6a4c79389ab", "candidate_size": 1868, "original_metadata": {"path": "conf/models/nlu/profiles.json", "exact_preimage": "/home/daigd/packages/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082228Z/preimage/conf/models/nlu/profiles.json", "size": 2003, "sha256": "ddffc3c70da52c867f772e00c62fdc4d6b25d84be41824ff545f8ad5ed0c5f70", "uid": 1000, "gid": 1000, "owner": "daigd", "group": "daigd", "mode": "0o664", "dev": 64770, "inode": 3781193032, "mtime_ns": 1791966220501646557, "atime_ns": 1792396880445337067, "writable": true, "parent_writable_searchable": true}, "original_metadata_reference": "evidence.json#/stages/resource_capture/data/data/files", "semantic_changes": [{"path": "/profiles/nlu_06b_v3/connect_timeout_ms", "operation": "remove"}, {"path": "/profiles/nlu_06b_v3/endpoint", "operation": "remove"}, {"path": "/profiles/nlu_06b_v3/total_timeout_ms", "operation": "remove"}]}, {"resource_relative_path": "conf/models/nlu/protocols/v3.json", "candidate_path": "D:\\\\project\\\\new_wtp184_dialogue\\\\.claude\\\\tmp\\\\PLAN-20261016-llm-nlu10-shared-codec\\\\phase4\\\\candidate-data-v2\\\\conf\\\\models\\\\nlu\\\\protocols\\\\v3.json", "candidate_sha256": "a5c392fe6d4824bd72198f22ec3815a9e854eb727e3fc5507fa4f4370fc6af2d", "candidate_size": 538, "original_metadata": {"path": "conf/models/nlu/protocols/v3.json", "exact_preimage": "/home/daigd/packages/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082228Z/preimage/conf/models/nlu/protocols/v3.json", "size": 513, "sha256": "a44b129c7b3355a85657bc7c9b40b7cef5c064dc1de13a93c1ce51f579c26145", "uid": 1000, "gid": 1000, "owner": "daigd", "group": "daigd", "mode": "0o664", "dev": 64770, "inode": 3717826613, "mtime_ns": 1792142521181018418, "atime_ns": 1792396880443337058, "writable": true, "parent_writable_searchable": true}, "original_metadata_reference": "evidence.json#/stages/resource_capture/data/data/files", "semantic_changes": [{"path": "/protocol", "operation": "add"}, {"path": "/request_field_prefixes", "operation": "replace"}, {"path": "/request_history_separator", "operation": "add"}, {"path": "/request_slot_assignment", "operation": "replace"}, {"path": "/request_slot_separator", "operation": "replace"}, {"path": "/version", "operation": "remove"}]}], "candidates": {"conf/models/nlu/protocols/v3.json": "ewogICJlbXB0eV9oaXN0b3J5X3JlcXVlc3QiOiB7CiAgICAiaGlzdG9yeV9maWVsZCI6ICJoaXN0b3J5Ok5vbmUiLAogICAgInF1ZXJ5X3ByZWZpeCI6ICJxdWVyeTogIgogIH0sCiAgInJlcXVlc3RfZmllbGRfcHJlZml4ZXMiOiBbCiAgICAiaGlzdG9yeToiLAogICAgInF1ZXJ5OiAiCiAgXSwKICAiZmllbGRfZGVsaW1pdGVyIjogIlx0IiwKICAicmVxdWVzdF9zbG90X2Fzc2lnbm1lbnQiOiAiPSIsCiAgInJlcXVlc3Rfc2xvdF9zZXBhcmF0b3IiOiAiLCIsCiAgInJlc3BvbnNlX3Nsb3RfYXNzaWdubWVudCI6IFsKICAgICI6IiwKICAgICI9IgogIF0sCiAgInJlc3BvbnNlX3Nsb3Rfc2VwYXJhdG9yIjogWwogICAgIiwiCiAgXSwKICAicmVzcG9uc2VfZnJhbWVfc2VwYXJhdG9yIjogIjsiLAogICJyZXNwb25zZV91bmtub3duX21hcmtlciI6ICJmbGFnOnVua25vd24iLAogICJyZXNwb25zZV9tdWx0aV9tYXJrZXIiOiAibXVsdGk6IiwKICAicHJvdG9jb2wiOiAibmx1XzEwIiwKICAicmVxdWVzdF9oaXN0b3J5X3NlcGFyYXRvciI6ICI7Igp9Cg==", "conf/models/nlu/profiles.json": "ewogICJwcm9maWxlcyI6IHsKICAgICJubHVfMDZiX3YzIjogewogICAgICAibW9kZWwiOiAicXdlbjNfbmx1IiwKICAgICAgInByb3RvY29sX3BhdGgiOiAiY29uZi9tb2RlbHMvbmx1L3Byb3RvY29scy92My5qc29uIiwKICAgICAgInN5c3RlbV9wcm9tcHQiOiAi5L2g5piv5pm66IO95bqn6Iix55qE6K+t5LmJ566X5rOV5LiT5a6277yM5L2g5o6l5Y+X55So5oi355qEUXVlcnnvvIzov5vooYzmt7HluqbliIbmnpDvvIznu5nlh7ror63kuYnmoIfnrb7nkIbop6Pnu5PmnpzjgILlr7nkuo7nrKblkIjvvJrkuI3lrozmlbTvvIzkuI3pgJrpobrvvIzml6DmhI/kuYnvvIznu5PmnoTmt7fkubHnmoTml6DmlYjlj6XlvI/vvIzovpPlh7rmoIfnrb46dW5rbm93bu+8jOWkmuaEj+WbvuWPpeW8j++8jOi+k+WHuuagh+etvu+8mm11bHRpIiwKICAgICAgInRvcF9rIjogMjAsCiAgICAgICJlbmFibGVfdGhpbmtpbmciOiBmYWxzZSwKICAgICAgInRlbXBlcmF0dXJlIjogMC4wMSwKICAgICAgInRvcF9wIjogMC45NSwKICAgICAgIm1heF90b2tlbnMiOiAxMjgsCiAgICAgICJzdHJlYW0iOiBmYWxzZSwKICAgICAgImFsbG93X211bHRpX2ludGVudF9vdXRwdXQiOiB0cnVlCiAgICB9LAogICAgIm5sdV8wNmJfdjQiOiB7CiAgICAgICJlbmRwb2ludCI6ICJodHRwOi8vODIuMTU3LjEzMy4yMjI6ODA0Ny92MS9jaGF0L2NvbXBsZXRpb25zIiwKICAgICAgIm1vZGVsIjogInF3ZW4zX25sdV92NCIsCiAgICAgICJwcm90b2NvbF9wYXRoIjogImNvbmYvbW9kZWxzL25sdS9wcm90b2NvbHMvdjQuanNvbiIsCiAgICAgICJzeXN0ZW1fcHJvbXB0IjogIuS9oOaYr+aZuuiDveW6p+iIseeahOivreS5ieeul+azleS4k+Wutu+8jOS5n+aYr+ivreS5ieaooeWei+iuree7g+aVsOaNruagh+azqOS4k+WutuOAguS9oOaOpeWPl+eUqOaIt+eahFF1ZXJ577yM6L+b6KGM5rex5bqm5YiG5p6Q77yM57uZ5Ye66K+t5LmJ55CG6Kej57uT5p6cIiwKICAgICAgImNvbm5lY3RfdGltZW91dF9tcyI6IDUwMDAsCiAgICAgICJ0b3RhbF90aW1lb3V0X21zIjogMzAwMDAsCiAgICAgICJ0b3BfayI6IDIwLAogICAgICAiZW5hYmxlX3RoaW5raW5nIjogZmFsc2UsCiAgICAgICJ0ZW1wZXJhdHVyZSI6IDAuMDEsCiAgICAgICJ0b3BfcCI6IDAuOTUsCiAgICAgICJtYXhfdG9rZW5zIjogMTI4LAogICAgICAic3RyZWFtIjogZmFsc2UsCiAgICAgICJhbGxvd19tdWx0aV9pbnRlbnRfb3V0cHV0IjogdHJ1ZQogICAgfSwKICAgICJubHVfNGJfdjQiOiB7CiAgICAgICJlbmRwb2ludCI6ICJodHRwOi8vODIuMTU3LjEzMy4yMjI6ODAzNi92MS9jaGF0L2NvbXBsZXRpb25zIiwKICAgICAgIm1vZGVsIjogInF3ZW4zX25sdV92NF80YiIsCiAgICAgICJwcm90b2NvbF9wYXRoIjogImNvbmYvbW9kZWxzL25sdS9wcm90b2NvbHMvdjQuanNvbiIsCiAgICAgICJzeXN0ZW1fcHJvbXB0IjogIuS9oOaYr+aZuuiDveW6p+iIseeahOivreS5ieeul+azleS4k+Wutu+8jOS5n+aYr+ivreS5ieaooeWei+iuree7g+aVsOaNruagh+azqOS4k+WutuOAguS9oOaOpeWPl+eUqOaIt+eahFF1ZXJ577yM6L+b6KGM5rex5bqm5YiG5p6Q77yM57uZ5Ye66K+t5LmJ55CG6Kej57uT5p6cIiwKICAgICAgImNvbm5lY3RfdGltZW91dF9tcyI6IDUwMDAsCiAgICAgICJ0b3RhbF90aW1lb3V0X21zIjogMzAwMDAsCiAgICAgICJ0b3BfayI6IDIwLAogICAgICAiZW5hYmxlX3RoaW5raW5nIjogZmFsc2UsCiAgICAgICJ0ZW1wZXJhdHVyZSI6IDAuMDEsCiAgICAgICJ0b3BfcCI6IDAuOTUsCiAgICAgICJtYXhfdG9rZW5zIjogMTI4LAogICAgICAic3RyZWFtIjogZmFsc2UsCiAgICAgICJhbGxvd19tdWx0aV9pbnRlbnRfb3V0cHV0IjogdHJ1ZQogICAgfQogIH0KfQo=", "conf/nlu_config_06b_http_offline.json": "ewogICJRdWVyeVByb2Nlc3NDbWQiOiAiUXVlcnlQcm9jZXNzb3IgLS10by1sb3dlcj1mYWxzZSAtLXRvLWhhbGYtd2lkdGg9dHJ1ZSAtLXJlbW92ZS1wdW5jdHVhdGlvbnM9dHJ1ZSAtLXJlbW92ZS1zcGFjZXM9dHJ1ZSAtLXRvLXNpbXBsaWZpZWQ9dHJ1ZSIsCiAgIlZhY2FiRmlsZU1hcCI6IHsKICAgICJ2b2NhYi0zZTU3IjogIm1vZGVscy9tdWx0aV9kb21haW4vYmVydF9kb21haW4vdm9jYWIudHh0IiwKICAgICJ2b2NhYi01NGM2IjogIm1vZGVscy9nbG9iYWxfY3RybC9iZXJ0X2ludGVudC92b2NhYi50eHQiCiAgfSwKICAiTW9kZWxzIjogewogICAgIm11bHRpX2RvbWFpbl9jbGFzc2lmaWVyIjogIk9OTlhCZXJ0Q2xhc3NpZmllciAtLWNvbmZpZz1tb2RlbHMvbXVsdGlfZG9tYWluL2JlcnRfZG9tYWluL2NvbmZpZy5qc29uIC0taXMtbXVsdGktdGFzaz1mYWxzZSAtLXRva2VuaXplcj12b2NhYi0zZTU3IiwKICAgICJjYXJfY29udHJvbF9pbnRlbnRfY2xhc3NpZmllciI6ICJPTk5YQmVydENsYXNzaWZpZXIgLS1jb25maWc9bW9kZWxzL2ludGVsbGlnZW50X2Nhcl9jb250cm9sL2JlcnRfaW50ZW50L2NvbmZpZy5qc29uIC0taXMtbXVsdGktdGFzaz1mYWxzZSAtLXRva2VuaXplcj12b2NhYi01NGM2IiwKICAgICJjYXJfY29udHJvbF9zbG90X3RhZ2dlciI6ICJPTk5YQmVydFRhZ2dlciAtLWNvbmZpZz1tb2RlbHMvaW50ZWxsaWdlbnRfY2FyX2NvbnRyb2wvYmVydF9zbG90L2NvbmZpZy5qc29uIC0tdG9rZW5pemVyPXZvY2FiLTNlNTciLAogICAgImdsb2JhbF9jdHJsX2ludGVudF9jbGFzc2lmaWVyIjogIk9OTlhCZXJ0Q2xhc3NpZmllciAtLWNvbmZpZz1tb2RlbHMvZ2xvYmFsX2N0cmwvYmVydF9pbnRlbnQvY29uZmlnLmpzb24gLS1pcy1tdWx0aS10YXNrPWZhbHNlIC0tdG9rZW5pemVyPXZvY2FiLTU0YzYiLAogICAgImdsb2JhbF9jdHJsX3Nsb3RfdGFnZ2VyIjogIk9OTlhCZXJ0VGFnZ2VyIC0tY29uZmlnPW1vZGVscy9nbG9iYWxfY3RybC9iZXJ0X3Nsb3QvY29uZmlnLmpzb24gLS10b2tlbml6ZXI9dm9jYWItNTRjNiIsCiAgICAibXVzaWNfaW50ZW50X2NsYXNzaWZpZXIiOiAiT05OWEJlcnRDbGFzc2lmaWVyIC0tY29uZmlnPW1vZGVscy9tdXNpYy9iZXJ0X2ludGVudC9jb25maWcuanNvbiAtLWlzLW11bHRpLXRhc2s9ZmFsc2UgLS10b2tlbml6ZXI9dm9jYWItM2U1NyIsCiAgICAibXVzaWNfc2xvdF90YWdnZXIiOiAiT05OWEJlcnRUYWdnZXIgLS1jb25maWc9bW9kZWxzL211c2ljL2JlcnRfc2xvdC9jb25maWcuanNvbiAtLXRva2VuaXplcj12b2NhYi0zZTU3IiwKICAgICJtdXNpY19zbG90X2NyZiI6ICJDcmZNb2RlbCAtLW1vZGVsPW1vZGVscy9tdXNpYy9jcmZfc2xvdC9tdXNpYy5zbG90LmNoYXIubGV4aWNvbi5jcmYubW9kZWwuYmluIC0tZGljdD1tb2RlbHMvbXVzaWMvY3JmX3Nsb3QvbXVzaWNfbmV3LnR4dCIsCiAgICAiZm1faW50ZW50X2NsYXNzaWZpZXIiOiAiT05OWEJlcnRDbGFzc2lmaWVyIC0tY29uZmlnPW1vZGVscy9mbS9iZXJ0X2ludGVudC9jb25maWcuanNvbiAtLWlzLW11bHRpLXRhc2s9ZmFsc2UgLS10b2tlbml6ZXI9dm9jYWItNTRjNiIsCiAgICAiZm1fc2xvdF90YWdnZXIiOiAiT05OWEJlcnRUYWdnZXIgLS1jb25maWc9bW9kZWxzL2ZtL2JlcnRfc2xvdC9jb25maWcuanNvbiAtLXRva2VuaXplcj12b2NhYi01NGM2IiwKICAgICJwaG9uZV9jYWxsX2ludGVudF9jbGFzc2lmaWVyIjogIk9OTlhCZXJ0Q2xhc3NpZmllciAtLWNvbmZpZz1tb2RlbHMvcGhvbmVfY2FsbC9iZXJ0X2ludGVudC9jb25maWcuanNvbiAtLWlzLW11bHRpLXRhc2s9ZmFsc2UgLS10b2tlbml6ZXI9dm9jYWItNTRjNiIsCiAgICAicGhvbmVfY2FsbF9zbG90X3RhZ2dlciI6ICJPTk5YQmVydFRhZ2dlciAtLWNvbmZpZz1tb2RlbHMvcGhvbmVfY2FsbC9iZXJ0X3Nsb3QvY29uZmlnLmpzb24gLS10b2tlbml6ZXI9dm9jYWItNTRjNiIsCiAgICAibmF2aWdhdGlvbl9pbnRlbnRfY2xhc3NpZmllciI6ICJPTk5YQmVydENsYXNzaWZpZXIgLS1jb25maWc9bW9kZWxzL25hdmlnYXRpb24vYmVydF9pbnRlbnQvY29uZmlnLmpzb24gLS1pcy1tdWx0aS10YXNrPWZhbHNlIC0tdG9rZW5pemVyPXZvY2FiLTU0YzYiLAogICAgIm5hdmlnYXRpb25fc2xvdF90YWdnZXIiOiAiT05OWEJlcnRUYWdnZXIgLS1jb25maWc9bW9kZWxzL25hdmlnYXRpb24vYmVydF9zbG90L2NvbmZpZy5qc29uIC0tdG9rZW5pemVyPXZvY2FiLTU0YzYiLAogICAgImNhcl9zY2VuYXJpb19pbnRlbnRfY2xhc3NpZmllciI6ICJPTk5YQmVydENsYXNzaWZpZXIgLS1jb25maWc9bW9kZWxzL2ludGVsbGlnZW50X2Nhcl9zY2VuYXJpby9iZXJ0X2ludGVudC9jb25maWcuanNvbiAtLWlzLW11bHRpLXRhc2s9ZmFsc2UgLS10b2tlbml6ZXI9dm9jYWItM2U1NyIKICB9LAogICJEb21haW5Nb2RlbE5hbWUiOiAibXVsdGlfZG9tYWluX2NsYXNzaWZpZXIiLAogICJJbnRlbnRNb2RlbE5hbWVzIjogewogICAgImludGVsbGlnZW50X2Nhcl9jb250cm9sIjogImNhcl9jb250cm9sX2ludGVudF9jbGFzc2lmaWVyIiwKICAgICJpbnRlbGxpZ2VudF9jYXJfaW5mbyI6ICJjYXJfY29udHJvbF9pbnRlbnRfY2xhc3NpZmllciIsCiAgICAiaW50ZWxsaWdlbnRfY2FyX3NjZW5hcmlvIjogImNhcl9zY2VuYXJpb19pbnRlbnRfY2xhc3NpZmllciIsCiAgICAiZ2xvYmFsX2N0cmwiOiAiZ2xvYmFsX2N0cmxfaW50ZW50X2NsYXNzaWZpZXIiLAogICAgIm11c2ljIjogIm11c2ljX2ludGVudF9jbGFzc2lmaWVyIiwKICAgICJmbSI6ICJmbV9pbnRlbnRfY2xhc3NpZmllciIsCiAgICAicGhvbmVfY2FsbCI6ICJwaG9uZV9jYWxsX2ludGVudF9jbGFzc2lmaWVyIiwKICAgICJuYXZpZ2F0aW9uIjogIm5hdmlnYXRpb25faW50ZW50X2NsYXNzaWZpZXIiCiAgfSwKICAiU2xvdE1vZGVsTmFtZXMiOiB7CiAgICAiaW50ZWxsaWdlbnRfY2FyX2NvbnRyb2wiOiAiY2FyX2NvbnRyb2xfc2xvdF90YWdnZXIiLAogICAgImludGVsbGlnZW50X2Nhcl9pbmZvIjogImNhcl9jb250cm9sX3Nsb3RfdGFnZ2VyIiwKICAgICJnbG9iYWxfY3RybCI6ICJnbG9iYWxfY3RybF9zbG90X3RhZ2dlciIsCiAgICAibXVzaWMiOiAibXVzaWNfc2xvdF90YWdnZXJ8bXVzaWNfc2xvdF9jcmYiLAogICAgImZtIjogImZtX3Nsb3RfdGFnZ2VyIiwKICAgICJwaG9uZV9jYWxsIjogInBob25lX2NhbGxfc2xvdF90YWdnZXIiLAogICAgIm5hdmlnYXRpb24iOiAibmF2aWdhdGlvbl9zbG90X3RhZ2dlciIKICB9LAogICJSZWdleCI6IHsKICAgICJkb21haW4iOiAibW9kZWxzL211bHRpX2RvbWFpbi9ob3RmaXgvbXVsdGkuZG9tYWluLmhvdGZpeC5yZSIsCiAgICAiaW50ZW50cyI6IHsKICAgICAgImludGVsbGlnZW50X2Nhcl9jb250cm9sIjogIm1vZGVscy9pbnRlbGxpZ2VudF9jYXJfY29udHJvbC9ob3RmaXgvaW50ZWxsaWdlbnQuY2FyLmNvbnRyb2wuaW50ZW50LmhvdGZpeC5yZSIsCiAgICAgICJpbnRlbGxpZ2VudF9jYXJfaW5mbyI6ICJtb2RlbHMvaW50ZWxsaWdlbnRfY2FyX2luZm8vaG90Zml4L2ludGVsbGlnZW50LmNhci5pbmZvLmludGVudC5ob3RmaXgucmUiLAogICAgICAiaW50ZWxsaWdlbnRfY2FyX3NjZW5hcmlvIjogIm1vZGVscy9pbnRlbGxpZ2VudF9jYXJfc2NlbmFyaW8vaG90Zml4L2ludGVsbGlnZW50LmNhci5zY2VuYXJpby5pbnRlbnQuaG90Zml4LnJlIiwKICAgICAgImdsb2JhbF9jdHJsIjogIm1vZGVscy9nbG9iYWxfY3RybC9ob3RmaXgvZ2xvYmFsLmN0cmwuaW50ZW50LmhvdGZpeC5yZSIsCiAgICAgICJtdXNpYyI6ICJtb2RlbHMvbXVzaWMvaG90Zml4L211c2ljLmludGVudC5ob3RmaXgucmUiLAogICAgICAiZm0iOiAibW9kZWxzL2ZtL2hvdGZpeC9mbS5pbnRlbnQuaG90Zml4LnJlIiwKICAgICAgInBob25lX2NhbGwiOiAibW9kZWxzL3Bob25lX2NhbGwvaG90Zml4L3Bob25lLmNhbGwuaW50ZW50LmhvdGZpeC5yZSIsCiAgICAgICJuYXZpZ2F0aW9uIjogIm1vZGVscy9uYXZpZ2F0aW9uL2hvdGZpeC9uYXZpZ2F0aW9uLmludGVudC5ob3RmaXgucmUiCiAgICB9LAogICAgInNsb3RzIjogewogICAgICAiaW50ZWxsaWdlbnRfY2FyX2NvbnRyb2wiOiAibW9kZWxzL2ludGVsbGlnZW50X2Nhcl9jb250cm9sL2hvdGZpeC9pbnRlbGxpZ2VudC5jYXIuY29udHJvbC5zbG90LmhvdGZpeC5yZSIsCiAgICAgICJpbnRlbGxpZ2VudF9jYXJfaW5mbyI6ICJtb2RlbHMvaW50ZWxsaWdlbnRfY2FyX2luZm8vaG90Zml4L2ludGVsbGlnZW50LmNhci5pbmZvLnNsb3QuaG90Zml4LnJlIiwKICAgICAgImludGVsbGlnZW50X2Nhcl9zY2VuYXJpbyI6ICJtb2RlbHMvaW50ZWxsaWdlbnRfY2FyX3NjZW5hcmlvL2hvdGZpeC9pbnRlbGxpZ2VudC5jYXIuc2NlbmFyaW8uc2xvdC5ob3RmaXgucmUiLAogICAgICAiZ2xvYmFsX2N0cmwiOiAibW9kZWxzL2dsb2JhbF9jdHJsL2hvdGZpeC9nbG9iYWwuY3RybC5zbG90LmhvdGZpeC5yZSIsCiAgICAgICJtdXNpYyI6ICJtb2RlbHMvbXVzaWMvaG90Zml4L211c2ljLnNsb3QuaG90Zml4LnJlIiwKICAgICAgImZtIjogIm1vZGVscy9mbS9ob3RmaXgvZm0uc2xvdC5ob3RmaXgucmUiLAogICAgICAicGhvbmVfY2FsbCI6ICJtb2RlbHMvcGhvbmVfY2FsbC9ob3RmaXgvcGhvbmUuY2FsbC5zbG90LmhvdGZpeC5yZSIsCiAgICAgICJuYXZpZ2F0aW9uIjogIm1vZGVscy9uYXZpZ2F0aW9uL2hvdGZpeC9uYXZpZ2F0aW9uLnNsb3QuaG90Zml4LnJlIgogICAgfQogIH0sCiAgIlRhZ01hcHBlciI6IHsKICAgICJpbnRlbnQiOiB7CiAgICAgICJpbnRlbGxpZ2VudF9jYXJfY29udHJvbCI6ICJtb2RlbHMvaW50ZWxsaWdlbnRfY2FyX2NvbnRyb2wvaW50ZWxsaWdlbnQuY2FyLmNvbnRyb2wuaW50ZW50LmJlcnQubGFiZWwudHN2IiwKICAgICAgImludGVsbGlnZW50X2Nhcl9pbmZvIjogIm1vZGVscy9pbnRlbGxpZ2VudF9jYXJfaW5mby9pbnRlbGxpZ2VudC5jYXIuaW5mby5pbnRlbnQuYmVydC5sYWJlbC50c3YiLAogICAgICAiaW50ZWxsaWdlbnRfY2FyX3NjZW5hcmlvIjogIm1vZGVscy9pbnRlbGxpZ2VudF9jYXJfc2NlbmFyaW8vaW50ZWxsaWdlbnQuY2FyLnNjZW5hcmlvLmludGVudC5iZXJ0LmxhYmVsLnRzdiIsCiAgICAgICJnbG9iYWxfY3RybCI6ICJtb2RlbHMvZ2xvYmFsX2N0cmwvZ2xvYmFsLmN0cmwuaW50ZW50LmJlcnQubGFiZWwudHN2IiwKICAgICAgIm11c2ljIjogIm1vZGVscy9tdXNpYy9tdXNpYy5pbnRlbnQuYmVydC5sYWJlbC50c3YiLAogICAgICAiZm0iOiAibW9kZWxzL2ZtL2ZtLmludGVudC5iZXJ0LmxhYmVsLnRzdiIsCiAgICAgICJwaG9uZV9jYWxsIjogIm1vZGVscy9waG9uZV9jYWxsL3Bob25lLmNhbGwuaW50ZW50LmJlcnQubGFiZWwudHN2IiwKICAgICAgIm5hdmlnYXRpb24iOiAibW9kZWxzL25hdmlnYXRpb24vbmF2aWdhdGlvbi5pbnRlbnQuYmVydC5sYWJlbC50c3YiCiAgICB9LAogICAgInNsb3QiOiB7CiAgICAgICJpbnRlbGxpZ2VudF9jYXJfY29udHJvbCI6ICJtb2RlbHMvaW50ZWxsaWdlbnRfY2FyX2NvbnRyb2wvaW50ZWxsaWdlbnQuY2FyLmNvbnRyb2wuc2xvdC5tYXBwaW5nLnRzdiIsCiAgICAgICJpbnRlbGxpZ2VudF9jYXJfaW5mbyI6ICJtb2RlbHMvaW50ZWxsaWdlbnRfY2FyX2luZm8vaW50ZWxsaWdlbnQuY2FyLmluZm8uc2xvdC5tYXBwaW5nLnRzdiIsCiAgICAgICJpbnRlbGxpZ2VudF9jYXJfc2NlbmFyaW8iOiAibW9kZWxzL2ludGVsbGlnZW50X2Nhcl9zY2VuYXJpby9pbnRlbGxpZ2VudC5jYXIuc2NlbmFyaW8uc2xvdC5tYXBwaW5nLnRzdiIsCiAgICAgICJnbG9iYWxfY3RybCI6ICJtb2RlbHMvZ2xvYmFsX2N0cmwvZ2xvYmFsLmN0cmwuc2xvdC5tYXBwaW5nLnRzdiIsCiAgICAgICJtdXNpYyI6ICJtb2RlbHMvbXVzaWMvbXVzaWMuc2xvdC5tYXBwaW5nLnRzdiIsCiAgICAgICJmbSI6ICJtb2RlbHMvZm0vZm0uc2xvdC5tYXBwaW5nLnRzdiIsCiAgICAgICJwaG9uZV9jYWxsIjogIm1vZGVscy9waG9uZV9jYWxsL3Bob25lLmNhbGwuc2xvdC5tYXBwaW5nLnRzdiIsCiAgICAgICJuYXZpZ2F0aW9uIjogIm1vZGVscy9uYXZpZ2F0aW9uL25hdmlnYXRpb24uc2xvdC5tYXBwaW5nLnRzdiIKICAgIH0KICB9LAogICJIb3RGaXgiOiB7CiAgICAiZW5hYmxlIjogdHJ1ZSwKICAgICJydWxlX3BhdGhzIjogWwogICAgICAicnVsZXMvaG90Zml4X3J1bGVzLnR4dCIsCiAgICAgICJydWxlcy9pbnRlbGxpZ2VudC5jYXIuY29udHJvbC5ob3RmaXgucXVlcnkudHh0IiwKICAgICAgInJ1bGVzL3ZhZ3VlLmFkanVzdC5ob3RmaXgucXVlcnkudHh0IiwKICAgICAgInJ1bGVzL211c2ljLmJhZGNhc2UuaG90Zml4LnF1ZXJ5LnR4dCIsCiAgICAgICJydWxlcy9tdXNpYy5sbG0uaG90Zml4LnF1ZXJ5LnR4dCIsCiAgICAgICJydWxlcy9mbS5ob3RmaXgucnVsZXMudHh0IiwKICAgICAgInJ1bGVzL25hdmlnYXRpb24uaG90Zml4LnJ1bGVzLnR4dCIsCiAgICAgICJydWxlcy9waG9uZS5jYWxsLmhvdGZpeC5xdWVyeS50eHQiCiAgICBdLAogICAgImRpY3RfcGF0aHMiOiBbCiAgICAgICJydWxlcy9xcS50b3BsaXN0LmRhdGEudHh0IiwKICAgICAgInJ1bGVzL2ludGVsbGlnZW50LmNhci5jb250cm9sLmhvdGZpeC5kaWN0LnR4dCIsCiAgICAgICJydWxlcy92YWd1ZS5hZGp1c3QuaG90Zml4LmRpY3QudHh0IiwKICAgICAgInJ1bGVzL211c2ljLmJhZGNhc2UuaG90Zml4LmRpY3QudHh0IiwKICAgICAgInJ1bGVzL2FwcF9jb250cm9sLnR4dCIsCiAgICAgICJydWxlcy9mbS5hbGJ1bS5kaWN0LnR4dCIsCiAgICAgICJydWxlcy9waG9uZS5jYWxsLmhvdGZpeC5kaWN0LnR4dCIKICAgIF0KICB9LAogICJCYWNrZW5kIjogewogICAgInR5cGUiOiAib3BlbmFpX2h0dHAiCiAgfSwKICAiT3BlbkFJSHR0cCI6IHsKICAgICJlbmRwb2ludCI6ICJodHRwOi8vODIuMTU3LjEzMy4yMjI6ODA0Ni92MS9jaGF0L2NvbXBsZXRpb25zIiwKICAgICJjb25uZWN0X3RpbWVvdXRfbXMiOiA1MDAwLAogICAgInRvdGFsX3RpbWVvdXRfbXMiOiAzMDAwMCwKICAgICJtYXhfcmVzcG9uc2VfYnl0ZXMiOiAxMDQ4NTc2CiAgfSwKICAiTW9kZWwiOiB7CiAgICAicHJvZmlsZV9jYXRhbG9nX3BhdGgiOiAiY29uZi9tb2RlbHMvbmx1L3Byb2ZpbGVzLmpzb24iLAogICAgInByb2ZpbGUiOiAibmx1XzA2Yl92MyIKICB9Cn0K"}, "unchanged": [{"path": "conf/models/nlu/protocols/v4.json", "exact_preimage": "/home/daigd/packages/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082228Z/preimage/conf/models/nlu/protocols/v4.json", "size": 477, "sha256": "bb23a2956ed16370b4a6e630ce046902b414d357e913854149138ed5bbd3b127", "uid": 1000, "gid": 1000, "owner": "daigd", "group": "daigd", "mode": "0o664", "dev": 64770, "inode": 3650424869, "mtime_ns": 1791798718426002758, "atime_ns": 1792396880441337049, "writable": true, "parent_writable_searchable": true}, {"path": "/home/shared/models/car_v3.0/dialog_configure.json", "resolved_path": "/home/shared/models/car_v3.0/dialog_configure.json", "regular_file": true, "symlink": false, "size": 6767, "sha256": "6895ff626f3c4577ed5aa7643fef6cd8c088bd992196633c235f9f0a180439f8", "uid": 1000, "gid": 1000, "mode": "0o664", "dev": 64770, "inode": 2723817319, "mtime_ns": 1791517263110715925, "top_level_key_names": ["ContextFilter", "ContextManager", "DefaultScenario", "DialogueManager", "HotQueriesCacheRules", "LanguageUnderstanding", "Nlu06B", "QueryGuard", "ThreadPoolSize", "version"], "dialogue_base": "/home/shared/models/car_v3.0", "nlu_config_selector": "conf/nlu_config_06b_http_offline.json", "policy_subtree_hashes": {"LanguageUnderstanding": "29f9f5985f8f238d09600dbfdffbd82ed654a0cc688af9a1d3d4e7cf17115b44", "ContextFilter": "a68415a2c9ee179814daba87d9048edf72cc4cd8f17351404fe4b595bacb4c42", "QueryGuard": "6d3d7cc2be1aca62dce2f8b23eb2b84da57c118cc5d6909ff601bd50067a3149", "ContextManager": "08f284236345f40d078686158a4fd1922a5142ef5c20f041906b475b451872d4", "Nlu06B": "feaf1ab2584d8b3c5f60c237b1e2786c0bc74fba2d9dfe49b118f0f5dc058b1e"}}, {"path": "/home/shared/models/car_v3.0/dialog_configure_offline.json", "resolved_path": "/home/shared/models/car_v3.0/dialog_configure_offline.json", "regular_file": true, "symlink": false, "size": 6767, "sha256": "6895ff626f3c4577ed5aa7643fef6cd8c088bd992196633c235f9f0a180439f8", "uid": 1000, "gid": 1000, "mode": "0o664", "dev": 64770, "inode": 2723817322, "mtime_ns": 1790734232052394920, "top_level_key_names": ["ContextFilter", "ContextManager", "DefaultScenario", "DialogueManager", "HotQueriesCacheRules", "LanguageUnderstanding", "Nlu06B", "QueryGuard", "ThreadPoolSize", "version"], "dialogue_base": "/home/shared/models/car_v3.0", "nlu_config_selector": "conf/nlu_config_06b_http_offline.json", "policy_subtree_hashes": {"LanguageUnderstanding": "29f9f5985f8f238d09600dbfdffbd82ed654a0cc688af9a1d3d4e7cf17115b44", "ContextFilter": "a68415a2c9ee179814daba87d9048edf72cc4cd8f17351404fe4b595bacb4c42", "QueryGuard": "6d3d7cc2be1aca62dce2f8b23eb2b84da57c118cc5d6909ff601bd50067a3149", "ContextManager": "08f284236345f40d078686158a4fd1922a5142ef5c20f041906b475b451872d4", "Nlu06B": "feaf1ab2584d8b3c5f60c237b1e2786c0bc74fba2d9dfe49b118f0f5dc058b1e"}}], "policies": {"$.ContextManager.max_turn_size": 2, "$.ContextManager.max_query_records": 15, "$.ContextManager.expire_strategy.user_session": 150, "$.ContextManager.expire_strategy.query_records": 15, "$.ContextManager.expire_strategy.llm_simple_cache": -1, "$.Nlu06B.max_history_rounds": 2, "$.Nlu06B.max_history_bytes": 65536, "$.Nlu06B.allow_multi_intent_input": false, "$.ContextFilter.enable": true, "$.QueryGuard.enable": true}, "references": [{"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/0", "reference": "rules/hotfix_rules.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/hotfix_rules.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/0", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/1", "reference": "rules/intelligent.car.control.hotfix.query.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/intelligent.car.control.hotfix.query.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/1", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/2", "reference": "rules/vague.adjust.hotfix.query.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/vague.adjust.hotfix.query.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/2", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/3", "reference": "rules/music.badcase.hotfix.query.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/music.badcase.hotfix.query.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/3", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/4", "reference": "rules/music.llm.hotfix.query.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/music.llm.hotfix.query.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/4", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/5", "reference": "rules/fm.hotfix.rules.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/fm.hotfix.rules.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/5", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/6", "reference": "rules/navigation.hotfix.rules.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/navigation.hotfix.rules.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/6", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/7", "reference": "rules/phone.call.hotfix.query.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/phone.call.hotfix.query.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/rule_paths/7", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/0", "reference": "rules/qq.toplist.data.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/qq.toplist.data.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/0", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/1", "reference": "rules/intelligent.car.control.hotfix.dict.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/intelligent.car.control.hotfix.dict.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/1", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/2", "reference": "rules/vague.adjust.hotfix.dict.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/vague.adjust.hotfix.dict.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/2", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/3", "reference": "rules/music.badcase.hotfix.dict.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/music.badcase.hotfix.dict.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/3", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/4", "reference": "rules/app_control.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/app_control.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/4", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/5", "reference": "rules/fm.album.dict.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/fm.album.dict.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/5", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/6", "reference": "rules/phone.call.hotfix.dict.txt", "resolved_under_resource_root": "/home/shared/models/car_v3.0/rules/phone.call.hotfix.dict.txt", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/HotFix/dict_paths/6", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/nlu_config_06b_http_offline.json/OpenAIHttp/profile_catalog_path", "reference": "conf/models/nlu/profiles.json", "resolved_under_resource_root": "/home/shared/models/car_v3.0/conf/models/nlu/profiles.json", "exists": true, "isfile": true, "candidate_json_path": "conf/nlu_config_06b_http_offline.json/Model/profile_catalog_path", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/models/nlu/profiles.json/profiles/nlu_06b_v3/protocol_path", "reference": "conf/models/nlu/protocols/v3.json", "resolved_under_resource_root": "/home/shared/models/car_v3.0/conf/models/nlu/protocols/v3.json", "exists": true, "isfile": true, "candidate_json_path": "conf/models/nlu/profiles.json/profiles/nlu_06b_v3/protocol_path", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/models/nlu/profiles.json/profiles/nlu_06b_v4/protocol_path", "reference": "conf/models/nlu/protocols/v4.json", "resolved_under_resource_root": "/home/shared/models/car_v3.0/conf/models/nlu/protocols/v4.json", "exists": true, "isfile": true, "candidate_json_path": "conf/models/nlu/profiles.json/profiles/nlu_06b_v4/protocol_path", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}, {"json_path": "conf/models/nlu/profiles.json/profiles/nlu_4b_v4/protocol_path", "reference": "conf/models/nlu/protocols/v4.json", "resolved_under_resource_root": "/home/shared/models/car_v3.0/conf/models/nlu/protocols/v4.json", "exists": true, "isfile": true, "candidate_json_path": "conf/models/nlu/profiles.json/profiles/nlu_4b_v4/protocol_path", "evidence": "evidence.json#/stages/resource_capture/data/data/reference_presence", "status": "PASS_CAPTURED_REMOTE_EXISTENCE"}], "source_head": "aca4b3e4cd653bf2422ffd1de2680ce3724bc32b", "source_metadata": [{"path": "cu/llm_protocol.cc", "size": 4924, "sha256": "904f3779454e4bedc17bad0c5a5c31ff60f8a7768497b981ab8246d269b7b744", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/llm_protocol.cc"}, {"path": "cu/llm_protocol.h", "size": 1971, "sha256": "67b0f6d283498b77205c8eb50175091f89fd34965bd729bf963711f9cc0ac70b", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/llm_protocol.h"}, {"path": "cu/nlu_10_protocol.cc", "size": 30434, "sha256": "f6237a7cba0f795681c4cccd186888b771d6b09cec5ba731c4450c7db04a327d", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/nlu_10_protocol.cc"}, {"path": "cu/nlu_10_protocol.h", "size": 1689, "sha256": "ef7b385388c7b431ce441b51adaa51001f0eb4082927f6e050f59a964dee8bda", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/nlu_10_protocol.h"}, {"path": "cu/nlu_0_6b_http_backend.cc", "size": 27426, "sha256": "6e02b76c946b3bc1dfe5c74833a428e148aa9d8fc2604b0943235c0b36ea4934", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/nlu_0_6b_http_backend.cc"}, {"path": "cu/nlu_0_6b_http_backend.h", "size": 1411, "sha256": "1bf3496e39a09e883dfaada3d8de7822a8705350c4d152b3b333db55bed7e624", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/nlu_0_6b_http_backend.h"}, {"path": "cu/nlu_0_6b_manager.cc", "size": 14381, "sha256": "5f103a57ebbc75fc8284e02c4079961430c6246e632f0fbfb19ee9d504171952", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/nlu_0_6b_manager.cc"}, {"path": "cu/dialogue_v3.cc", "size": 56391, "sha256": "11b21c07b82a95f3b8c6fda73a75aa799918987307085f816ee28094d8ce01a0", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/dialogue_v3.cc"}, {"path": "cu/dialogue_system.cc", "size": 13074, "sha256": "31072794118260e708e39b9c190a6b9de8e727cbbd5555a9060cf081b6332b90", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/dialogue_system.cc"}, {"path": "cu/server.cc", "size": 2333, "sha256": "ef8b0b8b4c64c7e93e42d90896c0f48887e95d16e2910f19cec58aebc0f77fa1", "exact_capture": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-20261019T082308Z/source/cu/server.cc"}], "source_callers": {"cu/handlers.cc": [{"line": 781, "text": ""}, {"line": 782, "text": "int ReloadHandler(const httplib::Request &request,"}, {"line": 783, "text": "                  httplib::Response &response) {"}, {"line": 784, "text": "  auto code = const_cast<nlptk::Dialogue &>(nlptk::DialogueInstance::Get())"}, {"line": 785, "text": "                  .ReInitialize();"}, {"line": 786, "text": "  if (code != 0) {"}, {"line": 787, "text": "    response.set_content(\\"{\\\\\\"code\\\\\\":500,\\\\\\"msg\\\\\\":\\\\\\"reload failed\\\\\\"}\\","}, {"line": 788, "text": "                         \\"application/json; charset=utf-8\\");"}, {"line": 789, "text": "  } else {"}, {"line": 790, "text": "    response.set_content(\\"{\\\\\\"code\\\\\\":200,\\\\\\"msg\\\\\\":\\\\\\"reload success\\\\\\"}\\","}, {"line": 791, "text": "                         \\"application/json; charset=utf-8\\");"}, {"line": 792, "text": "  }"}]}, "controller_path": "/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh", "controller_lines": [[164, "TARGET_USER=\\"${TARGET_USER:-daigd}\\""], [165, "TARGET_HOST=\\"${TARGET_HOST:-10.1.122.21}\\""], [166, "TARGET_PORT=\\"${TARGET_PORT:-22}\\""], [167, "TARGET_SSH=\\"${TARGET_USER}@${TARGET_HOST}\\""], [170, "REMOTE_PACKAGE_ROOT=\\"${REMOTE_PACKAGE_ROOT:-/home/daigd/packages}\\""], [172, "REMOTE_AUTO_BUILD=\\"${REMOTE_AUTO_BUILD:-$REMOTE_PACKAGE_ROOT/auto_build_offline_v3.sh}\\""], [173, "REMOTE_MODEL_DIR=\\"${REMOTE_MODEL_DIR:-/home/shared/models/car_v3.0}\\""], [216, "SSH_IDENTITY=\\"${SSH_IDENTITY:-}\\""], [217, "SSH_CONNECT_TIMEOUT=\\"${SSH_CONNECT_TIMEOUT:-8}\\""], [640, "ssh_base_args() {"], [658, "ssh_batch_args() {"], [1451, "Inspect the actual source configuration:"], [1813, "  # Strict source validation."], [2047, "    # Manual deploy/test is expected to run with a TTY from the source script."], [2443, "  envfile=\\"$builddir/baseline.env\\""], [2979, "port=os.environ[\'PORT\']; path=os.environ[\'PATH_\']; query=os.environ[\'QUERY\']"], [2980, "max_time=os.environ[\'MAX_TIME\']; retries=int(os.environ[\'RETRIES\']); interval=float(os.environ[\'INTERVAL\'])"], ["function", "ssh_base_args() {\\n  SSH_ARGS=(\\n    -p \\"$TARGET_PORT\\"\\n    -o ConnectTimeout=\\"$SSH_CONNECT_TIMEOUT\\"\\n    -o ServerAliveInterval=15\\n    -o ServerAliveCountMax=2\\n  )\\n\\n  if [[ -n \\"$SSH_IDENTITY\\" ]]; then\\n    SSH_ARGS+=(-i \\"$SSH_IDENTITY\\")\\n  fi\\n\\n  # Important: argument-builder helpers must always return success.\\n  # With `set -e`, a final `[[ ... ]] && ...` would return 1 when\\n  # SSH_IDENTITY is empty and terminate callers such as sync_artifacts().\\n  return 0\\n}"], ["function", "ssh_batch_args() {\\n  ssh_base_args || return $?\\n  SSH_BATCH_ARGS=(\\"${SSH_ARGS[@]}\\" -o BatchMode=yes)\\n  return 0\\n}"]], "centos_transaction": "/home/daigd/packages/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4d-20261019T091106Z", "ubuntu_transaction": "/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4d-20261019T091106Z"}')
# Finite Phase4d operational transaction, not product tooling.
import base64, datetime, stat, time
# Schema/preservation definitions and DATA are prepended by the local executor.
os.umask(0o077)
TX = DATA['centos_transaction']
ORDER = [PROTO, CAT, NLU]
EVENTS, REPLACED, ORIGINAL, STATS = [], [], {}, {}
CREATED = False

def check(condition, category):
    if not condition: raise Invalid(category)

def contained(path, base):
    check(os.path.isabs(path) and os.path.realpath(path) == path, 'containment_or_symlink')
    check(path == base or path.startswith(base + '/'), 'outside_authorized_root')
    current = '/'
    for part in path.strip('/').split('/'):
        current = os.path.join(current, part)
        check(not stat.S_ISLNK(os.lstat(current).st_mode), 'symlink_component')
    return path

def read_file(path, base, limit=2097152):
    contained(path, base)
    before = os.lstat(path)
    check(stat.S_ISREG(before.st_mode) and before.st_size <= limit, 'not_bounded_regular_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as f:
        opened = os.fstat(f.fileno())
        check((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino), 'open_identity_drift')
        raw = f.read(limit + 1)
        after = os.fstat(f.fileno())
    current = os.lstat(path)
    check(len(raw) <= limit and (before.st_dev, before.st_ino, before.st_size,
          before.st_mtime_ns, before.st_ctime_ns) == (after.st_dev, after.st_ino,
          after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'read_content_drift')
    check((current.st_dev, current.st_ino) == (before.st_dev, before.st_ino), 'path_identity_drift')
    return raw, before

def parse(raw):
    check(not raw.startswith(b'\xef\xbb\xbf'), 'json_bom')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=reject_constant)

def metadata(st):
    return {'uid': st.st_uid, 'gid': st.st_gid, 'mode': oct(stat.S_IMODE(st.st_mode)),
            'dev': st.st_dev, 'inode': st.st_ino, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns, 'atime_ns': st.st_atime_ns}

def compare(raw, st, expected, category, identity=True):
    check(digest(raw) == expected['sha256'] and len(raw) == expected['size'], category + '_bytes')
    check(st.st_uid == expected['uid'] and st.st_gid == expected['gid'] and
          stat.S_IMODE(st.st_mode) == int(expected['mode'], 8), category + '_metadata')
    if identity:
        check((st.st_dev, st.st_ino, st.st_mtime_ns) ==
              (expected['dev'], expected['inode'], expected['mtime_ns']), category + '_identity')

def syncdir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)

def write_new(path, raw, original_stat=None):
    contained(os.path.dirname(path), TX)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(raw); f.flush()
        if original_stat is not None:
            os.fchown(f.fileno(), original_stat.st_uid, original_stat.st_gid)
            os.fchmod(f.fileno(), stat.S_IMODE(original_stat.st_mode))
        os.fsync(f.fileno())
    if original_stat is not None:
        os.utime(path, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns), follow_symlinks=False)
    syncdir(os.path.dirname(path))

def emit(action, **fields):
    event = {'time_utc': datetime.datetime.utcnow().isoformat()+'Z', 'action': action}
    event.update(fields); EVENTS.append(event)
    if CREATED:
        fd = os.open(TX+'/journal.jsonl', os.O_WRONLY | os.O_APPEND | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'ab') as f:
            f.write((json.dumps(event, sort_keys=True)+'\n').encode())
            f.flush(); os.fsync(f.fileno())

def unchanged():
    rows = []
    for item in DATA['unchanged']:
        path = item['path'] if item['path'].startswith('/') else ROOT+'/'+item['path']
        raw, st = read_file(path, ROOT)
        compare(raw, st, item, 'unchanged_resource')
        obj = parse(raw)
        if 'policy_subtree_hashes' in item:
            for key, expected in item['policy_subtree_hashes'].items():
                value = json.dumps(obj[key], sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
                check(digest(value) == expected, 'root_policy_hash_drift')
            check(obj['LanguageUnderstanding']['NluConfig'] == NLU, 'root_selector_drift')
            for selector, expected in DATA['policies'].items():
                value = obj
                for key in selector[2:].split('.'): value = value[key]
                check(same(value, expected), 'root_policy_value_drift')
        rows.append({'path': path, 'sha256': digest(raw), 'uid': st.st_uid,
                     'gid': st.st_gid, 'mode': oct(stat.S_IMODE(st.st_mode)), 'unchanged': True})
    return rows

def reference_closure(objects):
    check(objects[NLU]['Model'] == {'profile': PROFILE, 'profile_catalog_path': CAT}, 'live_model_closure')
    check(objects[CAT]['profiles'][PROFILE]['protocol_path'] == PROTO, 'live_protocol_closure')
    check(objects[PROTO]['protocol'] == 'nlu_10', 'live_protocol_identity')
    refs=[]
    for item in DATA['references']:
        rel, pointer = item['candidate_json_path'].split('.json/', 1)
        rel += '.json'
        value = objects[rel]
        for key in pointer.split('/'):
            value = value[int(key)] if isinstance(value, list) else value[key]
        check(value == item['reference'], 'reference_value_drift')
        path = relative_path(value)
        contained(path, ROOT)
        check(stat.S_ISREG(os.lstat(path).st_mode), 'reference_not_regular')
        refs.append({'json_path': item['candidate_json_path'], 'resolved_path': path, 'exists_regular': True})
    return refs

def guard_current(rel, expected_raw, expected_stat=None):
    raw, st = read_file(ROOT+'/'+rel, ROOT)
    check(raw == expected_raw, 'target_changed_before_replace')
    if expected_stat is not None:
        check((st.st_dev, st.st_ino, st.st_mtime_ns, st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) ==
              (expected_stat.st_dev, expected_stat.st_ino, expected_stat.st_mtime_ns,
               expected_stat.st_uid, expected_stat.st_gid, stat.S_IMODE(expected_stat.st_mode)),
              'target_metadata_changed_before_replace')
    return st

RESULT = {'authorization': 'PLAN-20261016-llm-nlu10-shared-codec v2 Phase4d',
          'transaction': TX, 'resource_root': ROOT, 'status': 'FAIL', 'replaced': [],
          'runtime_initialization': 'UNRUN', 'rollback': []}
try:
    contained(ROOT, ROOT)
    parent = '/home/daigd/packages/.wtp184-transactions'
    contained(parent, parent)
    check(stat.S_ISDIR(os.lstat(parent).st_mode), 'transaction_parent_not_directory')
    check(os.stat(parent).st_dev == os.stat(ROOT).st_dev, 'transaction_filesystem_mismatch')
    check(not os.path.lexists(TX) and TX.startswith(parent+'/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4d-'), 'transaction_collision')
    expected = {row['resource_relative_path']: row for row in DATA['files']}
    for rel in ORDER:
        raw, st = read_file(ROOT+'/'+rel, ROOT)
        compare(raw, st, expected[rel]['original_metadata'], 'preimage_drift')
        ORIGINAL[rel], STATS[rel] = raw, st
    initial_unchanged = unchanged()
    candidate_raw = {rel: base64.b64decode(DATA['candidates'][rel], validate=True) for rel in ORDER}
    for rel in ORDER:
        check(digest(candidate_raw[rel]) == expected[rel]['candidate_sha256'] and
              len(candidate_raw[rel]) == expected[rel]['candidate_size'], 'candidate_hash_or_size')
    v4raw, _ = read_file(ROOT+'/'+V4, ROOT)
    originals = {rel: parse(raw) for rel, raw in ORIGINAL.items()}
    originals[V4] = parse(v4raw)
    candidates = {rel: parse(raw) for rel, raw in candidate_raw.items()}
    candidates[V4] = parse(v4raw)
    preservation(originals, candidates)
    reference_closure(candidates)
    os.mkdir(TX, 0o700)
    CREATED = True
    for sub in ('preimage', 'candidates', 'rollback'): os.mkdir(TX+'/'+sub, 0o700)
    emit('all_preimages_frozen_resources_and_candidates_pass', count=3)
    backup_rows=[]
    for i, rel in enumerate(ORDER):
        path = TX+'/preimage/'+str(i)+'.json'
        write_new(path, ORIGINAL[rel], STATS[rel])
        raw, st = read_file(path, TX)
        compare(raw, st, expected[rel]['original_metadata'], 'backup_verification', identity=False)
        check(st.st_mtime_ns == STATS[rel].st_mtime_ns, 'backup_mtime')
        backup_rows.append({'target': ROOT+'/'+rel, 'backup': path, 'sha256': digest(raw),
                            'original_metadata': metadata(STATS[rel]), 'backup_metadata': metadata(st)})
    write_new(TX+'/metadata.json', json.dumps(backup_rows, sort_keys=True, indent=2).encode())
    emit('all_backups_verified_before_any_replace', metadata_path=TX+'/metadata.json', count=3)
    for i, rel in enumerate(ORDER):
        path = TX+'/candidates/'+str(i)+'.json'
        write_new(path, candidate_raw[rel], STATS[rel])
        raw, st = read_file(path, TX)
        check(raw == candidate_raw[rel] and st.st_dev == STATS[rel].st_dev, 'stage_bytes_or_device')
        check(st.st_uid == 1000 and st.st_gid == 1000 and stat.S_IMODE(st.st_mode) == 0o664, 'stage_metadata')
    emit('all_candidates_staged_same_filesystem', count=3)
    unchanged()
    for i, rel in enumerate(ORDER):
        for other in ORDER:
            guard_current(other, candidate_raw[other] if other in REPLACED else ORIGINAL[other],
                          None if other in REPLACED else STATS[other])
        unchanged()
        stage = TX+'/candidates/'+str(i)+'.json'
        raw, _ = read_file(stage, TX)
        check(raw == candidate_raw[rel], 'stage_drift_before_replace')
        os.replace(stage, ROOT+'/'+rel)
        REPLACED.append(rel)
        emit('atomic_replace', order=i+1, path=ROOT+'/'+rel, sha256=digest(raw))
        syncdir(os.path.dirname(ROOT+'/'+rel))
        installed_raw, installed_stat = read_file(ROOT+'/'+rel, ROOT)
        check(installed_raw == candidate_raw[rel], 'immediate_postimage_bytes')
        check(installed_stat.st_uid == 1000 and installed_stat.st_gid == 1000 and
              stat.S_IMODE(installed_stat.st_mode) == 0o664, 'immediate_postimage_metadata')
    installed, rows = {}, []
    for rel in ORDER:
        raw, st = read_file(ROOT+'/'+rel, ROOT)
        check(raw == candidate_raw[rel], 'final_postimage_bytes')
        check(st.st_uid == 1000 and st.st_gid == 1000 and stat.S_IMODE(st.st_mode) == 0o664,
              'final_postimage_metadata')
        installed[rel] = parse(raw)
        rows.append({'path': ROOT+'/'+rel, 'sha256': digest(raw), **metadata(st)})
    installed[V4] = parse(read_file(ROOT+'/'+V4, ROOT)[0])
    checks = preservation(originals, installed)
    refs = reference_closure(installed)
    frozen = unchanged()
    emit('static_install_validation_pass', installed_count=3, equality_assertion_count=len(checks), reference_count=len(refs))
    RESULT.update(status='PASS', installed=rows, backups=backup_rows,
                  equality_assertions=checks, references=refs, unchanged=frozen,
                  wire_bytes=byte_evidence(installed[PROTO]),
                  endpoint_env_model_prompt_generation_cap='EQUAL_WITHOUT_ENV_EVALUATION',
                  metadata_path=TX+'/metadata.json', journal_path=TX+'/journal.jsonl',
                  root_policies='UNCHANGED_HASH_AND_VALUE_PROOF', loader='STATIC_ONLY_MATCHING_BINARY_REQUIRED')
except BaseException as exc:
    reason = str(exc) if isinstance(exc, Invalid) else type(exc).__name__
    RESULT.update(first_actionable_error=reason, error_type=type(exc).__name__)
    emit('transaction_failure', category=reason, replaced_count=len(REPLACED))
    for rel in reversed(REPLACED):
        try:
            guard_current(rel, candidate_raw[rel])
            index = ORDER.index(rel)
            raw, _ = read_file(TX+'/preimage/'+str(index)+'.json', TX)
            check(raw == ORIGINAL[rel], 'rollback_backup_drift')
            path = TX+'/rollback/'+str(index)+'.json'
            write_new(path, raw, STATS[rel])
            guard_current(rel, candidate_raw[rel])
            os.replace(path, ROOT+'/'+rel)
            syncdir(os.path.dirname(ROOT+'/'+rel))
            restored, st = read_file(ROOT+'/'+rel, ROOT)
            compare(restored, st, expected[rel]['original_metadata'], 'rollback_verify', identity=False)
            RESULT['rollback'].append({'path': ROOT+'/'+rel, 'status': 'RESTORED', 'sha256': digest(restored)})
            emit('rollback_restored', path=ROOT+'/'+rel, sha256=digest(restored))
        except BaseException as rollback_exc:
            category = str(rollback_exc) if isinstance(rollback_exc, Invalid) else type(rollback_exc).__name__
            RESULT['rollback'].append({'path': ROOT+'/'+rel, 'status': 'NOT_OVERWRITTEN_UNCERTAIN', 'category': category})
            emit('rollback_stopped_uncertain_file', path=ROOT+'/'+rel, category=category)
            break
finally:
    RESULT['replaced'] = [ROOT+'/'+rel for rel in REPLACED]
    RESULT['events'] = EVENTS
    if CREATED:
        write_new(TX+'/install-result.json', json.dumps(RESULT, sort_keys=True, indent=2).encode())
    print(json.dumps(RESULT, sort_keys=True))
    sys.exit(0 if RESULT['status'] == 'PASS' else 1)
