# DATA, CENTOS_CODE, EXPECTED_PIN and pinned bridge guard prepended by executor.
import re, stat, sys, time
os.umask(0o077)
ROOT='/home/daigd/dialogue'
TX=DATA['ubuntu_transaction']
report={'status':'FAIL','transaction':TX,'target_mutation':'NONE','commands':[]}
def need(condition, category):
    if not condition: raise RuntimeError(category)
def bounded(path, root):
    need(os.path.realpath(path)==path and path.startswith(root+'/'), 'source_containment')
    before=os.lstat(path)
    need(stat.S_ISREG(before.st_mode) and before.st_size<=2097152,'source_bounded_file')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as f:
        opened=os.fstat(f.fileno()); raw=f.read(2097153); after=os.fstat(f.fileno())
    need((before.st_dev,before.st_ino)==(opened.st_dev,opened.st_ino),'source_identity_drift')
    need((before.st_size,before.st_mtime_ns,before.st_ctime_ns)==
         (after.st_size,after.st_mtime_ns,after.st_ctime_ns) and len(raw)<=2097152,'source_read_drift')
    return raw
try:
    s=bounded(DATA['controller_path'],'/home/daigd').decode()
    for item in DATA['controller_lines']:
        value=item[1]
        if item[0]=='function' or re.match(r'^(TARGET_|REMOTE_|SSH_)',value):
            need(value in s,'controller_relevant_contract_drift')
    env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0';env['GIT_PAGER']='cat'
    def git(args):
        cmd=['git','-c','core.fsmonitor=false','-c','core.pager=cat','-C',ROOT]+args
        r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12)
        report['commands'].append({'argv':cmd,'exit_status':r.returncode})
        need(r.returncode==0,'source_git_read_failed')
        return r.stdout.decode().strip()
    head=git(['rev-parse','HEAD'])
    paths=[x['path'] for x in DATA['source_metadata']]
    dirty=git(['status','--porcelain','--untracked-files=all','--']+paths)
    checked=[]
    for item in DATA['source_metadata']:
        raw=bounded(ROOT+'/'+item['path'],ROOT)
        need(hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size'],
             'relevant_loader_source_drift:'+item['path'])
        checked.append(item['path'])
    for rel, spans in DATA['source_callers'].items():
        lines=bounded(ROOT+'/'+rel,ROOT).decode().splitlines()
        for item in spans:
            need(item['line']<=len(lines) and lines[item['line']-1]==item['text'],
                 'relevant_loader_caller_drift:'+rel)
    need(not os.path.lexists(ROOT+'/cu/dialogue.cc'),'captured_absent_source_now_present')
    report['source_contract']={'status':'PASS','captured_head':DATA['source_head'],'current_head':head,
        'head_equal':head==DATA['source_head'],'scoped_dirty':bool(dirty),
        'loader_files_exact_match':checked,'immediate_caller_spans_exact_match':True,
        'unrelated_source_changes_reverted':False}
    parent='/home/daigd/.wtp184-transactions'
    need(os.path.realpath(parent)==parent and os.path.isdir(parent),'ubuntu_transaction_parent')
    need(not os.path.lexists(TX) and TX.startswith(parent+'/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4d-'),'ubuntu_transaction_collision')
    os.mkdir(TX,0o700)
    with open(TX+'/centos-operation.py','xb') as f: f.write(CENTOS_CODE.encode())
    with open(TX+'/input-metadata.json','xb') as f:
        f.write(json.dumps({k:v for k,v in DATA.items() if k!='candidates'},sort_keys=True).encode())
    command='timeout --signal=TERM --kill-after=5s 65s python3 -I -'
    cmd=['ssh']+SSH_OPTIONS+[TARGET,command]
    r=subprocess.run(cmd,input=CENTOS_CODE.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=85)
    report['commands'].append({'argv':cmd,'exit_status':r.returncode,'stderr_bytes':len(r.stderr)})
    need(len(r.stdout)<=262144,'centos_output_bound')
    if r.stdout:
        try: report['centos']=json.loads(r.stdout)
        except ValueError: report['centos']={'status':'FAIL','first_actionable_error':'non_json_transport_output'}
    else: report['centos']={'status':'FAIL','first_actionable_error':'no_transport_output'}
    report['centos_exit']=r.returncode
    report['controller_contract_pin']=contract_pin
    report['target_mutation']='THREE_ORDERED_CONFIG_REPLACEMENTS' if report['centos'].get('status')=='PASS' else 'SEE_CENTOS_EVIDENCE'
    report['status']='PASS' if r.returncode==0 and report['centos'].get('status')=='PASS' else 'FAIL'
except BaseException as exc:
    report['first_actionable_error']=str(exc) if isinstance(exc,RuntimeError) else type(exc).__name__
if os.path.isdir(TX):
    with open(TX+'/control-result.json','x') as f: json.dump(report,f,sort_keys=True,indent=2)
print(json.dumps(report,sort_keys=True))
sys.exit(0 if report['status']=='PASS' else 1)
