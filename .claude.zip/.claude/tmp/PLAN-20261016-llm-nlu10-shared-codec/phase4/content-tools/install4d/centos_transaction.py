# Finite Phase4d operational transaction, not product tooling.
import base64, datetime, stat, time
# Schema/preservation definitions and DATA are prepended by the local executor.
os.umask(0o077)
TX = DATA['centos_transaction']
ORDER = [PROTO, CAT, NLU]
EVENTS, REPLACED, ORIGINAL, STATS = [], [], {}, {}
CREATED = False

def check(condition, category):
    if not condition: raise Invalid(category)

def contained(path, base):
    check(os.path.isabs(path) and os.path.realpath(path) == path, 'containment_or_symlink')
    check(path == base or path.startswith(base + '/'), 'outside_authorized_root')
    current = '/'
    for part in path.strip('/').split('/'):
        current = os.path.join(current, part)
        check(not stat.S_ISLNK(os.lstat(current).st_mode), 'symlink_component')
    return path

def read_file(path, base, limit=2097152):
    contained(path, base)
    before = os.lstat(path)
    check(stat.S_ISREG(before.st_mode) and before.st_size <= limit, 'not_bounded_regular_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as f:
        opened = os.fstat(f.fileno())
        check((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino), 'open_identity_drift')
        raw = f.read(limit + 1)
        after = os.fstat(f.fileno())
    current = os.lstat(path)
    check(len(raw) <= limit and (before.st_dev, before.st_ino, before.st_size,
          before.st_mtime_ns, before.st_ctime_ns) == (after.st_dev, after.st_ino,
          after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'read_content_drift')
    check((current.st_dev, current.st_ino) == (before.st_dev, before.st_ino), 'path_identity_drift')
    return raw, before

def parse(raw):
    check(not raw.startswith(b'\xef\xbb\xbf'), 'json_bom')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=reject_constant)

def metadata(st):
    return {'uid': st.st_uid, 'gid': st.st_gid, 'mode': oct(stat.S_IMODE(st.st_mode)),
            'dev': st.st_dev, 'inode': st.st_ino, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns, 'atime_ns': st.st_atime_ns}

def compare(raw, st, expected, category, identity=True):
    check(digest(raw) == expected['sha256'] and len(raw) == expected['size'], category + '_bytes')
    check(st.st_uid == expected['uid'] and st.st_gid == expected['gid'] and
          stat.S_IMODE(st.st_mode) == int(expected['mode'], 8), category + '_metadata')
    if identity:
        check((st.st_dev, st.st_ino, st.st_mtime_ns) ==
              (expected['dev'], expected['inode'], expected['mtime_ns']), category + '_identity')

def syncdir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)

def write_new(path, raw, original_stat=None):
    contained(os.path.dirname(path), TX)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(raw); f.flush()
        if original_stat is not None:
            os.fchown(f.fileno(), original_stat.st_uid, original_stat.st_gid)
            os.fchmod(f.fileno(), stat.S_IMODE(original_stat.st_mode))
        os.fsync(f.fileno())
    if original_stat is not None:
        os.utime(path, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns), follow_symlinks=False)
    syncdir(os.path.dirname(path))

def emit(action, **fields):
    event = {'time_utc': datetime.datetime.utcnow().isoformat()+'Z', 'action': action}
    event.update(fields); EVENTS.append(event)
    if CREATED:
        fd = os.open(TX+'/journal.jsonl', os.O_WRONLY | os.O_APPEND | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'ab') as f:
            f.write((json.dumps(event, sort_keys=True)+'\n').encode())
            f.flush(); os.fsync(f.fileno())

def unchanged():
    rows = []
    for item in DATA['unchanged']:
        path = item['path'] if item['path'].startswith('/') else ROOT+'/'+item['path']
        raw, st = read_file(path, ROOT)
        compare(raw, st, item, 'unchanged_resource')
        obj = parse(raw)
        if 'policy_subtree_hashes' in item:
            for key, expected in item['policy_subtree_hashes'].items():
                value = json.dumps(obj[key], sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
                check(digest(value) == expected, 'root_policy_hash_drift')
            check(obj['LanguageUnderstanding']['NluConfig'] == NLU, 'root_selector_drift')
            for selector, expected in DATA['policies'].items():
                value = obj
                for key in selector[2:].split('.'): value = value[key]
                check(same(value, expected), 'root_policy_value_drift')
        rows.append({'path': path, 'sha256': digest(raw), 'uid': st.st_uid,
                     'gid': st.st_gid, 'mode': oct(stat.S_IMODE(st.st_mode)), 'unchanged': True})
    return rows

def reference_closure(objects):
    check(objects[NLU]['Model'] == {'profile': PROFILE, 'profile_catalog_path': CAT}, 'live_model_closure')
    check(objects[CAT]['profiles'][PROFILE]['protocol_path'] == PROTO, 'live_protocol_closure')
    check(objects[PROTO]['protocol'] == 'nlu_10', 'live_protocol_identity')
    refs=[]
    for item in DATA['references']:
        rel, pointer = item['candidate_json_path'].split('.json/', 1)
        rel += '.json'
        value = objects[rel]
        for key in pointer.split('/'):
            value = value[int(key)] if isinstance(value, list) else value[key]
        check(value == item['reference'], 'reference_value_drift')
        path = relative_path(value)
        contained(path, ROOT)
        check(stat.S_ISREG(os.lstat(path).st_mode), 'reference_not_regular')
        refs.append({'json_path': item['candidate_json_path'], 'resolved_path': path, 'exists_regular': True})
    return refs

def guard_current(rel, expected_raw, expected_stat=None):
    raw, st = read_file(ROOT+'/'+rel, ROOT)
    check(raw == expected_raw, 'target_changed_before_replace')
    if expected_stat is not None:
        check((st.st_dev, st.st_ino, st.st_mtime_ns, st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)) ==
              (expected_stat.st_dev, expected_stat.st_ino, expected_stat.st_mtime_ns,
               expected_stat.st_uid, expected_stat.st_gid, stat.S_IMODE(expected_stat.st_mode)),
              'target_metadata_changed_before_replace')
    return st

RESULT = {'authorization': 'PLAN-20261016-llm-nlu10-shared-codec v2 Phase4d',
          'transaction': TX, 'resource_root': ROOT, 'status': 'FAIL', 'replaced': [],
          'runtime_initialization': 'UNRUN', 'rollback': []}
try:
    contained(ROOT, ROOT)
    parent = '/home/daigd/packages/.wtp184-transactions'
    contained(parent, parent)
    check(stat.S_ISDIR(os.lstat(parent).st_mode), 'transaction_parent_not_directory')
    check(os.stat(parent).st_dev == os.stat(ROOT).st_dev, 'transaction_filesystem_mismatch')
    check(not os.path.lexists(TX) and TX.startswith(parent+'/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4d-'), 'transaction_collision')
    expected = {row['resource_relative_path']: row for row in DATA['files']}
    for rel in ORDER:
        raw, st = read_file(ROOT+'/'+rel, ROOT)
        compare(raw, st, expected[rel]['original_metadata'], 'preimage_drift')
        ORIGINAL[rel], STATS[rel] = raw, st
    initial_unchanged = unchanged()
    candidate_raw = {rel: base64.b64decode(DATA['candidates'][rel], validate=True) for rel in ORDER}
    for rel in ORDER:
        check(digest(candidate_raw[rel]) == expected[rel]['candidate_sha256'] and
              len(candidate_raw[rel]) == expected[rel]['candidate_size'], 'candidate_hash_or_size')
    v4raw, _ = read_file(ROOT+'/'+V4, ROOT)
    originals = {rel: parse(raw) for rel, raw in ORIGINAL.items()}
    originals[V4] = parse(v4raw)
    candidates = {rel: parse(raw) for rel, raw in candidate_raw.items()}
    candidates[V4] = parse(v4raw)
    preservation(originals, candidates)
    reference_closure(candidates)
    os.mkdir(TX, 0o700)
    CREATED = True
    for sub in ('preimage', 'candidates', 'rollback'): os.mkdir(TX+'/'+sub, 0o700)
    emit('all_preimages_frozen_resources_and_candidates_pass', count=3)
    backup_rows=[]
    for i, rel in enumerate(ORDER):
        path = TX+'/preimage/'+str(i)+'.json'
        write_new(path, ORIGINAL[rel], STATS[rel])
        raw, st = read_file(path, TX)
        compare(raw, st, expected[rel]['original_metadata'], 'backup_verification', identity=False)
        check(st.st_mtime_ns == STATS[rel].st_mtime_ns, 'backup_mtime')
        backup_rows.append({'target': ROOT+'/'+rel, 'backup': path, 'sha256': digest(raw),
                            'original_metadata': metadata(STATS[rel]), 'backup_metadata': metadata(st)})
    write_new(TX+'/metadata.json', json.dumps(backup_rows, sort_keys=True, indent=2).encode())
    emit('all_backups_verified_before_any_replace', metadata_path=TX+'/metadata.json', count=3)
    for i, rel in enumerate(ORDER):
        path = TX+'/candidates/'+str(i)+'.json'
        write_new(path, candidate_raw[rel], STATS[rel])
        raw, st = read_file(path, TX)
        check(raw == candidate_raw[rel] and st.st_dev == STATS[rel].st_dev, 'stage_bytes_or_device')
        check(st.st_uid == 1000 and st.st_gid == 1000 and stat.S_IMODE(st.st_mode) == 0o664, 'stage_metadata')
    emit('all_candidates_staged_same_filesystem', count=3)
    unchanged()
    for i, rel in enumerate(ORDER):
        for other in ORDER:
            guard_current(other, candidate_raw[other] if other in REPLACED else ORIGINAL[other],
                          None if other in REPLACED else STATS[other])
        unchanged()
        stage = TX+'/candidates/'+str(i)+'.json'
        raw, _ = read_file(stage, TX)
        check(raw == candidate_raw[rel], 'stage_drift_before_replace')
        os.replace(stage, ROOT+'/'+rel)
        REPLACED.append(rel)
        emit('atomic_replace', order=i+1, path=ROOT+'/'+rel, sha256=digest(raw))
        syncdir(os.path.dirname(ROOT+'/'+rel))
        installed_raw, installed_stat = read_file(ROOT+'/'+rel, ROOT)
        check(installed_raw == candidate_raw[rel], 'immediate_postimage_bytes')
        check(installed_stat.st_uid == 1000 and installed_stat.st_gid == 1000 and
              stat.S_IMODE(installed_stat.st_mode) == 0o664, 'immediate_postimage_metadata')
    installed, rows = {}, []
    for rel in ORDER:
        raw, st = read_file(ROOT+'/'+rel, ROOT)
        check(raw == candidate_raw[rel], 'final_postimage_bytes')
        check(st.st_uid == 1000 and st.st_gid == 1000 and stat.S_IMODE(st.st_mode) == 0o664,
              'final_postimage_metadata')
        installed[rel] = parse(raw)
        rows.append({'path': ROOT+'/'+rel, 'sha256': digest(raw), **metadata(st)})
    installed[V4] = parse(read_file(ROOT+'/'+V4, ROOT)[0])
    checks = preservation(originals, installed)
    refs = reference_closure(installed)
    frozen = unchanged()
    emit('static_install_validation_pass', installed_count=3, equality_assertion_count=len(checks), reference_count=len(refs))
    RESULT.update(status='PASS', installed=rows, backups=backup_rows,
                  equality_assertions=checks, references=refs, unchanged=frozen,
                  wire_bytes=byte_evidence(installed[PROTO]),
                  endpoint_env_model_prompt_generation_cap='EQUAL_WITHOUT_ENV_EVALUATION',
                  metadata_path=TX+'/metadata.json', journal_path=TX+'/journal.jsonl',
                  root_policies='UNCHANGED_HASH_AND_VALUE_PROOF', loader='STATIC_ONLY_MATCHING_BINARY_REQUIRED')
except BaseException as exc:
    reason = str(exc) if isinstance(exc, Invalid) else type(exc).__name__
    RESULT.update(first_actionable_error=reason, error_type=type(exc).__name__)
    emit('transaction_failure', category=reason, replaced_count=len(REPLACED))
    for rel in reversed(REPLACED):
        try:
            guard_current(rel, candidate_raw[rel])
            index = ORDER.index(rel)
            raw, _ = read_file(TX+'/preimage/'+str(index)+'.json', TX)
            check(raw == ORIGINAL[rel], 'rollback_backup_drift')
            path = TX+'/rollback/'+str(index)+'.json'
            write_new(path, raw, STATS[rel])
            guard_current(rel, candidate_raw[rel])
            os.replace(path, ROOT+'/'+rel)
            syncdir(os.path.dirname(ROOT+'/'+rel))
            restored, st = read_file(ROOT+'/'+rel, ROOT)
            compare(restored, st, expected[rel]['original_metadata'], 'rollback_verify', identity=False)
            RESULT['rollback'].append({'path': ROOT+'/'+rel, 'status': 'RESTORED', 'sha256': digest(restored)})
            emit('rollback_restored', path=ROOT+'/'+rel, sha256=digest(restored))
        except BaseException as rollback_exc:
            category = str(rollback_exc) if isinstance(rollback_exc, Invalid) else type(rollback_exc).__name__
            RESULT['rollback'].append({'path': ROOT+'/'+rel, 'status': 'NOT_OVERWRITTEN_UNCERTAIN', 'category': category})
            emit('rollback_stopped_uncertain_file', path=ROOT+'/'+rel, category=category)
            break
finally:
    RESULT['replaced'] = [ROOT+'/'+rel for rel in REPLACED]
    RESULT['events'] = EVENTS
    if CREATED:
        write_new(TX+'/install-result.json', json.dumps(RESULT, sort_keys=True, indent=2).encode())
    print(json.dumps(RESULT, sort_keys=True))
    sys.exit(0 if RESULT['status'] == 'PASS' else 1)
