EXPECTED_PIN='1b0a2660b2b042c4fb2524dbba34e95951ae77c758f180698f155c8f69291a01'
CENTOS_CODE="import os,json,stat,re,urllib.parse\nROOT='/home/shared/models/car_v3.0'\nif os.path.realpath(ROOT)!=ROOT: raise RuntimeError('Resource root drift')\ndef contained(p):\n if not os.path.realpath(p).startswith(ROOT+'/'):raise RuntimeError('Resource child path escape')\n return p\nroot_json=[]\nfor n in sorted(os.listdir(ROOT)):\n if not n.endswith('.json'):continue\n p=contained(ROOT+'/'+n);s=os.stat(p)\n if len(root_json)>=100:raise RuntimeError('Bounded JSON filename inventory exceeded')\n root_json.append({'path':n,'size':s.st_size,'symlink':os.path.islink(p),'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid})\n# Config referrer content reads stay within conf/*.json, already authorized.\nconsumers=[];conf_json=[]\nfor n in sorted(os.listdir(ROOT+'/conf')):\n if not n.endswith('.json'):continue\n p=contained(ROOT+'/conf/'+n);s=os.stat(p)\n conf_json.append({'path':'conf/'+n,'size':s.st_size})\n if not stat.S_ISREG(s.st_mode) or s.st_size>2097152:continue\n obj=json.loads(open(p,'rb').read(2097153).decode('utf-8-sig'))\n def walk(v,jp='$'):\n  if isinstance(v,dict):\n   for k,x in v.items():\n    if re.search(r'profile|catalog|protocol|NluConfig|LanguageUnderstanding|ContextManager|^Nlu06B$',k,re.I):\n     if isinstance(x,str) and re.search(r'endpoint|prompt|model',k,re.I):continue\n     consumers.append({'path':'conf/'+n,'json_path':jp+'.'+k,'value':x})\n    if isinstance(x,(dict,list)):walk(x,jp+'.'+k)\n  elif isinstance(v,list):\n   for i,x in enumerate(v):walk(x,jp+'['+str(i)+']')\n walk(obj)\nselected=json.load(open(ROOT+'/conf/nlu_config_06b_http_offline.json'))\ncat=json.load(open(ROOT+'/conf/models/nlu/profiles.json'))\nprof=cat['profiles'][selected['OpenAIHttp']['profile']]\ncommon=set(prof)&set(selected['OpenAIHttp'])\nequality={k:prof[k]==selected['OpenAIHttp'][k] for k in sorted(common)}\nprint(json.dumps({'root_json_filename_inventory_only':root_json,'conf_json_filename_inventory':conf_json,'profile_and_config_consumers':consumers,'selected_profile_vs_nluconfig_equality':equality,'selected_profile_transport_keys':[k for k in prof if k in ('endpoint','api_key_env','connect_timeout_ms','total_timeout_ms','max_response_bytes')],'selected_nlu_transport_keys':[k for k in selected['OpenAIHttp'] if k in ('endpoint','api_key_env','connect_timeout_ms','total_timeout_ms','max_response_bytes')],'hotfix_policy':selected.get('HotFix'),'summary':{'root_json_filenames':len(root_json),'root_json_content_read':False,'conf_profile_consumers':len(consumers),'selected_overrides_differ':any(not v for v in equality.values()),'target_content_mutation':'NONE'}},ensure_ascii=False))\n"
import hashlib,json,os,shlex,subprocess
TARGET='daigd@10.1.122.21'
SSH_SETTINGS=['BatchMode=yes','StrictHostKeyChecking=yes','IdentitiesOnly=yes','PreferredAuthentications=publickey','PasswordAuthentication=no','KbdInteractiveAuthentication=no','IdentityAgent=none','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=8','ConnectionAttempts=1','ServerAliveInterval=15','ServerAliveCountMax=2']
SSH_OPTIONS=['-p','22']+[v for s in SSH_SETTINGS for v in ('-o',s)]
r=subprocess.run(['ssh','-G','-p','22',TARGET],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12,check=True)
keys={'hostname','user','port','identityfile','userknownhostsfile','globalknownhostsfile','proxyjump','proxycommand','hostkeyalias'}
config={}
for line in r.stdout.decode().splitlines():
    k,_,v=line.partition(' ')
    if k in keys: config.setdefault(k,[]).append(v)
for k,v in {'hostname':'10.1.122.21','user':'daigd','port':'22'}.items():
    if config.get(k)!=[v]: raise RuntimeError('Controller destination mismatch: '+k)
for k in ('proxyjump','proxycommand'):
    if config.get(k,['none'])!=['none']: raise RuntimeError('Controller proxy requires explicit validation; stop')
identities=[os.path.expanduser(p) for p in config.get('identityfile',[])]
if not any(os.path.isfile(p) and os.access(p,os.R_OK) for p in identities): raise RuntimeError('No existing configured controller identity; stop')
host=config.get('hostkeyalias',config['hostname'])[0]
trusted=False
for group in config.get('userknownhostsfile',[])+config.get('globalknownhostsfile',[]):
    for p in shlex.split(group):
        p=os.path.expanduser(p)
        if not os.path.isfile(p): continue
        r=subprocess.run(['ssh-keygen','-F',host,'-f',p],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        if r.returncode==0 and r.stdout: trusted=True
if not trusted: raise RuntimeError('Controller existing trusted host key missing; stop')
contract_pin=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()
if EXPECTED_PIN is not None and EXPECTED_PIN!=contract_pin: raise RuntimeError('Controller contract drift; stop')
command='timeout --signal=TERM --kill-after=5s 65s python3 -I -'
r=subprocess.run(['ssh']+SSH_OPTIONS+[TARGET,command],input=CENTOS_CODE.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=85)
if r.returncode:
    raise RuntimeError('CentOS capture SSH exit=%d: %s'%(r.returncode,r.stderr.decode(errors='replace')[-1500:]))
data=json.loads(r.stdout)
print(json.dumps({'controller_contract_pin':contract_pin,'centos_exit':r.returncode,'data':data,'summary':data.get('summary',{})},ensure_ascii=False))
