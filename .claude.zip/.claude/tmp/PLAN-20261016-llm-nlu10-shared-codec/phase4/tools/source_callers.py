import os,json,re
ROOT='/home/daigd/dialogue'
spans={'cu/server.cc':[(1,130)],'cu/nlu_0_6b_manager.cc':[(238,310)],'cu/dialogue_system.cc':[(178,214)],'cu/dialogue_v3.cc':[(770,790),(938,980)]}
out={}
for rel,ranges in spans.items():
 p=ROOT+'/'+rel
 if not os.path.realpath(p).startswith(ROOT+'/'):raise RuntimeError('Source path escape')
 lines=open(p).read().splitlines();out[rel]=[{'line':i+1,'text':x} for i,x in enumerate(lines) if any(a<=i+1<=b for a,b in ranges)]
# Only exact immediate callers with configuration entrypoint symbols, bounded source files.
callers={}
for name in os.listdir(ROOT+'/cu'):
 if name not in ('main.cc','server.h','handlers.cc','handlers.h','application.cc','application.h'):continue
 p=ROOT+'/cu/'+name
 if not os.path.realpath(p).startswith(ROOT+'/'):raise RuntimeError('Caller path escape')
 if os.stat(p).st_size>2097152:raise RuntimeError('Caller too large')
 lines=open(p).read().splitlines();hits=[i for i,x in enumerate(lines) if re.search(r'Initialize\(|config_file|DEFINE_string|FLAGS_.*config|dialogue.*json|config.*\.json',x)]
 keep=set()
 for i in hits:keep.update(range(max(0,i-4),min(len(lines),i+8)))
 if keep:callers['cu/'+name]=[{'line':i+1,'text':lines[i]} for i in sorted(keep)]
print(json.dumps({'source_spans':out,'immediate_callers':callers,'summary':{'read':'exact initialization and immediate caller excerpts','target_mutation':'NONE'}}))
