import json,re,os,subprocess
p='/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh'
assert os.path.realpath(p)==p
s=open(p).read(); lines=s.splitlines()
need=[]
for i,line in enumerate(lines,1):
    if re.search(r'^(TARGET_(USER|HOST|PORT|SSH)|SSH_(IDENTITY|CONNECT_TIMEOUT)|REMOTE_(MODEL_DIR|AUTO_BUILD|PACKAGE_ROOT))=|^ssh_(base|batch)_args\(\)|(^|\s)(source|\.)\s|BASH_ENV|^.*\.env',line):
        need.append((i,line))
for func in ('ssh_base_args','ssh_batch_args'):
    m=re.search(r'^'+func+r'\(\) \{.*?^\}',s,re.M|re.S)
    if m: need.append(('function',m.group()))
print(json.dumps({'installed_controller':p,'contract_lines':need,'summary':{'controller_read':'scoped defaults/SSH functions only','executed_or_sourced':False}}))
