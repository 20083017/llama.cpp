EXPECTED_PIN=None
CENTOS_CODE="import os,json,stat,hashlib,re,pwd,grp,time\nROOT='/home/shared/models/car_v3.0'\nreal=os.path.realpath(ROOT)\nif not os.path.isdir(real): raise RuntimeError('Resource root unavailable')\ndef check(rel):\n    p=os.path.join(real,rel); rp=os.path.realpath(p)\n    if not rp.startswith(real+'/'): raise RuntimeError('Child resolved-path escape: '+rel)\n    return p\ndef meta(rel):\n    p=check(rel); s=os.stat(p)\n    return {'path':rel,'resolved_path':os.path.realpath(p),'symlink':os.path.islink(p),'size':s.st_size,'uid':s.st_uid,'gid':s.st_gid,'owner':pwd.getpwuid(s.st_uid).pw_name,'group':grp.getgrgid(s.st_gid).gr_name,'mode':oct(stat.S_IMODE(s.st_mode)),'dev':s.st_dev,'inode':s.st_ino,'mtime_ns':int(s.st_mtime*1000000000),'writable':os.access(p,os.W_OK),'parent_writable_searchable':os.access(os.path.dirname(p),os.W_OK|os.X_OK)}\nfiles=[]\nbase=check('conf/models/nlu')\nfor directory,dirs,names in os.walk(base,followlinks=False):\n    for d in dirs: check(os.path.relpath(os.path.join(directory,d),real))\n    for n in names:\n        if not n.endswith('.json'): continue\n        rel=os.path.relpath(os.path.join(directory,n),real)\n        if len(files)>=128: raise RuntimeError('JSON inventory exceeds 128; selected-only scope needed')\n        files.append(meta(rel))\nselection='conf/nlu_config_06b_http_offline.json'\nselected_meta=meta(selection)\np=check(selection)\nif selected_meta['size']>2097152 or not stat.S_ISREG(os.stat(p).st_mode): raise RuntimeError('Selected NluConfig not bounded regular file')\nraw=open(p,'rb').read(2097153); selected=json.loads(raw.decode('utf-8-sig'))\ndef shape(v):\n    if isinstance(v,dict): return {k:shape(x) for k,x in v.items()}\n    if isinstance(v,list): return {'type':'array','count':len(v),'items':list(dict.fromkeys(type(x).__name__ for x in v))}\n    if isinstance(v,str):\n        if re.search(r'^(conf/|models/).*\\.json$',v) or v in ('openai_http','offline','nlu_10'): return v\n        return {'type':'string','length':len(v)}\n    return v\nreferrers=[]\nconf=check('conf')\nfor n in sorted(os.listdir(conf)):\n    if not n.endswith('.json'): continue\n    rel='conf/'+n; p=check(rel); s=os.stat(p)\n    if not stat.S_ISREG(s.st_mode) or s.st_size>2097152: continue\n    try: obj=json.loads(open(p,'rb').read(2097153).decode('utf-8-sig'))\n    except (ValueError,UnicodeError): continue\n    if isinstance(obj,dict):\n        lu=obj.get('LanguageUnderstanding')\n        if isinstance(lu,dict) and 'NluConfig' in lu:\n            referrers.append({'path':rel,'LanguageUnderstanding.NluConfig':lu['NluConfig'],'meta':meta(rel)})\nhelper='/home/daigd/packages/auto_build_offline_v3.sh'\nif os.path.realpath(helper)!=helper: raise RuntimeError('Helper path ambiguity')\nhelperlines=open(helper).read().splitlines()\nexcerpts=[{'line':i,'text':x} for i,x in enumerate(helperlines,1) if re.search(r'cp -rf.*model|^root=|^release_folder=|/data|/models|run_server|run.sh|--model',x)]\nprint(json.dumps({'requested_root':ROOT,'resolved_root':real,'root_meta':meta('conf'),'nlu_json_inventory':sorted(files,key=lambda x:x['path']),'selected_nlu_config':selected_meta,'nlu_config_shape':shape(selected),'dialogue_referrers':referrers,'helper_path':helper,'helper_path_excerpts':excerpts,'summary':{'root_proven':real,'family_json_count':len(files),'referrer_count':len(referrers),'target_content_mutation':'NONE'}},ensure_ascii=False))\n"
import hashlib,json,os,shlex,subprocess
TARGET='daigd@10.1.122.21'
SSH_SETTINGS=['BatchMode=yes','StrictHostKeyChecking=yes','IdentitiesOnly=yes','PreferredAuthentications=publickey','PasswordAuthentication=no','KbdInteractiveAuthentication=no','IdentityAgent=none','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=8','ConnectionAttempts=1','ServerAliveInterval=15','ServerAliveCountMax=2']
SSH_OPTIONS=['-p','22']+[v for s in SSH_SETTINGS for v in ('-o',s)]
r=subprocess.run(['ssh','-G','-p','22',TARGET],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12,check=True)
keys={'hostname','user','port','identityfile','userknownhostsfile','globalknownhostsfile','proxyjump','proxycommand','hostkeyalias'}
config={}
for line in r.stdout.decode().splitlines():
    k,_,v=line.partition(' ')
    if k in keys: config.setdefault(k,[]).append(v)
for k,v in {'hostname':'10.1.122.21','user':'daigd','port':'22'}.items():
    if config.get(k)!=[v]: raise RuntimeError('Controller destination mismatch: '+k)
for k in ('proxyjump','proxycommand'):
    if config.get(k,['none'])!=['none']: raise RuntimeError('Controller proxy requires explicit validation; stop')
identities=[os.path.expanduser(p) for p in config.get('identityfile',[])]
if not any(os.path.isfile(p) and os.access(p,os.R_OK) for p in identities): raise RuntimeError('No existing configured controller identity; stop')
host=config.get('hostkeyalias',config['hostname'])[0]
trusted=False
for group in config.get('userknownhostsfile',[])+config.get('globalknownhostsfile',[]):
    for p in shlex.split(group):
        p=os.path.expanduser(p)
        if not os.path.isfile(p): continue
        r=subprocess.run(['ssh-keygen','-F',host,'-f',p],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        if r.returncode==0 and r.stdout: trusted=True
if not trusted: raise RuntimeError('Controller existing trusted host key missing; stop')
contract_pin=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()
if EXPECTED_PIN is not None and EXPECTED_PIN!=contract_pin: raise RuntimeError('Controller contract drift; stop')
command='timeout --signal=TERM --kill-after=5s 65s python3 -I -c '+shlex.quote(CENTOS_CODE)
r=subprocess.run(['ssh']+SSH_OPTIONS+[TARGET,command],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=85)
if r.returncode:
    raise RuntimeError('CentOS capture SSH exit=%d: %s'%(r.returncode,r.stderr.decode(errors='replace')[-1500:]))
data=json.loads(r.stdout)
print(json.dumps({'controller_contract_pin':contract_pin,'centos_exit':r.returncode,'data':data,'summary':data.get('summary',{})},ensure_ascii=False))
