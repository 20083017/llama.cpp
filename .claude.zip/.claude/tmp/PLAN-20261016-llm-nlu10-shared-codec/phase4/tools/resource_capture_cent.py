import os,json,stat,hashlib,re,pwd,grp,time,urllib.parse
ROOT='/home/shared/models/car_v3.0'
real=os.path.realpath(ROOT)
if real!=ROOT: raise RuntimeError('Root changed since inventory')
STAMP=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())
TX='/home/daigd/packages/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-'+STAMP
os.umask(0o077)
def mkdir_private(p):
    if os.path.lexists(p):
        if os.path.islink(p) or not os.path.isdir(p): raise RuntimeError('Artifact directory ambiguity')
    else: os.mkdir(p,0o700)
mkdir_private('/home/daigd/packages/.wtp184-transactions')
os.mkdir(TX,0o700); os.mkdir(TX+'/preimage',0o700)
def check(rel):
    p=os.path.join(real,rel); rp=os.path.realpath(p)
    if not rp.startswith(real+'/'): raise RuntimeError('Child resolved-path escape: '+rel)
    return p
redacted=[]
def redact(v,path):
    if isinstance(v,dict):
        result={}
        for k,x in v.items():
            kp=path+'/'+k
            if re.search(r'^(api[_-]?key|access[_-]?token|auth[_-]?token|password|passwd|secret|client_secret|authorization|token)$',k,re.I) and x:
                redacted.append(kp); result[k]='[REDACTED_INLINE_CREDENTIAL]'
            else: result[k]=redact(x,kp)
        return result
    if isinstance(v,list): return [redact(x,path+'/'+str(i)) for i,x in enumerate(v)]
    if isinstance(v,str) and re.match(r'^https?://',v):
        u=urllib.parse.urlsplit(v); net=u.netloc; query=u.query
        if '@' in net: net='[REDACTED_USERINFO]@'+net.rsplit('@',1)[1]; redacted.append(path+'#userinfo')
        if query:
            pairs=urllib.parse.parse_qsl(query,keep_blank_values=True); changed=False; clean=[]
            for k,x in pairs:
                if re.search(r'key|token|secret|password|auth|signature',k,re.I): clean.append((k,'[REDACTED]')); changed=True
                else: clean.append((k,x))
            if changed: query=urllib.parse.urlencode(clean); redacted.append(path+'#query')
        return urllib.parse.urlunsplit((u.scheme,net,u.path,query,u.fragment))
    return v
packet={}; manifest=[]
paths=['conf/nlu_config_06b_http_offline.json','conf/models/nlu/profiles.json','conf/models/nlu/protocols/v3.json','conf/models/nlu/protocols/v4.json']
for rel in paths:
    p=check(rel); s=os.stat(p)
    if not stat.S_ISREG(s.st_mode) or os.path.islink(p) or s.st_size>2097152: raise RuntimeError('Not bounded non-symlink regular JSON: '+rel)
    raw=open(p,'rb').read(2097153); obj=json.loads(raw.decode('utf-8-sig'))
    after=os.stat(p)
    if (s.st_dev,s.st_ino,s.st_size,s.st_mtime)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime): raise RuntimeError('Capture drift: '+rel)
    dest=TX+'/preimage/'+rel
    os.makedirs(os.path.dirname(dest),mode=0o700,exist_ok=True)
    with os.fdopen(os.open(dest,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as f: f.write(raw)
    m={'path':rel,'exact_preimage':dest,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'uid':s.st_uid,'gid':s.st_gid,'owner':pwd.getpwuid(s.st_uid).pw_name,'group':grp.getgrgid(s.st_gid).gr_name,'mode':oct(stat.S_IMODE(s.st_mode)),'dev':s.st_dev,'inode':s.st_ino,'mtime_ns':getattr(s,'st_mtime_ns',int(s.st_mtime*1e9)),'atime_ns':getattr(s,'st_atime_ns',int(s.st_atime*1e9)),'writable':os.access(p,os.W_OK),'parent_writable_searchable':os.access(os.path.dirname(p),os.W_OK|os.X_OK)}
    manifest.append(m); packet[rel]=redact(obj,rel)
# Recursively locate only relevant selector/base/history/config facts in bounded conf referrers.
def selector_paths(v,path='$'):
    result=[]
    if isinstance(v,dict):
        for k,x in v.items():
            xp=path+'.'+k
            if k in ('LanguageUnderstanding','NluConfig','ContextManager','Context','QueryHistory','History','QueryHistoryStore'):
                result.append({'json_path':xp,'value':redact(x,xp)})
            if isinstance(x,(dict,list)): result.extend(selector_paths(x,xp))
    elif isinstance(v,list):
        for i,x in enumerate(v): result.extend(selector_paths(x,path+'['+str(i)+']'))
    return result
referrers=[]; consumers=[]; conf_files=0; errors=[]
refs=('conf/models/nlu/profiles.json','conf/models/nlu/protocols/v3.json','conf/models/nlu/protocols/v4.json','conf/nlu_config_06b_http_offline.json')
for n in sorted(os.listdir(check('conf'))):
    if not n.endswith('.json'): continue
    conf_files+=1
    if conf_files>128: raise RuntimeError('Conf referrer count exceeds bounded 128')
    rel='conf/'+n; p=check(rel); s=os.stat(p)
    if not stat.S_ISREG(s.st_mode) or s.st_size>2097152: errors.append({'path':rel,'reason':'not bounded regular JSON'}); continue
    try: raw=open(p,'rb').read(2097153); obj=json.loads(raw.decode('utf-8-sig'))
    except (ValueError,UnicodeError): errors.append({'path':rel,'reason':'parse failed'}); continue
    sel=selector_paths(obj)
    if sel: referrers.append({'path':rel,'selectors':sel})
    def walk(v,jp='$'):
        if isinstance(v,dict):
            for k,x in v.items(): walk(x,jp+'.'+k)
        elif isinstance(v,list):
            for i,x in enumerate(v): walk(x,jp+'['+str(i)+']')
        elif isinstance(v,str):
            if v in refs or any(v.endswith('/'+x) for x in refs): consumers.append({'path':rel,'json_path':jp,'reference':v})
    walk(obj)
# Only configured JSON/HotFix reference presence is inspected, not model weights or their tree.
references=[]
def refs_walk(v,jp):
    if isinstance(v,dict):
        for k,x in v.items(): refs_walk(x,jp+'/'+k)
    elif isinstance(v,list):
        for i,x in enumerate(v): refs_walk(x,jp+'/'+str(i))
    elif isinstance(v,str) and (v.startswith('conf/') or '/HotFix/' in jp or v.endswith('.json')):
        if '://' in v: return
        candidate=os.path.join(real,v)
        rp=os.path.realpath(candidate)
        if not rp.startswith(real+'/'): raise RuntimeError('Configured reference escapes root: '+jp)
        references.append({'json_path':jp,'reference':v,'resolved_under_resource_root':rp,'exists':os.path.exists(candidate),'isfile':os.path.isfile(candidate)})
for rel,obj in packet.items(): refs_walk(obj,rel)
with open(TX+'/metadata.json','x') as f: json.dump({'resource_root':real,'captured_utc':STAMP,'files':manifest,'redacted_local_paths':redacted},f,indent=2)
print(json.dumps({'resource_root':real,'transaction':TX,'files':manifest,'redacted_json':packet,'redacted_paths':redacted,'conf_referrers':referrers,'shared_consumers':consumers,'reference_presence':references,'bounded_conf_files_examined':conf_files,'referrer_gaps':errors,'summary':{'preimage_count':len(manifest),'redacted_path_count':len(redacted),'referrer_count':len(referrers),'shared_consumer_count':len(consumers),'missing_reference_count':sum(not x['exists'] for x in references),'target_content_mutation':'NONE'}},ensure_ascii=False))
