import os,json,stat,hashlib,re,pwd,grp,time
ROOT='/home/shared/models/car_v3.0'
real=os.path.realpath(ROOT)
if not os.path.isdir(real): raise RuntimeError('Resource root unavailable')
def check(rel):
    p=os.path.join(real,rel); rp=os.path.realpath(p)
    if not rp.startswith(real+'/'): raise RuntimeError('Child resolved-path escape: '+rel)
    return p
def meta(rel):
    p=check(rel); s=os.stat(p)
    return {'path':rel,'resolved_path':os.path.realpath(p),'symlink':os.path.islink(p),'size':s.st_size,'uid':s.st_uid,'gid':s.st_gid,'owner':pwd.getpwuid(s.st_uid).pw_name,'group':grp.getgrgid(s.st_gid).gr_name,'mode':oct(stat.S_IMODE(s.st_mode)),'dev':s.st_dev,'inode':s.st_ino,'mtime_ns':int(s.st_mtime*1000000000),'writable':os.access(p,os.W_OK),'parent_writable_searchable':os.access(os.path.dirname(p),os.W_OK|os.X_OK)}
files=[]
base=check('conf/models/nlu')
for directory,dirs,names in os.walk(base,followlinks=False):
    for d in dirs: check(os.path.relpath(os.path.join(directory,d),real))
    for n in names:
        if not n.endswith('.json'): continue
        rel=os.path.relpath(os.path.join(directory,n),real)
        if len(files)>=128: raise RuntimeError('JSON inventory exceeds 128; selected-only scope needed')
        files.append(meta(rel))
selection='conf/nlu_config_06b_http_offline.json'
selected_meta=meta(selection)
p=check(selection)
if selected_meta['size']>2097152 or not stat.S_ISREG(os.stat(p).st_mode): raise RuntimeError('Selected NluConfig not bounded regular file')
raw=open(p,'rb').read(2097153); selected=json.loads(raw.decode('utf-8-sig'))
def shape(v):
    if isinstance(v,dict): return {k:shape(x) for k,x in v.items()}
    if isinstance(v,list): return {'type':'array','count':len(v),'items':list(dict.fromkeys(type(x).__name__ for x in v))}
    if isinstance(v,str):
        if re.search(r'^(conf/|models/).*\.json$',v) or v in ('openai_http','offline','nlu_10'): return v
        return {'type':'string','length':len(v)}
    return v
referrers=[]
conf=check('conf')
for n in sorted(os.listdir(conf)):
    if not n.endswith('.json'): continue
    rel='conf/'+n; p=check(rel); s=os.stat(p)
    if not stat.S_ISREG(s.st_mode) or s.st_size>2097152: continue
    try: obj=json.loads(open(p,'rb').read(2097153).decode('utf-8-sig'))
    except (ValueError,UnicodeError): continue
    if isinstance(obj,dict):
        lu=obj.get('LanguageUnderstanding')
        if isinstance(lu,dict) and 'NluConfig' in lu:
            referrers.append({'path':rel,'LanguageUnderstanding.NluConfig':lu['NluConfig'],'meta':meta(rel)})
helper='/home/daigd/packages/auto_build_offline_v3.sh'
if os.path.realpath(helper)!=helper: raise RuntimeError('Helper path ambiguity')
helperlines=open(helper).read().splitlines()
excerpts=[{'line':i,'text':x} for i,x in enumerate(helperlines,1) if re.search(r'cp -rf.*model|^root=|^release_folder=|/data|/models|run_server|run.sh|--model',x)]
print(json.dumps({'requested_root':ROOT,'resolved_root':real,'root_meta':meta('conf'),'nlu_json_inventory':sorted(files,key=lambda x:x['path']),'selected_nlu_config':selected_meta,'nlu_config_shape':shape(selected),'dialogue_referrers':referrers,'helper_path':helper,'helper_path_excerpts':excerpts,'summary':{'root_proven':real,'family_json_count':len(files),'referrer_count':len(referrers),'target_content_mutation':'NONE'}},ensure_ascii=False))
