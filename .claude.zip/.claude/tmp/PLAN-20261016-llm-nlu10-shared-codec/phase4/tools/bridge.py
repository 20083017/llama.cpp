import hashlib,json,os,shlex,subprocess
TARGET='daigd@10.1.122.21'
SSH_SETTINGS=['BatchMode=yes','StrictHostKeyChecking=yes','IdentitiesOnly=yes','PreferredAuthentications=publickey','PasswordAuthentication=no','KbdInteractiveAuthentication=no','IdentityAgent=none','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=8','ConnectionAttempts=1','ServerAliveInterval=15','ServerAliveCountMax=2']
SSH_OPTIONS=['-p','22']+[v for s in SSH_SETTINGS for v in ('-o',s)]
r=subprocess.run(['ssh','-G','-p','22',TARGET],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12,check=True)
keys={'hostname','user','port','identityfile','userknownhostsfile','globalknownhostsfile','proxyjump','proxycommand','hostkeyalias'}
config={}
for line in r.stdout.decode().splitlines():
    k,_,v=line.partition(' ')
    if k in keys: config.setdefault(k,[]).append(v)
for k,v in {'hostname':'10.1.122.21','user':'daigd','port':'22'}.items():
    if config.get(k)!=[v]: raise RuntimeError('Controller destination mismatch: '+k)
for k in ('proxyjump','proxycommand'):
    if config.get(k,['none'])!=['none']: raise RuntimeError('Controller proxy requires explicit validation; stop')
identities=[os.path.expanduser(p) for p in config.get('identityfile',[])]
if not any(os.path.isfile(p) and os.access(p,os.R_OK) for p in identities): raise RuntimeError('No existing configured controller identity; stop')
host=config.get('hostkeyalias',config['hostname'])[0]
trusted=False
for group in config.get('userknownhostsfile',[])+config.get('globalknownhostsfile',[]):
    for p in shlex.split(group):
        p=os.path.expanduser(p)
        if not os.path.isfile(p): continue
        r=subprocess.run(['ssh-keygen','-F',host,'-f',p],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        if r.returncode==0 and r.stdout: trusted=True
if not trusted: raise RuntimeError('Controller existing trusted host key missing; stop')
contract_pin=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()
if EXPECTED_PIN is not None and EXPECTED_PIN!=contract_pin: raise RuntimeError('Controller contract drift; stop')
command='timeout --signal=TERM --kill-after=5s 65s python3 -I -'
r=subprocess.run(['ssh']+SSH_OPTIONS+[TARGET,command],input=CENTOS_CODE.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=85)
if r.returncode:
    raise RuntimeError('CentOS capture SSH exit=%d: %s'%(r.returncode,r.stderr.decode(errors='replace')[-1500:]))
data=json.loads(r.stdout)
print(json.dumps({'controller_contract_pin':contract_pin,'centos_exit':r.returncode,'data':data,'summary':data.get('summary',{})},ensure_ascii=False))
