import os,json,stat,re,urllib.parse
ROOT='/home/shared/models/car_v3.0'
if os.path.realpath(ROOT)!=ROOT: raise RuntimeError('Resource root drift')
def contained(p):
 if not os.path.realpath(p).startswith(ROOT+'/'):raise RuntimeError('Resource child path escape')
 return p
root_json=[]
for n in sorted(os.listdir(ROOT)):
 if not n.endswith('.json'):continue
 p=contained(ROOT+'/'+n);s=os.stat(p)
 if len(root_json)>=100:raise RuntimeError('Bounded JSON filename inventory exceeded')
 root_json.append({'path':n,'size':s.st_size,'symlink':os.path.islink(p),'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid})
# Config referrer content reads stay within conf/*.json, already authorized.
consumers=[];conf_json=[]
for n in sorted(os.listdir(ROOT+'/conf')):
 if not n.endswith('.json'):continue
 p=contained(ROOT+'/conf/'+n);s=os.stat(p)
 conf_json.append({'path':'conf/'+n,'size':s.st_size})
 if not stat.S_ISREG(s.st_mode) or s.st_size>2097152:continue
 obj=json.loads(open(p,'rb').read(2097153).decode('utf-8-sig'))
 def walk(v,jp='$'):
  if isinstance(v,dict):
   for k,x in v.items():
    if re.search(r'profile|catalog|protocol|NluConfig|LanguageUnderstanding|ContextManager|^Nlu06B$',k,re.I):
     if isinstance(x,str) and re.search(r'endpoint|prompt|model',k,re.I):continue
     consumers.append({'path':'conf/'+n,'json_path':jp+'.'+k,'value':x})
    if isinstance(x,(dict,list)):walk(x,jp+'.'+k)
  elif isinstance(v,list):
   for i,x in enumerate(v):walk(x,jp+'['+str(i)+']')
 walk(obj)
selected=json.load(open(ROOT+'/conf/nlu_config_06b_http_offline.json'))
cat=json.load(open(ROOT+'/conf/models/nlu/profiles.json'))
prof=cat['profiles'][selected['OpenAIHttp']['profile']]
common=set(prof)&set(selected['OpenAIHttp'])
equality={k:prof[k]==selected['OpenAIHttp'][k] for k in sorted(common)}
print(json.dumps({'root_json_filename_inventory_only':root_json,'conf_json_filename_inventory':conf_json,'profile_and_config_consumers':consumers,'selected_profile_vs_nluconfig_equality':equality,'selected_profile_transport_keys':[k for k in prof if k in ('endpoint','api_key_env','connect_timeout_ms','total_timeout_ms','max_response_bytes')],'selected_nlu_transport_keys':[k for k in selected['OpenAIHttp'] if k in ('endpoint','api_key_env','connect_timeout_ms','total_timeout_ms','max_response_bytes')],'hotfix_policy':selected.get('HotFix'),'summary':{'root_json_filenames':len(root_json),'root_json_content_read':False,'conf_profile_consumers':len(consumers),'selected_overrides_differ':any(not v for v in equality.values()),'target_content_mutation':'NONE'}},ensure_ascii=False))
