import os,json,re,subprocess,time,stat,hashlib
ROOT='/home/daigd/dialogue'
paths=['cu/llm_protocol.cc','cu/llm_protocol.h','cu/nlu_10_protocol.cc','cu/nlu_10_protocol.h','cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend.h','cu/nlu_0_6b_manager.cc','cu/dialogue_v3.cc','cu/dialogue.cc','cu/dialogue_system.cc','cu/server.cc']
env=os.environ.copy(); env['GIT_OPTIONAL_LOCKS']='0'; env['GIT_PAGER']='cat'
def git(args): return subprocess.run(['git','-c','core.fsmonitor=false','-c','core.pager=cat','-C',ROOT]+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12,check=True).stdout.decode()
identity={'head':git(['rev-parse','HEAD']).strip(),'branch':git(['rev-parse','--abbrev-ref','HEAD']).strip(),'scoped_status':git(['status','--porcelain','--untracked-files=all','--']+paths)}
os.umask(0o077)
parent='/home/daigd/.wtp184-transactions'
if os.path.lexists(parent):
    if os.path.islink(parent) or not os.path.isdir(parent): raise RuntimeError('Artifact path ambiguity')
else: os.mkdir(parent,0o700)
TX=parent+'/PLAN-20261016-llm-nlu10-shared-codec-v2-phase4a-'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())
os.mkdir(TX,0o700);os.mkdir(TX+'/source',0o700)
source={}; symbols={}; files=[]
for rel in paths:
    p=ROOT+'/'+rel
    if not os.path.exists(p): source[rel]={'absent':True}; continue
    if not os.path.realpath(p).startswith(ROOT+'/'): raise RuntimeError('Source resolved-path escape')
    st=os.stat(p)
    if not stat.S_ISREG(st.st_mode) or st.st_size>2097152: raise RuntimeError('Source not bounded regular')
    raw=open(p,'rb').read(2097153); text=raw.decode(); lines=text.splitlines()
    dest=TX+'/source/'+rel; os.makedirs(os.path.dirname(dest),mode=0o700,exist_ok=True)
    with open(dest,'xb') as f: f.write(raw)
    files.append({'path':rel,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'exact_capture':dest})
    if rel in paths[:6]:
        source[rel]={'line_start':1,'text':text}
    else:
        hits=[i for i,x in enumerate(lines) if re.search(r'CreateLlmProtocol|OpenAIHttp|profile_catalog|NluConfig|LanguageUnderstanding|model_path|model_dir|Nlu06BManager::Initialize|Dialogue::Initialize|DialogueV3::Initialize|model_root|Context|History',x)]
        symbols[rel]=[{'line':i+1,'text':lines[i]} for i in hits]
        included=set()
        for i in hits:
            included.update(range(max(0,i-6),min(len(lines),i+14)))
        source[rel]={'excerpts':[{'line':i+1,'text':lines[i]} for i in sorted(included)]}
with open(TX+'/metadata.json','x') as f:json.dump({'identity':identity,'files':files},f,indent=2)
print(json.dumps({'identity':identity,'transaction':TX,'files':files,'source':source,'symbols':symbols,'summary':{'head':identity['head'],'branch':identity['branch'],'scoped_dirty':bool(identity['scoped_status']),'source_files_captured':len(files),'source_edits':0,'builds':0}},ensure_ascii=False))
