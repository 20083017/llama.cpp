import hashlib,json,os,shlex,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
SSH='C:/Program Files/Git/usr/bin/ssh.exe'
KEYGEN='C:/Program Files/Git/usr/bin/ssh-keygen.exe'
CYGPATH='C:/Program Files/Git/usr/bin/cygpath.exe'
ALIAS='new2_wtp184-server'
SETTINGS=['BatchMode=yes','StrictHostKeyChecking=yes','IdentitiesOnly=yes','PreferredAuthentications=publickey','PasswordAuthentication=no','KbdInteractiveAuthentication=no','IdentityAgent=none','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=10','ConnectionAttempts=1','ServerAliveInterval=10','ServerAliveCountMax=2']
OPTIONS=[v for s in SETTINGS for v in ('-o',s)]
def run(args): return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15,check=True)
def native(p): return Path(run([CYGPATH,'-w',os.path.expanduser(p)]).stdout.decode().strip())
if any(k in os.environ for k in ('WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS')): raise RuntimeError('Unexpected explicit SSH contract; stop')
def getconf(opts):
    fields={'hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','stricthostkeychecking','proxyjump','proxycommand','hostkeyalias'}
    d={}
    for line in run([SSH,'-G']+opts+[ALIAS]).stdout.decode().splitlines():
        k,_,v=line.partition(' ')
        if k in fields: d.setdefault(k,[]).append(v)
    return d
cfg=getconf([])
for k,v in {'hostname':'10.1.120.40','user':'daigd','port':'22','identitiesonly':'yes'}.items():
    if cfg.get(k)!=[v]: raise RuntimeError('Canonical alias mismatch: '+k)
for k in ('proxycommand','proxyjump'):
    if cfg.get(k,['none'])!=['none']: raise RuntimeError('Unvalidated proxy routing; stop')
if not cfg.get('identityfile'): raise RuntimeError('No configured identity')
for p in cfg['identityfile']:
    f=native(p)
    if not f.is_file() or not os.access(f,os.R_OK): raise RuntimeError('Configured identity unavailable')
strict=getconf(OPTIONS)
if strict.get('stricthostkeychecking') not in (['yes'],['true']): raise RuntimeError('Strict trust unavailable')
trusted=False
for group in cfg.get('userknownhostsfile',[])+cfg.get('globalknownhostsfile',[]):
    for p in shlex.split(group,posix=False):
        f=native(p.strip('"'))
        if not f.is_file(): continue
        host=cfg.get('hostkeyalias',cfg['hostname'])[0]
        r=subprocess.run([KEYGEN,'-F',host,'-f',str(f)],capture_output=True,timeout=10)
        if r.returncode==0 and r.stdout: trusted=True
if not trusted: raise RuntimeError('No trusted canonical host entry')
pin=hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()
pinfile=BASE/'tools'/'contract-pin.sha256'
if pinfile.exists():
    if pinfile.read_text()!=pin: raise RuntimeError('SSH contract drift; stop')
else: pinfile.write_text(pin)
name=sys.argv[1]
if not name.replace('_','').isalnum(): raise RuntimeError('Invalid stage')
script=(BASE/'tools'/(name+'.py')).read_text(encoding='utf-8')
cmd='timeout --signal=TERM --kill-after=5s 95s python3 -I -'
r=subprocess.run([SSH]+OPTIONS+[ALIAS,cmd],input=script.encode(),capture_output=True,timeout=120)
print('action='+name+' role=Ubuntu-control exit='+str(r.returncode))
if r.returncode:
    print(r.stderr.decode(errors='replace')[-2500:]); sys.exit(r.returncode)
if len(r.stdout)>8*1024*1024: raise RuntimeError('Bounded packet limit exceeded')
result=json.loads(r.stdout)
evidence=BASE/'evidence.json'
prior=json.loads(evidence.read_text(encoding='utf-8')) if evidence.exists() else {'authorization':'PLAN-20261016-llm-nlu10-shared-codec v2 Phase4a','target_mutation':'NONE','ubuntu_transport':{'alias':ALIAS,'destination':'daigd@10.1.120.40','port':22,'publickey_only':True,'strict_trust':True,'proxy':'none','forwarding_tty_mux':False},'stages':{}}
prior['stages'][name]={'exit_status':r.returncode,'data':result}
with evidence.open('w',encoding='utf-8') as f: json.dump(prior,f,ensure_ascii=False,indent=2)
print('protected_packet='+str(evidence))
print(json.dumps(result.get('summary',{}),ensure_ascii=False))
