import datetime, hashlib, json, os, re, stat
ROOT = '/home/shared/models/car_v3.0'
NAMES = ('dialog_configure.json', 'dialog_configure_offline.json')
if os.path.realpath(ROOT) != ROOT:
    raise RuntimeError('Resource root drift')
RELEVANT = re.compile(r'nlu|languageunderstanding|context|history|histories|ttl|admission|in.?flight|capacity|queryguard', re.I)
SENSITIVE = re.compile(r'password|passwd|secret|token|api.?key|credential|auth|endpoint|url|host|address|port|routing|connection', re.I)
REF = re.compile(r'(?:nlu[^/]*\.json|profiles\.json|protocols/[^/]*\.json)$', re.I)
def digest(v):
    return hashlib.sha256(json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()
def safe(v, path):
    if SENSITIVE.search(path):
        return {'redacted': True, 'type': type(v).__name__}
    if not isinstance(v, str):
        return v
    if re.fullmatch(r'[A-Za-z0-9_./-]{1,240}', v) and not re.search(r'(?:\d{1,3}\.){3}\d{1,3}', v):
        return v
    result = {'redacted_string': True, 'length': len(v), 'sha256': hashlib.sha256(v.encode('utf-8')).hexdigest()}
    if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_:]*', v.split(' ', 1)[0]):
        result['leading_type'] = v.split(' ', 1)[0]
    return result
files, objects = [], []
for name in NAMES:
    path = ROOT + '/' + name
    if os.path.realpath(path) != path:
        raise RuntimeError('Authorized root config path escape or symlink')
    before = os.lstat(path)
    if not stat.S_ISREG(before.st_mode) or before.st_size > 2097152:
        raise RuntimeError('Authorized root config is not a bounded regular file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as f:
        opened = os.fstat(f.fileno())
        if not stat.S_ISREG(opened.st_mode) or (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise RuntimeError('Authorized root config identity drift')
        raw = f.read(2097153)
        after = os.fstat(f.fileno())
    if len(raw) > 2097152 or (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise RuntimeError('Authorized root config content drift')
    obj = json.loads(raw.decode('utf-8-sig'))
    if not isinstance(obj, dict):
        raise RuntimeError('Expected root JSON object')
    rows, refs = [], []
    def walk(v, path='$'):
        if isinstance(v, dict):
            for k, x in v.items():
                walk(x, path + '.' + k)
        elif isinstance(v, list):
            for i, x in enumerate(v):
                walk(x, path + '[' + str(i) + ']')
        else:
            if RELEVANT.search(path):
                rows.append({'json_path': path, 'value': safe(v, path)})
            if isinstance(v, str) and REF.search(v):
                if not re.fullmatch(r'[A-Za-z0-9_./-]{1,240}', v):
                    refs.append({'json_path': path, 'value': '[redacted nonlocal reference]'})
                else:
                    refs.append({'json_path': path, 'value': v, 'lexical_path_from_dialogue_base': os.path.normpath(os.path.join(ROOT, v))})
    walk(obj)
    if len(rows) > 1000 or len(refs) > 100:
        raise RuntimeError('Relevant evidence bound exceeded')
    selected = obj.get('LanguageUnderstanding', {}).get('NluConfig')
    files.append({'path': path, 'resolved_path': path, 'regular_file': True, 'symlink': False,
        'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
        'uid': before.st_uid, 'gid': before.st_gid, 'mode': oct(stat.S_IMODE(before.st_mode)),
        'dev': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns,
        'dialogue_base': ROOT, 'nlu_config_selector': safe(selected, '$.LanguageUnderstanding.NluConfig'),
        'references': refs, 'relevant_leaves': rows,
        'policy_subtree_hashes': {k: digest(v) for k, v in obj.items() if RELEVANT.search(k)}})
    objects.append(obj)
keys = set(objects[0]) | set(objects[1])
print(json.dumps({'captured_at_utc': datetime.datetime.utcnow().isoformat()+'Z',
    'authorization': 'PLAN-20261016-llm-nlu10-shared-codec v2 Phase4a bounded root-referrer continuation',
    'resource_root': ROOT, 'files': files,
    'root_object_equal': objects[0] == objects[1],
    'relevant_top_level_equality': {k: objects[0].get(k) == objects[1].get(k) for k in sorted(keys) if RELEVANT.search(k)},
    'summary': {'root_configs_read': 2, 'target_content_mutation': 'NONE', 'full_configs_exported': False,
    'references': {f['path']: f['nlu_config_selector'] for f in files}}}, ensure_ascii=False))
