import hashlib, json, pathlib, re, subprocess
base=pathlib.Path('/home/daigd/packages/android-lib')
pointer=base/'LATEST-v3-debug'
name=pointer.read_text().strip()
assert pathlib.Path(name).name==name and name.endswith('.so')
artifact=base/name
assert artifact.resolve().parent==base.resolve()
meta=pathlib.Path(str(artifact)+'.meta')
fields=dict(line.split('=',1) for line in meta.read_text().splitlines() if '=' in line)
sha=hashlib.sha256()
with artifact.open('rb') as f:
    for chunk in iter(lambda:f.read(1024*1024),b''): sha.update(chunk)
expected={'artifact':name,'project':'/home/daigd/dialogue','branch':'feat/v3-nlu-linux','git_commit':'3f086385c81509d40ccb82813758dd1d6d24c0f3','bazel_target':'//cu:libdialogue_api.so','dialogue_version':'v3','build_profile':'debug','dialogue_pipeline_define':'dialogue_pipeline_v3=true','compilation_mode':'dbg','strip_mode':'never','package_strip_actual_state':'not_stripped','android_abi':'arm64-v8a','android_api':'21','sha256':sha.hexdigest(),'size':str(artifact.stat().st_size)}
for k,v in expected.items(): assert fields.get(k)==v,(k,fields.get(k),v)
print('ARTIFACT='+str(artifact))
print('METADATA='+str(meta))
print('POINTER='+str(pointer)+' -> '+name)
print('METADATA_INTEGRITY=PASS '+json.dumps(fields,sort_keys=True))
def run(args):
    return subprocess.check_output(args,universal_newlines=True,timeout=30,stderr=subprocess.STDOUT)
print('ELF_FILE='+run(['file',str(artifact)]).strip())
header=run(['readelf','-h',str(artifact)])
for l in header.splitlines():
    if any(x in l for x in ['Class:','Type:','Machine:']): print(l.strip())
assert 'AArch64' in header and 'DYN' in header
wanted={'InitializeWithNlu06BInference','Initialize','Process','StreamingProcess','LLMInference','Release'}
found={}
symbols=run(['readelf','--dyn-syms','--wide',str(artifact)])
for l in symbols.splitlines():
    parts=l.split()
    if len(parts)>=8 and parts[-1] in wanted:
        assert parts[3]=='FUNC' and parts[4]=='GLOBAL' and parts[5]=='DEFAULT' and parts[6]!='UND',l
        found[parts[-1]]=l.strip()
assert set(found)==wanted,sorted(wanted-set(found))
for k in sorted(found): print('EXPORT='+found[k])
sections=run(['readelf','-SW',str(artifact)])
assert '.debug_info' in sections and '.symtab' in sections
print('DEBUG_SECTIONS=.debug_info and .symtab present')
print('COMPILER_COMMENT='+run(['readelf','-p','.comment',str(artifact)]).strip())
for l in run(['readelf','-d',str(artifact)]).splitlines():
    if 'NEEDED' in l: print('DYNAMIC='+l.strip())
print('PACKAGE_EXPORT_ACCEPTANCE=PASS')
