import hashlib, json, os, pathlib, re, subprocess, sys, time
root = pathlib.Path('/home/daigd/dialogue')
env = os.environ.copy()
env.update(GIT_OPTIONAL_LOCKS='0', GIT_PAGER='cat', PAGER='cat')
def git(p, *args):
    return subprocess.check_output(['git','-c','core.fsmonitor=false','-C',str(p),*args],env=env,timeout=10,universal_newlines=True).strip()
def identity(p):
    index = pathlib.Path(git(p,'rev-parse','--git-path','index'))
    if not index.is_absolute(): index = p/index
    return {'head':git(p,'rev-parse','HEAD'),'branch':git(p,'symbolic-ref','--short','HEAD'),'index_sha256':hashlib.sha256(index.read_bytes()).hexdigest()}
def state():
    w=root/'WORKSPACE'; s=w.stat()
    return {'parent':identity(root),'third_party':identity(root/'third_party'),'workspace':{'sha256':hashlib.sha256(w.read_bytes()).hexdigest(),'mode':oct(s.st_mode & 0o7777),'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size}}
before=state()
assert str(root.resolve()) == str(root)
assert str((root/'third_party').resolve()) == str(root/'third_party')
assert before['parent']['head']=='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert before['parent']['branch']=='feat/v3-nlu-linux'
print('BEFORE='+json.dumps(before,sort_keys=True),flush=True)
print('SCOPED_DIRTY='+git(root,'status','--porcelain','--untracked-files=normal','--','WORKSPACE','cu'),flush=True)
command=['timeout','--kill-after=15s','1800s','/bin/bash','--noprofile','--norc','/home/daigd/cu-dev-pipeline-v18-android-dialogue-api.sh','android_v3_debug_build','--android-ndk','/home/daigd/workspaces/android-ndk-r20b','--android-abi','arm64-v8a','--android-api','21','--message','PLAN-20261016-llm-nlu10-shared-codec v1 Android V3 callback API validation']
env.update(LC_ALL='C',PROJECT_DIR=str(root),THIRD_PARTY_DIR=str(root/'third_party'))
print('COMMAND='+json.dumps(command),flush=True)
started=time.time()
p=subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True,errors='replace')
errors=[]; logpaths=set(); selected=0
for line in p.stdout:
    for path in re.findall(r'/home/daigd/packages/logs/[^\s]+\.log',line): logpaths.add(path)
    if re.search(r'error:|ERROR:|failed|FAILED|FATAL',line): errors=(errors+[line.rstrip()])[-20:]
    if selected<65 and re.search(r'ANDROID_CC_VERSION=|ANDROID_NDK_REVISION=|Bazel log:|Dialogue version/profile:|Bazel define:|Compilation/strip:|Target ABI/API:|ANDROID_PACKAGE_|artifact=|metadata=|sha256=|size=|latest_pointer=|Restoring original|Build completed|Log file:|Log:',line):
        print(line.rstrip(),flush=True); selected+=1
rc=p.wait()
print('PIPELINE_EXIT='+str(rc),flush=True)
print('ELAPSED_SECONDS='+str(round(time.time()-started,2)),flush=True)
print('PIPELINE_LOGS='+json.dumps(sorted(logpaths)),flush=True)
after=state()
print('AFTER='+json.dumps(after,sort_keys=True),flush=True)
print('SOURCE_PROTECTION='+('PASS' if before==after else 'FAIL'),flush=True)
if rc:
    print('FIRST_ACTIONABLE_EXCERPT\n'+'\n'.join(errors),flush=True)
if before!=after: sys.exit(90)
sys.exit(rc)
