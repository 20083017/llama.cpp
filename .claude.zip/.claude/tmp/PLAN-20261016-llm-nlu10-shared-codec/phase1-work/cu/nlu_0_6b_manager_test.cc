// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_0_6b_manager.h"

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <thread>
#include <vector>

#include "base/json_helper.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace {

std::string TestBasePath() {
  const char* temp_dir = std::getenv("TEST_TMPDIR");
  return temp_dir == nullptr ? std::string() : std::string(temp_dir);
}

Json::Value MakeConfig(bool enable_hotfix = true) {
  const std::string base_path = TestBasePath();
  if (base_path.empty()) {
    return Json::Value();
  }
  const std::string rule_name = "nlu_0_6b_hotfix_rules.txt";
  const std::string dict_name = "nlu_0_6b_hotfix_dict.txt";
  const std::string rule_path = base_path + "/" + rule_name;
  const std::string dict_path = base_path + "/" + dict_name;
  nlu::SemanticFrame frame;
  frame.domain = {"intelligent_car_control", 1.0f};
  frame.intents.emplace_back("turn_on_device", 1.0f);
  frame.slots.Add(new nlu::Slot("name", "window"));
  nlu::SemanticFrame malformed_frame;
  std::ofstream rules(rule_path.c_str());
  rules << "^[打开|开启](?P<name><device>)$\t"
        << JsonHelper::ToString(frame.Serialize()) << std::endl;
  rules << "^[坏|错](?P<name><device>)$\t"
        << JsonHelper::ToString(malformed_frame.Serialize()) << std::endl;
  rules.close();
  std::ofstream dict(dict_path.c_str());
  dict << "车窗\tdevice" << std::endl;
  dict << "规则\tdevice" << std::endl;
  dict.close();
  if (!rules || !dict) {
    return Json::Value();
  }

  Json::Value config = JsonHelper::ParseJsonFromString(R"JSON(
  {
    "MockResponses": {
      "mock single": {
        "is_rejected": false,
        "reject_reason": "",
        "rewritten_query": "must be ignored",
        "is_multi_intent": false,
        "frames": [
          {"domain":"vehicle","intents":["open_window"],
           "slots":{"name":"window"}}
        ]
      },
      "mock multi": {
        "is_rejected": false,
        "reject_reason": "",
        "is_multi_intent": true,
        "frames": [
          {"domain":"vehicle","intents":["open_window"],"slots":{}},
          {"domain":"media","intents":["play_music"],"slots":{}}
        ]
      },
      "mock rejected": {
        "is_rejected": true,
        "reject_reason": "unsafe request",
        "rewritten_query": "do not use this",
        "is_multi_intent": false,
        "frames": []
      },
      "rejected absent frames": {
        "is_rejected": true,
        "reject_reason": "unsupported",
        "is_multi_intent": false
      },
      "partial": {
        "is_rejected": false,
        "reject_reason": "",
        "is_multi_intent": false
      },
      "contradictory rejected": {
        "is_rejected": true,
        "reject_reason": "unsafe",
        "is_multi_intent": false,
        "frames": [
          {"domain":"vehicle","intents":["open"],"slots":{}}
        ]
      },
      "rejected without reason": {
        "is_rejected": true,
        "reject_reason": "",
        "is_multi_intent": false,
        "frames": []
      },
      "single marked multi": {
        "is_rejected": false,
        "reject_reason": "",
        "is_multi_intent": true,
        "frames": [
          {"domain":"vehicle","intents":["open"],"slots":{}}
        ]
      },
      "multi marked single": {
        "is_rejected": false,
        "reject_reason": "",
        "is_multi_intent": false,
        "frames": [
          {"domain":"vehicle","intents":["open"],"slots":{}},
          {"domain":"media","intents":["play"],"slots":{}}
        ]
      },
      "incomplete frame": {
        "is_rejected": false,
        "reject_reason": "",
        "is_multi_intent": false,
        "frames": [
          {"domain":"vehicle","intents":[],"slots":{}}
        ]
      },
      "bad rewritten query": {
        "is_rejected": false,
        "reject_reason": "",
        "rewritten_query": 7,
        "is_multi_intent": false,
        "frames": [
          {"domain":"vehicle","intents":["open"],"slots":{}}
        ]
      }
    }
  })JSON");
  config["HotFix"]["enable"] = enable_hotfix;
  config["HotFix"]["rule_paths"] = Json::Value(Json::arrayValue);
  config["HotFix"]["rule_paths"].append(rule_name);
  config["HotFix"]["dict_paths"] = Json::Value(Json::arrayValue);
  config["HotFix"]["dict_paths"].append(dict_name);
  return config;
}

int ProcessQuery(Nlu06BManager* manager, const std::string& query,
                 bool enable_hotfix, nlu::SemanticFrames* output,
                 Nlu06BResultInfo* info) {
  Nlu06BRequest request;
  request.request_id = "request-" + query;
  request.query = query;
  request.enable_hotfix = enable_hotfix;
  request.hotfix_query = query;
  return manager->Process(request, output, info);
}

TEST(Nlu06BManagerTest, HotFixHitIsCompleteAndDoesNotUseMock) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  ASSERT_EQ(0, ProcessQuery(&manager, "打开车窗", true, &output, &info));
  ASSERT_EQ(1u, output.size());
  EXPECT_FALSE(info.is_rejected);
  EXPECT_EQ("hotfix", info.result_source);
  EXPECT_EQ("intelligent_car_control", output[0]->domain.value);
  ASSERT_EQ(1u, output[0]->intents.size());
  EXPECT_EQ("turn_on_device", output[0]->intents[0].value);
}

TEST(Nlu06BManagerTest, HotFixMissAndDisabledConfigUseOneMockResult) {
  for (bool configured : {true, false}) {
    Nlu06BManager manager;
    ASSERT_EQ(0, manager.Initialize(MakeConfig(configured), TestBasePath()));
    nlu::SemanticFrames output;
    Nlu06BResultInfo info;
    ASSERT_EQ(0, ProcessQuery(&manager, "mock single", true, &output, &info));
    ASSERT_EQ(1u, output.size());
    EXPECT_EQ("mock", info.result_source);
    EXPECT_FALSE(info.is_multi_intent);
    EXPECT_EQ("vehicle", output[0]->domain.value);
  }
}

TEST(Nlu06BManagerTest, MalformedHotFixHitIsErrorNotMiss) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  EXPECT_LT(ProcessQuery(&manager, "坏规则", true, &output, &info), 0);
  EXPECT_TRUE(output.empty());
  EXPECT_TRUE(info.result_source.empty());
}

TEST(Nlu06BManagerTest, HotFixInitializationErrorIsExplicit) {
  Json::Value config = MakeConfig();
  config["HotFix"]["rule_paths"][0] = "missing-rules.txt";
  Nlu06BManager manager;
  EXPECT_LT(manager.Initialize(config, TestBasePath()), 0);
}

TEST(Nlu06BManagerTest, AcceptedSingleAndMultiContractsAgreeWithFrames) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  ASSERT_EQ(0, ProcessQuery(&manager, "mock single", false, &output, &info));
  EXPECT_FALSE(info.is_multi_intent);
  ASSERT_EQ(1u, output.size());
  output.clear();
  ASSERT_EQ(0, ProcessQuery(&manager, "mock multi", false, &output, &info));
  EXPECT_TRUE(info.is_multi_intent);
  ASSERT_EQ(2u, output.size());
  EXPECT_EQ("vehicle", output[0]->domain.value);
  EXPECT_EQ("media", output[1]->domain.value);
}

TEST(Nlu06BManagerTest, RejectedContractHasReasonAndNoBusinessFrames) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  for (const char* query : {"mock rejected", "rejected absent frames"}) {
    nlu::SemanticFrames output;
    Nlu06BResultInfo info;
    ASSERT_EQ(0, ProcessQuery(&manager, query, false, &output, &info));
    EXPECT_TRUE(info.is_rejected);
    EXPECT_FALSE(info.reject_reason.empty());
    EXPECT_EQ("mock", info.result_source);
    EXPECT_TRUE(output.empty());
  }
}

TEST(Nlu06BManagerTest, RewrittenQueryIsValidatedButIgnored) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  ASSERT_EQ(0, ProcessQuery(&manager, "mock single", false, &output, &info));
  ASSERT_EQ(1u, output.size());
  EXPECT_EQ("vehicle", output[0]->domain.value);
  EXPECT_EQ("open_window", output[0]->intents[0].value);
  EXPECT_EQ("mock", info.result_source);
  EXPECT_TRUE(info.reject_reason.empty());
}

TEST(Nlu06BManagerTest, MalformedContradictoryAndUnknownClearAllOutput) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  const char* queries[] = {
      "unknown", "partial", "contradictory rejected",
      "rejected without reason", "single marked multi",
      "multi marked single", "incomplete frame", "bad rewritten query"};
  for (const char* query : queries) {
    nlu::SemanticFrames output;
    output.push_back(new nlu::SemanticFrame());
    Nlu06BResultInfo info;
    info.is_rejected = true;
    info.reject_reason = "stale";
    info.result_source = "stale";
    EXPECT_LT(ProcessQuery(&manager, query, false, &output, &info), 0)
        << query;
    EXPECT_TRUE(output.empty()) << query;
    EXPECT_FALSE(info.is_rejected) << query;
    EXPECT_TRUE(info.reject_reason.empty()) << query;
    EXPECT_TRUE(info.result_source.empty()) << query;
  }
}

TEST(Nlu06BManagerTest, DisabledHotFixHasNoRuleOrLegacyFallback) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  EXPECT_LT(ProcessQuery(&manager, "打开车窗", false, &output, &info), 0);
  EXPECT_TRUE(output.empty());
  EXPECT_TRUE(info.result_source.empty());
}

TEST(Nlu06BManagerTest, SeparateCallsNeverShareOwningFrames) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  nlu::SemanticFrames first;
  nlu::SemanticFrames second;
  Nlu06BResultInfo info;
  ASSERT_EQ(0, ProcessQuery(&manager, "mock single", false, &first, &info));
  ASSERT_EQ(0, ProcessQuery(&manager, "mock single", false, &second, &info));
  ASSERT_EQ(1u, first.size());
  ASSERT_EQ(1u, second.size());
  EXPECT_NE(first[0], second[0]);
  first[0]->domain.value = "changed";
  EXPECT_EQ("vehicle", second[0]->domain.value);
}

TEST(Nlu06BManagerTest, BackendSelectionDefaultsToMockAndRejectsInvalid) {
  Json::Value config = MakeConfig(false);
  Nlu06BManager default_manager;
  ASSERT_EQ(0, default_manager.Initialize(config, TestBasePath()));

  config["Backend"]["type"] = "mock";
  Nlu06BManager explicit_manager;
  ASSERT_EQ(0, explicit_manager.Initialize(config, TestBasePath()));

  config["Backend"]["type"] = "unknown";
  Nlu06BManager unknown_manager;
  EXPECT_LT(unknown_manager.Initialize(config, TestBasePath()), 0);

  config["Backend"]["type"] = "";
  Nlu06BManager empty_manager;
  EXPECT_LT(empty_manager.Initialize(config, TestBasePath()), 0);

  config["Backend"] = "mock";
  Nlu06BManager malformed_manager;
  EXPECT_LT(malformed_manager.Initialize(config, TestBasePath()), 0);
}

Json::Value WithHttpModel(Json::Value config, const std::string& base) {
  Json::Value profile = JsonHelper::ParseJsonFromString(R"JSON({
    "model":"qwen3_nlu", "system_prompt":"parse vehicle semantics",
    "protocol_path":"manager_protocol.json", "stream":false,
    "temperature":0.1, "top_p":0.9, "top_k":10, "max_tokens":128,
    "enable_thinking":false, "allow_multi_intent_output":false
  })JSON");
  Json::Value catalog(Json::objectValue);
  catalog["profiles"]["daily-driver"] = profile;
  std::ofstream catalog_file((base + "/manager_catalog.json").c_str());
  catalog_file << JsonHelper::ToString(catalog);
  Json::Value protocol = JsonHelper::ParseJsonFromString(R"JSON({
    "protocol":"nlu_10", "request_field_prefixes":["history:","query: "],
    "field_delimiter":"\t", "request_slot_assignment":"=",
    "request_slot_separator":",", "response_slot_assignment":"=",
    "response_slot_separator":",", "response_frame_separator":";",
    "response_unknown_marker":"unknown", "response_multi_marker":"multi:"
  })JSON");
  std::ofstream protocol_file((base + "/manager_protocol.json").c_str());
  protocol_file << JsonHelper::ToString(protocol);
  config["Backend"]["type"] = "openai_http";
  config["Model"]["profile"] = "daily-driver";
  config["Model"]["profile_catalog_path"] = "manager_catalog.json";
  config["OpenAIHttp"]["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  config["OpenAIHttp"]["connect_timeout_ms"] = 1000;
  config["OpenAIHttp"]["total_timeout_ms"] = 2000;
  return config;
}

TEST(Nlu06BManagerTest, OpenAIHttpRequiresConfigAndHotFixStillBypassesIt) {
  Json::Value missing_config = MakeConfig();
  missing_config["Backend"]["type"] = "openai_http";
  Nlu06BManager invalid_manager;
  EXPECT_LT(invalid_manager.Initialize(missing_config, TestBasePath()), 0);

  Json::Value config = WithHttpModel(MakeConfig(), TestBasePath());
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(config, TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  ASSERT_EQ(0, ProcessQuery(&manager, "打开车窗", true, &output, &info));
  ASSERT_EQ(1u, output.size());
  EXPECT_EQ("hotfix", info.result_source);
  EXPECT_EQ("intelligent_car_control", output[0]->domain.value);
}

TEST(Nlu06BManagerTest, LiveOpenAIHttpCaseWhenEndpointIsInjected) {
  const char* endpoint = std::getenv("WTP184_NLU06B_LIVE_ENDPOINT");
  if (endpoint == nullptr || endpoint[0] == '\0') {
    return;
  }

  Json::Value config = WithHttpModel(MakeConfig(false), TestBasePath());
  config["OpenAIHttp"]["endpoint"] = "${WTP184_NLU06B_LIVE_ENDPOINT}";
  config["OpenAIHttp"]["connect_timeout_ms"] = 5000;
  config["OpenAIHttp"]["total_timeout_ms"] = 30000;
  config["OpenAIHttp"]["max_response_bytes"] = 1048576;

  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(config, TestBasePath()));
  Nlu06BRequest request;
  request.request_id = "live-contract-check";
  request.query = "<助手>:<用户>:副驾驶座椅加热降到1档";
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  ASSERT_EQ(0, manager.Process(request, &output, &info));
  ASSERT_EQ(1u, output.size());
  EXPECT_EQ("nlu06b", info.result_source);
  EXPECT_FALSE(info.is_rejected);
  EXPECT_FALSE(info.is_multi_intent);
  EXPECT_EQ("intelligent_car_control", output[0]->domain.value);
  ASSERT_EQ(1u, output[0]->intents.size());
  EXPECT_EQ("seat_heating_control", output[0]->intents[0].value);
  ASSERT_NE(nullptr, output[0]->slots.GetSlot("area"));
  ASSERT_NE(nullptr, output[0]->slots.GetSlot("gear_number"));
  ASSERT_NE(nullptr, output[0]->slots.GetSlot("gear_unit"));
  ASSERT_NE(nullptr, output[0]->slots.GetSlot("position"));
  EXPECT_EQ("座椅", output[0]->slots.GetSlot("area")->value);
  EXPECT_EQ("1", output[0]->slots.GetSlot("gear_number")->value);
  EXPECT_EQ("档", output[0]->slots.GetSlot("gear_unit")->value);
  EXPECT_EQ("副驾", output[0]->slots.GetSlot("position")->value);
}

TEST(Nlu06BManagerTest, ConcurrentMockMissesRemainIsolated) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(false), TestBasePath()));
  const size_t thread_count = 8u;
  std::vector<int> results(thread_count, 0);
  std::vector<std::thread> threads;
  for (size_t i = 0; i < thread_count; ++i) {
    threads.push_back(std::thread([&manager, &results, i]() {
      nlu::SemanticFrames output;
      Nlu06BResultInfo info;
      results[i] = ProcessQuery(&manager, "missing fixture", false,
                                &output, &info);
      EXPECT_TRUE(output.empty());
      EXPECT_TRUE(info.result_source.empty());
    }));
  }
  for (auto& thread : threads) {
    thread.join();
  }
  for (const int result : results) {
    EXPECT_LT(result, 0);
  }
}


TEST(Nlu06BManagerTest, ForwardsModelRootToProfileBackendFactory) {
  const std::string base = TestBasePath();
  ASSERT_FALSE(base.empty());
  Json::Value config = WithHttpModel(Json::Value(Json::objectValue), base);
  Nlu06BManager manager;
  EXPECT_EQ(0, manager.Initialize(config, base));
  Nlu06BManager missing_base;
  EXPECT_LT(missing_base.Initialize(config, std::string()), 0);
  Json::Value stale = config;
  stale["OpenAIHttp"]["profile"] = "daily-driver";
  Nlu06BManager stale_manager;
  EXPECT_LT(stale_manager.Initialize(stale, base), 0);
  stale = config;
  stale.removeMember("Model");
  Nlu06BManager missing_model;
  EXPECT_LT(missing_model.Initialize(stale, base), 0);
  std::remove((base + "/manager_catalog.json").c_str());
  std::remove((base + "/manager_protocol.json").c_str());
}

TEST(Nlu06BManagerTest, PerCallCarrierForwardsExactTextWithoutChangingBusiness) {
  // These are existing MockResponses carriers, not an HTTP integration test.
  // The HTTP fake-transport tests separately establish decoding provenance.
  Json::Value config = MakeConfig(false);
  const std::string raw = "flag:multi|vehicle\topen_window\tname=车窗\n：；";
  config["MockResponses"]["mock multi"]["nlu_result"] = raw;
  config["MockResponses"]["mock rejected"]["nlu_result"] = "flag:unknown";
  config["MockResponses"]["partial"]["nlu_result"] = "";
  config["MockResponses"]["incomplete frame"]["nlu_result"] = raw;
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(config, TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  ASSERT_EQ(0, ProcessQuery(&manager, "mock multi", false, &output, &info));
  ASSERT_EQ(2u, output.size());
  EXPECT_TRUE(info.is_multi_intent);
  EXPECT_FALSE(info.is_hit_rule);
  ASSERT_TRUE(info.nlu_result.isString());
  EXPECT_EQ(raw, info.nlu_result.asString());
  ASSERT_EQ(0, ProcessQuery(&manager, "mock rejected", false, &output, &info));
  EXPECT_TRUE(output.empty());
  EXPECT_TRUE(info.is_rejected);
  EXPECT_FALSE(info.is_multi_intent);
  EXPECT_FALSE(info.is_hit_rule);
  EXPECT_EQ("flag:unknown", info.nlu_result.asString());
  for (const char* query : {"partial", "incomplete frame"}) {
    ASSERT_LT(ProcessQuery(&manager, query, false, &output, &info), 0);
    EXPECT_TRUE(output.empty());
    EXPECT_FALSE(info.is_rejected);
    EXPECT_FALSE(info.is_multi_intent);
    EXPECT_FALSE(info.is_slot_immutable);
    EXPECT_FALSE(info.is_hit_rule);
    EXPECT_TRUE(info.result_source.empty());
    EXPECT_TRUE(info.reject_reason.empty());
    ASSERT_TRUE(info.nlu_result.isString());
    EXPECT_EQ(std::string(query) == "partial" ? std::string() : raw,
              info.nlu_result.asString());
  }
  ASSERT_LT(ProcessQuery(&manager, "unknown", false, &output, &info), 0);
  EXPECT_TRUE(output.empty());
  EXPECT_TRUE(info.nlu_result.isNull());
  ASSERT_EQ(0, ProcessQuery(&manager, "mock single", false, &output, &info));
  EXPECT_TRUE(info.nlu_result.isNull());
}

TEST(Nlu06BManagerTest, RuleProvenanceAndDiagnosticClearAreCallLocal) {
  Nlu06BManager manager;
  ASSERT_EQ(0, manager.Initialize(MakeConfig(), TestBasePath()));
  nlu::SemanticFrames output;
  Nlu06BResultInfo info;
  info.nlu_result = "stale";
  ASSERT_EQ(0, ProcessQuery(&manager, "打开车窗", true, &output, &info));
  EXPECT_TRUE(info.is_hit_rule);
  EXPECT_FALSE(info.matched_rule.empty());
  EXPECT_TRUE(info.nlu_result.isNull());
  ASSERT_LT(ProcessQuery(&manager, "坏规则", true, &output, &info), 0);
  // The failure code alone is not proof that the matcher reported a hit.
  // Positive-hit provenance is asserted above; error business state stays clear.
  EXPECT_TRUE(output.empty());
  EXPECT_FALSE(info.is_rejected);
  EXPECT_FALSE(info.is_multi_intent);
  EXPECT_TRUE(info.result_source.empty());
  EXPECT_TRUE(info.matched_rule.empty());
  EXPECT_TRUE(info.nlu_result.isNull());
  ASSERT_EQ(0, ProcessQuery(&manager, "mock rejected", false, &output, &info));
  EXPECT_TRUE(info.is_rejected);
  EXPECT_FALSE(info.is_hit_rule);
  info.nlu_result = "";
  info.is_hit_rule = true;
  info.Clear();
  EXPECT_TRUE(info.nlu_result.isNull());
  EXPECT_FALSE(info.is_hit_rule);
  EXPECT_FALSE(info.is_rejected);
}

TEST(Nlu06BManagerTest, InvalidOutputAlsoClearsReusedInfo) {
  Nlu06BManager manager;
  Nlu06BRequest request;
  request.request_id = "invalid-output";
  request.query = "query";
  Nlu06BResultInfo info;
  info.nlu_result = "stale";
  info.is_hit_rule = true;
  info.is_multi_intent = true;
  info.is_rejected = true;
  info.result_source = "stale";
  EXPECT_LT(manager.Process(request, nullptr, &info), 0);
  EXPECT_TRUE(info.nlu_result.isNull());
  EXPECT_FALSE(info.is_hit_rule);
  EXPECT_FALSE(info.is_multi_intent);
  EXPECT_FALSE(info.is_rejected);
  EXPECT_TRUE(info.result_source.empty());
}

}  // namespace
}  // namespace nlptk
