// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/llm_protocol.h"

#include <cstdlib>
#include <fstream>
#include <limits.h>
#include <sstream>

#include "cu/nlu_10_protocol.h"

namespace nlptk {
namespace {

bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output);

bool ReadFileJson(const std::string& path, Json::Value* output) {
  std::ifstream input(path.c_str(), std::ios::in | std::ios::binary);
  if (!input || output == nullptr) return false;
  std::ostringstream text;
  text << input.rdbuf();
  return ParseJsonWithoutLogging(text.str(), output);
}

bool ResolveModelPath(const std::string& base_path, const std::string& relative,
                      std::string* resolved) {
  if (resolved == nullptr || base_path.empty() || relative.empty() ||
      relative[0] == '/' || base_path.find('\0') != std::string::npos ||
      relative.find('\0') != std::string::npos) return false;
  char base_buffer[PATH_MAX];
  char path_buffer[PATH_MAX];
  if (realpath(base_path.c_str(), base_buffer) == nullptr ||
      realpath((base_path + "/" + relative).c_str(), path_buffer) == nullptr)
    return false;
  const std::string base(base_buffer);
  const std::string path(path_buffer);
  if (path.compare(0, base.size(), base) != 0 ||
      (path.size() > base.size() && path[base.size()] != '/')) return false;
  *resolved = path;
  return true;
}

bool ReadRequiredString(const Json::Value& config, const char* name,
                        std::string* output) {
  if (!config.isObject() || !config[name].isString()) return false;
  *output = config[name].asString();
  return !output->empty();
}

bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output) {
  if (output == nullptr || text.empty()) {
    return false;
  }
  Json::CharReaderBuilder builder;
  JSONCPP_STRING errors;
  std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
  Json::Value parsed;
  if (!reader || !reader->parse(text.data(), text.data() + text.size(),
                                &parsed, &errors)) {
    return false;
  }
  *output = parsed;
  return true;
}

}  // namespace

const char* ContentParseResultName(ContentParseResult result) {
  switch (result) {
    case kContentSuccess:
      return "success";
    case kContentNullResult:
      return "null_result";
    case kContentInvalidDomainField:
      return "invalid_domain_field";
    case kContentInvalidIntentField:
      return "invalid_intent_field";
    case kContentEmptyDomain:
      return "empty_domain";
    case kContentEmptyIntent:
      return "empty_intent";
    case kContentInvalidSlotPair:
      return "invalid_slot_pair";
    case kContentEmptySlotName:
      return "empty_slot_name";
    case kContentEmptySlotValue:
      return "empty_slot_value";
    case kContentDuplicateSlot:
      return "duplicate_slot";
    case kContentTrailingSlotSeparator:
      return "trailing_slot_separator";
    case kContentInvalidWrapper:
      return "invalid_wrapper";
    case kContentMissingTab:
      return "missing_tab";
    case kContentExtraTab:
      return "extra_tab";
  }
  return "unknown";
}

std::unique_ptr<LlmProtocol> CreateLlmProtocol(
    const Json::Value& selector, const std::string& base_path) {
  std::string catalog_relative;
  std::string profile_name;
  if (!selector.isObject() || selector.size() != 2u ||
      !ReadRequiredString(selector, "profile_catalog_path", &catalog_relative) ||
      !ReadRequiredString(selector, "profile", &profile_name))
    return std::unique_ptr<LlmProtocol>();
  std::string catalog_path;
  Json::Value catalog;
  if (!ResolveModelPath(base_path, catalog_relative, &catalog_path) ||
      !ReadFileJson(catalog_path, &catalog) || !catalog.isObject() ||
      !catalog["profiles"].isObject() ||
      !catalog["profiles"][profile_name].isObject())
    return std::unique_ptr<LlmProtocol>();
  const Json::Value& profile = catalog["profiles"][profile_name];
  std::string protocol_relative;
  std::string protocol_path;
  Json::Value protocol;
  if (!ReadRequiredString(profile, "protocol_path", &protocol_relative) ||
      !ResolveModelPath(base_path, protocol_relative, &protocol_path) ||
      !ReadFileJson(protocol_path, &protocol) || !protocol.isObject() ||
      protocol.isMember("version") || protocol.isMember("response_protocol") ||
      protocol.isMember("response_flag_prefix") ||
      !protocol["protocol"].isString())
    return std::unique_ptr<LlmProtocol>();
  if (protocol["protocol"].asString() == "nlu_10")
    return Nlu10Protocol::Create(profile, protocol);
  return std::unique_ptr<LlmProtocol>();
}

}  // namespace nlptk
