// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_NLU_10_PROTOCOL_H_
#define CU_NLU_10_PROTOCOL_H_

#include <vector>

#include "cu/llm_protocol.h"

namespace nlptk {

// Normalized initialization-only values; the codec is the sole stored owner.
struct Nlu10ProtocolSettings {
  std::string model;
  std::string system_prompt;
  double temperature;
  double top_p;
  int top_k;
  int max_tokens;
  bool enable_thinking;
  bool allow_multi_intent_output;
  std::vector<std::string> request_prefixes;
  std::vector<std::string> empty_history_request_prefixes;
  char field_delimiter;
  char request_slot_assignment;
  char request_slot_separator;
  char request_history_separator;
  std::vector<char> response_slot_assignments;
  std::vector<char> response_slot_separators;
  std::vector<char> response_frame_separators;
  std::string response_unknown_marker;
  std::string response_multi_marker;
};

class Nlu10Protocol : public LlmProtocol {
 public:
  static std::unique_ptr<LlmProtocol> Create(const Json::Value& profile,
                                            const Json::Value& descriptor);
  bool BuildRequest(const Nlu06BRequest& request,
                    Json::Value* payload) const override;
  ContentParseResult ParseResponse(const std::string& content,
                                   Json::Value* result) const override;
  std::string model_identity() const override;
  const char* protocol_identity() const override { return "nlu_10"; }

 private:
  explicit Nlu10Protocol(const Nlu10ProtocolSettings& settings)
      : settings_(settings) {}
  const Nlu10ProtocolSettings settings_;
};

}  // namespace nlptk

#endif  // CU_NLU_10_PROTOCOL_H_
