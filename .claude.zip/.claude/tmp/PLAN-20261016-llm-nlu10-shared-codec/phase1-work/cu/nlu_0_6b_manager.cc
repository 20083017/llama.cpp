// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_0_6b_manager.h"

#include "cu/nlu_0_6b_backend.h"
#include "cu/nlu_0_6b_http_backend.h"

#include <cassert>
#include <memory>
#include <utility>
#include <vector>

#include "base/json_helper.h"
#include "base/logging.h"
#include "common/query.h"
#include "nlu/semantic_frame.h"
#include "nlu/slot.h"
#include "qts/nlu_cache.h"

namespace nlptk {
namespace {

bool IsCompleteFrame(const nlu::SemanticFrame* frame) {
  if (frame == nullptr || frame->domain.value.empty() ||
      frame->intents.empty()) {
    return false;
  }
  for (const auto& intent : frame->intents) {
    if (intent.value.empty()) {
      return false;
    }
  }
  std::vector<nlu::Slot*> slots;
  frame->slots.List("", &slots);
  for (const auto* slot : slots) {
    if (slot == nullptr || slot->name.empty()) {
      return false;
    }
  }
  return true;
}

bool AreCompleteFrames(const nlu::SemanticFrames& frames) {
  if (frames.empty()) {
    return false;
  }
  for (const auto* frame : frames) {
    if (!IsCompleteFrame(frame)) {
      return false;
    }
  }
  return true;
}

bool ReadRequiredBool(const Json::Value& value, const char* name, bool* out) {
  if (!value.isMember(name) || !value[name].isBool() || out == nullptr) {
    return false;
  }
  *out = value[name].asBool();
  return true;
}

bool ReadRequiredString(const Json::Value& value, const char* name,
                        std::string* out) {
  if (!value.isMember(name) || !value[name].isString() || out == nullptr) {
    return false;
  }
  *out = value[name].asString();
  return true;
}

int BuildFrame(const Json::Value& value, nlu::SemanticFrame** output) {
  assert(output);
  *output = nullptr;
  if (!value.isObject() || !value.isMember("domain") ||
      !value["domain"].isString() || value["domain"].asString().empty() ||
      !value.isMember("intents") || !value["intents"].isArray() ||
      value["intents"].empty() || !value.isMember("slots") ||
      !value["slots"].isObject()) {
    return -1;
  }

  std::unique_ptr<nlu::SemanticFrame> frame(new nlu::SemanticFrame());
  frame->domain = {value["domain"].asString(), 1.0f};
  for (const auto& intent : value["intents"]) {
    if (!intent.isString() || intent.asString().empty()) {
      return -1;
    }
    frame->intents.emplace_back(intent.asString(), 1.0f);
  }
  const Json::Value& slots = value["slots"];
  for (auto it = slots.begin(); it != slots.end(); ++it) {
    if (it.name().empty() || !it->isString()) {
      return -1;
    }
    frame->slots.Add(new nlu::Slot(it.name(), it->asString()));
  }
  if (!IsCompleteFrame(frame.get())) {
    return -1;
  }
  *output = frame.release();
  return 0;
}

int BuildFrames(const Json::Value& values, nlu::SemanticFrames* output) {
  assert(output);
  if (!values.isArray() || values.empty()) {
    return -1;
  }
  for (const auto& value : values) {
    nlu::SemanticFrame* frame = nullptr;
    if (BuildFrame(value, &frame) < 0) {
      output->clear();
      return -1;
    }
    output->push_back(frame);
  }
  return 0;
}

int BuildBackendResult(const Json::Value& fixture,
                       const std::string& result_source,
                       nlu::SemanticFrames* output,
                       Nlu06BResultInfo* info) {
  assert(output);
  assert(info);
  if (!fixture.isObject()) {
    return -1;
  }

  bool is_rejected = false;
  bool is_multi_intent = false;
  std::string reject_reason;
  if (!ReadRequiredBool(fixture, "is_rejected", &is_rejected) ||
      !ReadRequiredString(fixture, "reject_reason", &reject_reason) ||
      !ReadRequiredBool(fixture, "is_multi_intent", &is_multi_intent)) {
    return -1;
  }
  if (fixture.isMember("rewritten_query") &&
      !fixture["rewritten_query"].isString()) {
    return -1;
  }

  const bool has_frames = fixture.isMember("frames");
  if (is_rejected) {
    if (reject_reason.empty() || is_multi_intent ||
        (has_frames &&
         (!fixture["frames"].isArray() || !fixture["frames"].empty()))) {
      return -1;
    }
    info->is_rejected = true;
    info->reject_reason = reject_reason;
    info->result_source = result_source;
    return 0;
  }

  if (!reject_reason.empty() || !has_frames ||
      BuildFrames(fixture["frames"], output) < 0 ||
      !AreCompleteFrames(*output) ||
      is_multi_intent != (output->size() > 1)) {
    output->clear();
    return -1;
  }
  info->is_multi_intent = is_multi_intent;
  info->result_source = result_source;
  return 0;
}

class MockNlu06BBackend : public Nlu06BBackend {
 public:
  explicit MockNlu06BBackend(const Json::Value& responses)
      : responses_(responses) {}

  int Process(const Nlu06BRequest& request,
              Json::Value* result) const override {
    if (result == nullptr) {
      return -1;
    }
    *result = Json::Value();
    const Json::Value& fixture = responses_[request.query];
    if (fixture.isNull()) {
      return -1;
    }
    *result = fixture;
    return 0;
  }

  const char* result_source() const override { return "mock"; }

 private:
  const Json::Value responses_;
};

}  // namespace

struct Nlu06BManager::Impl {
  Impl() : initialized(false), hotfix_enabled(false) {}

  bool initialized;
  bool hotfix_enabled;
  std::unique_ptr<clu::NluCache> hotfix_cache;
  std::unique_ptr<Nlu06BBackend> backend;
};

void Nlu06BResultInfo::Clear() {
  is_rejected = false;
  is_multi_intent = false;
  is_slot_immutable = false;
  reject_reason.clear();
  result_source.clear();
  matched_rule.clear();
  nlu_result = Json::Value();
  is_hit_rule = false;
}

Nlu06BManager::Nlu06BManager() : impl_(new Impl()) {}
Nlu06BManager::~Nlu06BManager() = default;

int Nlu06BManager::Initialize(const Json::Value& config,
                              const std::string& base_path) {
  if (!impl_ || !config.isObject()) {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_init_result "
               << "stage=input outcome=error reason=invalid_config";
    return -1;
  }
  impl_->initialized = false;
  impl_->hotfix_enabled = false;
  impl_->hotfix_cache.reset();
  impl_->backend.reset();

  const Json::Value hotfix = JsonHelper::ResolveJPath(config, "HotFix");
  impl_->hotfix_enabled =
      JsonHelper::ResolveJPath<bool>(hotfix, "enable", false);
  if (impl_->hotfix_enabled) {
    std::unique_ptr<clu::NluCache> cache(new clu::NluCache());
    if (cache->Initialize(hotfix, base_path) < 0) {
      LOG(ERROR) << "component=nlu06b_manager event=nlu06b_init_result "
                 << "stage=hotfix outcome=error reason=cache_init_failed";
      return -1;
    }
    impl_->hotfix_cache = std::move(cache);
  }

  std::string backend_type("mock");
  const Json::Value backend_config =
      JsonHelper::ResolveJPath(config, "Backend");
  if (!backend_config.isNull()) {
    if (!backend_config.isObject() ||
        (backend_config.isMember("type") &&
         (!backend_config["type"].isString() ||
          backend_config["type"].asString().empty()))) {
      LOG(ERROR) << "component=nlu06b_manager event=nlu06b_init_result "
                 << "stage=backend_config outcome=error "
                 << "reason=invalid_backend_type";
      return -1;
    }
    if (backend_config.isMember("type")) {
      backend_type = backend_config["type"].asString();
    }
  }

  if (backend_type == "mock") {
    Json::Value fixtures = Json::Value(Json::objectValue);
    const Json::Value configured_fixtures =
        JsonHelper::ResolveJPath(config, "MockResponses");
    if (!configured_fixtures.isNull() && !configured_fixtures.isObject()) {
      LOG(ERROR) << "component=nlu06b_manager event=nlu06b_init_result "
                 << "stage=mock_config outcome=error "
                 << "reason=invalid_mock_responses";
      return -1;
    }
    if (configured_fixtures.isObject()) {
      fixtures = configured_fixtures;
    }
    impl_->backend.reset(new MockNlu06BBackend(fixtures));
  } else if (backend_type == "openai_http") {
    impl_->backend = CreateNlu06BHttpBackend(config, base_path);
    if (!impl_->backend) {
      LOG(ERROR) << "component=nlu06b_manager event=nlu06b_init_result "
                 << "stage=http_config outcome=error "
                 << "reason=backend_init_failed";
      return -1;
    }
  } else {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_init_result "
               << "stage=backend_config outcome=error "
               << "reason=unsupported_backend_type";
    return -1;
  }
  impl_->initialized = true;
  LOG(INFO) << "component=nlu06b_manager event=nlu06b_init_result "
            << "stage=complete outcome=ok backend=" << backend_type
            << " hotfix_enabled=" << impl_->hotfix_enabled;
  return 0;
}

int Nlu06BManager::Process(const Nlu06BRequest& request,
                           nlu::SemanticFrames* output,
                           Nlu06BResultInfo* info) const {
  if (info != nullptr) {
    info->Clear();
  }
  if (output == nullptr || info == nullptr) {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
               << "stage=input outcome=error request_id="
               << request.request_id << " reason=invalid_output";
    return -1;
  }
  output->clear();
  if (!impl_ || !impl_->initialized || request.query.empty()) {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
               << "stage=input outcome=error request_id="
               << request.request_id << " reason=invalid_state_or_input";
    return -1;
  }

  if (request.enable_hotfix && impl_->hotfix_enabled) {
    if (!impl_->hotfix_cache) {
      LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
                 << "stage=hotfix outcome=error request_id="
                 << request.request_id << " reason=cache_unavailable";
      return -1;
    }
    std::map<std::string, std::string> context = request.hotfix_context;
    clu::Query query(request.hotfix_query.empty() ? request.query
                                                   : request.hotfix_query);
    query.SetRequestId(request.request_id);
    query.SetContextVariables(&context);
    const int cache_code =
        impl_->hotfix_cache->GetCache(query, output, &info->matched_rule);
    if (cache_code < 0) {
      output->clear();
      info->Clear();
      LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
                 << "stage=hotfix outcome=error request_id="
                 << request.request_id << " reason=cache_process_failed";
      return -1;
    }
    if (cache_code > 0) {
      if (!AreCompleteFrames(*output)) {
        output->clear();
        info->Clear();
        info->is_hit_rule = true;
        LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
                   << "stage=hotfix outcome=error request_id="
                   << request.request_id << " reason=invalid_frames";
        return -1;
      }
      info->is_hit_rule = true;
      info->is_slot_immutable = cache_code == 2;
      info->is_multi_intent = output->size() > 1;
      info->result_source = "hotfix";
      LOGI << "component=nlu06b_manager event=nlu06b_backend_result "
           << "stage=hotfix outcome=ok request_id=" << request.request_id
           << " source=hotfix frame_count=" << output->size();
      return 0;
    }
    output->clear();
    info->Clear();
  }

  if (!impl_->backend) {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
               << "stage=backend outcome=error request_id="
               << request.request_id << " reason=backend_unavailable";
    return -1;
  }
  Json::Value result;
  const char* result_source = impl_->backend->result_source();
  if (result_source == nullptr || result_source[0] == '\0') {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
               << "stage=backend_contract outcome=error request_id="
               << request.request_id << " reason=invalid_result_source";
    return -1;
  }
  const std::string safe_source(result_source);
  if (safe_source != "mock" && safe_source != "nlu06b") {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
               << "stage=backend_contract outcome=error request_id="
               << request.request_id << " reason=unsupported_result_source";
    return -1;
  }
  int result_code = impl_->backend->Process(request, &result);
  if (result_code < 0) {
    if (safe_source == "mock") {
      LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
                 << "stage=backend outcome=error request_id="
                 << request.request_id
                 << " source=mock reason=backend_process_failed";
    }
    output->clear();
    info->Clear();
  } else if (BuildBackendResult(result, result_source, output, info) < 0) {
    LOG(ERROR) << "component=nlu06b_manager event=nlu06b_backend_result "
               << "stage=structured_result outcome=error request_id="
               << request.request_id << " source=" << safe_source
               << " reason=invalid_structured_result";
    output->clear();
    info->Clear();
    result_code = -1;
  }
  // Forward only decoded text, independently of cleared invalid business data.
  if (result.isObject() && result["nlu_result"].isString()) {
    info->nlu_result.swap(result["nlu_result"]);
  }
  if (result_code < 0) {
    return -1;
  }
  LOGI << "component=nlu06b_manager event=nlu06b_backend_result "
       << "stage=backend outcome=ok request_id=" << request.request_id
       << " source=" << safe_source << " rejected=" << info->is_rejected
       << " multi_intent=" << info->is_multi_intent
       << " frame_count=" << output->size();
  return 0;
}

}  // namespace nlptk
