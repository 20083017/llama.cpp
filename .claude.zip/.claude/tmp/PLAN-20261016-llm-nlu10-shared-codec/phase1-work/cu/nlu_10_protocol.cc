// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_10_protocol.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <set>
#include <utility>

namespace nlptk {
namespace {

const size_t kMaximumProfileTextBytes = 128u;

bool IsAsciiSpace(char value) {
  return std::isspace(static_cast<unsigned char>(value)) != 0;
}

std::string TrimAsciiSpace(const std::string& value) {
  size_t begin = 0;
  while (begin < value.size() && IsAsciiSpace(value[begin])) {
    ++begin;
  }
  size_t end = value.size();
  while (end > begin && IsAsciiSpace(value[end - 1])) {
    --end;
  }
  return value.substr(begin, end - begin);
}

bool ReadRequiredString(const Json::Value& config, const char* name,
                        std::string* output) {
  if (output == nullptr || !config.isMember(name) ||
      !config[name].isString()) {
    return false;
  }
  *output = config[name].asString();
  return !output->empty();
}

bool ReadOptionalInt(const Json::Value& config, const char* name,
                     int default_value, int minimum, int maximum, int* output) {
  if (output == nullptr) {
    return false;
  }
  *output = default_value;
  if (!config.isMember(name)) {
    return true;
  }
  if (!config[name].isInt()) {
    return false;
  }
  const int value = config[name].asInt();
  if (value < minimum || value > maximum) {
    return false;
  }
  *output = value;
  return true;
}

bool ReadOptionalDouble(const Json::Value& config, const char* name,
                        double default_value, double minimum,
                        double maximum, bool minimum_inclusive,
                        double* output) {
  if (output == nullptr) {
    return false;
  }
  *output = default_value;
  if (!config.isMember(name)) {
    return true;
  }
  if (!config[name].isNumeric()) {
    return false;
  }
  const double value = config[name].asDouble();
  const bool below_minimum =
      minimum_inclusive ? value < minimum : value <= minimum;
  if (!std::isfinite(value) || below_minimum || value > maximum) {
    return false;
  }
  *output = value;
  return true;
}

bool ReadRequiredBoolValue(const Json::Value& value, const char* name,
                           bool* output) {
  if (output == nullptr || !value.isMember(name) || !value[name].isBool())
    return false;
  *output = value[name].asBool();
  return true;
}

bool IsPrintableDelimiter(char value) {
  const unsigned char byte = static_cast<unsigned char>(value);
  return byte >= 0x21u && byte <= 0x7eu;
}

bool ContainsAsciiControl(const std::string& value) {
  for (size_t i = 0u; i < value.size(); ++i) {
    const unsigned char byte = static_cast<unsigned char>(value[i]);
    if (byte < 0x20u || byte == 0x7fu) return true;
  }
  return false;
}

bool ContainsProfileRecordDelimiter(const std::string& value,
                                    char field_delimiter) {
  return value.find('\0') != std::string::npos ||
         value.find('\t') != std::string::npos ||
         value.find('\r') != std::string::npos ||
         value.find('\n') != std::string::npos ||
         value.find(field_delimiter) != std::string::npos;
}

bool ReadDelimiter(const Json::Value& value, const char* name,
                   bool allow_tab, char* output) {
  if (output == nullptr || !value.isMember(name) || !value[name].isString())
    return false;
  const std::string configured = value[name].asString();
  if (configured.size() != 1u ||
      (!IsPrintableDelimiter(configured[0]) &&
       !(allow_tab && configured[0] == '\t'))) return false;
  *output = configured[0];
  return true;
}

bool ReadResponseDelimiterCandidates(const Json::Value& value,
                                     const char* name,
                                     bool allow_compact_string,
                                     std::vector<char>* output) {
  if (output == nullptr || !value.isMember(name)) return false;
  const Json::Value& configured = value[name];
  std::vector<char> parsed;
  if (configured.isString()) {
    const std::string candidates = configured.asString();
    if (candidates.size() > 94u ||
        (!allow_compact_string && candidates.size() != 1u)) return false;
    parsed.assign(candidates.begin(), candidates.end());
  } else if (configured.isArray()) {
    if (configured.size() > 94u) return false;
    for (Json::ArrayIndex i = 0u; i < configured.size(); ++i) {
      if (!configured[i].isString() || configured[i].asString().size() != 1u)
        return false;
      parsed.push_back(configured[i].asString()[0]);
    }
  } else {
    return false;
  }
  if (parsed.empty()) return false;
  std::set<char> unique;
  for (size_t i = 0u; i < parsed.size(); ++i) {
    if (!IsPrintableDelimiter(parsed[i]) || !unique.insert(parsed[i]).second)
      return false;
  }
  output->swap(parsed);
  return true;
}

bool IsDelimiterCandidate(const std::vector<char>& candidates, char byte) {
  return std::find(candidates.begin(), candidates.end(), byte) !=
         candidates.end();
}

bool ProfileRolesAreDistinct(const Nlu10ProtocolSettings& config) {
  if (config.field_delimiter == config.request_slot_assignment ||
      config.field_delimiter == config.request_slot_separator ||
      config.request_slot_assignment == config.request_slot_separator)
    return false;
  std::set<char> response_roles;
  response_roles.insert(config.field_delimiter);
  const std::vector<char>* roles[] = {&config.response_slot_assignments,
      &config.response_slot_separators, &config.response_frame_separators};
  for (size_t i = 0u; i < sizeof(roles) / sizeof(roles[0]); ++i) {
    for (size_t j = 0u; j < roles[i]->size(); ++j) {
      if (!response_roles.insert((*roles[i])[j]).second) return false;
    }
  }
  return true;
}

bool ReadProfileMarkers(const Json::Value& protocol,
                        Nlu10ProtocolSettings* parsed) {
  if (protocol.isMember("response_flag_prefix") ||
      !ReadRequiredString(protocol, "response_unknown_marker",
                          &parsed->response_unknown_marker) ||
      !ReadRequiredString(protocol, "response_multi_marker",
                          &parsed->response_multi_marker)) return false;
  const std::string* markers[] = {&parsed->response_unknown_marker,
                                  &parsed->response_multi_marker};
  for (size_t i = 0u; i < 2u; ++i) {
    if (markers[i]->size() > kMaximumProfileTextBytes ||
        ContainsProfileRecordDelimiter(*markers[i], parsed->field_delimiter))
      return false;
    for (size_t j = 0u; j < parsed->response_frame_separators.size(); ++j) {
      if (markers[i]->find(parsed->response_frame_separators[j]) !=
          std::string::npos) return false;
    }
  }
  return parsed->response_unknown_marker != parsed->response_multi_marker;
}

bool ParseSettings(const Json::Value& profile, const Json::Value& protocol,
                   Nlu10ProtocolSettings* output) {
  if (output == nullptr || !profile.isObject() || !protocol.isObject() ||
      !profile["protocol_path"].isString() ||
      profile["protocol_path"].asString().empty() ||
      !protocol["protocol"].isString() ||
      protocol["protocol"].asString() != "nlu_10" ||
      protocol.isMember("version") || protocol.isMember("response_protocol") ||
      protocol.isMember("response_flag_prefix") ||
      !protocol["request_field_prefixes"].isArray()) return false;
  // Common model settings have one authority. Reject stale transport/format
  // keys instead of silently ignoring configuration from an older binary.
  const char* allowed[] = {"model", "system_prompt", "stream", "temperature",
      "top_p", "top_k", "max_tokens", "enable_thinking",
      "allow_multi_intent_output", "protocol_path"};
  if (profile.size() != sizeof(allowed) / sizeof(allowed[0])) return false;
  for (size_t i = 0u; i < sizeof(allowed) / sizeof(allowed[0]); ++i) {
    if (!profile.isMember(allowed[i])) return false;
  }
  Nlu10ProtocolSettings parsed;
  parsed.request_history_separator = ';';  // U+003B / 3B, request role only.
  if (!ReadRequiredString(profile, "model", &parsed.model) ||
      !ReadRequiredString(profile, "system_prompt", &parsed.system_prompt) ||
      !profile["stream"].isBool() || profile["stream"].asBool() ||
      !ReadOptionalDouble(profile, "temperature", 0.01, 0.0, 2.0, true,
                          &parsed.temperature) ||
      !ReadOptionalDouble(profile, "top_p", 0.95, 0.0, 1.0, false,
                          &parsed.top_p) ||
      !ReadOptionalInt(profile, "top_k", 20, 1, 1000, &parsed.top_k) ||
      !ReadOptionalInt(profile, "max_tokens", 1024, 1, 65536,
                       &parsed.max_tokens) ||
      !ReadRequiredBoolValue(profile, "enable_thinking", &parsed.enable_thinking) ||
      !ReadRequiredBoolValue(profile, "allow_multi_intent_output",
                             &parsed.allow_multi_intent_output)) return false;
  if (protocol.isMember("request_history_separator") &&
      !ReadDelimiter(protocol, "request_history_separator", false,
                     &parsed.request_history_separator)) return false;
  if (!ReadDelimiter(protocol, "field_delimiter", true,
                     &parsed.field_delimiter) ||
      !ReadDelimiter(protocol, "request_slot_assignment", false,
                     &parsed.request_slot_assignment) ||
      !ReadDelimiter(protocol, "request_slot_separator", false,
                     &parsed.request_slot_separator) ||
      !ReadResponseDelimiterCandidates(protocol, "response_slot_assignment",
                                       true, &parsed.response_slot_assignments) ||
      !ReadResponseDelimiterCandidates(protocol, "response_slot_separator",
                                       false, &parsed.response_slot_separators) ||
      !ReadResponseDelimiterCandidates(protocol, "response_frame_separator",
                                       false, &parsed.response_frame_separators) ||
      !ProfileRolesAreDistinct(parsed) || !ReadProfileMarkers(protocol, &parsed))
    return false;
  if (parsed.request_history_separator == parsed.field_delimiter ||
      parsed.request_history_separator == parsed.request_slot_assignment ||
      parsed.request_history_separator == parsed.request_slot_separator)
    return false;
  if (ContainsAsciiControl(parsed.response_unknown_marker) ||
      ContainsAsciiControl(parsed.response_multi_marker)) return false;
  const size_t count = 2u;
  if (protocol["request_field_prefixes"].size() != count) return false;
  parsed.request_prefixes.clear();
  for (size_t i = 0u; i < count; ++i) {
    const Json::Value& prefix = protocol["request_field_prefixes"]
        [static_cast<Json::ArrayIndex>(i)];
    if (!prefix.isString()) return false;
    const std::string text = prefix.asString();
    if (text.size() > kMaximumProfileTextBytes ||
        ContainsProfileRecordDelimiter(text, parsed.field_delimiter) ||
        ContainsAsciiControl(text) ||
        text.find(parsed.request_history_separator) != std::string::npos)
      return false;
    parsed.request_prefixes.push_back(text);
  }
  parsed.empty_history_request_prefixes.clear();
  if (protocol.isMember("empty_history_request")) {
    const Json::Value& option = protocol["empty_history_request"];
    if (!option.isObject() || option.size() != 2u ||
        !option["history_field"].isString() ||
        !option["query_prefix"].isString())
      return false;

    const std::string history_field = option["history_field"].asString();
    const std::string query_prefix = option["query_prefix"].asString();
    if (history_field.empty() ||
        history_field.size() > kMaximumProfileTextBytes ||
        query_prefix.size() > kMaximumProfileTextBytes ||
        ContainsProfileRecordDelimiter(history_field,
                                       parsed.field_delimiter) ||
        ContainsProfileRecordDelimiter(query_prefix,
                                       parsed.field_delimiter) ||
        ContainsAsciiControl(history_field) || ContainsAsciiControl(query_prefix) ||
        history_field.find(parsed.request_history_separator) != std::string::npos ||
        query_prefix.find(parsed.request_history_separator) != std::string::npos)
      return false;

    parsed.empty_history_request_prefixes.push_back(history_field);
    parsed.empty_history_request_prefixes.push_back(query_prefix);
  }

  // Without the existing whole-field override, None is literal history data.
  if (parsed.empty_history_request_prefixes.empty() &&
      (ContainsProfileRecordDelimiter("None", parsed.field_delimiter) ||
       std::string("None").find(parsed.request_history_separator) !=
           std::string::npos)) return false;

  *output = parsed;
  return true;
}

// V10 uses descriptor-owned structural bytes; query cleaning remains local.
// UTF-8 punctuation in query/value text is not normalized.
bool CleanV10Query(const std::string& query, std::string* cleaned) {
  if (cleaned == nullptr || query.empty() ||
      query.find('\0') != std::string::npos) return false;
  *cleaned = query;
  for (size_t i = 0u; i < cleaned->size(); ++i) {
    char& byte = (*cleaned)[i];
    if (byte == '\t' || byte == '\r' || byte == '\n') byte = ' ';
  }
  return true;
}

// Request records reserve only the configured field/history roles, not slot
// syntax in domain/intent text. Assignment bytes after the first are value data.
bool ContainsV10RequestRecordDelimiter(const std::string& text,
                                       const Nlu10ProtocolSettings& config) {
  return ContainsAsciiControl(text) ||
         ContainsProfileRecordDelimiter(text, config.field_delimiter) ||
         text.find(config.request_history_separator) != std::string::npos;
}

bool BuildV10HistoryRow(const Json::Value& history,
                        const Nlu10ProtocolSettings& config, std::string* row) {
  if (row == nullptr || !history.isObject() ||
      !history["v3_nlu_semantics"].isArray() ||
      history["v3_nlu_semantics"].size() != 1u ||
      !history["v3_nlu_semantics"][0u].isObject()) return false;
  const Json::Value& semantic = history["v3_nlu_semantics"][0u];
  if (!semantic["query"].isString() || !semantic["domain"].isString() ||
      !semantic["intent"].isString() || !semantic["slots"].isObject()) return false;
  std::string query;
  const std::string domain = semantic["domain"].asString();
  const std::string intent = semantic["intent"].asString();
  if (!CleanV10Query(semantic["query"].asString(), &query) ||
      ContainsV10RequestRecordDelimiter(query, config) ||
      TrimAsciiSpace(domain).empty() || TrimAsciiSpace(intent).empty() ||
      ContainsV10RequestRecordDelimiter(domain, config) ||
      domain == config.response_unknown_marker ||
      ContainsV10RequestRecordDelimiter(intent, config)) return false;
  std::vector<std::pair<std::string, std::string> > slots;
  for (Json::ValueConstIterator slot = semantic["slots"].begin();
       slot != semantic["slots"].end(); ++slot) {
    const std::string name = slot.name();
    if (TrimAsciiSpace(name).empty() || !(*slot).isString() ||
        ContainsV10RequestRecordDelimiter(name, config) ||
        name.find(config.request_slot_assignment) != std::string::npos ||
        name.find(config.request_slot_separator) != std::string::npos)
      return false;
    const std::string value = (*slot).asString();
    if (TrimAsciiSpace(value).empty() ||
        ContainsV10RequestRecordDelimiter(value, config) ||
        value.find(config.request_slot_separator) != std::string::npos)
      return false;
    slots.push_back(std::make_pair(slot.name(), value));
  }
  std::sort(slots.begin(), slots.end());
  row->assign(query);
  row->push_back(config.field_delimiter);
  row->append(domain);
  row->push_back(config.field_delimiter);
  row->append(intent);
  row->push_back(config.field_delimiter);  // Retain the empty fourth column.
  for (size_t i = 0u; i < slots.size(); ++i) {
    if (i != 0u) row->push_back(config.request_slot_separator);
    row->append(slots[i].first);
    row->push_back(config.request_slot_assignment);
    row->append(slots[i].second);  // Preserve subsequent assignments and pipes.
  }
  return true;
}

bool BuildV10UserContent(const Nlu06BRequest& request,
                         const Nlu10ProtocolSettings& config,
                         std::string* content) {
  std::string query;
  if (content == nullptr || !CleanV10Query(request.query, &query) ||
      (!request.histories.isNull() && !request.histories.isArray())) return false;
  const bool empty = request.histories.isNull() || request.histories.empty();
  const bool use_empty_history_request =
      empty && !config.empty_history_request_prefixes.empty();
  const std::vector<std::string>& prefixes = use_empty_history_request
      ? config.empty_history_request_prefixes : config.request_prefixes;
  std::string formatted = prefixes[0u];
  if (empty) {
    if (!use_empty_history_request) formatted.append("None");
  } else {
    // Consume the already bounded, chronological projection, without another
    // selection policy or fallback from corrupt history to an empty history.
    for (Json::ArrayIndex i = 0u; i < request.histories.size(); ++i) {
      std::string row;
      if (!BuildV10HistoryRow(request.histories[i], config, &row)) return false;
      if (i != 0u) formatted.push_back(config.request_history_separator);
      formatted.append(row);
    }
  }
  formatted.push_back(config.request_history_separator);
  formatted.append(prefixes[1u]);
  formatted.append(query);
  content->swap(formatted);
  return true;
}

bool IsProfileResponseSyntax(const Nlu10ProtocolSettings& config, char byte) {
  return byte == config.field_delimiter ||
         IsDelimiterCandidate(config.response_slot_separators, byte) ||
         IsDelimiterCandidate(config.response_frame_separators, byte) ||
         IsDelimiterCandidate(config.response_slot_assignments, byte);
}

bool HasProfileWrapper(const std::string& content,
                       const Nlu10ProtocolSettings& config) {
  if (content.find('\0') != std::string::npos ||
      content.find('\r') != std::string::npos ||
      content.find('\n') != std::string::npos ||
      content.find('\f') != std::string::npos ||
      content.find('\v') != std::string::npos ||
      (config.field_delimiter != '\t' &&
       content.find('\t') != std::string::npos) ||
      (!IsProfileResponseSyntax(config, '`') &&
       content.find('`') != std::string::npos)) return true;
  const size_t first = content.find_first_not_of(' ');
  const size_t last = content.find_last_not_of(' ');
  if (first == std::string::npos || last == std::string::npos) return false;
  const char begin = content[first];
  const char end = content[last];
  // Preserve wrapper rejection unless the punctuation is configured syntax.
  if (IsProfileResponseSyntax(config, begin) ||
      IsProfileResponseSyntax(config, end)) return false;
  return (begin == '"' && end == '"') || (begin == '\'' && end == '\'') ||
         (begin == '{' && end == '}') || (begin == '[' && end == ']');
}

ContentParseResult ParseProfileFrame(
    const std::string& content, const Nlu10ProtocolSettings& config,
    char* response_assignment, char* response_slot_separator,
    Json::Value* frame) {
  const std::vector<char>& assignments = config.response_slot_assignments;
  if (frame == nullptr || response_assignment == nullptr ||
      response_slot_separator == nullptr || assignments.empty() ||
      config.response_slot_separators.empty() ||
      HasProfileWrapper(content, config)) {
    return kContentInvalidWrapper;
  }
  const size_t first = content.find(config.field_delimiter);
  const size_t second = first == std::string::npos ? std::string::npos
      : content.find(config.field_delimiter, first + 1u);
  if (first == std::string::npos)
    return kContentMissingTab;
  if (second != std::string::npos &&
      content.find(config.field_delimiter, second + 1u) != std::string::npos)
    return kContentExtraTab;
  const std::string domain_text = content.substr(0u, first);
  const std::string intent_text = content.substr(first + 1u,
      second == std::string::npos ? std::string::npos : second - first - 1u);
  const std::string domain = domain_text;
  const std::string intent = intent_text;
  const std::string slot_text = second == std::string::npos
      ? std::string() : content.substr(second + 1u);
  if (domain.empty()) return kContentEmptyDomain;
  if (intent.empty()) return kContentEmptyIntent;
  if (TrimAsciiSpace(domain).empty() || ContainsAsciiControl(domain) ||
      domain == config.response_unknown_marker)
    return kContentInvalidDomainField;
  if (TrimAsciiSpace(intent).empty() || ContainsAsciiControl(intent))
    return kContentInvalidIntentField;
  // A multi marker belongs at the payload boundary, never on individual rows.
  if (content.compare(0u, config.response_multi_marker.size(),
                      config.response_multi_marker) == 0)
    return kContentInvalidWrapper;
  // Only slot fields select a separator; retain one style across all frames.
  for (size_t i = 0u; i < config.response_slot_separators.size(); ++i) {
    const char candidate = config.response_slot_separators[i];
    if (slot_text.find(candidate) == std::string::npos) continue;
    if (*response_slot_separator != '\0' &&
        *response_slot_separator != candidate) return kContentInvalidSlotPair;
    *response_slot_separator = candidate;
  }
  const char separator = *response_slot_separator;
  Json::Value slots(Json::objectValue);
  std::set<std::string> names;
  size_t offset = 0u;
  while (offset < slot_text.size()) {
    // Empty/one-pair fields need not select any separator.
    const size_t end = separator == '\0' ? std::string::npos
                                         : slot_text.find(separator, offset);
    const std::string pair = slot_text.substr(
        offset, end == std::string::npos ? std::string::npos : end - offset);
    char pair_assignment = '\0';
    size_t split = std::string::npos;
    for (size_t i = 0u; i < assignments.size(); ++i) {
      const size_t candidate = pair.find(assignments[i]);
      if (candidate == std::string::npos) continue;
      // V10 splits at the first configured assignment; later bytes are data.
      if (pair_assignment != '\0') {
        return kContentInvalidSlotPair;
      }
      pair_assignment = assignments[i];
      split = candidate;
    }
    if (pair.empty() || pair_assignment == '\0' ||
        (*response_assignment != '\0' &&
         *response_assignment != pair_assignment)) {
      return kContentInvalidSlotPair;
    }
    *response_assignment = pair_assignment;
    const std::string name = pair.substr(0u, split);
    const std::string value = pair.substr(split + 1u);
    if (name.empty()) return kContentEmptySlotName;
    if (value.empty() || TrimAsciiSpace(value).empty())
      return kContentEmptySlotValue;
    if (TrimAsciiSpace(name).empty() || ContainsAsciiControl(name) ||
        ContainsAsciiControl(value)) return kContentInvalidSlotPair;
    if (!names.insert(name).second) return kContentDuplicateSlot;
    slots[name] = value;
    if (end == std::string::npos) break;
    offset = end + 1u;
    if (offset == slot_text.size()) return kContentTrailingSlotSeparator;
  }
  (*frame)["domain"] = domain;
  (*frame)["intents"] = Json::Value(Json::arrayValue);
  (*frame)["intents"].append(intent);
  (*frame)["slots"] = slots;
  return kContentSuccess;
}

std::string TrimV10AsciiSpace(const std::string& text) {
  const size_t first = text.find_first_not_of(" \t\r\n\f\v");
  if (first == std::string::npos) return std::string();
  return text.substr(first, text.find_last_not_of(" \t\r\n\f\v") - first + 1u);
}

bool ContainsV10ReasoningTag(const std::string& text) {
  return text.find("<think") != std::string::npos ||
         text.find("</think") != std::string::npos ||
         text.find("<reasoning") != std::string::npos ||
         text.find("</reasoning") != std::string::npos;
}

bool ReadV10ResponsePayload(const std::string& raw, std::string* payload) {
  if (payload == nullptr || raw.find('\0') != std::string::npos) return false;
  std::string text = TrimV10AsciiSpace(raw);
  const char* opening = nullptr;
  const char* closing = nullptr;
  if (text.compare(0u, 7u, "<think>") == 0) {
    opening = "<think>";
    closing = "</think>";
  } else if (text.compare(0u, 11u, "<reasoning>") == 0) {
    opening = "<reasoning>";
    closing = "</reasoning>";
  }
  if (opening != nullptr) {
    const size_t begin = std::string(opening).size();
    const size_t end = text.find(closing, begin);
    if (end == std::string::npos ||
        ContainsV10ReasoningTag(text.substr(begin, end - begin))) return false;
    text = TrimV10AsciiSpace(text.substr(end + std::string(closing).size()));
  }
  if (text.empty() || ContainsV10ReasoningTag(text)) return false;
  payload->swap(text);
  return true;
}

ContentParseResult ParseProfileContent(const Nlu10ProtocolSettings& config,
                                       const std::string& raw_content,
                                       Json::Value* result) {
  if (result == nullptr) return kContentNullResult;
  std::string v10_content;
  if (!ReadV10ResponsePayload(raw_content, &v10_content))
    return kContentInvalidWrapper;
  const std::string& content = v10_content;
  if (content == config.response_unknown_marker) {
    (*result)["is_rejected"] = true;
    (*result)["reject_reason"] = "unknown";
    (*result)["is_multi_intent"] = false;
    (*result)["frames"] = Json::Value(Json::arrayValue);
    return kContentSuccess;
  }
  char response_frame_separator = '\0';
  const size_t marker_size = config.response_multi_marker.size();
  const bool has_multi_marker =
      content.compare(0u, marker_size, config.response_multi_marker) == 0;
  // Choose the used alternative, independent of descriptor order. All
  // candidates are structural: mixing leading/inter-frame styles is invalid.
  for (size_t i = 0u; i < config.response_frame_separators.size(); ++i) {
    const char candidate = config.response_frame_separators[i];
    if (content.find(candidate, has_multi_marker ? marker_size : 0u) ==
        std::string::npos) continue;
    if (has_multi_marker && response_frame_separator == '\0')
      response_frame_separator = candidate;
    if (candidate != response_frame_separator) return kContentInvalidWrapper;
  }
  if (has_multi_marker && response_frame_separator == '\0')
    return kContentInvalidWrapper;
  std::vector<std::string> records;
  if (response_frame_separator != '\0') {
    size_t offset = marker_size;
    // Only after the COMPLETE exact marker, accept zero or one leading byte
    // of the same style used between frames. Empty/double/trailing rows still
    // fail below; the marker alone or a single frame is never valid multi.
    if (offset < content.size() && content[offset] == response_frame_separator)
      ++offset;
    while (offset <= content.size()) {
      const size_t end = content.find(response_frame_separator, offset);
      records.push_back(content.substr(
          offset, end == std::string::npos ? std::string::npos : end - offset));
      if (end == std::string::npos) break;
      offset = end + 1u;
    }
    if (records.size() < 2u) return kContentInvalidWrapper;
  } else {
    records.push_back(content);
  }
  Json::Value frames(Json::arrayValue);
  char response_assignment = '\0';
  char response_slot_separator = '\0';
  for (size_t i = 0u; i < records.size(); ++i) {
    Json::Value frame(Json::objectValue);
    const ContentParseResult code = ParseProfileFrame(
        records[i], config, &response_assignment, &response_slot_separator, &frame);
    if (code != kContentSuccess) return code;
    frames.append(frame);
  }
  if (frames.size() > 1u && !config.allow_multi_intent_output) {
    (*result)["is_rejected"] = true;
    (*result)["reject_reason"] = "multi_intent_disabled";
    (*result)["is_multi_intent"] = false;
    (*result)["frames"] = Json::Value(Json::arrayValue);
    return kContentSuccess;
  }
  (*result)["is_rejected"] = false;
  (*result)["reject_reason"] = "";
  (*result)["is_multi_intent"] = frames.size() > 1u;
  (*result)["frames"] = frames;
  return kContentSuccess;
}

}  // namespace

std::unique_ptr<LlmProtocol> Nlu10Protocol::Create(
    const Json::Value& profile, const Json::Value& descriptor) {
  Nlu10ProtocolSettings settings;
  if (!ParseSettings(profile, descriptor, &settings))
    return std::unique_ptr<LlmProtocol>();
  return std::unique_ptr<LlmProtocol>(new Nlu10Protocol(settings));
}

bool Nlu10Protocol::BuildRequest(const Nlu06BRequest& request,
                                 Json::Value* payload) const {
  if (payload == nullptr) return false;
  *payload = Json::Value();
  std::string content;
  if (!BuildV10UserContent(request, settings_, &content)) return false;
  Json::Value built(Json::objectValue);
  built["model"] = settings_.model;
  built["messages"] = Json::Value(Json::arrayValue);
  Json::Value message(Json::objectValue);
  message["role"] = "system";
  message["content"] = settings_.system_prompt;
  built["messages"].append(message);
  message["role"] = "user";
  message["content"] = content;
  built["messages"].append(message);
  built["temperature"] = settings_.temperature;
  built["top_p"] = settings_.top_p;
  built["top_k"] = settings_.top_k;
  built["max_tokens"] = settings_.max_tokens;
  built["stream"] = false;
  built["enable_thinking"] = settings_.enable_thinking;
  *payload = built;
  return true;
}

ContentParseResult Nlu10Protocol::ParseResponse(
    const std::string& content, Json::Value* result) const {
  if (result == nullptr) return kContentNullResult;
  *result = Json::Value();
  Json::Value parsed;
  const ContentParseResult code = ParseProfileContent(settings_, content, &parsed);
  if (code == kContentSuccess) *result = parsed;
  return code;
}

std::string Nlu10Protocol::model_identity() const {
  size_t size = std::min(settings_.model.size(), size_t(128u));
  if (size < settings_.model.size()) {
    while (size > 0u &&
           (static_cast<unsigned char>(settings_.model[size]) & 0xc0u) == 0x80u)
      --size;
  }
  std::string identity = settings_.model.substr(0u, size);
  for (size_t i = 0u; i < identity.size(); ++i) {
    const unsigned char byte = static_cast<unsigned char>(identity[i]);
    if (std::iscntrl(byte) || std::isspace(byte)) identity[i] = '_';
  }
  return identity;
}

}  // namespace nlptk
