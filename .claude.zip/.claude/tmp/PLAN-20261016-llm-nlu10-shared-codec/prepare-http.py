from pathlib import Path
b=Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261016-llm-nlu10-shared-codec'); w=b/'phase1-work/cu'
s=(b/'source/cu/nlu_0_6b_http_backend.cc').read_text(encoding='utf-8')
def part(a,z): return s[s.index(a):s.index(z)]
h=s[:s.index('const size_t kMaximumLoggedModelBytes')]+part('struct HttpBackendConfig {','const char* HttpStatusCategory')
a=h.index('  std::string model;'); z=h.index('  bool diagnostic_capture_enabled;',a)
h=h[:a]+'''  int connect_timeout_ms;
  int total_timeout_ms;
  int max_response_bytes;
'''+h[z:]
h+=part('const char* HttpStatusCategory','bool ReadOptionalDouble(')
a=h.index('bool IsAsciiSpace('); z=h.index('bool ReadRequiredString(',a); h=h[:a]+h[z:]
h+=part('bool IsDiagnosticRequestIdPrefix(', 'bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output);')
p=part('bool ParseConfig(', 'bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output) {')
a=p.index('  parsed.profile_mode'); z=p.index('  if (configured_endpoint.size()',a)
p=p[:a]+'''  // Only execution-specific keys belong in OpenAIHttp. No flat/profile or
  // legacy format alias is accepted by the canonical factory signatures.
  const char* allowed[] = {"endpoint", "api_key_env", "connect_timeout_ms",
      "total_timeout_ms", "max_response_bytes", "diagnostic_capture_enabled",
      "diagnostic_capture_output_path", "diagnostic_capture_request_id_prefix",
      "diagnostic_capture_max_entries", "diagnostic_capture_max_content_bytes"};
  const Json::Value::Members names = config.getMemberNames();
  for (size_t i = 0u; i < names.size(); ++i) {
    bool known = false;
    for (size_t j = 0u; j < sizeof(allowed) / sizeof(allowed[0]); ++j)
      if (names[i] == allowed[j]) known = true;
    if (!known) return false;
  }
  const Json::Value& effective = config;
  std::string configured_endpoint;
  if (!ReadRequiredString(effective, "endpoint", &configured_endpoint))
    return false;
'''+p[z:]
p=p.replace('bool ParseConfig(const Json::Value& config, const std::string& base_path,\n                 HttpBackendConfig* output)', 'bool ParseConfig(const Json::Value& config, HttpBackendConfig* output)')
a=p.index('                       &parsed.max_response_bytes) ||'); z=p.index(' {\n    return false;',a)
p=p[:a]+'''                       &parsed.max_response_bytes))'''+p[z:]
a=p.index('  parsed.enable_thinking'); z=p.index('  parsed.diagnostic_capture_enabled',a); p=p[:a]+p[z:]
h+=p+part('bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output) {','bool ContainsTsvRecordDelimiter(')
h+=part('size_t BoundedUtf8PrefixSize(', 'const char* ResponseProtocolName(')
h+='''std::string BackendIdentityForLog(const std::string& endpoint,
                                  const LlmProtocol& protocol) {
  return std::string(" endpoint_url=") + SanitizeEndpointForLog(endpoint) +
         " model=" + protocol.model_identity() +
         " response_protocol=" + protocol.protocol_identity();
}

'''+part('enum DiagnosticCaptureWriteResult', 'class HttpBackend :')
k=part('class HttpBackend :','}  // namespace\n\nstd::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(')
k=k.replace('HttpBackend(const HttpBackendConfig& config,','HttpBackend(const HttpBackendConfig& config,\n              std::unique_ptr<LlmProtocol> protocol,')
k=k.replace(': config_(config),',': config_(config),\n        protocol_(std::move(protocol)),')
a=k.index('    if (result == nullptr'); z=k.index('    Nlu06BHttpRequest http_request;',a)
k=k[:a]+'''    if (result == nullptr) return -1;
    *result = Json::Value();
    Json::Value payload;
    if (!protocol_->BuildRequest(request, &payload)) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=input outcome=error request_id="
                 << SanitizeLogValue(request.request_id, 128u)
                 << " reason=invalid_input";
      return -1;
    }

'''+k[z:]
a=k.index('    const ContentParseResult parse_result ='); z=k.index('    if (capture_writer_',a)
k=k[:a]+'''    const ContentParseResult parse_result = protocol_->ParseResponse(content, result);
'''+k[z:]
k=k.replace('BackendIdentityForLog(config_.endpoint, config_.model,\n                                          config_.response_protocol)','BackendIdentityForLog(config_.endpoint, *protocol_)')
k=k.replace('  const HttpBackendConfig config_;','  const HttpBackendConfig config_;\n  const std::unique_ptr<LlmProtocol> protocol_;')
k=k.replace('  if (!transport || !ParseConfig(config, base_path, &parsed)) {','''  if (!transport || !config.isObject() ||
      !ParseConfig(config["OpenAIHttp"], &parsed)) {''')
needle='  std::unique_ptr<DiagnosticCaptureWriter> capture_writer;'
k=k.replace(needle,'''  std::unique_ptr<LlmProtocol> protocol = CreateLlmProtocol(config["Model"], base_path);
  if (!protocol) return std::unique_ptr<Nlu06BBackend>();
'''+needle)
k=k.replace('parsed, std::move(transport), std::move(capture_writer)))','parsed, std::move(protocol), std::move(transport), std::move(capture_writer)))')
k=k.replace('<< request.request_id','<< SanitizeLogValue(request.request_id, 128u)')
for ending in ['<< " reason=invalid_input";', '<< "max_response_bytes=" << http_request.max_response_bytes;', '<< " reason=transport";', '<< HttpStatusCategory(response.status_code);', '<< "response_bytes=" << response.body.size();', '<< " reason=write_failed";']:
 k=k.replace(ending, ending[:-1]+'\n                 << BackendIdentityForLog(config_.endpoint, *protocol_);')
h+=k+s[s.index('}  // namespace\n\nstd::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend('):]
h=h.replace('#include "cu/nlu_0_6b_http_backend.h"','#include "cu/nlu_0_6b_http_backend.h"\n\n#include "cu/llm_protocol.h"')
for inc in ['#include <fstream>\n','#include <sstream>\n','#include <set>\n']: h=h.replace(inc,'')
(w/'nlu_0_6b_http_backend.cc').write_text(h,encoding='utf-8',newline='\n')
p=w/'nlu_0_6b_http_backend.h'; h=p.read_text(encoding='utf-8'); h=h.replace('std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(', '// config is canonical NluConfig with Model and OpenAIHttp sections.\nstd::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(',1); p.write_text(h,encoding='utf-8',newline='\n')
p=w/'nlu_0_6b_manager.cc'; h=p.read_text(encoding='utf-8'); h=h.replace('    const Json::Value http_config =\n        JsonHelper::ResolveJPath(config, "OpenAIHttp");\n    impl_->backend = CreateNlu06BHttpBackend(http_config, base_path);', '    impl_->backend = CreateNlu06BHttpBackend(config, base_path);'); p.write_text(h,encoding='utf-8',newline='\n')
p=w/'BUILD'; h=p.read_text(encoding='utf-8'); pos=h.index('cc_library(\n  name = "nlu_0_6b_http_backend"'); h=h[:pos]+'''cc_library(
  name = "llm_protocol",
  srcs = ["llm_protocol.cc", "nlu_10_protocol.cc"],
  hdrs = ["llm_protocol.h", "nlu_10_protocol.h"],
  deps = [":nlu_0_6b_backend"],
  copts = ["-std=c++11", "-fPIC"],
)

cc_test(
  name = "llm_protocol_test",
  srcs = ["llm_protocol_test.cc"],
  deps = [
    ":llm_protocol",
    ":nlu_0_6b_backend",
    "@base//base:base",
    "@third_party//gtest:gtest_main",
  ],
  copts = ["-std=c++11"],
)

'''+h[pos:]; h=h.replace('  name = "nlu_0_6b_http_backend",\n  srcs', '  name = "nlu_0_6b_http_backend",\n  srcs'); pos=h.index('  name = "nlu_0_6b_http_backend",'); d=h.index('  deps = [',pos)+len('  deps = ['); h=h[:d]+'\n    ":llm_protocol",'+h[d:]; p.write_text(h,encoding='utf-8',newline='\n')
