set -euo pipefail
umask 077
cd /home/daigd/dialogue
export GIT_OPTIONAL_LOCKS=0 GIT_PAGER=cat
export CC=/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc
export CXX=/home/daigd/tools/wtp184-gcc493-sysroot/bin/g++
export PATH=/home/daigd/tools/wtp184-gcc493-sysroot/bin:/home/daigd/tools/gcc-4.9.3-centos7/bin:$PATH
unset WTP184_NLU06B_LIVE_ENDPOINT GTEST_FILTER GTEST_FAIL_FAST
verify_state() {
 python3 -I - <<'PY'
import pathlib,hashlib,subprocess
r=pathlib.Path('/home/daigd/dialogue')
assert hashlib.sha256((r/'.git/index').read_bytes()).hexdigest()=='5ce26801c99f4784a6913904ce8b1a766fc84d1be0dad7cc00fbfc688e84f179'
def git(*a):return subprocess.check_output(['git','-c','core.fsmonitor=false','-C',str(r),*a]).strip().decode()
assert git('rev-parse','HEAD')=='3f086385c81509d40ccb82813758dd1d6d24c0f3' and git('symbolic-ref','--short','HEAD')=='feat/v3-nlu-linux'
print('PROTECTION_PASS: rawindex/branch/HEAD unchanged')
PY
}
trap verify_state EXIT
for name in nlu_0_6b_offline_backend_test llm_protocol_test nlu_0_6b_http_backend_test nlu_0_6b_manager_test dialogue_system_inference_test dialogue_v3_test dialogue_v3_pipeline_test; do
 target="//cu:$name"
 base="/home/daigd/wtp184-validation-logs/PLAN-20261016-llm-nlu10-shared-codec-v1-phase2-$name"
 log="$base-2.log"
 if [[ -e "$log" ]]; then log="$base-2-$(date -u +%Y%m%dT%H%M%S%NZ).log"; fi
 set -o noclobber
 : > "$log"
 set +o noclobber
 cmd=(timeout --kill-after=15s 580s bazel test --cpu=k8 --host_cpu=k8 --define=dialogue_pipeline_v3=true --test_output=all --subcommands --cache_test_results=no "--action_env=CC=$CC" "--action_env=CXX=$CXX" "--action_env=PATH=$PATH" "$target")
 if [[ "$name" == nlu_0_6b_manager_test ]]; then cmd+=(--test_arg=--gtest_filter=-Nlu06BManagerTest.LiveOpenAIHttpCaseWhenEndpointIsInjected); fi
 {
  printf 'START_UTC=%s\nROOT=/home/daigd/dialogue\nTARGET=%s\nCOMMAND=' "$(date -u +%FT%TZ)" "$target"
  printf '%q ' "${cmd[@]}";printf '\nCOMPILER_VERSION\n';"$CXX" --version
  printf '\nCOMPILER_SYSROOT\n';"$CXX" -print-sysroot
 } >> "$log" 2>&1
 set +e
 "${cmd[@]}" >> "$log" 2>&1
 rc=$?
 set -e
 printf '\nBAZEL_EXIT=%s\nEND_UTC=%s\n' "$rc" "$(date -u +%FT%TZ)" >> "$log"
 printf '\nTARGET=%s EXIT=%s LOG=%s\n' "$target" "$rc" "$log"
 python3 -I - "$log" "$rc" <<'PY'
import sys,re,pathlib
p=pathlib.Path(sys.argv[1]);lines=p.read_text(errors='replace').splitlines()
for n,l in enumerate(lines,1):
 if re.search(r'^\[==========\]|^\[  PASSED  \]|^\[  FAILED  \]|^\[  SKIPPED \]|^Executed |^//cu:.*(?:PASSED|FAILED)|^BAZEL_EXIT=',l):print(str(n)+':'+l)
proof=[]
for n,l in enumerate(lines,1):
 if ' -c cu/' in l and ' -std=' in l.replace("'",''):
  src=re.search(r' -c (\S+)',l).group(1);std=re.findall(r'-std=([^\s\x27]+)',l)
  v3='DIALOGUE_PIPELINE_V3' in l
  proof.append('compile line '+str(n)+' source='+src+' final_std='+std[-1]+' wrapper='+str('/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc' in l)+' v3_define='+str(v3))
for l in proof: print(l)
if int(sys.argv[2]):
 print('FIRST_ACTIONABLE_FAILURE_EXCERPT')
 hits=[n for n,l in enumerate(lines) if re.search(r'error:|Failure$|^\[  FAILED  \]|^FAIL:|^ERROR: .*failed',l)]
 start=hits[0] if hits else max(0,len(lines)-20)
 for n in range(max(0,start-2),min(len(lines),start+18)):print(str(n+1)+':'+lines[n])
PY
 if [[ "$rc" -ne 0 ]]; then printf 'STOP: later ordered targets UNRUN\n';exit "$rc"; fi
done
printf '\nALL_SEVEN_NATIVE_TARGETS_PASS\n'
