from pathlib import Path
import re
b=Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261016-llm-nlu10-shared-codec'); w=b/'phase1-work/cu'
s=(b/'source/cu/nlu_0_6b_http_backend_test.cc').read_text(encoding='utf-8')
def part(a,z): return s[s.index(a):s.index(z)]
prefix=s[:s.index('TEST(Nlu06BHttpBackendTest, MapsExactPipeResult')]
prefix=prefix.replace('#include <cstdio>','#include <cstdio>\n#include <cstdlib>')
a=prefix.index('Json::Value MakeConfig()'); z=prefix.index('class ConstantTransport',a)
prefix=prefix[:a]+'''std::string TransportFixtureRoot() {
  const char* root = std::getenv("TEST_TMPDIR");
  return root == nullptr ? std::string() : std::string(root);
}

Json::Value MakeConfig() {
  const std::string root = TransportFixtureRoot();
  Json::Value protocol = JsonHelper::ParseJsonFromString(R"JSON({
    "protocol":"nlu_10", "request_field_prefixes":["history:","query: "],
    "field_delimiter":"\\t", "request_slot_assignment":"=",
    "request_slot_separator":",", "response_slot_assignment":"=",
    "response_slot_separator":",", "response_frame_separator":";",
    "response_unknown_marker":"unknown", "response_multi_marker":"multi:"
  })JSON");
  Json::Value catalog = JsonHelper::ParseJsonFromString(R"JSON({"profiles":{
    "transport-fixture":{"model":"qwen3", "system_prompt":"parse vehicle semantics",
    "protocol_path":"transport-protocol.json", "stream":false,
    "temperature":0.01,"top_p":0.95,"top_k":20,"max_tokens":1024,
    "enable_thinking":false,"allow_multi_intent_output":true}}})JSON");
  std::ofstream descriptor((root + "/transport-protocol.json").c_str());
  descriptor << JsonHelper::ToString(protocol);
  std::ofstream profiles((root + "/transport-catalog.json").c_str());
  profiles << JsonHelper::ToString(catalog);
  Json::Value config(Json::objectValue);
  config["Model"]["profile_catalog_path"] = "transport-catalog.json";
  config["Model"]["profile"] = "transport-fixture";
  config["OpenAIHttp"]["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  return config;
}

'''+prefix[z:]
prefix=prefix.replace('config["diagnostic_', 'config["OpenAIHttp"]["diagnostic_')
prefix=prefix.replace('      config, std::unique_ptr<Nlu06BHttpTransport>', '      config, TransportFixtureRoot(), std::unique_ptr<Nlu06BHttpTransport>')
prefix=prefix.replace('  request.histories.append("prior query");\n','')
# Transport/capture tests retain purpose, with canonical config and text.
transport=part('TEST(Nlu06BHttpBackendTest, TransportEnvelopeStatusAndSizeFailuresClearResult)', '}  // namespace\n\nconst char kV10SystemPromptForTest')
transport=transport.replace('config["', 'config["OpenAIHttp"]["')
# The replacement above includes variable suffixes, intentionally updating
# small_config, missing_endpoint_env, capture_bad_prefix, etc.
transport=re.sub(r'(\w+)\.removeMember\("(endpoint)"\)',r'\1["OpenAIHttp"].removeMember("\2")',transport)
transport=transport.replace('domain=d|intent=i|slot=', 'd\u0009i').replace('domain=vehicle|intent=open_window|slot=position：front', 'vehicle\u0009open_window\u0009position=front').replace('domain=vehicle|intent=open_window|slot=note：', 'vehicle\u0009open_window\u0009note=').replace('domain=vehicle|intent=open_window|slot=', 'vehicle\u0009open_window')
transport=transport.replace('"missing_pipe"', '"missing_tab"')
transport=transport.replace('      MakeCaptureConfig(path, "parallel-", 8, 4096),\n', '      MakeCaptureConfig(path, "parallel-", 8, 4096), TransportFixtureRoot(),\n')
a=transport.index('  struct Case {',transport.index('DecodedDiagnosticsPreserveExactBytesAndReset')); z=transport.index('  EXPECT_EQ(std::string(u8"：")',a)
transport=transport[:a]+'''  struct Case { std::string content; int code; };
  const Case cases[] = {
      {"  vehicle\\topen_window  \\n", 0},
      {"vehicle\\topen_window\\tname=车窗,position=副驾", 0},
      {"vehicle\\topen_window\\tname：车窗；position：副驾\\n", -1},
      {"vehicle\\topen_window\\tfirst=1,second:2", -1},
      {"", -1}, {"未解析\\t原文\\n：；=|", -1}};
'''+transport[z:]
transport=transport.replace('    config["OpenAIHttp"]["response_protocol"] = cases[i].protocol;\n','')
transport=transport.replace('bad_top_p["top_p"] = 0.0;', 'bad_top_p["OpenAIHttp"]["max_response_bytes"] = 0;')
# Config mutation lines use other variable names; wrap every remaining flat key.
keys=['endpoint','connect_timeout_ms','total_timeout_ms','top_p','response_protocol','api_key_env','diagnostic_capture_enabled','diagnostic_capture_output_path','diagnostic_capture_request_id_prefix','diagnostic_capture_max_entries','diagnostic_capture_max_content_bytes']
for key in keys:
 transport=re.sub(r'\b(\w+)\["'+key+r'"\]',r'\1["OpenAIHttp"]["'+key+'"]',transport)
transport=transport.replace('["OpenAIHttp"]["OpenAIHttp"]','["OpenAIHttp"]')
transport=transport.replace('bad_top_p["OpenAIHttp"]["top_p"] = 0.0;', 'bad_top_p["OpenAIHttp"]["max_response_bytes"] = 0;')
# Preserve bounded schema detail and leakage test purposes from retired fixtures.
logs=part('TEST(Nlu06BHttpBackendTest, LogsBoundedContentSchemaDetails)', 'TEST(Nlu06BHttpBackendTest, RejectsMalformedTsvV1Content)')
a=logs.index('  const FailureCase failures[]'); z=logs.index('  for (size_t i = 0;',a)
logs=logs[:a]+'''  const FailureCase failures[] = {
      {"vehicle", "missing_tab"},
      {"multi:fm\\tstop;\\tstop", "empty_domain"},
      {"vehicle\\t\\tname=window", "empty_intent"},
      {"unknown\\tstop", "invalid_domain_field"},
      {"vehicle\\top\\x01en", "invalid_intent_field"},
      {"vehicle\\topen\\tname", "invalid_slot_pair"},
      {"vehicle\\topen\\t=window", "empty_slot_name"},
      {"vehicle\\topen\\tname=,area=driver", "empty_slot_value"},
      {"vehicle\\topen\\tname=window,name=roof", "duplicate_slot"},
      {"vehicle\\topen\\tname=window,", "trailing_slot_separator"},
      {"vehicle\\topen\\tname=window\\textra", "extra_tab"},
      {"`vehicle\\topen`", "invalid_wrapper"}};
'''+logs[z:]
logs=logs.replace('  config["endpoint"] = unsafe_endpoint;','  config["OpenAIHttp"]["endpoint"] = unsafe_endpoint;')
logs=logs.replace('  config["model"] = unsafe_model;\n  config["response_protocol"] = "tsv_v1";','''  Json::Value catalog = JsonHelper::ParseJsonFromFile(
      TransportFixtureRoot() + "/transport-catalog.json");
  catalog["profiles"]["transport-fixture"]["model"] = unsafe_model;
  {
    std::ofstream output((TransportFixtureRoot() + "/transport-catalog.json").c_str());
    output << JsonHelper::ToString(catalog);
  }''')
logs=logs.replace('response_protocol=tsv_v1','response_protocol=nlu_10')
# Canonical-only helpers, preserving friendly profile names and arbitrary filenames.
helpers='''const char kV10SystemPromptForTest[] =
    u8"你是智能座舱的语义算法专家，你接受用户的Query，进行深度分析，给出语义标签理解结果。对于符合：不完整，不通顺，无意义，结构混乱的无效句式，输出标签:unknown；多意图句式，输出标签：multi";

Json::Value MakeProfileSelector(const std::string& profile) {
  Json::Value config(Json::objectValue);
  config["Model"]["profile"] = profile;
  config["Model"]["profile_catalog_path"] = "catalog.json";
  config["OpenAIHttp"]["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  config["OpenAIHttp"]["connect_timeout_ms"] = 1200;
  config["OpenAIHttp"]["total_timeout_ms"] = 3400;
  return config;
}

Json::Value MakeProfileProtocol(const std::string& protocol_id,
                                const Json::Value& assignments) {
  Json::Value protocol(Json::objectValue);
  protocol["protocol"] = protocol_id;
  protocol["request_field_prefixes"] = Json::Value(Json::arrayValue);
  protocol["request_field_prefixes"].append("history:");
  protocol["request_field_prefixes"].append("query: ");
  protocol["field_delimiter"] = "\\t";
  protocol["request_slot_assignment"] = "=";
  protocol["request_slot_separator"] = ",";
  protocol["response_slot_assignment"] = assignments;
  protocol["response_slot_separator"] = ",";
  protocol["response_frame_separator"] = ";";
  protocol["response_unknown_marker"] = "unknown";
  protocol["response_multi_marker"] = "multi:";
  return protocol;
}

'''+part('void WriteProfileProtocol(', 'void WriteProfileFiles(')+'''void WriteProfileFiles(const std::string& root, const std::string& profile,
                       const std::string& protocol_id, bool allow_multi,
                       const Json::Value& assignments = Json::Value("=")) {
  Json::Value selected(Json::objectValue);
  selected["model"] = "qwen3_nlu";
  selected["system_prompt"] = kV10SystemPromptForTest;
  selected["protocol_path"] = "protocol.json";
  selected["stream"] = false;
  selected["temperature"] = 0.2;
  selected["top_p"] = 0.8;
  selected["top_k"] = 12;
  selected["max_tokens"] = 256;
  selected["enable_thinking"] = false;
  selected["allow_multi_intent_output"] = allow_multi;
  Json::Value catalog(Json::objectValue);
  catalog["profiles"][profile] = selected;
  std::ofstream output((root + "/catalog.json").c_str());
  output << JsonHelper::ToString(catalog);
  WriteProfileProtocol(root, MakeProfileProtocol(protocol_id, assignments));
}

'''+part('Json::Value MakeEmptyHistoryOptionForTest(', 'Json::Value MakeEmptyHistoryProtocolForTest(')
tail=s[s.index('namespace {\n\nstd::string WriteV10FilesForTest'):]
a=tail.index('TEST(Nlu06BHttpBackendTest, ProfileV10DoesNotRelaxOlderNamedProfiles)'); z=tail.index('TEST(Nlu06BHttpBackendTest, ProfileV10PreservesRawCapture',a); tail=tail[:a]+tail[z:]
tail=tail.replace('nlu_06b_v10','nlu_10').replace('const char* fields[] = {"version",','const char* fields[] = {"protocol",')
# Previously rejected one-leading row is now accepted; retain double negative.
tail=tail.replace('markers[m] + "%vehicle#open%music#play",  // No leading record separator.', 'markers[m] + "%%vehicle#open%music#play",  // Repeated leading separator.')
a=tail.index('    if (m < 2u) {'); z=tail.index('    WriteProfileProtocol(root, protocol);',a)
tail=tail[:a]+'''    protocol["response_unknown_marker"] = unknowns[m];
    protocol["response_multi_marker"] = markers[m];
'''+tail[z:]
a=tail.index('  Json::Value catalog =',tail.index('ProfileV10PreservesRawCapture')); z=tail.index('  const std::string raw',a)
tail=tail[:a]+'''  Json::Value config = MakeProfileSelector("v10");
  Json::Value& profile = config["OpenAIHttp"];
  profile["diagnostic_capture_enabled"] = true;
  profile["diagnostic_capture_output_path"] = capture_path;
  profile["diagnostic_capture_request_id_prefix"] = "v10-capture-";
  profile["diagnostic_capture_max_entries"] = 1;
  profile["diagnostic_capture_max_content_bytes"] = 1024;
'''+tail[z:]
tail=tail.replace('  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(root, "v10", raw, &fake);','''  std::unique_ptr<FakeTransport> transport(new FakeTransport(0, 200, MakeEnvelope(raw)));
  fake = transport.get();
  std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
      config, root, std::unique_ptr<Nlu06BHttpTransport>(transport.release()));''',1)
a=tail.index('TEST(Nlu06BHttpBackendTest, SelectedProtocolFilenameDoesNotSelectLayout)'); z=tail.index('TEST(Nlu06BHttpBackendTest, ProfileV10FrameAlternativesAreOrderIndependent)',a)
tail=tail[:a]+'''TEST(Nlu06BHttpBackendTest, SelectedProtocolFilenameDoesNotSelectLayout) {
  const char* filenames[] = {"v3.json", "v42.json", "v10.json", "v11.json"};
  for (size_t i = 0u; i < 4u; ++i) {
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string root = WriteV10FilesForTest(&directory);
    directory.NewFile(filenames[i]);
    Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
    protocol["request_history_separator"] = "~";
    WriteSelectedProtocolForTest(root, "v10", filenames[i], protocol);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", "multi:fm\\tstop;music\\tplay", &fake);
    ASSERT_TRUE(backend);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeProfileHistoryRequest(), &result));
    EXPECT_EQ(2u, result["frames"].size());
    EXPECT_EQ("history:history query\\tvehicle\\topen_window\\talpha=first,zeta=last~query: current query",
              ReadPayload(fake)["messages"][1u]["content"].asString());
  }
}

'''+tail[z:]
out=prefix+logs+transport+'}  // namespace\n\n'+helpers+tail
(w/'nlu_0_6b_http_backend_test.cc').write_text(out,encoding='utf-8',newline='\n')
