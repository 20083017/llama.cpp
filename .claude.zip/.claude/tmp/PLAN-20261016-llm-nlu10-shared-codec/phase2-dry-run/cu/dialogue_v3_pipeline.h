// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_DIALOGUE_V3_PIPELINE_H_
#define CU_DIALOGUE_V3_PIPELINE_H_

#include <map>
#include <string>
#include <utility>
#include <vector>

#include "cu/nlu_0_6b_manager.h"
#include "nlu/semantic_frames.h"

namespace nlptk {

struct DialogueV3Input {
  std::string request_id;
  std::string query;
  std::string original_query;
  bool enable_hotfix;
  std::map<std::string, std::string> hotfix_context;

  DialogueV3Input() : enable_hotfix(false) {}
};

struct DialogueV3RouteResult {
  bool guarded;
  bool is_rejected;
  bool is_multi_intent;
  bool is_slot_immutable;
  std::string reject_reason;
  std::string result_source;
  std::string matched_rule;
  std::vector<std::pair<std::string, std::string> > guard_slots;
  // Per-call diagnostics survive business validation, but never enter frames.
  Json::Value nlu_result;
  bool is_hit_rule;
  bool nlu_is_multi_intent;

  DialogueV3RouteResult();
  void Clear();
};

class DialogueV3Guard {
 public:
  virtual ~DialogueV3Guard() {}
  virtual bool IsGuarded(
      const std::string& request_id, const std::string& original_query,
      std::vector<std::pair<std::string, std::string> >* slots) const = 0;
};

class DialogueV3NluProcessor {
 public:
  virtual ~DialogueV3NluProcessor() {}
  virtual int Process(const Nlu06BRequest& request,
                      nlu::SemanticFrames* output,
                      Nlu06BResultInfo* info) const = 0;
};

class DialogueV3Pipeline {
 public:
  DialogueV3Pipeline();
  ~DialogueV3Pipeline();

  // Returns 1 when HotQuery already supplied the complete response, 0 when
  // output owns one complete routed semantic result, and -1 on error.
  int Route(const DialogueV3Input& input,
            const Nlu06BRequest& model_request, int hot_query_code,
            const nlu::SemanticFrames* hot_query_frames,
            const DialogueV3Guard* guard,
            const DialogueV3NluProcessor* nlu_processor,
            nlu::SemanticFrames* output,
            DialogueV3RouteResult* result) const;

 private:
  DialogueV3Pipeline(const DialogueV3Pipeline&) = delete;
  DialogueV3Pipeline& operator=(const DialogueV3Pipeline&) = delete;
};

}  // namespace nlptk

#endif  // CU_DIALOGUE_V3_PIPELINE_H_
