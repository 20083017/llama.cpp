// Copyright 2022 the project authors. All Rights Reserved.

#ifndef CU_DIALOGUE_H_
#define CU_DIALOGUE_H_

#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
#include "cu/dialogue_v3.h"
#else
#include "cu/dialogue_v2.h"
#endif

#endif  // CU_DIALOGUE_H_
