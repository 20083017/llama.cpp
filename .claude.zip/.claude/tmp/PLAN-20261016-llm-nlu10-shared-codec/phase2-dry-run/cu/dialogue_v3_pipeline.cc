// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/dialogue_v3_pipeline.h"

#include "cu/dialogue_internal.h"
#include "base/logging.h"
#include "nlu/semantic_frame.h"

namespace nlptk {
namespace {

const char kHotQuerySource[] = "hotquery";
const char kHotFixSource[] = "hotfix";
const char kMockSource[] = "mock";
const char kNlu06BSource[] = "nlu06b";
const char kGuardSource[] = "guard";
const char kSensitiveDomain[] = "sensitive";
const char kRejectedDomain[] = "other";

void AddSyntheticFrame(const std::string& domain,
                       nlu::SemanticFrames* output) {
  nlu::SemanticFrame* frame = new nlu::SemanticFrame();
  frame->domain = {domain, 1.0f};
  frame->intents.emplace_back(domain, 1.0f);
  output->push_back(frame);
}

}  // namespace

DialogueV3RouteResult::DialogueV3RouteResult() { Clear(); }

void DialogueV3RouteResult::Clear() {
  guarded = false;
  is_rejected = false;
  is_multi_intent = false;
  is_slot_immutable = false;
  reject_reason.clear();
  result_source.clear();
  matched_rule.clear();
  guard_slots.clear();
  nlu_result = Json::Value();
  is_hit_rule = false;
  nlu_is_multi_intent = false;
}

DialogueV3Pipeline::DialogueV3Pipeline() {}
DialogueV3Pipeline::~DialogueV3Pipeline() {}

int DialogueV3Pipeline::Route(
    const DialogueV3Input& input, const Nlu06BRequest& model_request,
    int hot_query_code, const nlu::SemanticFrames* hot_query_frames,
    const DialogueV3Guard* guard,
    const DialogueV3NluProcessor* nlu_processor,
    nlu::SemanticFrames* output, DialogueV3RouteResult* result) const {
  if (result != nullptr) {
    result->Clear();
  }
  if (output == nullptr || result == nullptr || input.request_id.empty() ||
      input.query.empty() || model_request.request_id != input.request_id ||
      model_request.query != input.query) {
    LOG(ERROR) << "component=v3_pipeline event=v3_route_result stage=input "
               << "outcome=error request_id=" << input.request_id
               << " reason=invalid_input";
    return -1;
  }
  output->clear();

  if (hot_query_code < 0) {
    LOG(ERROR) << "component=v3_pipeline event=v3_route_result "
               << "stage=hotquery outcome=error request_id="
               << input.request_id << " reason=hotquery_failed";
    return -1;
  }
  if (hot_query_code > 0) {
    if (hot_query_frames == nullptr ||
        !dialogue_internal::AreCompleteSemanticFrames(*hot_query_frames)) {
      LOG(ERROR) << "component=v3_pipeline event=v3_route_result "
                 << "stage=hotquery outcome=error request_id="
                 << input.request_id << " reason=invalid_frames";
      return -1;
    }
    result->is_multi_intent = hot_query_frames->size() > 1;
    result->result_source = kHotQuerySource;
    LOGI << "component=v3_pipeline event=v3_route_result stage=hotquery "
         << "outcome=ok request_id=" << input.request_id
         << " source=hotquery rejected=0 multi_intent="
         << result->is_multi_intent
         << " frame_count=" << hot_query_frames->size();
    return 1;
  }

  if (guard != nullptr &&
      guard->IsGuarded(input.request_id, input.original_query,
                       &result->guard_slots)) {
    result->guarded = true;
    result->result_source = kGuardSource;
    AddSyntheticFrame(kSensitiveDomain, output);
    LOGI << "component=v3_pipeline event=v3_route_result stage=guard "
         << "outcome=ok request_id=" << input.request_id
         << " source=guard rejected=0 multi_intent=0 frame_count=1";
    return 0;
  }

  if (nlu_processor == nullptr) {
    LOG(ERROR) << "component=v3_pipeline event=v3_route_result stage=nlu "
               << "outcome=error request_id=" << input.request_id
               << " reason=processor_unavailable";
    return -1;
  }
  Nlu06BResultInfo info;
  const int nlu_code = nlu_processor->Process(model_request, output, &info);
  result->nlu_result.swap(info.nlu_result);
  result->is_hit_rule = info.is_hit_rule;
  if (nlu_code < 0) {
    output->clear();
    return -1;
  }
  result->nlu_is_multi_intent = info.is_multi_intent;

  if (info.is_rejected) {
    if (!output->empty() || info.reject_reason.empty() ||
        info.is_multi_intent ||
        (info.result_source != kMockSource &&
         info.result_source != kNlu06BSource)) {
      output->clear();
      LOG(ERROR) << "component=v3_pipeline event=v3_route_result stage=nlu "
                 << "outcome=error request_id=" << input.request_id
                 << " reason=invalid_rejected_contract";
      return -1;
    }
  } else if (!info.reject_reason.empty() ||
             !dialogue_internal::AreCompleteSemanticFrames(*output) ||
             info.is_multi_intent != (output->size() > 1) ||
             (info.result_source != kHotFixSource &&
              info.result_source != kMockSource &&
              info.result_source != kNlu06BSource)) {
    output->clear();
    LOG(ERROR) << "component=v3_pipeline event=v3_route_result stage=nlu "
               << "outcome=error request_id=" << input.request_id
               << " reason=invalid_accepted_contract";
    return -1;
  }
  result->is_rejected = info.is_rejected;
  result->is_multi_intent = info.is_multi_intent;
  result->is_slot_immutable = info.is_slot_immutable;
  result->reject_reason = info.reject_reason;
  result->result_source = info.result_source;
  result->matched_rule = info.matched_rule;
  if (info.is_rejected) {
    AddSyntheticFrame(kRejectedDomain, output);
    LOGI << "component=v3_pipeline event=v3_route_result stage=nlu "
         << "outcome=ok request_id=" << input.request_id
         << " source=" << info.result_source
         << " rejected=1 multi_intent=0 frame_count=1";
    return 0;
  }
  LOGI << "component=v3_pipeline event=v3_route_result stage=nlu outcome=ok "
       << "request_id=" << input.request_id
       << " source=" << info.result_source << " rejected=0 multi_intent="
       << info.is_multi_intent << " frame_count=" << output->size();
  return 0;
}

}  // namespace nlptk
