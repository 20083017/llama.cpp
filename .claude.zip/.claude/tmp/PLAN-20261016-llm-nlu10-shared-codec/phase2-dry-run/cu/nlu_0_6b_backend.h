// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_NLU_0_6B_BACKEND_H_
#define CU_NLU_0_6B_BACKEND_H_

#include <map>
#include <string>

#include "json/json.h"

namespace nlptk {

struct Nlu06BRequest {
  std::string request_id;
  std::string query;
  Json::Value histories;
  Json::Value model_last_context;
  bool enable_hotfix;
  std::string hotfix_query;
  std::map<std::string, std::string> hotfix_context;

  Nlu06BRequest() : histories(Json::arrayValue), enable_hotfix(false) {}
};

class Nlu06BBackend {
 public:
  virtual ~Nlu06BBackend() {}

  virtual int Process(const Nlu06BRequest& request,
                      Json::Value* result) const = 0;
  virtual const char* result_source() const = 0;
};

}  // namespace nlptk

#endif  // CU_NLU_0_6B_BACKEND_H_
