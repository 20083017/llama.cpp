// Copyright 2022 the project authors. All Rights Reserved.

#ifndef CU_DIALOGUE_SYSTEM_H_
#define CU_DIALOGUE_SYSTEM_H_

#include <string>

extern "C" {

typedef void (*InferenceCallback)(const char *token, void *stream);

typedef void (*StreamingProcessCallback)(const char *content, void *custom_ptr);

bool Initialize(const char *config_file);

const char *Process(const char *query);

bool StreamingProcess(const char *query, void *custom_ptr, StreamingProcessCallback callback);

const char *LLMInference(const char *prompt, const char *config, void *custom_ptr, 
                         InferenceCallback callback);

void Release();

}  // extern "C"

#endif  // CU_DIALOGUE_SYSTEM_H_
