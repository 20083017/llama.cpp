// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/dialogue_v3_pipeline.h"

#include <string>
#include <utility>
#include <vector>

#include "gtest/gtest.h"
#include "nlu/semantic_frame.h"

namespace nlptk {
namespace {

void AddFrame(const std::string& domain, const std::string& intent,
              nlu::SemanticFrames* frames) {
  nlu::SemanticFrame* frame = new nlu::SemanticFrame();
  frame->domain = {domain, 1.0f};
  frame->intents.emplace_back(intent, 1.0f);
  frames->push_back(frame);
}

DialogueV3Input MakeInput() {
  DialogueV3Input input;
  input.request_id = "request-1";
  input.query = "normalized query";
  input.original_query = "Original Query";
  input.enable_hotfix = true;
  input.hotfix_context["first_wakeup"] = "false";
  return input;
}

Nlu06BRequest MakeRequest(const DialogueV3Input& input) {
  Nlu06BRequest request;
  request.request_id = input.request_id;
  request.query = input.query;
  request.enable_hotfix = input.enable_hotfix;
  request.hotfix_query = input.query;
  request.hotfix_context = input.hotfix_context;
  request.histories.append("history");
  request.model_last_context["last_domain"] = "vehicle";
  return request;
}

class FakeGuard : public DialogueV3Guard {
 public:
  FakeGuard(bool guarded, std::vector<std::string>* events)
      : guarded_(guarded), calls_(0), events_(events) {}

  bool IsGuarded(
      const std::string&, const std::string&,
      std::vector<std::pair<std::string, std::string> >* slots) const override {
    ++calls_;
    if (events_ != nullptr) {
      events_->push_back("guard");
    }
    if (guarded_) {
      slots->push_back(std::make_pair("reason", "sensitive"));
    }
    return guarded_;
  }

  int calls() const { return calls_; }

 private:
  bool guarded_;
  mutable int calls_;
  std::vector<std::string>* events_;
};

class FakeNlu : public DialogueV3NluProcessor {
 public:
  FakeNlu(const std::string& source, bool rejected, bool malformed,
          std::vector<std::string>* events)
      : source_(source),
        rejected_(rejected),
        malformed_(malformed),
        calls_(0),
        events_(events) {}

  int Process(const Nlu06BRequest& request, nlu::SemanticFrames* output,
              Nlu06BResultInfo* info) const override {
    ++calls_;
    last_request_ = request;
    if (events_ != nullptr) {
      events_->push_back("nlu");
    }
    info->Clear();
    info->result_source = source_;
    info->is_rejected = rejected_;
    info->nlu_result = diagnostic_text;
    info->is_hit_rule = diagnostic_rule_hit;
    info->is_multi_intent = multi_intent;
    if (fail) {
      output->push_back(new nlu::SemanticFrame());
      return -1;
    }
    if (rejected_) {
      info->reject_reason = "mock rejection";
      return 0;
    }
    if (malformed_) {
      output->push_back(new nlu::SemanticFrame());
      return 0;
    }
    AddFrame("vehicle", "open_window", output);
    if (multi_intent) {
      AddFrame("media", "play_music", output);
    }
    return 0;
  }

  Json::Value diagnostic_text;
  bool diagnostic_rule_hit {false};
  bool multi_intent {false};
  bool fail {false};

  int calls() const { return calls_; }
  const Nlu06BRequest& last_request() const { return last_request_; }

 private:
  std::string source_;
  bool rejected_;
  bool malformed_;
  mutable int calls_;
  mutable Nlu06BRequest last_request_;
  std::vector<std::string>* events_;
};

TEST(DialogueV3PipelineTest, HotQueryWinsBeforeGuardAndNlu) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  std::vector<std::string> events;
  FakeGuard guard(true, &events);
  FakeNlu nlu("mock", false, false, &events);
  nlu::SemanticFrames hot_frames;
  AddFrame("media", "play", &hot_frames);
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;

  EXPECT_EQ(1, pipeline.Route(input, request, 1, &hot_frames, &guard, &nlu,
                              &output, &result));
  EXPECT_TRUE(output.empty());
  EXPECT_EQ("hotquery", result.result_source);
  EXPECT_EQ(0, guard.calls());
  EXPECT_EQ(0, nlu.calls());
  EXPECT_TRUE(events.empty());
}

TEST(DialogueV3PipelineTest, QueryGuardWinsBeforeHotFixAndMock) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  std::vector<std::string> events;
  FakeGuard guard(true, &events);
  FakeNlu nlu("hotfix", false, false, &events);
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;

  EXPECT_EQ(0, pipeline.Route(input, request, 0, nullptr, &guard, &nlu,
                              &output, &result));
  ASSERT_EQ(1u, output.size());
  EXPECT_EQ("sensitive", output[0]->domain.value);
  EXPECT_TRUE(result.guarded);
  ASSERT_EQ(1u, result.guard_slots.size());
  EXPECT_EQ(1, guard.calls());
  EXPECT_EQ(0, nlu.calls());
  ASSERT_EQ(1u, events.size());
  EXPECT_EQ("guard", events[0]);
}

TEST(DialogueV3PipelineTest, NluReceivesProjectedQueryHistoryAfterGuardMiss) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  std::vector<std::string> events;
  FakeGuard guard(false, &events);
  FakeNlu nlu("hotfix", false, false, &events);
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;

  EXPECT_EQ(0, pipeline.Route(input, request, 0, nullptr, &guard, &nlu,
                              &output, &result));
  ASSERT_EQ(1u, output.size());
  EXPECT_EQ("vehicle", output[0]->domain.value);
  EXPECT_EQ("hotfix", result.result_source);
  ASSERT_EQ(2u, events.size());
  EXPECT_EQ("guard", events[0]);
  EXPECT_EQ("nlu", events[1]);
  ASSERT_EQ(1u, nlu.last_request().histories.size());
  EXPECT_EQ("vehicle",
            nlu.last_request().model_last_context["last_domain"].asString());
}

TEST(DialogueV3PipelineTest, SuccessfulMockRejectionCreatesCompleteOtherFrame) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  FakeNlu nlu("mock", true, false, nullptr);
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;

  EXPECT_EQ(0, pipeline.Route(input, request, 0, nullptr, nullptr, &nlu,
                              &output, &result));
  ASSERT_EQ(1u, output.size());
  EXPECT_EQ("other", output[0]->domain.value);
  ASSERT_EQ(1u, output[0]->intents.size());
  EXPECT_EQ("other", output[0]->intents[0].value);
  EXPECT_TRUE(result.is_rejected);
  EXPECT_EQ("mock rejection", result.reject_reason);
}

TEST(DialogueV3PipelineTest, Nlu06BSourceAcceptsValidResultAndRejection) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);

  FakeNlu accepted("nlu06b", false, false, nullptr);
  nlu::SemanticFrames accepted_output;
  DialogueV3RouteResult accepted_result;
  ASSERT_EQ(0, pipeline.Route(input, request, 0, nullptr, nullptr, &accepted,
                              &accepted_output, &accepted_result));
  ASSERT_EQ(1u, accepted_output.size());
  EXPECT_EQ("vehicle", accepted_output[0]->domain.value);
  EXPECT_EQ("nlu06b", accepted_result.result_source);
  EXPECT_FALSE(accepted_result.is_rejected);

  FakeNlu rejected("nlu06b", true, false, nullptr);
  nlu::SemanticFrames rejected_output;
  DialogueV3RouteResult rejected_result;
  ASSERT_EQ(0, pipeline.Route(input, request, 0, nullptr, nullptr, &rejected,
                              &rejected_output, &rejected_result));
  ASSERT_EQ(1u, rejected_output.size());
  EXPECT_EQ("other", rejected_output[0]->domain.value);
  EXPECT_EQ("nlu06b", rejected_result.result_source);
  EXPECT_TRUE(rejected_result.is_rejected);
}

TEST(DialogueV3PipelineTest, MalformedNlu06BResultFailsExplicitly) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  FakeNlu malformed("nlu06b", false, true, nullptr);
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;

  EXPECT_LT(pipeline.Route(input, request, 0, nullptr, nullptr, &malformed,
                           &output, &result),
            0);
  EXPECT_TRUE(output.empty());
  EXPECT_TRUE(result.result_source.empty());
}

TEST(DialogueV3PipelineTest, InvalidSourceOrIncompleteFrameFailsExplicitly) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  for (int bad_case = 0; bad_case < 2; ++bad_case) {
    FakeNlu nlu(bad_case == 0 ? "network" : "mock", false,
                bad_case == 1, nullptr);
    nlu::SemanticFrames output;
    DialogueV3RouteResult result;
    EXPECT_LT(pipeline.Route(input, request, 0, nullptr, nullptr, &nlu,
                             &output, &result),
              0);
    EXPECT_TRUE(output.empty());
  }
}

TEST(DialogueV3PipelineTest, RequestIdentityMismatchFailsWithoutCallingNlu) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  Nlu06BRequest request = MakeRequest(input);
  request.request_id = "wrong-request";
  FakeNlu nlu("mock", false, false, nullptr);
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;

  EXPECT_LT(pipeline.Route(input, request, 0, nullptr, nullptr, &nlu,
                           &output, &result),
            0);
  EXPECT_EQ(0, nlu.calls());
}

TEST(DialogueV3PipelineTest, DecodedErrorKeepsTextAndRuleButClearsBusiness) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  FakeNlu failed("nlu06b", true, false, nullptr);
  failed.diagnostic_text = "未解析\t原文\n：；=|";
  failed.diagnostic_rule_hit = true;
  failed.fail = true;
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;
  ASSERT_LT(pipeline.Route(input, request, 0, nullptr, nullptr, &failed,
                           &output, &result), 0);
  EXPECT_TRUE(output.empty());
  EXPECT_FALSE(result.is_rejected);
  EXPECT_FALSE(result.is_multi_intent);
  EXPECT_FALSE(result.is_slot_immutable);
  EXPECT_FALSE(result.nlu_is_multi_intent);
  EXPECT_TRUE(result.result_source.empty());
  EXPECT_TRUE(result.reject_reason.empty());
  EXPECT_TRUE(result.matched_rule.empty());
  EXPECT_TRUE(result.is_hit_rule);
  ASSERT_TRUE(result.nlu_result.isString());
  EXPECT_EQ(failed.diagnostic_text.asString(), result.nlu_result.asString());
  FakeGuard guard(true, nullptr);
  ASSERT_EQ(0, pipeline.Route(input, request, 0, nullptr, &guard, &failed,
                              &output, &result));
  EXPECT_TRUE(result.guarded);
  EXPECT_TRUE(result.nlu_result.isNull());
  EXPECT_FALSE(result.is_hit_rule);
  EXPECT_EQ(1, failed.calls());
}

TEST(DialogueV3PipelineTest, LaterValidationRetainsOnlyReportedDiagnostics) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  for (bool rejected : {false, true}) {
    FakeNlu invalid(rejected ? "invalid-source" : "nlu06b", rejected,
                    !rejected, nullptr);
    invalid.diagnostic_text = "";
    invalid.diagnostic_rule_hit = true;
    nlu::SemanticFrames output;
    DialogueV3RouteResult result;
    ASSERT_LT(pipeline.Route(input, request, 0, nullptr, nullptr, &invalid,
                             &output, &result), 0);
    EXPECT_TRUE(output.empty());
    EXPECT_FALSE(result.is_rejected);
    EXPECT_FALSE(result.is_multi_intent);
    EXPECT_TRUE(result.reject_reason.empty());
    EXPECT_TRUE(result.result_source.empty());
    EXPECT_TRUE(result.is_hit_rule);
    ASSERT_TRUE(result.nlu_result.isString());
    EXPECT_EQ("", result.nlu_result.asString());
    result.Clear();
    EXPECT_TRUE(result.nlu_result.isNull());
    EXPECT_FALSE(result.is_hit_rule);
    EXPECT_FALSE(result.nlu_is_multi_intent);
  }
}

TEST(DialogueV3PipelineTest, ClassificationIsNotHotQueryOrFinalFrameCount) {
  DialogueV3Pipeline pipeline;
  const DialogueV3Input input = MakeInput();
  const Nlu06BRequest request = MakeRequest(input);
  FakeNlu multi("nlu06b", false, false, nullptr);
  multi.multi_intent = true;
  multi.diagnostic_text = "flag:multi|vehicle\topen_window\t|media\tplay_music\t";
  nlu::SemanticFrames output;
  DialogueV3RouteResult result;
  ASSERT_EQ(0, pipeline.Route(input, request, 0, nullptr, nullptr, &multi,
                              &output, &result));
  ASSERT_EQ(2u, output.size());
  EXPECT_TRUE(result.nlu_is_multi_intent);
  EXPECT_FALSE(result.is_hit_rule);
  output.clear();
  AddFrame("other", "other", &output);
  EXPECT_TRUE(result.nlu_is_multi_intent);
  nlu::SemanticFrames hot_frames;
  AddFrame("vehicle", "open_window", &hot_frames);
  AddFrame("media", "play_music", &hot_frames);
  ASSERT_EQ(1, pipeline.Route(input, request, 1, &hot_frames, nullptr, &multi,
                              &output, &result));
  EXPECT_TRUE(result.is_multi_intent);
  EXPECT_FALSE(result.nlu_is_multi_intent);
  EXPECT_FALSE(result.is_hit_rule);
  EXPECT_TRUE(result.nlu_result.isNull());
  EXPECT_EQ(1, multi.calls());
  ASSERT_LT(pipeline.Route(input, request, -1, nullptr, nullptr, &multi,
                           &output, &result), 0);
  EXPECT_TRUE(result.nlu_result.isNull());
  EXPECT_FALSE(result.nlu_is_multi_intent);
}

}  // namespace
}  // namespace nlptk
