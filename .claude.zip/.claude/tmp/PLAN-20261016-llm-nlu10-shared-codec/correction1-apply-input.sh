set -euo pipefail
umask 077
python3 -I - <<'REMOTE'
import os,pathlib,hashlib,subprocess,datetime,shutil,base64,re
root=pathlib.Path('/home/daigd/dialogue')
assert root.resolve()==root
os.environ['GIT_OPTIONAL_LOCKS']='0';os.environ['GIT_PAGER']='cat'
def git(*a): return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','core.pager=cat','-C',str(root),*a]).strip().decode()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
head='3f086385c81509d40ccb82813758dd1d6d24c0f3';branch='feat/v3-nlu-linux'
assert git('rev-parse','HEAD')==head and git('symbolic-ref','--short','HEAD')==branch
index=root/'.git/index';index_sha=sha(index)
assert index_sha=='5ce26801c99f4784a6913904ce8b1a766fc84d1be0dad7cc00fbfc688e84f179'
target=root/'cu/nlu_0_6b_offline_backend_test.cc'
assert target.resolve()==target and target.is_file() and not target.is_symlink()
assert sha(target)=='6d3600bc710059b1c91557ffb0d342e47013dd3efd3926aae007a587bb7c59a6', 'Preimage drift; preserve'
attrs=target.stat();assert attrs.st_mode & 0o7777==0o644
manifest={'cu/BUILD': 'c3e29eafb3d0fbb7feefb2eb4064e619028ae6b5b9561e22082bdae3347ba127', 'cu/dialogue_system.cc': '31072794118260e708e39b9c190a6b9de8e727cbbd5555a9060cf081b6332b90', 'cu/dialogue_system.h': 'c14bff68b949073ed70dff2f591125269ad902afb356e561d3325e26a616109c', 'cu/dialogue_system_inference_test.cc': 'c9d6d5e3df616018e430ae8dbc6c6e8a677f5e18def6bebf3400660a58108446', 'cu/dialogue_v3.cc': '11b21c07b82a95f3b8c6fda73a75aa799918987307085f816ee28094d8ce01a0', 'cu/dialogue_v3.h': 'f3b00cc303487ac2f97622a13913a5bef0fe712210855a01513c296776673403', 'cu/dialogue_v3_test.cc': 'f97ebd460e19292a8036ed0560a10b4f4c0f0be6323635d77bf2c2a6ea099dce', 'cu/llm_protocol.cc': '904f3779454e4bedc17bad0c5a5c31ff60f8a7768497b981ab8246d269b7b744', 'cu/llm_protocol.h': '67b0f6d283498b77205c8eb50175091f89fd34965bd729bf963711f9cc0ac70b', 'cu/nlu_0_6b_http_backend.cc': '6e02b76c946b3bc1dfe5c74833a428e148aa9d8fc2604b0943235c0b36ea4934', 'cu/nlu_0_6b_http_backend_test.cc': 'f13db9ea1fb360e6634883204062338a8538f9c4ed9a93c3eb04a20fff3a862c', 'cu/nlu_0_6b_manager.cc': '5f103a57ebbc75fc8284e02c4079961430c6246e632f0fbfb19ee9d504171952', 'cu/nlu_0_6b_manager.h': '743b38ee79102b783f3dbcd65f7a22514b9629301dca235510efc8fd0813e84e', 'cu/nlu_0_6b_manager_test.cc': 'b07f752af9adbc43b4ea81a241652a16a3ebafe7c203caab727033c5fa7dd638', 'cu/nlu_0_6b_offline_backend.cc': '1a1d477800942bc3edf0baab50ad10d909d64a4e637bb189a63d1426f5788606', 'cu/nlu_0_6b_offline_backend.h': '6fb3d077b97b0ab85ae7ea68917e4e892b2cc8f628d07c490aeff6471f4b8173', 'cu/nlu_0_6b_offline_inference.h': 'bc6347bbd01064700faad095e7a091ce0eb71fdd13bce4e6c3027467d186be39'}
for name,digest in manifest.items():
 p=root/name
 assert p.resolve()==p and sha(p)==digest, 'Previous postimage drift: '+name
txn=pathlib.Path('/home/daigd/.wtp184-transactions')/('PLAN-20261016-llm-nlu10-shared-codec-v1-phase2-correction1-'+datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%S%fZ'))
txn.mkdir(mode=0o700)
print('TRANSACTION='+str(txn),flush=True)
with (txn/'application.log').open('x') as log:
 def emit(s): log.write(s+'\n');log.flush();print(s,flush=True)
 shutil.copy2(str(target),str(txn/'nlu_0_6b_offline_backend_test.cc.preimage'))
 assert target.read_bytes()==(txn/'nlu_0_6b_offline_backend_test.cc.preimage').read_bytes()
 patch=txn/'phase2-correction1.patch';patch.write_bytes(base64.b64decode('ZGlmZiAtLWdpdCBhL2N1L25sdV8wXzZiX29mZmxpbmVfYmFja2VuZF90ZXN0LmNjIGIvY3Uvbmx1XzBfNmJfb2ZmbGluZV9iYWNrZW5kX3Rlc3QuY2MKLS0tIGEvY3Uvbmx1XzBfNmJfb2ZmbGluZV9iYWNrZW5kX3Rlc3QuY2MKKysrIGIvY3Uvbmx1XzBfNmJfb2ZmbGluZV9iYWNrZW5kX3Rlc3QuY2MKQEAgLTI2OCw3ICsyNjgsNyBAQAogICB9CiAgIGNvbnN0IEpzb246OlZhbHVlIHBheWxvYWQgPSBKc29uSGVscGVyOjpQYXJzZUpzb25Gcm9tU3RyaW5nKHJlcXVlc3QpOwogICBjb25zdCBzdGQ6OnN0cmluZyBjb250ZW50ID0gcGF5bG9hZFsibWVzc2FnZXMiXVsxdV1bImNvbnRlbnQiXS5hc1N0cmluZygpOwotICBjb25zdCBzdGQ6OnN0cmluZyBvdXRwdXQgPSAidmVoaWNsZVx0b3Blblx0bmFtZT0iICsKKyAgY29uc3Qgc3RkOjpzdHJpbmcgb3V0cHV0ID0gc3RkOjpzdHJpbmcoInZlaGljbGVcdG9wZW5cdG5hbWU9IikgKwogICAgICAgKGNvbnRlbnQuZmluZCgicXVlcnk6IGFscGhhIikgIT0gc3RkOjpzdHJpbmc6Om5wb3MgPyAiYWxwaGEiIDogImJldGEiKTsKICAgY2FsbGJhY2sob3V0cHV0LmNfc3RyKCksIGNvbnRleHQpOwogICByZXR1cm4gMDsK'))
 emit('Preimage exact digest verified; backup literal-byte matched; mode0644/owner/group/index/branch/HEAD frozen; other17 postimages match')
 for dry in [True,False]:
  cmd=['patch','--batch','--verbose','--fuzz=0','--no-backup-if-mismatch','-p1','-d',str(root),'-i',str(patch)]
  if dry: cmd.insert(1,'--dry-run')
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20)
  out=r.stdout.decode();emit(('DRY_RUN' if dry else 'APPLY')+' exit='+str(r.returncode)+'\n'+out)
  assert r.returncode==0 and not re.search(r'offset|fuzz|FAILED|reject',out,re.I), 'Patch failed; preserve, no rollback'
 assert sha(target)=='ef6421eac03c01e8245f4474d2cd0c64d633b20cd4899ee8945d476063f994ee', 'Postimage mismatch; preserve, no rollback'
 after=target.stat();assert (after.st_mode,after.st_uid,after.st_gid)==(attrs.st_mode,attrs.st_uid,attrs.st_gid)
 for name,digest in manifest.items(): assert sha(root/name)==digest, 'Other postimage changed: '+name
 assert sha(index)==index_sha and git('rev-parse','HEAD')==head and git('symbolic-ref','--short','HEAD')==branch
 emit('PASS: correction expected postimage digest exact; mode0644/owner/group, other17postimages, rawindex, branch/HEAD preserved; no other product edit')
 emit('APPLICATION_LOG='+str(txn/'application.log'))

REMOTE
