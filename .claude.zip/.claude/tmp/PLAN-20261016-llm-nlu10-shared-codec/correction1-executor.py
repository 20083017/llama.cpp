import os, subprocess, shlex, hashlib, sys
ALIAS='new2_wtp184-server'
SSH='C:/Program Files/Git/usr/bin/ssh.exe'
KEYGEN='C:/Program Files/Git/usr/bin/ssh-keygen.exe'
OPTS=['-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','IdentitiesOnly=yes','-o','PasswordAuthentication=no','-o','KbdInteractiveAuthentication=no','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','RequestTTY=no','-o','ControlMaster=no','-o','ControlPath=none','-o','ControlPersist=no','-o','ConnectTimeout=10','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=2']
def validate(expected=None):
 assert not any(os.environ.get(k) for k in ['WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS']), 'Explicit contract present'
 p=subprocess.run([SSH,'-G',ALIAS],capture_output=True,text=True,timeout=15,check=True)
 d={}
 for line in p.stdout.splitlines():
  k,_,v=line.partition(' '); d.setdefault(k,[]).append(v)
 fields=['hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','stricthostkeychecking','proxyjump','proxycommand','hostkeyalias']
 pin=hashlib.sha256('\n'.join(k+'='+repr(d.get(k,[])) for k in fields).encode()).hexdigest()
 if expected: assert pin==expected, 'SSH contract drift'
 assert d['hostname']==['10.1.120.40'] and d['user']==['daigd'] and d['identitiesonly']==['yes']
 assert all(d.get(k,['none'])==['none'] for k in ['proxyjump','proxycommand'])
 assert d.get('stricthostkeychecking') in [['ask'],['true'],['yes']], 'Weak trust configuration'
 def path(v):
  v=os.path.expanduser(v.strip('"'))
  if len(v)>3 and v[0]=='/' and v[2]=='/': v=v[1]+':'+v[2:]
  return v
 assert d.get('identityfile') and all(os.path.isfile(path(v)) and os.access(path(v),os.R_OK) for v in d['identityfile'])
 trusted=False
 host=d.get('hostkeyalias',d['hostname'])[0]
 if d['port']!=['22']: host='['+host+']:'+d['port'][0]
 for field in ['userknownhostsfile','globalknownhostsfile']:
  for value in d.get(field,[]):
   for f in shlex.split(value,posix=False):
    f=path(f)
    if os.path.isfile(f) and subprocess.run([KEYGEN,'-F',host,'-f',f],capture_output=True,timeout=10).returncode==0: trusted=True
 assert trusted, 'No configured trusted host-key entry'
 return pin

def remote(script, seconds, pin):
 validate(pin)
 return subprocess.run([SSH,*OPTS,ALIAS,'timeout --kill-after=5s '+str(seconds)+'s /bin/bash --noprofile --norc -s'],input=script.encode(),timeout=seconds+25).returncode

if __name__=='__main__':
 pin=validate(sys.argv[1] if len(sys.argv)>1 else None)
 print('PIN='+pin,flush=True)
 print('Ubuntu build/test: validated alias daigd@10.1.120.40:22; actual strict=yes, no proxy/fallback/forwarding/TTY/mux',flush=True)
 raise SystemExit(remote(sys.stdin.read(),int(os.environ.get('EXECUTOR_SECONDS','40')),pin))
