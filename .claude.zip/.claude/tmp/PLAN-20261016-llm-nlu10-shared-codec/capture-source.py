import datetime, io, json, os, shlex, stat, subprocess, sys, tarfile
from pathlib import Path
ssh, keygen, cygpath, task_arg = sys.argv[1:]
task = Path(task_arg)
source, incoming, report = (task / n for n in ('source','incoming','source-baseline.txt'))
files = ['cu/BUILD','cu/nlu_0_6b_backend.h','cu/nlu_0_6b_http_backend.h','cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/nlu_0_6b_manager.h','cu/nlu_0_6b_manager.cc','cu/nlu_0_6b_manager_test.cc','cu/dialogue_v3.h','cu/dialogue_v3.cc','cu/dialogue_v3_test.cc','cu/dialogue_system.h','cu/dialogue_system.cc','cu/v3_linux_offline_test.cc','cu/dialogue_v3_pipeline.h','cu/dialogue_v3_pipeline.cc','cu/dialogue_v3_pipeline_test.cc','cu/dialogue.h']
head = '3f086385c81509d40ccb82813758dd1d6d24c0f3'
compare = {p: task.parent / old / 'v2-work' / p for p,old in [
 ('cu/nlu_0_6b_http_backend.cc','PLAN-20261016-nlu06b-config-driven-syntax'),
 ('cu/nlu_0_6b_http_backend_test.cc','PLAN-20261016-nlu06b-config-driven-syntax'),
 ('cu/v3_linux_offline_test.cc','PLAN-20261016-nlu06b-multi-query-history')]}
def run(args):
    return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12,check=True)
def native(p):
    return Path(run([cygpath,'-w',os.path.expanduser(p)]).stdout.decode().strip())
if any(os.environ.get(k) is not None for k in ('WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS')):
    raise RuntimeError('Explicit SSH overrides present; cannot use alias')
if any(p.exists() for p in (source,incoming,report)):
    raise RuntimeError('Packet destination already exists; preserved')
for p in compare.values():
    if not p.is_file(): raise RuntimeError('Missing supplied postimage: '+str(p))
alias = 'new2_wtp184-server'
settings = ['BatchMode=yes','StrictHostKeyChecking=yes','IdentitiesOnly=yes','PreferredAuthentications=publickey','PasswordAuthentication=no','KbdInteractiveAuthentication=no','IdentityAgent=none','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=10','ConnectionAttempts=1','ServerAliveInterval=10','ServerAliveCountMax=2']
options = [item for setting in settings for item in ('-o',setting)]
config = {}
allowed = {'hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','stricthostkeychecking','proxyjump','proxycommand','hostkeyalias'}
for line in run([ssh,'-G']+options+[alias]).stdout.decode().splitlines():
    key,_,value=line.partition(' ')
    if key in allowed: config.setdefault(key,[]).append(value)
for key,value in {'hostname':'10.1.120.40','user':'daigd','port':'22','identitiesonly':'yes'}.items():
    if config.get(key)!=[value]: raise RuntimeError('SSH identity mismatch: '+key)
if config.get('stricthostkeychecking') not in (['yes'],['true']): raise RuntimeError('Strict trust enforcement unavailable')
for key in ('proxyjump','proxycommand'):
    if config.get(key,['none'])!=['none']: raise RuntimeError('Unexpected proxy routing')
identities=config.get('identityfile',[])
if not identities: raise RuntimeError('Configured identity missing')
for p in identities:
    if not native(p).is_file() or not os.access(native(p),os.R_OK): raise RuntimeError('Configured identity unavailable')
trusted=False
for value in config.get('userknownhostsfile',[])+config.get('globalknownhostsfile',[]):
    for p in shlex.split(value,posix=False):
        path=native(p.strip(chr(34)))
        if not path.is_file(): continue
        r=subprocess.run([keygen,'-F',config.get('hostkeyalias',config['hostname'])[0],'-f',str(path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        if r.returncode==0 and r.stdout: trusted=True
if not trusted: raise RuntimeError('No existing configured trusted host-key entry')
remote = r'''
import io,json,os,stat,subprocess,sys,tarfile
root='/home/daigd/dialogue'
files=FILE_LIST
expected_head=EXPECTED_REVISION
expected_dirty=EXPECTED_DELTAS
if os.path.realpath(root)!=root: raise RuntimeError('Root path mismatch')
env=os.environ.copy()
env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_TERMINAL_PROMPT='0')
def git(*args):
    return subprocess.check_output(['git','--no-pager','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-c','diff.external=','-C',root]+list(args),env=env,timeout=10)
if git('rev-parse','--show-toplevel').decode().strip()!=root: raise RuntimeError('Git root mismatch')
branch=git('symbolic-ref','--short','HEAD').decode().strip()
head=git('rev-parse','HEAD').decode().strip()
if branch!='feat/v3-nlu-linux' or head!=expected_head: raise RuntimeError('Source identity mismatch: '+branch+' '+head)
for rel in files:
    resolved=os.path.realpath(os.path.join(root,rel))
    if not resolved.startswith(root+'/'): raise RuntimeError('Resolved path escape: '+rel)
    if not stat.S_ISREG(os.stat(resolved).st_mode): raise RuntimeError('Not a regular file: '+rel)
status=git('status','--porcelain=v1','-z','--untracked-files=all','--ignore-submodules=all','--',*files).decode().split('\0')
status=[s for s in status if s]
if sorted(status)!=sorted(' M '+p for p in expected_dirty): raise RuntimeError('Unexpected scoped status: '+repr(status))
index=[s for s in git('ls-files','--stage','-z','--',*files).decode().split('\0') if s]
if len(index)!=len(files): raise RuntimeError('Index capture gap')
meta={'root':root,'branch':branch,'head':head,'status':status,'index':index,'files':{}}
output=io.BytesIO()
with tarfile.open(fileobj=output,mode='w') as archive:
    for rel in files:
        with open(os.path.join(root,rel),'rb') as stream:
            before=os.fstat(stream.fileno());data=stream.read();after=os.fstat(stream.fileno())
        if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino) or len(data)!=before.st_size: raise RuntimeError('Unstable capture: '+rel)
        mode=stat.S_IMODE(before.st_mode)
        meta['files'][rel]={'mode':format(mode,'04o'),'bytes':len(data)}
        member=tarfile.TarInfo(rel);member.size=len(data);member.mode=mode
        archive.addfile(member,io.BytesIO(data))
    data=json.dumps(meta,sort_keys=True).encode()
    member=tarfile.TarInfo('__metadata__.json');member.size=len(data);member.mode=0o600
    archive.addfile(member,io.BytesIO(data))
sys.stdout.buffer.write(output.getvalue())
'''.replace('FILE_LIST',repr(files)).replace('EXPECTED_REVISION',repr(head)).replace('EXPECTED_DELTAS',repr(list(compare)))
command='timeout --signal=TERM --kill-after=5s 55s python3 -I -c '+shlex.quote(remote)
result=subprocess.run([ssh]+options+[alias,command],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=85)
if result.returncode:
    log=task/'capture-failure.log'
    log.write_bytes(b'SSH exit='+str(result.returncode).encode()+b'\n'+result.stderr)
    raise RuntimeError('Capture failed; exit='+str(result.returncode)+'; log='+str(log))
if not result.stdout or len(result.stdout)>16*1024*1024: raise RuntimeError('Archive missing or exceeds 16 MiB')
incoming.mkdir()
archive_path=incoming/'source-preimages.tar'
archive_path.write_bytes(result.stdout)
with tarfile.open(archive_path,'r:') as archive:
    members=archive.getmembers()
    expected=set(files+['__metadata__.json'])
    if len(members)!=len(expected) or {m.name for m in members}!=expected: raise RuntimeError('Archive finite path set mismatch')
    if any(not m.isfile() or m.size>4*1024*1024 for m in members): raise RuntimeError('Invalid archive type/size')
    metadata=json.loads(archive.extractfile('__metadata__.json').read())
    if metadata['head']!=head or set(metadata['files'])!=set(files): raise RuntimeError('Metadata identity/path gap')
    source.mkdir()
    for rel in files:
        member=archive.getmember(rel);data=archive.extractfile(member).read()
        if len(data)!=metadata['files'][rel]['bytes'] or format(member.mode,'04o')!=metadata['files'][rel]['mode']: raise RuntimeError('Bytes/mode capture mismatch: '+rel)
        target=source/rel;target.parent.mkdir(exist_ok=True)
        with target.open('xb') as stream: stream.write(data)
        os.chmod(target,member.mode)
comparisons=[(rel,(source/rel).read_bytes()==old.read_bytes(),old) for rel,old in compare.items()]
lines=['PLAN-20261016-llm-nlu10-shared-codec v1 / Phase1 source reconciliation',
 'Captured UTC: '+datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'Action: one-shot bounded read-only SSH finite archive capture; exit=0',
 'Host role: Ubuntu authoritative source; alias=new2_wtp184-server; daigd@10.1.120.40:22',
 'Contract: configured identity/existing trusted key; publickey only; strict host key;',
 ' no proxy/forwarding/TTY/multiplexing; connect10s/remote55s/local85s',
 'Root: '+metadata['root'],'Branch: '+metadata['branch'],'HEAD: '+metadata['head'],
 'Scope: 18 exact existing files; no whole-tree cleanliness claim',
 'Scoped staged changes: none','Scoped unstaged changes:']+metadata['status']+[
 'Scoped untracked files: none',
 'Other 15 listed files: empty scoped status, matching expected prior baseline',
 'Known new/missing files requiring retrieval: none; proposed new files not requested',
 'Metadata: path | authoritative working mode | bytes | index mode | stage']
index_modes={}
for entry in metadata['index']:
    attributes,rel=entry.split('\t',1);mode,oid,stage=attributes.split();index_modes[rel]=(mode,stage)
for rel in files:
    record=metadata['files'][rel]
    lines.append('%s | %s | %s | %s | %s'%(rel,record['mode'],record['bytes'],*index_modes[rel]))
lines.append('Exact byte comparison with supplied current postimages:')
for rel,exact,old in comparisons: lines.append('%s | %s | %s'%(rel,'IDENTICAL' if exact else 'DIFFERENT - preserved; do not absorb',old))
lines += ['Archive (authoritative Unix modes retained): '+str(archive_path),'Source packet: '+str(source),
 'No apply/build/test/runtime/model/HTTP/deploy/Git mutation performed.',
 'No hashes computed; no remote writes; no plan/check/CURRENT changes.']
report.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('SSH exit=0; captured '+str(len(files))+' existing files')
print('Source identity: '+metadata['branch']+' '+metadata['head'])
print('Scoped status: expected three unstaged modifications only; staged/untracked none')
for rel,exact,old in comparisons: print(rel+': '+('BYTE-IDENTICAL' if exact else 'DIFFERENT'))
print('Source packet: '+str(source));print('Metadata report: '+str(report))
if not all(exact for _,exact,_ in comparisons): raise RuntimeError('Postimage mismatch; preserve packet without adoption')
