from pathlib import Path
b=Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261016-llm-nlu10-shared-codec'); w=b/'phase1-work/cu'
s=(b/'source/cu/nlu_0_6b_manager_test.cc').read_text(encoding='utf-8')
a=s.index('TEST(Nlu06BManagerTest, ForwardsModelRootToProfileBackendFactory)'); z=s.index('TEST(Nlu06BManagerTest, PerCallCarrier',a)
s=s[:a]+'''TEST(Nlu06BManagerTest, ForwardsModelRootToProfileBackendFactory) {
  const std::string base = TestBasePath();
  ASSERT_FALSE(base.empty());
  Json::Value config = WithHttpModel(Json::Value(Json::objectValue), base);
  Nlu06BManager manager;
  EXPECT_EQ(0, manager.Initialize(config, base));
  Nlu06BManager missing_base;
  EXPECT_LT(missing_base.Initialize(config, std::string()), 0);
  Json::Value stale = config;
  stale["OpenAIHttp"]["profile"] = "daily-driver";
  Nlu06BManager stale_manager;
  EXPECT_LT(stale_manager.Initialize(stale, base), 0);
  stale = config;
  stale.removeMember("Model");
  Nlu06BManager missing_model;
  EXPECT_LT(missing_model.Initialize(stale, base), 0);
  std::remove((base + "/manager_catalog.json").c_str());
  std::remove((base + "/manager_protocol.json").c_str());
}

'''+s[z:]
helper='''Json::Value WithHttpModel(Json::Value config, const std::string& base) {
  Json::Value profile = JsonHelper::ParseJsonFromString(R"JSON({
    "model":"qwen3_nlu", "system_prompt":"parse vehicle semantics",
    "protocol_path":"manager_protocol.json", "stream":false,
    "temperature":0.1, "top_p":0.9, "top_k":10, "max_tokens":128,
    "enable_thinking":false, "allow_multi_intent_output":false
  })JSON");
  Json::Value catalog(Json::objectValue);
  catalog["profiles"]["daily-driver"] = profile;
  std::ofstream catalog_file((base + "/manager_catalog.json").c_str());
  catalog_file << JsonHelper::ToString(catalog);
  Json::Value protocol = JsonHelper::ParseJsonFromString(R"JSON({
    "protocol":"nlu_10", "request_field_prefixes":["history:","query: "],
    "field_delimiter":"\\t", "request_slot_assignment":"=",
    "request_slot_separator":",", "response_slot_assignment":"=",
    "response_slot_separator":",", "response_frame_separator":";",
    "response_unknown_marker":"unknown", "response_multi_marker":"multi:"
  })JSON");
  std::ofstream protocol_file((base + "/manager_protocol.json").c_str());
  protocol_file << JsonHelper::ToString(protocol);
  config["Backend"]["type"] = "openai_http";
  config["Model"]["profile"] = "daily-driver";
  config["Model"]["profile_catalog_path"] = "manager_catalog.json";
  config["OpenAIHttp"]["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  config["OpenAIHttp"]["connect_timeout_ms"] = 1000;
  config["OpenAIHttp"]["total_timeout_ms"] = 2000;
  return config;
}

'''
pos=s.index('TEST(Nlu06BManagerTest, OpenAIHttpRequiresConfigAndHotFixStillBypassesIt)'); s=s[:pos]+helper+s[pos:]
a=s.index('  Json::Value config = MakeConfig();',s.index('OpenAIHttpRequiresConfigAndHotFixStillBypassesIt')); z=s.index('  Nlu06BManager manager;',a)
s=s[:a]+'''  Json::Value config = WithHttpModel(MakeConfig(), TestBasePath());
'''+s[z:]
# The live opt-in test remains opt-in and is not part of this plan's execution.
a=s.index('  Json::Value config = MakeConfig(false);',s.index('LiveOpenAIHttpCaseWhenEndpointIsInjected')); z=s.index('  Nlu06BManager manager;',a)
s=s[:a]+'''  Json::Value config = WithHttpModel(MakeConfig(false), TestBasePath());
  config["OpenAIHttp"]["endpoint"] = "${WTP184_NLU06B_LIVE_ENDPOINT}";
  config["OpenAIHttp"]["connect_timeout_ms"] = 5000;
  config["OpenAIHttp"]["total_timeout_ms"] = 30000;
  config["OpenAIHttp"]["max_response_bytes"] = 1048576;

'''+s[z:]
(w/'nlu_0_6b_manager_test.cc').write_text(s,encoding='utf-8',newline='\n')
PY=0
