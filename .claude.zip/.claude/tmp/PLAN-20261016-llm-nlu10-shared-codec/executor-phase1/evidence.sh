#!/usr/bin/env bash
set -euo pipefail
python3 -I - <<'PY'
import hashlib, json, pathlib, shlex, subprocess
base=pathlib.Path('/home/daigd/wtp184-validation-logs')
prefix='PLAN-20261016-llm-nlu10-shared-codec-v1-phase1-'
for name in ('llm_protocol_test','nlu_0_6b_http_backend_test','nlu_0_6b_manager_test'):
    path=base/(prefix+name+'-1.log')
    lines=path.read_text().splitlines()
    print('LOG='+str(path))
    for i,line in enumerate(lines,1):
        if line.lstrip().startswith('/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc ') and ' -c cu/' in line:
            tokens=shlex.split(line.rstrip(')'))
            source=tokens[tokens.index('-c')+1]
            standards=[t for t in tokens if t.startswith('-std=')]
            if source in ('cu/llm_protocol.cc','cu/nlu_10_protocol.cc','cu/llm_protocol_test.cc','cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/nlu_0_6b_manager.cc','cu/nlu_0_6b_manager_test.cc'):
                print('line=%s source=%s compiler=%s standards=%s effective=%s'%(i,source,tokens[0],','.join(standards),standards[-1]))
        if line.startswith('Note: Google Test filter') or line.startswith('Executed ') or line.startswith('[  PASSED  ]') or line.startswith('BAZEL_EXIT='):
            print('line='+str(i)+' '+line)
print('ACTUAL_GCC_VERSION='+subprocess.check_output(['/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc','-dumpversion'],timeout=5).decode().strip())
print('ACTUAL_GCC_SYSROOT='+subprocess.check_output(['/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc','--print-sysroot'],timeout=5).decode().strip())
txn=pathlib.Path('/home/daigd/.wtp184-transactions/PLAN-20261016-llm-nlu10-shared-codec-v1-20261016T104748900240Z')
meta=json.loads((txn/'metadata.json').read_text())
index=pathlib.Path('/home/daigd/dialogue/.git/index')
print('FINAL_INDEX_UNCHANGED='+str(hashlib.sha256(index.read_bytes()).hexdigest()==meta['index_sha256_before']))
print('APPLICATION_RESULT='+meta['result'])
print('SCOPED_POSTAPPLY_STATUS='+repr(meta['scoped_status_after']))
PY
