#!/usr/bin/env bash
set -euo pipefail
base=/home/daigd/wtp184-validation-logs/PLAN-20261016-llm-nlu10-shared-codec-v1-phase1
printf '%s\n' '---COMPILER AND WRAPPER EVIDENCE---'
sed -n '1,65p' "${base}-llm_protocol_test-1.log"
printf '%s\n' '---ACTUAL CODEC COMPILE ACTIONS---'
grep -n -E 'llm_protocol(_test)?\.cc|nlu_10_protocol\.cc' "${base}-llm_protocol_test-1.log" | head -n 12
printf '%s\n' '---ACTUAL HTTP COMPILE ACTIONS---'
grep -n -E 'nlu_0_6b_http_backend(_test)?\.cc' "${base}-nlu_0_6b_http_backend_test-1.log" | head -n 8
printf '%s\n' '---ACTUAL MANAGER COMPILE / LIVE EXCLUSION---'
grep -n -E 'nlu_0_6b_manager(_test)?\.cc|Note: Google Test filter|LiveOpenAIHttpCaseWhenEndpointIsInjected|Executed ' "${base}-nlu_0_6b_manager_test-1.log" | head -n 10
