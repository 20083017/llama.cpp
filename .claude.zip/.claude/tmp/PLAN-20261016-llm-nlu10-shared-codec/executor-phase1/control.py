import base64, json, os, shlex, subprocess, sys, tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
TASK=HERE.parent
SSH,KEYGEN,CYGPATH,ACTION,*ARGS=sys.argv[1:]
ALIAS='new2_wtp184-server'
SETTINGS=['BatchMode=yes','StrictHostKeyChecking=yes','IdentitiesOnly=yes','PreferredAuthentications=publickey','PasswordAuthentication=no','KbdInteractiveAuthentication=no','IdentityAgent=none','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=10','ConnectionAttempts=1','ServerAliveInterval=10','ServerAliveCountMax=2']
OPTIONS=[x for setting in SETTINGS for x in ('-o',setting)]
def run(args):
    return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12,check=True)
def native(p):
    return Path(run([CYGPATH,'-w',os.path.expanduser(p)]).stdout.decode().strip())
if any(n in os.environ for n in ('WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS')):
    raise RuntimeError('Explicit contract unexpectedly present; stop')
config={}
allowed={'hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','stricthostkeychecking','proxyjump','proxycommand','hostkeyalias'}
for line in run([SSH,'-G']+OPTIONS+[ALIAS]).stdout.decode().splitlines():
    key,_,value=line.partition(' ')
    if key in allowed: config.setdefault(key,[]).append(value)
for k,v in {'hostname':'10.1.120.40','user':'daigd','port':'22','identitiesonly':'yes'}.items():
    if config.get(k)!=[v]: raise RuntimeError('Alias mismatch: '+k)
if config.get('stricthostkeychecking') not in (['yes'],['true']): raise RuntimeError('Strict trust unavailable')
for k in ('proxyjump','proxycommand'):
    if config.get(k,['none'])!=['none']: raise RuntimeError('Proxy routing rejected')
if not config.get('identityfile'): raise RuntimeError('Missing identity')
for p in config['identityfile']:
    f=native(p)
    if not f.is_file() or not os.access(f,os.R_OK): raise RuntimeError('Configured identity unavailable')
trusted=False
for value in config.get('userknownhostsfile',[])+config.get('globalknownhostsfile',[]):
    for p in shlex.split(value,posix=False):
        f=native(p.strip(chr(34)))
        if not f.is_file(): continue
        r=subprocess.run([KEYGEN,'-F',config.get('hostkeyalias',config['hostname'])[0],'-f',str(f)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        if r.returncode==0 and r.stdout: trusted=True
if not trusted: raise RuntimeError('No existing trusted host entry')
pinned=HERE/'pinned-contract.json'
if pinned.exists():
    if json.loads(pinned.read_text())!=config: raise RuntimeError('Pinned contract drift; stop')
else:
    with pinned.open('x') as f: json.dump(config,f,sort_keys=True)
print('Contract validated: Ubuntu authoritative source/build role, exact destination, publickey-only strict trust; no proxy/TTY/forwarding/mux',flush=True)
if ACTION=='apply':
    modified=['cu/BUILD','cu/nlu_0_6b_http_backend.h','cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/nlu_0_6b_manager.cc','cu/nlu_0_6b_manager_test.cc']
    new=['cu/llm_protocol.h','cu/llm_protocol.cc','cu/nlu_10_protocol.h','cu/nlu_10_protocol.cc','cu/llm_protocol_test.cc']
    with tarfile.open(TASK/'incoming'/'source-preimages.tar','r:') as a:
        meta=json.loads(a.extractfile('__metadata__.json').read())
    packet={'modified':modified,'new':new,'prior':meta,'patch':base64.b64encode((TASK/'phase1.patch').read_bytes()).decode(),
        'pre':{p:base64.b64encode((TASK/'source'/p).read_bytes()).decode() for p in modified+['cu/v3_linux_offline_test.cc']},
        'post':{p:base64.b64encode((TASK/'phase1-work'/p).read_bytes()).decode() for p in modified+new}}
    script=(HERE/'apply.py').read_text()
    loader="import io,json,sys; bundle=json.load(sys.stdin); sys.stdin=io.StringIO(json.dumps(bundle['data'])); exec(compile(bundle['code'], 'approved-phase1-apply', 'exec'))"
    command='timeout --signal=TERM --kill-after=5s 100s python3 -I -c '+shlex.quote(loader)
    payload=json.dumps({'code':script,'data':packet}).encode();limit=125
elif ACTION=='test':
    target,attempt=ARGS
    if target not in ('llm_protocol_test','nlu_0_6b_http_backend_test','nlu_0_6b_manager_test') or not attempt.isdigit(): raise RuntimeError('Bad finite test selector')
    script=(HERE/'test.sh').read_text()
    command='timeout --signal=TERM --kill-after=15s 620s /bin/bash --noprofile --norc -s -- '+shlex.quote(target)+' '+shlex.quote(attempt)
    payload=script.encode();limit=655
elif ACTION=='read':
    script=(HERE/ARGS[0]).read_text()
    command='timeout --signal=TERM --kill-after=5s 35s /bin/bash --noprofile --norc -s'
    payload=script.encode();limit=60
else: raise RuntimeError('Unknown action')
r=subprocess.run([SSH]+OPTIONS+[ALIAS,command],input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=limit)
print(r.stdout.decode(errors='replace'),end='')
if r.stderr: print(r.stderr.decode(errors='replace'),file=sys.stderr,end='')
print('SSH_COMMAND_EXIT='+str(r.returncode),flush=True)
sys.exit(r.returncode)
