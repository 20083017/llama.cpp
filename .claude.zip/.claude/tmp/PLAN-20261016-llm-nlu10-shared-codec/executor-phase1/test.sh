#!/usr/bin/env bash
set -euo pipefail
umask 077
target=${1:?}
attempt=${2:?}
root=/home/daigd/dialogue
logdir=/home/daigd/wtp184-validation-logs
[[ -d "$logdir" && ! -L "$logdir" && $(readlink -f -- "$logdir") == "$logdir" ]]
log="$logdir/PLAN-20261016-llm-nlu10-shared-codec-v1-phase1-${target}-${attempt}.log"
set -o noclobber
exec 3>"$log"
set +o noclobber
export CC=/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc
export CXX=/home/daigd/tools/wtp184-gcc493-sysroot/bin/g++
export PATH=/home/daigd/tools/wtp184-gcc493-sysroot/bin:/home/daigd/tools/gcc-4.9.3-centos7/bin:$PATH
unset WTP184_NLU06B_LIVE_ENDPOINT GTEST_FILTER GTEST_FAIL_FAST
cd "$root"
cmd=(timeout --kill-after=15s 580s bazel test --cpu=k8 --host_cpu=k8 --define=dialogue_pipeline_v3=true --test_output=all --subcommands --cache_test_results=no "--action_env=CC=$CC" "--action_env=CXX=$CXX" "--action_env=PATH=$PATH" "//cu:$target")
if [[ "$target" == nlu_0_6b_manager_test ]]; then
  cmd+=(--test_arg=--gtest_filter=-Nlu06BManagerTest.LiveOpenAIHttpCaseWhenEndpointIsInjected)
fi
{
  printf 'START_UTC=%s\nROOT=%s\nTARGET=//cu:%s\n' "$(date -u +%FT%TZ)" "$root" "$target"
  printf 'COMMAND='; printf '%q ' "${cmd[@]}"; printf '\n'
  printf '\nCOMPILER_VERSION\n'
  "$CXX" --version
  printf '\nCOMPILER_SYSROOT\n'
  "$CXX" --print-sysroot
  printf '\nWRAPPER_SOURCE\n'
  sed -n '1,100p' "$CC"
  printf '\nBAZEL_TEST_OUTPUT\n'
} >&3 2>&1
set +e
(ulimit -f 65536; "${cmd[@]}") >&3 2>&1
rc=$?
set -e
printf '\nBAZEL_EXIT=%s\nEND_UTC=%s\n' "$rc" "$(date -u +%FT%TZ)" >&3
exec 3>&-
printf 'TARGET=//cu:%s\nBAZEL_EXIT=%s\nPRIMARY_LOG=%s\nLOG_BYTES=%s\n' "$target" "$rc" "$log" "$(stat -c %s "$log")"
awk '/error:|fatal error:|ERROR:|FAILED|\[  FAILED  \]|\[==========\]|\[  PASSED  \]|Executed |BAZEL_EXIT=|TIMEOUT/ { if (n++<20) print }' "$log"
exit "$rc"
