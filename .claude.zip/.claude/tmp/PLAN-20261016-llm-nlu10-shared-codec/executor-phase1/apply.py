import base64, datetime, hashlib, json, os, pathlib, re, stat, subprocess, sys, tarfile, traceback
p=json.load(sys.stdin)
root=pathlib.Path('/home/daigd/dialogue')
plan='PLAN-20261016-llm-nlu10-shared-codec'
parent=pathlib.Path('/home/daigd/.wtp184-transactions')
if os.path.realpath(str(root))!=str(root): raise RuntimeError('Noncanonical root')
if parent.exists() and (parent.is_symlink() or str(parent.resolve())!=str(parent)): raise RuntimeError('Transaction parent linked')
parent.mkdir(mode=0o700,exist_ok=True)
txn=parent/(plan+'-v1-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
txn.mkdir(mode=0o700)
os.umask(0o077)
log=(txn/'application.log').open('x',buffering=1)
def emit(s):
    log.write(s+'\n'); print(s,flush=True)
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_TERMINAL_PROMPT='0')
def git(*args):
    return subprocess.check_output(['git','--no-pager','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-c','diff.external=','-C',str(root)]+list(args),env=env,timeout=10)
def ident(): return (git('symbolic-ref','--short','HEAD'),git('rev-parse','HEAD'))
def regular(rel,absent=False):
    path=root/rel
    if path.parent.is_symlink() or str(path.parent.resolve())!=str(path.parent): raise RuntimeError('Linked parent: '+rel)
    if absent:
        if os.path.lexists(str(path)): raise RuntimeError('New file already exists: '+rel)
        if str(path.resolve())!=str(path): raise RuntimeError('New path escaped/linked: '+rel)
    elif path.is_symlink() or not path.is_file() or str(path.resolve())!=str(path): raise RuntimeError('Not a regular nonlinked path: '+rel)
    return path
def attrs(path):
    s=path.stat(); return {'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size}
def sha(data): return hashlib.sha256(data).hexdigest()
mutated=False
try:
    modified=p['modified'];new=p['new'];changed=modified+new
    if len(changed)!=11 or len(set(changed))!=11: raise RuntimeError('Finite path set invalid')
    before_id=ident()
    if before_id!=(b'feat/v3-nlu-linux\n',b'3f086385c81509d40ccb82813758dd1d6d24c0f3\n'): raise RuntimeError('HEAD/branch mismatch '+repr(before_id))
    if git('rev-parse','--show-toplevel').decode().strip()!=str(root): raise RuntimeError('Git root mismatch')
    idx=pathlib.Path(git('rev-parse','--git-path','index').decode().strip())
    if not idx.is_absolute(): idx=root/idx
    if idx.is_symlink(): raise RuntimeError('Linked index')
    index_before=idx.read_bytes()
    scope=list(p['prior']['files'])+new
    scoped_before=git('status','--porcelain=v1','-z','--untracked-files=all','--ignore-submodules=all','--',*scope)
    preserved={}
    for rel in p['prior']['files']:
        path=regular(rel); data=path.read_bytes()
        if rel in p['pre']:
            expected=base64.b64decode(p['pre'][rel],validate=True)
            if data!=expected: raise RuntimeError('PREIMAGE_MISMATCH '+rel+' expected_sha256='+sha(expected)+' actual_sha256='+sha(data)+'; would clobber unowned drift')
            if attrs(path)['mode']!=int(p['prior']['files'][rel]['mode'],8): raise RuntimeError('Preimage mode mismatch '+rel)
        if rel not in modified: preserved[rel]=(data,attrs(path))
    for rel in new: regular(rel,absent=True)
    original={rel:attrs(root/rel) for rel in modified}
    if any(a['uid']!=os.geteuid() for a in original.values()): raise RuntimeError('Original owner differs; preserve rather than chown')
    patch=base64.b64decode(p['patch'],validate=True)
    headers=[]
    for line in patch.decode().splitlines():
        if line.startswith('+++ '):
            name=line[4:].split('\t',1)[0]
            if not name.startswith('b/'): raise RuntimeError('Invalid patch path')
            headers.append(name[2:])
    if len(headers)!=11 or set(headers)!=set(changed): raise RuntimeError('Patch path mismatch')
    patchpath=txn/'phase1.patch';patchpath.write_bytes(patch)
    with tarfile.open(str(txn/'preimages.tar'),'x') as archive:
        for rel in modified: archive.add(str(root/rel),arcname=rel,recursive=False)
    metadata={'plan':plan,'version':1,'phase':1,'root':str(root),'branch':before_id[0].decode().strip(),'head':before_id[1].decode().strip(),'modified':modified,'new':new,'original_attributes':original,'index_sha256_before':sha(index_before),'scoped_status_before':scoped_before.decode().split('\x00'),'patch_sha256':sha(patch),'preserved_paths':list(preserved)}
    (txn/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    def apply(dry):
        command=['patch','--batch','--forward','--fuzz=0','--no-backup-if-mismatch','-p1','-d',str(root),'-i',str(patchpath)]
        if dry: command.insert(1,'--dry-run')
        r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
        text=r.stdout.decode(errors='replace')
        emit(('DRY_RUN' if dry else 'ACTUAL_APPLY')+' exit='+str(r.returncode)+'\n'+text.rstrip())
        if r.returncode or re.search(r'offset|fuzz|reject|FAILED',text,re.I): raise RuntimeError('Nonexact patch result; preserved, no rollback/reapply')
    emit('TRANSACTION='+str(txn))
    emit('Preconditions PASS: six exact byte/mode preimages, offline exact bytes, five new paths absent; canonical nonlinked root/paths; HEAD/branch/index captured')
    apply(True)
    if ident()!=before_id or idx.read_bytes()!=index_before: raise RuntimeError('Identity/index drift before mutation')
    for rel in modified:
        if (root/rel).read_bytes()!=base64.b64decode(p['pre'][rel]) or attrs(root/rel)!=original[rel]: raise RuntimeError('Drift immediately before apply: '+rel)
    for rel in new: regular(rel,absent=True)
    mutated=True
    apply(False)
    for rel in changed:
        path=regular(rel)
        if path.read_bytes()!=base64.b64decode(p['post'][rel],validate=True): raise RuntimeError('POSTIMAGE_MISMATCH '+rel+'; do not reapply')
        if rel in modified:
            if attrs(path)!=dict(original[rel],size=path.stat().st_size): raise RuntimeError('Ownership/mode changed '+rel)
        elif stat.S_IMODE(path.stat().st_mode)!=0o644: raise RuntimeError('New mode not 0644 '+rel)
    for rel,(data,attr) in preserved.items():
        if (root/rel).read_bytes()!=data or attrs(root/rel)!=attr: raise RuntimeError('Untouched source changed '+rel)
    if ident()!=before_id or idx.read_bytes()!=index_before: raise RuntimeError('HEAD/branch/index changed after apply')
    metadata.update(result='PASS',postimage_comparison='11 literal byte comparisons passed',index_unchanged=True,unchanged_captured_paths=len(preserved),new_modes='0644',modified_modes='0664',scoped_status_after=git('status','--porcelain=v1','-z','--untracked-files=all','--ignore-submodules=all','--',*scope).decode().split('\x00'))
    (txn/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    emit('APPLICATION PASS: eleven expected postimages literal-byte-identical; six original ownership/modes retained; five new files 0644; twelve other captured paths untouched including prior offline test; raw index, HEAD and branch unchanged')
    emit('APPLICATION_LOG='+str(txn/'application.log'))
    emit('METADATA='+str(txn/'metadata.json'))
    emit('PREIMAGES='+str(txn/'preimages.tar'))
except Exception:
    emit('APPLICATION FAILURE; mutation_started='+str(mutated)+'; no automatic rollback/reapply\n'+traceback.format_exc())
    emit('APPLICATION_LOG='+str(txn/'application.log'))
    sys.exit(1)
