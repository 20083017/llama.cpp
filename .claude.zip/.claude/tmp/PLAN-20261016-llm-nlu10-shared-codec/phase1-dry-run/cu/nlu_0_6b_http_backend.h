// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_NLU_0_6B_HTTP_BACKEND_H_
#define CU_NLU_0_6B_HTTP_BACKEND_H_

#include <memory>
#include <string>
#include <vector>

#include "cu/nlu_0_6b_backend.h"
#include "json/json.h"

namespace nlptk {

struct Nlu06BHttpRequest {
  std::string endpoint;
  std::vector<std::string> headers;
  std::string body;
  long connect_timeout_ms;
  long total_timeout_ms;
  size_t max_response_bytes;
};

struct Nlu06BHttpResponse {
  long status_code;
  std::string body;

  Nlu06BHttpResponse() : status_code(0) {}
};

class Nlu06BHttpTransport {
 public:
  virtual ~Nlu06BHttpTransport() {}
  virtual int Post(const Nlu06BHttpRequest& request,
                   Nlu06BHttpResponse* response) const = 0;
};

std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config, const std::string& base_path);
std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config);
std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config, const std::string& base_path,
    std::unique_ptr<Nlu06BHttpTransport> transport);
std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config,
    std::unique_ptr<Nlu06BHttpTransport> transport);

}  // namespace nlptk

#endif  // CU_NLU_0_6B_HTTP_BACKEND_H_
