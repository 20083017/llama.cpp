import os,pathlib,hashlib,subprocess,datetime,shutil,base64,re
root=pathlib.Path('/home/daigd/dialogue')
assert root.resolve()==root
os.environ['GIT_OPTIONAL_LOCKS']='0';os.environ['GIT_PAGER']='cat'
def git(*a): return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','core.pager=cat','-C',str(root),*a]).strip().decode()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
head='3f086385c81509d40ccb82813758dd1d6d24c0f3';branch='feat/v3-nlu-linux'
assert git('rev-parse','HEAD')==head and git('symbolic-ref','--short','HEAD')==branch
index=root/'.git/index';index_sha=sha(index)
assert index_sha=='5ce26801c99f4784a6913904ce8b1a766fc84d1be0dad7cc00fbfc688e84f179'
target=root/'cu/nlu_0_6b_offline_backend_test.cc'
assert target.resolve()==target and target.is_file() and not target.is_symlink()
assert sha(target)==PREHASH, 'Preimage drift; preserve'
attrs=target.stat();assert attrs.st_mode & 0o7777==0o644
manifest=MANIFEST
for name,digest in manifest.items():
 p=root/name
 assert p.resolve()==p and sha(p)==digest, 'Previous postimage drift: '+name
txn=pathlib.Path('/home/daigd/.wtp184-transactions')/('PLAN-20261016-llm-nlu10-shared-codec-v1-phase2-correction1-'+datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%S%fZ'))
txn.mkdir(mode=0o700)
print('TRANSACTION='+str(txn),flush=True)
with (txn/'application.log').open('x') as log:
 def emit(s): log.write(s+'\n');log.flush();print(s,flush=True)
 shutil.copy2(str(target),str(txn/'nlu_0_6b_offline_backend_test.cc.preimage'))
 assert target.read_bytes()==(txn/'nlu_0_6b_offline_backend_test.cc.preimage').read_bytes()
 patch=txn/'phase2-correction1.patch';patch.write_bytes(base64.b64decode(PATCH))
 emit('Preimage exact digest verified; backup literal-byte matched; mode0644/owner/group/index/branch/HEAD frozen; other17 postimages match')
 for dry in [True,False]:
  cmd=['patch','--batch','--verbose','--fuzz=0','--no-backup-if-mismatch','-p1','-d',str(root),'-i',str(patch)]
  if dry: cmd.insert(1,'--dry-run')
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20)
  out=r.stdout.decode();emit(('DRY_RUN' if dry else 'APPLY')+' exit='+str(r.returncode)+'\n'+out)
  assert r.returncode==0 and not re.search(r'offset|fuzz|FAILED|reject',out,re.I), 'Patch failed; preserve, no rollback'
 assert sha(target)==POSTHASH, 'Postimage mismatch; preserve, no rollback'
 after=target.stat();assert (after.st_mode,after.st_uid,after.st_gid)==(attrs.st_mode,attrs.st_uid,attrs.st_gid)
 for name,digest in manifest.items(): assert sha(root/name)==digest, 'Other postimage changed: '+name
 assert sha(index)==index_sha and git('rev-parse','HEAD')==head and git('symbolic-ref','--short','HEAD')==branch
 emit('PASS: correction expected postimage digest exact; mode0644/owner/group, other17postimages, rawindex, branch/HEAD preserved; no other product edit')
 emit('APPLICATION_LOG='+str(txn/'application.log'))
