from pathlib import Path
b=Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261016-llm-nlu10-shared-codec'); w=b/'phase1-work/cu'
s=(b/'source/cu/nlu_0_6b_http_backend.cc').read_text(encoding='utf-8')
def part(a,z): return s[s.index(a):s.index(z)]
h=part('bool IsAsciiSpace(', 'bool IsDiagnosticRequestIdPrefix(')+part('bool ReadRequiredBoolValue(', 'bool ReadProfileMarkers(')
m=part('bool ReadProfileMarkers(', 'bool LoadProfileConfig(')
m=m[:m.index('  const bool legacy')]+'''  if (protocol.isMember("response_flag_prefix") ||
      !ReadRequiredString(protocol, "response_unknown_marker",
                          &parsed->response_unknown_marker) ||
      !ReadRequiredString(protocol, "response_multi_marker",
                          &parsed->response_multi_marker)) return false;
'''+m[m.index('  const std::string* markers[]'):]
h+=m
load=part('  if (protocol.isMember("request_history_separator")','  parsed->response_protocol = v10 ?').replace('parsed->','parsed.')
load=load.replace('  // The history-list role is active in V10 only. Older layouts ignore the\n  // omitted default, but an explicitly supplied descriptor role must be safe.\n','')
load=load.replace('(v10 || protocol.isMember("request_history_separator")) &&','')
load=load.replace('if (v10 && (','if (').replace('parsed.response_multi_marker)))','parsed.response_multi_marker))')
load=load.replace('const size_t count = v10 ? 2u : (v3 ? 7u : 6u);','const size_t count = 2u;')
load=load.replace('(v10 && (ContainsAsciiControl(text) ||','(ContainsAsciiControl(text) ||').replace('std::string::npos)))','std::string::npos))')
load=load.replace('(v10 && (ContainsAsciiControl(history_field) ||','(ContainsAsciiControl(history_field) ||')
load=load.replace('if (v10 && parsed.empty_history_request_prefixes.empty() &&','if (parsed.empty_history_request_prefixes.empty() &&')
load=load.replace('ProfileRolesAreDistinct(*parsed)', 'ProfileRolesAreDistinct(parsed)').replace('ReadProfileMarkers(protocol, parsed)','ReadProfileMarkers(protocol, &parsed)')
h+='''bool ParseSettings(const Json::Value& profile, const Json::Value& protocol,
                   Nlu10ProtocolSettings* output) {
  if (output == nullptr || !profile.isObject() || !protocol.isObject() ||
      !protocol["protocol"].isString() ||
      protocol["protocol"].asString() != "nlu_10" ||
      protocol.isMember("version") || protocol.isMember("response_protocol") ||
      protocol.isMember("response_flag_prefix") ||
      !protocol["request_field_prefixes"].isArray()) return false;
  // Common model settings have one authority. Reject stale transport/format
  // keys instead of silently ignoring configuration from an older binary.
  const char* allowed[] = {"model", "system_prompt", "stream", "temperature",
      "top_p", "top_k", "max_tokens", "enable_thinking",
      "allow_multi_intent_output", "protocol_path"};
  if (profile.size() != sizeof(allowed) / sizeof(allowed[0])) return false;
  for (size_t i = 0u; i < sizeof(allowed) / sizeof(allowed[0]); ++i) {
    if (!profile.isMember(allowed[i])) return false;
  }
  Nlu10ProtocolSettings parsed;
  parsed.request_history_separator = ';';  // U+003B / 3B, request role only.
  if (!ReadRequiredString(profile, "model", &parsed.model) ||
      !ReadRequiredString(profile, "system_prompt", &parsed.system_prompt) ||
      !profile["stream"].isBool() || profile["stream"].asBool() ||
      !ReadOptionalDouble(profile, "temperature", 0.01, 0.0, 2.0, true,
                          &parsed.temperature) ||
      !ReadOptionalDouble(profile, "top_p", 0.95, 0.0, 1.0, false,
                          &parsed.top_p) ||
      !ReadOptionalInt(profile, "top_k", 20, 1, 1000, &parsed.top_k) ||
      !ReadOptionalInt(profile, "max_tokens", 1024, 1, 65536,
                       &parsed.max_tokens) ||
      !ReadRequiredBoolValue(profile, "enable_thinking", &parsed.enable_thinking) ||
      !ReadRequiredBoolValue(profile, "allow_multi_intent_output",
                             &parsed.allow_multi_intent_output)) return false;
'''+load+'''  *output = parsed;
  return true;
}

'''
h+=part('// V10 uses descriptor-owned', 'bool BuildProfileUserContent(')
f=part('bool IsProfileResponseSyntax(', 'std::string TrimV10AsciiSpace(')
f=f.replace('  const bool v10 = config.response_protocol == kResponseProtocolProfileV10;\n','')
f=f.replace('if (first == std::string::npos || (!v10 && second == std::string::npos))','if (first == std::string::npos)')
f=f.replace('v10 ? domain_text : TrimAsciiSpace(domain_text)','domain_text').replace('v10 ? intent_text : TrimAsciiSpace(intent_text)','intent_text')
f=f.replace('if (v10 && (','if (').replace('domain == config.response_unknown_marker))','domain == config.response_unknown_marker)').replace('ContainsAsciiControl(intent)))','ContainsAsciiControl(intent))')
f=f.replace('if (v10 && content.compare','if (content.compare')
a=f.index('  if (config.response_protocol == kResponseProtocolProfileV3'); z=f.index('  // Only slot fields',a); f=f[:a]+f[z:]
f=f.replace('if (pair_assignment != \'\\0\' ||\n          (!v10 && pair.find(assignments[i], candidate + 1u) !=\n                       std::string::npos)) {','if (pair_assignment != \'\\0\') {')
f=f.replace('(v10 && TrimAsciiSpace(value).empty())','TrimAsciiSpace(value).empty()').replace('ContainsAsciiControl(value)))','ContainsAsciiControl(value))')
p=part('std::string TrimV10AsciiSpace(', 'ContentParseResult ParseContent(')
p=p.replace('  const bool v10 = config.response_protocol == kResponseProtocolProfileV10;\n','').replace('  if (v10 && !ReadV10ResponsePayload(raw_content, &v10_content))','  if (!ReadV10ResponsePayload(raw_content, &v10_content))').replace('v10 ? v10_content : raw_content','v10_content')
a=p.index('  if (!v10 && content.size()'); z=p.index('  for (size_t i = 0u; i < config.response_frame_separators',a)
p=p[:a]+'''  // Choose the used alternative, independent of descriptor order. All
  // candidates are structural: mixing leading/inter-frame styles is invalid.
'''+p[z:]
p=p.replace('v10 && has_multi_marker ? marker_size : 0u','has_multi_marker ? marker_size : 0u').replace('v10 && has_multi_marker','has_multi_marker')
p=p.replace('    size_t offset = marker_size + (v10 ? 0u : 1u);','''    size_t offset = marker_size;
    // Only after the COMPLETE exact marker, accept zero or one leading byte
    // of the same style used between frames. Empty/double/trailing rows still
    // fail below; the marker alone or a single frame is never valid multi.
    if (offset < content.size() && content[offset] == response_frame_separator)
      ++offset;''')
body=(h+f+p).replace('HttpBackendConfig','Nlu10ProtocolSettings').replace('if (below_minimum || value > maximum)', 'if (!std::isfinite(value) || below_minimum || value > maximum)')
(w/'nlu_10_protocol.cc').write_text('''// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_10_protocol.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <set>
#include <utility>

namespace nlptk {
namespace {

const size_t kMaximumProfileTextBytes = 128u;

'''+body+'''}  // namespace

std::unique_ptr<LlmProtocol> Nlu10Protocol::Create(
    const Json::Value& profile, const Json::Value& descriptor) {
  Nlu10ProtocolSettings settings;
  if (!ParseSettings(profile, descriptor, &settings))
    return std::unique_ptr<LlmProtocol>();
  return std::unique_ptr<LlmProtocol>(new Nlu10Protocol(settings));
}

bool Nlu10Protocol::BuildRequest(const Nlu06BRequest& request,
                                 Json::Value* payload) const {
  if (payload == nullptr) return false;
  *payload = Json::Value();
  std::string content;
  if (!BuildV10UserContent(request, settings_, &content)) return false;
  Json::Value built(Json::objectValue);
  built["model"] = settings_.model;
  built["messages"] = Json::Value(Json::arrayValue);
  Json::Value message(Json::objectValue);
  message["role"] = "system";
  message["content"] = settings_.system_prompt;
  built["messages"].append(message);
  message["role"] = "user";
  message["content"] = content;
  built["messages"].append(message);
  built["temperature"] = settings_.temperature;
  built["top_p"] = settings_.top_p;
  built["top_k"] = settings_.top_k;
  built["max_tokens"] = settings_.max_tokens;
  built["stream"] = false;
  built["enable_thinking"] = settings_.enable_thinking;
  *payload = built;
  return true;
}

ContentParseResult Nlu10Protocol::ParseResponse(
    const std::string& content, Json::Value* result) const {
  if (result == nullptr) return kContentNullResult;
  *result = Json::Value();
  Json::Value parsed;
  const ContentParseResult code = ParseProfileContent(settings_, content, &parsed);
  if (code == kContentSuccess) *result = parsed;
  return code;
}

std::string Nlu10Protocol::model_identity() const {
  size_t size = std::min(settings_.model.size(), size_t(128u));
  if (size < settings_.model.size()) {
    while (size > 0u &&
           (static_cast<unsigned char>(settings_.model[size]) & 0xc0u) == 0x80u)
      --size;
  }
  std::string identity = settings_.model.substr(0u, size);
  for (size_t i = 0u; i < identity.size(); ++i) {
    const unsigned char byte = static_cast<unsigned char>(identity[i]);
    if (std::iscntrl(byte) || std::isspace(byte)) identity[i] = '_';
  }
  return identity;
}

}  // namespace nlptk
''',encoding='utf-8',newline='\n')
