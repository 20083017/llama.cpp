// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_NLU_0_6B_OFFLINE_INFERENCE_H_
#define CU_NLU_0_6B_OFFLINE_INFERENCE_H_

extern "C" {

// Same function type as existing InferenceCallback; no public API dependency.
typedef void (*Nlu06BOutputCallback)(const char* chunk, void* request_context);

// 0 = success; nonzero = error. request_json/chunks/contexts are borrowed.
// Return only after ALL callbacks finish, including on error. Supply one full
// text or ordered serialized DELTAs, not snapshots. No exceptions or callbacks
// may escape invocation. Host must complete within its execution budget; this
// interface cannot hard-cancel a hung hook. Separate calls may overlap: provider
// supports independent contexts or host serializes admission externally.
// No reentrant lifecycle operations from callbacks.
typedef int (*Nlu06BInferenceHook)(
    const char* request_json, void* owner_context, void* request_context,
    Nlu06BOutputCallback callback);

}  // extern "C"

namespace nlptk {

// Initialization-only value binding. Host retains provider code/resources
// through all admitted calls and Release; core never releases SDK resources.
struct Nlu06BInferenceBinding {
  Nlu06BInferenceBinding(Nlu06BInferenceHook hook = nullptr,
                        void* context = nullptr)
      : inference(hook), owner_context(context) {}

  Nlu06BInferenceHook inference;
  void* owner_context;
};

}  // namespace nlptk

#endif  // CU_NLU_0_6B_OFFLINE_INFERENCE_H_
