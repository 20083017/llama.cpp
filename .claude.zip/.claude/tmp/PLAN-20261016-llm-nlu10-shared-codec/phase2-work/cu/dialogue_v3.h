// Copyright 2022 the project authors. All Rights Reserved.

#ifndef CU_DIALOGUE_V3_H_
#define CU_DIALOGUE_V3_H_

#include <atomic>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "cu/dialogue_request.h"
#include "cu/dialogue_response.h"
#include "cu/hot_queries_cache.h"
#include "ctx_filter/ctx_filter.h"
#include "dialog/client_content.h"
#include "dialog/context_manager.h"
#include "dialog/dialogue_manager.h"
#include "dialog/lang_gen_result.h"
#include "dialog/personalized_dict_manager.h"
#include "dialog/turn.h"
#include "dst/dst_manager.h"
#include "guard/query_guard.h"
#include "normalizer/slot_normalizer.h"
#include "plugins/plugin_manager.h"
#include "qts/query_processor.h"
#include "semantic_modifier/semantic_modifier.h"
#include "semantics_processor/multi_semantic_processor.h"
#include "semantics_processor/single_semantic_processor.h"

#include "cu/dialogue_v3_pipeline.h"
#include "cu/nlu_0_6b_offline_inference.h"

#if defined(__linux__) && !defined(__ANDROID__)
#include "qr/qr_manager.h"
#endif

namespace nlptk {

struct DialogueCode {
  static const int Success = 0;
  static const int E_Error = -1;
  static const int E_UnregistedScenario = -2;
  static const int E_Invalid = -3;
  static const int E_EmptyQuery = -4;
  static const int E_ContextManager = -5;
};

class Dialogue {
 public:
  static void Initialize();

 public:
  Dialogue();
  ~Dialogue();

  int Initialize(const std::string& config_file);
  // Additive init-time binding. A valid instance never silently rebinds.
  int Initialize(const std::string& config_file, Nlu06BInferenceBinding binding);
  int Process(const DialogueRequest& request, DialogueResponse* response) const;
  bool Valid() const { return valid_; }
  int ReInitialize();

 protected:
  int ProcessV3(const std::vector<dialog::Turn*>& history,
                dialog::Turn* current_turn, DialogueResponse* response,
                const DialogueV3Input& pipeline_input,
                const Nlu06BRequest& model_request,
                int hot_query_code) const;
  int BeforeProcess(const DialogueRequest& request, dialog::Turn* current_turn,
                    std::vector<dialog::Turn*>* history,
                    DialogueResponse* response) const;
  int AfterProcess(const std::string& session_id, dialog::Turn* current_turn,
                   std::vector<dialog::Turn*>* history) const;


  int GetHotQueryCache(DialogueResponse* response, dialog::Turn* turn) const;
#if defined(__linux__) && !defined(__ANDROID__)
  int QueryRejection(DialogueResponse* response) const;
#endif
  void Destruction();

 protected:
  friend class DialogueInstance;
  std::atomic<bool> valid_;

 public:
  size_t turn_history_size_;
  size_t query_history_size_;
  std::shared_ptr<dialog::ContextManager> context_manager_;
  std::shared_ptr<dialog::DialogueManager> dialogue_manager_;
  std::shared_ptr<clu::DstManager> dst_manager_;
  std::shared_ptr<clu::MultiSemanticProcessor> semantics_processor_;
  std::shared_ptr<clu::SingleSemanticProcessor> semantic_processor_;
  std::vector<clu::SemanticModifier*> semantic_modifiers_;
  clu::SlotNormalizer* normalizer_;
  std::shared_ptr<clu::PluginManager> plugin_manager_;
  std::unique_ptr<utils::SimpleThreadPool> thread_pool_;
  std::shared_ptr<HotQueriesCache> hot_queries_cache_;
  std::string config_file_;
  std::shared_ptr<clu::QueryProcessor> query_normalizer_;
  std::shared_ptr<clu::CtxFilter> ctx_filter_;
  std::shared_ptr<clu::QueryGuard> query_guard_;
#if defined(__linux__) && !defined(__ANDROID__)
  std::shared_ptr<clu::QrManager> qr_manager_;
#endif
  std::shared_ptr<dialog::PersonalizedDictManager>
      personalized_dict_manager_;
  std::shared_ptr<Nlu06BManager> nlu_0_6b_manager_;
  std::shared_ptr<DialogueV3Pipeline> v3_pipeline_;
  size_t model_history_rounds_;
  size_t model_history_bytes_;
  bool allow_multi_intent_history_;
  std::string version;

 private:
  int InitializeImpl(const std::string& config_file,
                     Nlu06BInferenceBinding binding);
  // Only installed after successful initialization; preserved by ReInitialize.
  std::unique_ptr<const Nlu06BInferenceBinding> inference_binding_;
};

class DialogueInstance {
 public:
  static bool Initialize(const std::string& config);
  static const Dialogue& Get();

 private:
  static Dialogue instance_;
};

}  // namespace nlptk

#endif  // CU_DIALOGUE_V3_H_
