// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/dialogue_internal.h"
#include "cu/dialogue_v3.h"
#include "cu/dialogue_v3_pipeline.h"
#include "cu/v3_query_history_policy.h"

#include <chrono>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "base/json_helper.h"
#include "dialog/flow_task_context.h"
#include "dialog/reference_parser.h"
#include "gtest/gtest.h"
#include "nlu/property.h"
#include "nlu/semantic_frame.h"

namespace nlptk {
namespace {

class FakeContextManager : public dialog::ContextManager {
 public:
  FakeContextManager()
      : turn_put_result(0), hset_result(0), hset_calls(0), del_calls(0) {}

  int Initialize(const std::string&) override { return 0; }
  int Initialize(const Json::Value&) override { return 0; }

  int Get(const std::string& key,
          std::vector<dialog::Turn*>* session) const override {
    events.push_back("turn-get:" + key);
    session->clear();
    return 0;
  }

  int Put(const std::string& key,
          const std::vector<dialog::Turn*>&) override {
    events.push_back("turn-put:" + key);
    return turn_put_result;
  }

  int Get(const std::string& key, std::string* value) const override {
    events.push_back("get:" + key);
    std::map<std::string, std::string>::const_iterator found = values.find(key);
    *value = found == values.end() ? std::string() : found->second;
    return 0;
  }

  int Put(const std::string& key, const std::string& value,
          const ContextType&) override {
    events.push_back("put:" + key);
    values[key] = value;
    return 0;
  }

  int ZGet(const std::string&, int,
           std::vector<std::string>* output) const override {
    output->clear();
    return 0;
  }

  int ZAdd(const std::string&, const std::string&, double,
           const ContextType&) override {
    return 0;
  }

  int HGet(const std::string& key,
           std::vector<std::string>* output) const override {
    events.push_back("hget:" + key);
    *output = hash_values;
    return 0;
  }

  int HSet(const std::string& key, const std::string& field,
           const std::string& value, const ContextType&) override {
    events.push_back("hset:" + key + ":" + field);
    ++hset_calls;
    if (hset_result < 0) {
      return hset_result;
    }
    hashes[key][field] = value;
    return 0;
  }

  int HDel(const std::string& key, const std::string& field) override {
    events.push_back("hdel:" + key + ":" + field);
    hashes[key].erase(field);
    return 0;
  }

  int Del(const std::string& key) override {
    events.push_back("del:" + key);
    ++del_calls;
    hashes.erase(key);
    return 0;
  }

  int turn_put_result;
  int hset_result;
  int hset_calls;
  int del_calls;
  mutable std::vector<std::string> events;
  mutable std::map<std::string, std::string> values;
  std::vector<std::string> hash_values;
  std::map<std::string, std::map<std::string, std::string> > hashes;
};

std::string SerializeQuery(const std::string& id, const std::string& text,
                           int64_t timestamp) {
  clu::Query query(text);
  query.SetRequestId(id);
  query.SetNormalizedQuery("normalized-" + text);
  query.SetTimeStamp(std::chrono::milliseconds(timestamp));
  query.SetExtraData("metadata", "preserved");
  query.SetEnableLLM(false);
  return JsonHelper::ToString(query.Serialize());
}

std::shared_ptr<clu::SubQuery> MakeSubQuery(const std::string& text,
                                            const std::string& category) {
  std::shared_ptr<clu::SubQuery> sub_query(new clu::SubQuery(text));
  sub_query->request_id = "current-id";
  sub_query->index = 1;
  sub_query->is_last = true;
  sub_query->category = category;
  return sub_query;
}

void PrepareResponse(DialogueResponse* response) {
  response->request_id = "current-id";
  response->session_id = "session-1";
  response->normalized_query = "normalized-current";
  std::shared_ptr<clu::Query> query(new clu::Query("current"));
  query->SetRequestId(response->request_id);
  query->SetNormalizedQuery(response->normalized_query);
  query->SetExtraData("metadata", "current-value");
  response->query_histories.push_back(query);
  response->sub_queries.push_back(MakeSubQuery("normalized-current", "vehicle"));
}

class FakeHotFixNlu : public DialogueV3NluProcessor {
 public:
  int Process(const Nlu06BRequest&, nlu::SemanticFrames* output,
              Nlu06BResultInfo* info) const override {
    info->Clear();
    info->result_source = "hotfix";

    std::unique_ptr<nlu::SemanticFrame> frame(new nlu::SemanticFrame());
    frame->domain = {"vehicle", 1.0f};
    frame->intents.emplace_back("set_wind_direction", 1.0f);

    std::unique_ptr<nlu::Slot> normalized_slot(
        new nlu::Slot("wind_direction", "吹脸吹足"));
    std::unique_ptr<nlu::CanonicalString> normalized_value(
        new nlu::CanonicalString("吹面吹脚"));
    if (normalized_slot->SetProperty(normalized_value.get()) < 0) {
      return -1;
    }
    normalized_value.release();
    if (frame->slots.Add(normalized_slot.get()) < 0) {
      return -1;
    }
    normalized_slot.release();

    std::unique_ptr<nlu::Slot> raw_only_slot(
        new nlu::Slot("fan_mode", "auto"));
    if (frame->slots.Add(raw_only_slot.get()) < 0) {
      return -1;
    }
    raw_only_slot.release();

    output->push_back(frame.release());
    return 0;
  }
};

TEST(DialogueV3Test, RestoresOwnedQueriesInTimeOrderThenAppendsCurrent) {
  FakeContextManager context;
  context.hash_values.push_back(SerializeQuery("later", "second", 20));
  context.hash_values.push_back(SerializeQuery("earlier", "first", 10));
  DialogueRequest request;
  request.id = "current-id";
  request.session_id = "session-1";
  request.query = "current";
  request.first_wakeup = false;
  std::vector<std::shared_ptr<clu::Query> > queries;

  ASSERT_EQ(0, RestoreV3QueryHistory(request, 4u, &context, &queries));
  ASSERT_EQ(3u, queries.size());
  EXPECT_EQ("earlier", queries[0]->GetRequestId());
  EXPECT_EQ("later", queries[1]->GetRequestId());
  EXPECT_EQ("current-id", queries[2]->GetRequestId());
  EXPECT_NE(queries[0].get(), queries[1].get());
  std::string metadata;
  EXPECT_EQ(0, queries[0]->GetExtraData("metadata", &metadata));
  EXPECT_EQ("preserved", metadata);
  ASSERT_GE(context.events.size(), 2u);
  EXPECT_EQ("hget:Query:session-1", context.events[0]);
  EXPECT_EQ("get:SubQuery:session-1", context.events[1]);
}

TEST(DialogueV3Test, FirstWakeupUsesExistingQueryKeyReset) {
  FakeContextManager context;
  DialogueRequest request;
  request.id = "current-id";
  request.session_id = "session-1";
  request.query = "current";
  request.first_wakeup = true;
  std::vector<std::shared_ptr<clu::Query> > queries;

  ASSERT_EQ(0, RestoreV3QueryHistory(request, 4u, &context, &queries));
  ASSERT_EQ(1u, queries.size());
  EXPECT_TRUE(queries[0]->IsFirstWakeUp());
  EXPECT_EQ(1, context.del_calls);
  ASSERT_EQ(1u, context.events.size());
  EXPECT_EQ("del:Query:session-1", context.events[0]);
}

TEST(DialogueV3Test, CompletedRequestStoresOnlyCurrentQueryAfterBothBarriers) {
  FakeContextManager context;
  DialogueResponse response;
  PrepareResponse(&response);
  std::shared_ptr<clu::Query> old_query(new clu::Query("old"));
  old_query->SetRequestId("old-id");
  response.query_histories.insert(response.query_histories.begin(), old_query);

  EXPECT_EQ(0, StoreV3QueryHistory(
                   true, true, true, 4u, &context, &response));
  EXPECT_EQ(1, context.hset_calls);
  ASSERT_EQ(1u, context.hashes["Query:session-1"].size());
  EXPECT_TRUE(context.hashes["Query:session-1"].find("old-id") ==
              context.hashes["Query:session-1"].end());
  const Json::Value stored = JsonHelper::ParseJsonFromString(
      context.hashes["Query:session-1"]["current-id"]);
  EXPECT_EQ("current-value", stored["extra_data"]["metadata"].asString());
  EXPECT_EQ("normalized-current:vehicle", stored["llm_command"].asString());
}

TEST(DialogueV3Test, FailedBarrierDoesNotWriteOrRenewQueryTtl) {
  for (int failed_barrier = 0; failed_barrier < 2; ++failed_barrier) {
    FakeContextManager context;
    DialogueResponse response;
    PrepareResponse(&response);
    EXPECT_EQ(1, StoreV3QueryHistory(
                     failed_barrier != 0, failed_barrier != 1, true,
                     4u, &context, &response));
    EXPECT_EQ(0, context.hset_calls);
    EXPECT_TRUE(context.hashes.empty());
  }
}

TEST(DialogueV3Test, DuplicateRequestIdOverwritesAndRenewsLikeHSet) {
  FakeContextManager context;
  DialogueResponse response;
  PrepareResponse(&response);
  ASSERT_EQ(0, StoreV3QueryHistory(
                   true, true, true, 4u, &context, &response));
  response.query_histories.back()->SetResponse("updated response");
  ASSERT_EQ(0, StoreV3QueryHistory(
                   true, true, true, 4u, &context, &response));

  EXPECT_EQ(2, context.hset_calls);
  ASSERT_EQ(1u, context.hashes["Query:session-1"].size());
  const Json::Value stored = JsonHelper::ParseJsonFromString(
      context.hashes["Query:session-1"]["current-id"]);
  EXPECT_EQ("updated response", stored["response"].asString());
}

TEST(DialogueV3Test, GuardSensitiveDoesNotEnterNluHistory) {
  FakeContextManager context;
  DialogueResponse response;
  PrepareResponse(&response);
  response.sub_queries.front()->is_sensitive = true;

  EXPECT_EQ(1, StoreV3QueryHistory(
                   true, true, false, 4u, &context, &response));
  EXPECT_EQ(0, context.hset_calls);
  EXPECT_TRUE(context.hashes.empty());
}

TEST(DialogueV3Test, RejectedMockDoesNotEnterNluHistory) {
  FakeContextManager context;
  DialogueResponse response;
  PrepareResponse(&response);
  response.sub_queries.front()->is_rejected = true;
  response.query_histories.back()->UpdateStatus(clu::Query::Status::kRejected);

  EXPECT_EQ(1, StoreV3QueryHistory(
                   true, true, false, 4u, &context, &response));
  EXPECT_EQ(0, context.hset_calls);
  EXPECT_TRUE(context.hashes.empty());
}

TEST(DialogueV3Test, GuardSensitiveDoesNotRenewHistoryWriteState) {
  FakeContextManager context;
  DialogueResponse response;
  PrepareResponse(&response);
  response.sub_queries.front()->is_sensitive = true;

  ASSERT_EQ(1, StoreV3QueryHistory(
                   true, true, false, 4u, &context, &response));
  EXPECT_EQ(0, context.hset_calls);
}

TEST(DialogueV3Test, RejectedMockDoesNotRenewHistoryWriteState) {
  FakeContextManager context;
  DialogueResponse response;
  PrepareResponse(&response);
  response.sub_queries.front()->is_rejected = true;
  response.query_histories.back()->UpdateStatus(clu::Query::Status::kRejected);

  ASSERT_EQ(1, StoreV3QueryHistory(
                   true, true, false, 4u, &context, &response));
  EXPECT_EQ(0, context.hset_calls);
}

TEST(DialogueV3Test, SemanticRoutesAreNluHistoryEligible) {
  for (int route = 0; route < 4; ++route) {
    dialogue_internal::V3NluHistoryEligibility eligibility;
    eligibility.status_ok = true;
    eligibility.semantics_complete = true;
    eligibility.semantic_count = route == 3 ? 2u : 1u;
    eligibility.multi_intent = route == 3;
    EXPECT_TRUE(dialogue_internal::IsNluHistoryEligible(eligibility));
  }
}

TEST(DialogueV3Test,
     SensitiveSemanticDomainDoesNotWriteWhenSubQueryFlagIsUnset) {
  FakeContextManager context;
  DialogueResponse response;
  PrepareResponse(&response);
  ASSERT_FALSE(response.sub_queries.front()->is_sensitive);
  response.sub_queries.front()->category = "sensitive";
  nlu::SemanticFrame* frame = new nlu::SemanticFrame();
  frame->domain = {"sensitive", 1.0f};
  frame->intents.emplace_back("sensitive", 1.0f);
  nlu::SemanticFrames frames;
  frames.push_back(frame);

  const dialogue_internal::V3NluHistoryEligibility eligibility =
      dialogue_internal::BuildV3NluHistoryEligibility(response, frames);
  const bool history_eligible =
      dialogue_internal::IsNluHistoryEligible(eligibility);
  ASSERT_FALSE(history_eligible);
  EXPECT_EQ(1, StoreV3QueryHistory(
                   true, true, history_eligible, 4u, &context, &response));
  EXPECT_EQ(0, context.hset_calls);
  EXPECT_TRUE(context.hashes.empty());
}

TEST(DialogueV3Test, SensitiveRejectedAndIncompleteRoutesAreIneligible) {
  dialogue_internal::V3NluHistoryEligibility eligibility;
  eligibility.status_ok = true;
  eligibility.semantics_complete = true;
  eligibility.semantic_count = 1;
  EXPECT_TRUE(dialogue_internal::IsNluHistoryEligible(eligibility));

  eligibility.sensitive = true;
  EXPECT_FALSE(dialogue_internal::IsNluHistoryEligible(eligibility));
  eligibility.sensitive = false;
  eligibility.rejected = true;
  EXPECT_FALSE(dialogue_internal::IsNluHistoryEligible(eligibility));
  eligibility.rejected = false;
  eligibility.semantics_complete = false;
  EXPECT_FALSE(dialogue_internal::IsNluHistoryEligible(eligibility));
  eligibility.semantics_complete = true;
  eligibility.multi_intent = true;
  EXPECT_FALSE(dialogue_internal::IsNluHistoryEligible(eligibility));
}

TEST(DialogueV3Test, FrameAliasDetachesOnFailureAndTransfersExactlyOnce) {
  nlu::SemanticFrames owner;
  nlu::SemanticFrames turn_frames;
  nlu::SemanticFrame* frame = new nlu::SemanticFrame();
  frame->domain = {"vehicle", 1.0f};
  frame->intents.emplace_back("open_window", 1.0f);
  owner.push_back(frame);
  {
    dialogue_internal::ScopedFrameAlias alias(&turn_frames, frame);
    ASSERT_TRUE(alias.attached());
    ASSERT_EQ(frame, turn_frames[0]);
  }
  EXPECT_TRUE(turn_frames.empty());
  ASSERT_EQ(1u, owner.size());
  EXPECT_EQ(frame, owner[0]);

  ASSERT_EQ(0, dialogue_internal::TransferFrameOwnership(
                   &owner, &turn_frames));
  EXPECT_TRUE(owner.empty());
  ASSERT_EQ(1u, turn_frames.size());
  EXPECT_EQ(frame, turn_frames[0]);
  EXPECT_LT(dialogue_internal::TransferFrameOwnership(
                &owner, &turn_frames),
            0);
}

TEST(DialogueV3Test,
     HotFixSlotProjectionPreservesRawAndFlowReferenceUsesCanonicalValue) {
  DialogueV3Input input;
  input.request_id = "normalized-slot-request";
  input.query = "set wind direction";
  input.original_query = input.query;
  input.enable_hotfix = true;

  Nlu06BRequest model_request;
  model_request.request_id = input.request_id;
  model_request.query = input.query;
  model_request.enable_hotfix = true;
  model_request.hotfix_query = input.query;

  DialogueV3Pipeline pipeline;
  FakeHotFixNlu fake_nlu;
  nlu::SemanticFrames routed_frames;
  DialogueV3RouteResult route_result;
  ASSERT_EQ(0, pipeline.Route(input, model_request, 0, nullptr, nullptr,
                              &fake_nlu, &routed_frames, &route_result));
  ASSERT_EQ(1u, routed_frames.size());
  EXPECT_EQ("hotfix", route_result.result_source);

  nlu::SemanticFrame* frame = routed_frames.front();
  ASSERT_NE(nullptr, frame);
  nlu::Slot* slot = frame->slots.GetSlot("wind_direction");
  ASSERT_NE(nullptr, slot);
  ASSERT_EQ(1u, slot->properties.size());
  ASSERT_EQ(typeid(nlu::CanonicalString), slot->properties[0]->Type());
  nlu::CanonicalString* normalized_value =
      static_cast<nlu::CanonicalString*>(slot->properties[0]);
  const std::string raw_before_projection = slot->value;
  const std::string normal_before_projection = normalized_value->Value();

  dialog::Turn turn;
  turn.session_id = "session-1";
  turn.text = input.query;
  clu::SubQuery dispatch_info(input.query);
  dispatch_info.category = "vehicle";
  dispatch_info.generate_text = input.query;
  dispatch_info.index = 0;

  {
    dialogue_internal::ScopedFrameAlias alias(&turn.frames, frame);
    ASSERT_TRUE(alias.attached());
    ASSERT_EQ(frame, turn.frames.front());

    const Json::Value projected =
        dialogue_internal::GetDispatchJsonResult(turn, dispatch_info);
    const Json::Value& projected_slots = projected["Nlu"]["Slots"];
    ASSERT_EQ(2u, projected_slots.size());
    EXPECT_EQ("吹面吹脚", projected_slots[0]["Value"].asString());
    EXPECT_EQ("吹脸吹足", projected_slots[0]["RawValue"].asString());
    EXPECT_EQ("auto", projected_slots[1]["Value"].asString());
    EXPECT_EQ("auto", projected_slots[1]["RawValue"].asString());
    EXPECT_EQ(raw_before_projection, slot->value);
    EXPECT_EQ(normal_before_projection, normalized_value->Value());

    dialog::TaskContext context(turn.frames.front());
    dialog::ReferenceParser parser("@{slot.wind_direction.normal}");
    ASSERT_EQ(0, parser.ParseOne());
    dialog::EventInput reference_value;
    ASSERT_EQ(0, parser.Acquire(context, &reference_value));
    EXPECT_EQ("吹面吹脚", reference_value.AsString());
    EXPECT_EQ(raw_before_projection, slot->value);
    EXPECT_EQ(normal_before_projection, normalized_value->Value());
  }

  EXPECT_TRUE(turn.frames.empty());
  ASSERT_EQ(1u, routed_frames.size());
  EXPECT_EQ(frame, routed_frames.front());
}

TEST(DialogueV3Test, SyncAndStreamExposeTheSameCompleteResult) {
  DialogueResponse synchronous;
  DialogueResponse streaming;
  synchronous.request_id = "request";
  streaming.request_id = "request";
  synchronous.session_id = "session";
  streaming.session_id = "session";
  synchronous.original_query = "query";
  streaming.original_query = "query";
  synchronous.stream = false;
  streaming.stream = true;
  Json::Value result;
  result["Query"] = "query";
  result["Results"] = Json::Value(Json::arrayValue);
  result["Results"].append(Json::Value(Json::objectValue));
  result["IsMultiIntent"] = false;
  synchronous.semantic_json = result;
  streaming.semantic_json = result;

  const Json::Value synchronous_json = synchronous.ToJson();
  const Json::Value streaming_json = streaming.ToJson();
  EXPECT_EQ(JsonHelper::ToString(synchronous_json["Payload"]["Semantic"]),
            JsonHelper::ToString(streaming_json["Payload"]["Semantic"]));
  EXPECT_TRUE(streaming_json["Header"]["IsEnd"].asBool());
}

TEST(DialogueV3Test, QueryCloneUsesSerializationRatherThanIncompleteCopy) {
  clu::Query source("query");
  source.SetRequestId("id");
  source.SetFirstWakeUp(true);
  source.SetExtraData("metadata", "value");
  source.SetDomainRelevance("relevant");
  std::shared_ptr<clu::Query> clone;

  ASSERT_EQ(0, dialogue_internal::CloneQuery(source, &clone));
  ASSERT_TRUE(clone);
  EXPECT_NE(&source, clone.get());
  EXPECT_TRUE(clone->IsFirstWakeUp());
  EXPECT_EQ("relevant", clone->GetDomainRelevance());
  std::string metadata;
  EXPECT_EQ(0, clone->GetExtraData("metadata", &metadata));
  EXPECT_EQ("value", metadata);
}

TEST(DialogueV3Test, V3DebugIsFlatTypedExactAndAbsentOnDefaultOrCopy) {
  DialogueResponse response;
  PrepareResponse(&response);
  response.debug = true;
  // The shared serializer's default is also the unchanged V2 default.
  const char* keys[] = {"is_hotcachequeries", "is_hit_rule", "is_rejected",
                        "is_multi_intent", "nlu_result"};
  const Json::Value default_json = response.ToJson();
  for (const char* key : keys) {
    EXPECT_FALSE(default_json["debug"].isMember(key));
  }
  Json::Value& diagnostics = response.debug_info.v3_diagnostics;
  diagnostics["is_hotcachequeries"] = true;
  diagnostics["is_hit_rule"] = false;
  diagnostics["is_rejected"] = true;
  diagnostics["is_multi_intent"] = true;
  const std::string text = "flag:multi|车控\t打开\tname=车窗\n：；";
  diagnostics["nlu_result"] = text;
  // Synthetic rejection metadata must not redefine the provenance projection.
  response.rejection_result.SetHitRule(
      "synthetic reason", true, clu::MultiClassQueryResult::kRejectionTag);
  const Json::Value json = response.ToJson();
  for (size_t i = 0u; i < 4u; ++i) {
    EXPECT_TRUE(json["debug"][keys[i]].isBool());
  }
  EXPECT_TRUE(json["debug"]["is_hotcachequeries"].asBool());
  EXPECT_FALSE(json["debug"]["is_hit_rule"].asBool());
  EXPECT_TRUE(json["debug"]["is_rejected"].asBool());
  EXPECT_TRUE(json["debug"]["is_multi_intent"].asBool());
  ASSERT_TRUE(json["debug"]["nlu_result"].isString());
  EXPECT_EQ(text, json["debug"]["nlu_result"].asString());
  EXPECT_FALSE(json["debug"].isMember("v3_diagnostics"));
  EXPECT_TRUE(json["debug"].isMember("HotQueryCache"));
  const Json::Value round_trip = JsonHelper::ParseJsonFromString(
      JsonHelper::ToString(json));
  EXPECT_EQ(text, round_trip["debug"]["nlu_result"].asString());
  EXPECT_EQ(std::string(u8"：；"), std::string("\xEF\xBC\x9A\xEF\xBC\x9B"));
  // Projection does not enter semantic output or the Query/history carrier.
  EXPECT_EQ(std::string::npos,
            JsonHelper::ToString(json["Payload"]).find("nlu_result"));
  EXPECT_EQ(std::string::npos,
            JsonHelper::ToString(response.query_histories.back()->Serialize())
                .find("nlu_result"));
  DialogueResponse copy(response);
  EXPECT_TRUE(copy.debug_info.v3_diagnostics.isNull());
  for (const char* key : keys) {
    EXPECT_FALSE(copy.ToJson()["debug"].isMember(key));
  }
  diagnostics["nlu_result"] = "";
  ASSERT_TRUE(response.ToJson()["debug"]["nlu_result"].isString());
  EXPECT_EQ("", response.ToJson()["debug"]["nlu_result"].asString());
  diagnostics.removeMember("nlu_result");
  EXPECT_FALSE(response.ToJson()["debug"].isMember("nlu_result"));
  response.debug = false;
  diagnostics["nlu_result"] = text;
  EXPECT_FALSE(response.ToJson().isMember("debug"));
}

TEST(DialogueV3Test, ErrorBeforeRoutingResetsReusedResponseDiagnostics) {
  Dialogue dialogue;
  DialogueRequest request;
  request.id = "not-initialized";
  request.enable_debug = true;
  DialogueResponse response;
  response.debug_info.v3_diagnostics["nlu_result"] = "stale";
  response.debug_info.v3_diagnostics["is_hit_rule"] = true;
  ASSERT_EQ(503, dialogue.Process(request, &response));
  const Json::Value json = response.ToJson();
  EXPECT_FALSE(json["debug"].isMember("nlu_result"));
  const char* flags[] = {"is_hotcachequeries", "is_hit_rule", "is_rejected",
                         "is_multi_intent"};
  for (const char* flag : flags) {
    EXPECT_TRUE(json["debug"][flag].isBool());
    EXPECT_FALSE(json["debug"][flag].asBool());
  }
  request.enable_debug = false;
  ASSERT_EQ(503, dialogue.Process(request, &response));
  EXPECT_TRUE(response.debug_info.v3_diagnostics.isNull());
  EXPECT_FALSE(response.ToJson().isMember("debug"));
}

TEST(DialogueV3Test, FinalStreamAndAggregateKeepTheSameRequestedDiagnostics) {
  DialogueResponse aggregate;
  DialogueResponse stream;
  aggregate.debug = true;
  stream.debug = true;
  stream.stream = true;
  const std::string raw = "vehicle\topen_window\tname=车窗\n";
  aggregate.debug_info.v3_diagnostics["nlu_result"] = raw;
  aggregate.debug_info.v3_diagnostics["is_multi_intent"] = true;
  stream.debug_info = aggregate.debug_info;
  const Json::Value aggregate_json = aggregate.ToJson();
  const Json::Value stream_json = stream.ToJson();
  EXPECT_EQ(aggregate_json["debug"]["nlu_result"],
            stream_json["debug"]["nlu_result"]);
  EXPECT_EQ(aggregate_json["debug"]["is_multi_intent"],
            stream_json["debug"]["is_multi_intent"]);
  EXPECT_TRUE(stream_json["Header"]["IsEnd"].asBool());
  DialogueResponse intermediate(stream);
  EXPECT_FALSE(intermediate.ToJson()["debug"].isMember("nlu_result"));
}

#if defined(__linux__) && !defined(__ANDROID__)
class NativeDialogueProbe : public Dialogue {
 public:
  using Dialogue::BeforeProcess;
  using Dialogue::ProcessV3;
  using Dialogue::QueryRejection;
};

void PrepareNativeProbe(NativeDialogueProbe* dialogue,
                        DialogueResponse* response) {
  PrepareResponse(response);
  response->debug = true;
  response->rejection_result.SetContextVariables(&response->context_variables);
  response->query_histories.back()->SetContextVariables(
      &response->context_variables);
  dialogue->qr_manager_.reset(new clu::QrManager());
  dialogue->v3_pipeline_.reset(new DialogueV3Pipeline());
  // The existing null-modifier error boundary stops these fixture calls before
  // plugins/DM. No configuration, Redis, HTTP or model service is required.
  dialogue->semantic_modifiers_.push_back(nullptr);
}

TEST(DialogueV3Test, NativeMissingOrEmptyMicrophonePositionDefaultsToDriver) {
  for (bool microphone_without_position : {false, true}) {
    NativeDialogueProbe dialogue;
    std::shared_ptr<FakeContextManager> context(new FakeContextManager());
    dialogue.context_manager_ = context;
    // Exercise restoration as well as the current Query mutation. Historical
    // explicit positions must not be changed by the current driver's fallback.
    clu::Query historical("historical raw text");
    historical.SetRequestId("historical-position");
    historical.SetSoundPosition("副驾");
    context->hash_values.push_back(JsonHelper::ToString(historical.Serialize()));
    DialogueRequest request;
    request.id = "position-current";
    request.session_id = "position-session";
    request.query = "当前原文	：；\n保留";
    request.first_wakeup = false;
    request.enable_debug = true;
    DialogueResponse response;
    dialog::Turn turn;
    if (microphone_without_position) {
      std::shared_ptr<dialog::EventInput> microphone(new dialog::EventInput());
      microphone->SetName("microphone");
      microphone->SetValue(std::string());
      turn.inputs.push_back(microphone);
    }
    std::vector<dialog::Turn*> history;
    ASSERT_EQ(static_cast<int>(DialogueCode::Success),
              dialogue.BeforeProcess(request, &turn, &history, &response));
    ASSERT_TRUE(history.empty());
    ASSERT_EQ(2u, response.query_histories.size());
    EXPECT_EQ("副驾", response.query_histories.front()->GetSoundPosition());
    EXPECT_EQ("historical raw text", response.query_histories.front()->GetQuery());
    EXPECT_EQ("主驾", response.query_histories.back()->GetSoundPosition());
    EXPECT_EQ(request.query, response.query_histories.back()->GetQuery());
    EXPECT_EQ(request.query, response.original_query);
    EXPECT_EQ("副驾", response.context_variables["last_query.microphone.position"]);
    EXPECT_FALSE(response.rejection_result.IsRepeatQuery());
  }
}

void SeedQrMetadata(DialogueResponse* response) {
  // This tests reported metadata/exception handling, not CRE rule execution.
  response->rejection_result.SetHitRule(
      "fixture-qr-reject", true, clu::MultiClassQueryResult::kRejectionTag);
  response->rejection_result.SetHitRule(
      "fixture-qr-semantic", true, clu::MultiClassQueryResult::kSemanticTag);
}

int RunNativeProbe(NativeDialogueProbe* dialogue, DialogueResponse* response,
                   int hot_code, dialog::Turn* turn) {
  DialogueV3Input input;
  input.request_id = response->request_id;
  input.query = response->normalized_query;
  input.original_query = response->original_query;
  Nlu06BRequest request;
  request.request_id = input.request_id;
  request.query = input.query;
  std::vector<dialog::Turn*> history;
  return dialogue->ProcessV3(history, turn, response, input, request, hot_code);
}

Json::Value ProbeNluConfig(bool rejected) {
  Json::Value config(Json::objectValue);
  Json::Value& result = config["MockResponses"]["normalized-current"];
  result["is_rejected"] = rejected;
  result["reject_reason"] = rejected ? "fixture-rejection" : "";
  result["is_multi_intent"] = false;
  result["frames"] = Json::Value(Json::arrayValue);
  if (!rejected) {
    Json::Value frame(Json::objectValue);
    frame["domain"] = "vehicle";
    frame["intents"].append("open_window");
    frame["slots"] = Json::Value(Json::objectValue);
    result["frames"].append(frame);
  }
  return config;
}

TEST(DialogueV3Test, NativeQrRejectionAndExceptionsUseEffectiveAdmission) {
  for (int scenario = 0; scenario < 4; ++scenario) {
    NativeDialogueProbe dialogue;
    DialogueResponse response;
    PrepareNativeProbe(&dialogue, &response);
    SeedQrMetadata(&response);
    response.rejection_result.SetFirstWakeup(scenario == 1 || scenario == 3);
    response.rejection_result.SetRepeatQuery(scenario == 2);
    if (scenario == 3) response.rejection_result.SetVersion("v2.0");
    const bool effective_rejected = scenario == 0 || scenario == 3;
    if (!effective_rejected) {
      dialogue.nlu_0_6b_manager_.reset(new Nlu06BManager());
      ASSERT_EQ(0, dialogue.nlu_0_6b_manager_->Initialize(
                       ProbeNluConfig(false), ""));
    }
    dialog::Turn turn;
    EXPECT_EQ(static_cast<int>(DialogueCode::E_Error),
              RunNativeProbe(&dialogue, &response, 0, &turn));
    ASSERT_EQ(1u, response.sub_queries.size());
    EXPECT_EQ(effective_rejected ? "other" : "vehicle",
              response.sub_queries.front()->category);
    EXPECT_EQ(effective_rejected, response.sub_queries.front()->is_rejected);
    EXPECT_EQ(effective_rejected,
              (response.query_histories.back()->GetStatus() &
               static_cast<int>(clu::Query::Status::kRejected)) != 0);
    nlu::SemanticFrames admission_frames;
    nlu::SemanticFrame* admission_frame = new nlu::SemanticFrame();
    admission_frame->domain = {response.sub_queries.front()->category, 1.0f};
    admission_frame->intents.emplace_back("fixture_intent", 1.0f);
    admission_frames.push_back(admission_frame);
    EXPECT_EQ(!effective_rejected, dialogue_internal::IsNluHistoryEligible(
        dialogue_internal::BuildV3NluHistoryEligibility(response, admission_frames)));
    const Json::Value debug = response.ToJson()["debug"];
    EXPECT_EQ(effective_rejected, debug["is_rejected"].asBool());
    EXPECT_TRUE(debug["is_hit_rule"].asBool());
    EXPECT_FALSE(debug["is_multi_intent"].asBool());
    EXPECT_FALSE(debug.isMember("nlu_result"));
    ASSERT_TRUE(debug["NluInfo"].isArray());
    ASSERT_EQ(1u, debug["NluInfo"].size());
    EXPECT_EQ(effective_rejected ? "qr" : "mock",
              debug["NluInfo"][0u]["source"].asString());
    if (scenario == 1) {
      // v1 wakeup permits NLU without changing QR's raw rejection metadata.
      EXPECT_TRUE(response.rejection_result.isRjected());
      EXPECT_TRUE(debug["RejectionInfo"]["is_rejected"].asBool());
    }
  }
}

TEST(DialogueV3Test, NativeNluRejectDoesNotOverwriteQrMatcherMetadata) {
  NativeDialogueProbe dialogue;
  DialogueResponse response;
  PrepareNativeProbe(&dialogue, &response);
  Json::Value config = ProbeNluConfig(true);
  config["MockResponses"]["normalized-current"]["nlu_result"] = "flag:unknown";
  // QR acceptance/wakeup does not waive the independent NLU rejection gate.
  response.rejection_result.SetFirstWakeup(true);
  dialogue.nlu_0_6b_manager_.reset(new Nlu06BManager());
  ASSERT_EQ(0, dialogue.nlu_0_6b_manager_->Initialize(config, ""));
  dialog::Turn turn;
  ASSERT_EQ(static_cast<int>(DialogueCode::E_Error),
            RunNativeProbe(&dialogue, &response, 0, &turn));
  ASSERT_EQ(1u, response.sub_queries.size());
  EXPECT_TRUE(response.sub_queries.front()->is_rejected);
  EXPECT_FALSE(response.rejection_result.IsHitRejectedRule());
  EXPECT_FALSE(response.rejection_result.isRjected());
  const Json::Value debug = response.ToJson()["debug"];
  EXPECT_FALSE(debug["is_hit_rule"].asBool());
  EXPECT_TRUE(debug["is_rejected"].asBool());
  EXPECT_EQ("flag:unknown", debug["nlu_result"].asString());
}

TEST(DialogueV3Test, NativeDecodedErrorProjectsTextBeforeReturning) {
  for (const std::string& text : {std::string(), std::string("未解析\t原文\n：；")}) {
    NativeDialogueProbe dialogue;
    DialogueResponse response;
    PrepareNativeProbe(&dialogue, &response);
    Json::Value config = ProbeNluConfig(false);
    Json::Value& carrier = config["MockResponses"]["normalized-current"];
    carrier["frames"] = Json::Value(Json::arrayValue);
    carrier["nlu_result"] = text;
    dialogue.nlu_0_6b_manager_.reset(new Nlu06BManager());
    ASSERT_EQ(0, dialogue.nlu_0_6b_manager_->Initialize(config, ""));
    dialog::Turn turn;
    ASSERT_EQ(static_cast<int>(DialogueCode::E_Error),
              RunNativeProbe(&dialogue, &response, 0, &turn));
    const Json::Value debug = response.ToJson()["debug"];
    ASSERT_TRUE(debug["nlu_result"].isString());
    EXPECT_EQ(text, debug["nlu_result"].asString());
    EXPECT_FALSE(debug["is_hit_rule"].asBool());
    EXPECT_FALSE(debug["is_rejected"].asBool());
    EXPECT_FALSE(debug["is_multi_intent"].asBool());
    EXPECT_TRUE(turn.frames.empty());
    EXPECT_EQ(static_cast<int>(clu::Query::Status::kOk),
              response.query_histories.back()->GetStatus());
  }
}

TEST(DialogueV3Test, NativeHotQueryBypassesQrAndFailureDoesNotBecomeReject) {
  NativeDialogueProbe dialogue;
  dialogue.v3_pipeline_.reset(new DialogueV3Pipeline());
  DialogueResponse response;
  PrepareResponse(&response);
  response.debug = true;
  dialog::Turn turn;
  nlu::SemanticFrame* frame = new nlu::SemanticFrame();
  frame->domain = {"media", 1.0f};
  frame->intents.emplace_back("play", 1.0f);
  turn.frames.push_back(frame);
  // No QR/guard/NLU owner exists: the supplied complete HotQuery still wins.
  ASSERT_EQ(static_cast<int>(DialogueCode::Success),
            RunNativeProbe(&dialogue, &response, 1, &turn));
  EXPECT_FALSE(response.ToJson()["debug"].isMember("nlu_result"));
  EXPECT_FALSE(response.ToJson()["debug"]["is_multi_intent"].asBool());
  ASSERT_EQ(static_cast<int>(DialogueCode::E_Error),
            RunNativeProbe(&dialogue, &response, -1, &turn));
  EXPECT_FALSE(response.ToJson()["debug"]["is_rejected"].asBool());
  EXPECT_EQ(static_cast<int>(DialogueCode::E_Error),
            dialogue.QueryRejection(&response));
}
#endif

TEST(DialogueV3Test, RejectedCurrentDoesNotReplaceAcceptedHistoryForNextQuery) {
  FakeContextManager context;
  DialogueResponse accepted;
  PrepareResponse(&accepted);
  accepted.request_id = "A";
  accepted.query_histories.back()->SetRequestId("A");
  nlu::SemanticFrames frames;
  nlu::SemanticFrame* frame = new nlu::SemanticFrame();
  frame->domain = {"vehicle", 1.0f};
  frame->intents.emplace_back("open_window", 1.0f);
  frames.push_back(frame);
  Json::Value semantics;
  ASSERT_EQ(0, BuildV3NluHistorySemantics("accepted-A", frames, &semantics));
  ASSERT_EQ(0, AttachV3NluHistorySemantics(
                   semantics, accepted.query_histories.back().get()));
  ASSERT_TRUE(dialogue_internal::IsNluHistoryEligible(
      dialogue_internal::BuildV3NluHistoryEligibility(accepted, frames)));
  ASSERT_EQ(0, StoreV3QueryHistory(true, true, true, 4u, &context, &accepted));
  ASSERT_EQ(1, context.hset_calls);

  DialogueResponse rejected;
  PrepareResponse(&rejected);
  rejected.request_id = "B";
  rejected.query_histories.back()->SetRequestId("B");
  rejected.query_histories.back()->UpdateStatus(clu::Query::Status::kRejected);
  rejected.sub_queries.front()->is_rejected = true;
  const bool eligible = dialogue_internal::IsNluHistoryEligible(
      dialogue_internal::BuildV3NluHistoryEligibility(rejected, frames));
  ASSERT_FALSE(eligible);
  ASSERT_EQ(1, StoreV3QueryHistory(true, true, eligible, 4u, &context, &rejected));
  EXPECT_EQ(1, context.hset_calls);
  ASSERT_EQ(1u, context.hashes["Query:session-1"].size());
  context.hash_values.push_back(context.hashes["Query:session-1"]["A"]);

  DialogueRequest next;
  next.id = "C";
  next.session_id = "session-1";
  next.query = "next-C";
  next.first_wakeup = false;
  std::vector<std::shared_ptr<clu::Query> > queries;
  ASSERT_EQ(0, RestoreV3QueryHistory(next, 4u, &context, &queries));
  Json::Value histories;
  Json::Value selected;
  ASSERT_EQ(0, ProjectV3QueryHistories(queries, "C", 1u, 65536u, false,
                                      &histories, &selected));
  ASSERT_EQ(1u, histories.size());
  EXPECT_EQ("accepted-A", selected[0u]["query"].asString());
  EXPECT_EQ("open_window", selected[0u]["intent"].asString());
  // Even a previously supplied rejected record is filtered by the unchanged
  // latest-eligible selector, not deleted or retroactively QR-classified.
  ASSERT_EQ(0, AttachV3NluHistorySemantics(
                   semantics, rejected.query_histories.back().get()));
  queries.insert(queries.end() - 1, rejected.query_histories.back());
  ASSERT_EQ(0, ProjectV3QueryHistories(queries, "C", 1u, 65536u, false,
                                      &histories, &selected));
  ASSERT_EQ(1u, histories.size());
  EXPECT_EQ("accepted-A", selected[0u]["query"].asString());
  EXPECT_EQ(1, context.hset_calls);
}

int UncalledInference(const char*, void*, void*, Nlu06BOutputCallback) {
  ADD_FAILURE() << "Invalid initialization must not invoke provider";
  return 1;
}

TEST(DialogueV3Test, AdditiveInitializerRejectsInvalidInputsWithoutBinding) {
  Dialogue dialogue;
  EXPECT_LT(dialogue.Initialize("", Nlu06BInferenceBinding(&UncalledInference)), 0);
  EXPECT_LT(dialogue.Initialize("not-used", Nlu06BInferenceBinding()), 0);
  EXPECT_LT(dialogue.Initialize(std::string("bad\0path", 8u),
                               Nlu06BInferenceBinding(&UncalledInference)), 0);
  EXPECT_FALSE(dialogue.Valid());
  EXPECT_FALSE(dialogue.nlu_0_6b_manager_);
}

}  // namespace
}  // namespace nlptk
