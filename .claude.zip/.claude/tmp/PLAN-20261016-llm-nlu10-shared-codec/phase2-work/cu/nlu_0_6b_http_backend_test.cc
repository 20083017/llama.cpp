// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_0_6b_http_backend.h"

#include "cu/llm_protocol.h"
#include "cu/nlu_0_6b_offline_backend.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

#include "base/json_helper.h"
#include "base/logging.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace {

class FakeTransport : public Nlu06BHttpTransport {
 public:
  FakeTransport(int result_code, long status_code, const std::string& body)
      : result_code_(result_code),
        status_code_(status_code),
        body_(body),
        post_count_(0) {}

  int Post(const Nlu06BHttpRequest& request,
           Nlu06BHttpResponse* response) const override {
    ++post_count_;
    request_ = request;
    if (result_code_ < 0 || response == nullptr) {
      return -1;
    }
    response->status_code = status_code_;
    response->body = body_;
    return 0;
  }

  int post_count() const { return post_count_; }
  void SetResponseBody(const std::string& body) { body_ = body; }

  mutable Nlu06BHttpRequest request_;

 private:
  int result_code_;
  long status_code_;
  std::string body_;
  mutable int post_count_;
};

class ScopedLogCapture : public google::LogSink {
 public:
  ScopedLogCapture() { google::AddLogSink(this); }
  ~ScopedLogCapture() override { google::RemoveLogSink(this); }

  void send(google::LogSeverity severity, const char* full_filename,
            const char* base_filename, int line,
            const google::LogMessageTime& log_message_time,
            const char* message, size_t message_len) override {
    (void)severity;
    (void)full_filename;
    (void)base_filename;
    (void)line;
    (void)log_message_time;
    std::lock_guard<std::mutex> lock(mutex_);
    messages_.append(message, message_len);
    messages_.push_back('\n');
  }

  std::string messages() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return messages_;
  }

 private:
  mutable std::mutex mutex_;
  std::string messages_;
};

std::string TransportFixtureRoot() {
  const char* root = std::getenv("TEST_TMPDIR");
  return root == nullptr ? std::string() : std::string(root);
}

Json::Value MakeConfig() {
  const std::string root = TransportFixtureRoot();
  Json::Value protocol = JsonHelper::ParseJsonFromString(R"JSON({
    "protocol":"nlu_10", "request_field_prefixes":["history:","query: "],
    "field_delimiter":"\t", "request_slot_assignment":"=",
    "request_slot_separator":",", "response_slot_assignment":"=",
    "response_slot_separator":",", "response_frame_separator":";",
    "response_unknown_marker":"unknown", "response_multi_marker":"multi:"
  })JSON");
  Json::Value catalog = JsonHelper::ParseJsonFromString(R"JSON({"profiles":{
    "transport-fixture":{"model":"qwen3", "system_prompt":"parse vehicle semantics",
    "protocol_path":"transport-protocol.json", "stream":false,
    "temperature":0.01,"top_p":0.95,"top_k":20,"max_tokens":1024,
    "enable_thinking":false,"allow_multi_intent_output":true}}})JSON");
  std::ofstream descriptor((root + "/transport-protocol.json").c_str());
  descriptor << JsonHelper::ToString(protocol);
  std::ofstream profiles((root + "/transport-catalog.json").c_str());
  profiles << JsonHelper::ToString(catalog);
  Json::Value config(Json::objectValue);
  config["Model"]["profile_catalog_path"] = "transport-catalog.json";
  config["Model"]["profile"] = "transport-fixture";
  config["OpenAIHttp"]["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  return config;
}

class ConstantTransport : public Nlu06BHttpTransport {
 public:
  ConstantTransport(long status_code, const std::string& body)
      : status_code_(status_code), body_(body) {}

  int Post(const Nlu06BHttpRequest& request,
           Nlu06BHttpResponse* response) const override {
    (void)request;
    if (response == nullptr) {
      return -1;
    }
    response->status_code = status_code_;
    response->body = body_;
    return 0;
  }

 private:
  long status_code_;
  std::string body_;
};

class ScopedCaptureDirectory {
 public:
  ScopedCaptureDirectory() {
    char path[] = "/tmp/wtp184_nlu06b_capture_XXXXXX";
    char* created = mkdtemp(path);
    if (created != nullptr) {
      path_ = created;
    }
  }

  ~ScopedCaptureDirectory() {
    for (size_t i = 0; i < files_.size(); ++i) {
      std::remove(files_[i].c_str());
    }
    if (!path_.empty()) {
      rmdir(path_.c_str());
    }
  }

  bool valid() const { return !path_.empty(); }

  std::string NewFile(const std::string& name) {
    const std::string path = path_ + "/" + name;
    files_.push_back(path);
    return path;
  }

 private:
  std::string path_;
  std::vector<std::string> files_;
};

Json::Value MakeCaptureConfig(const std::string& path,
                              const std::string& prefix,
                              int max_entries, int max_content_bytes) {
  Json::Value config = MakeConfig();
  config["OpenAIHttp"]["diagnostic_capture_enabled"] = true;
  config["OpenAIHttp"]["diagnostic_capture_output_path"] = path;
  config["OpenAIHttp"]["diagnostic_capture_request_id_prefix"] = prefix;
  config["OpenAIHttp"]["diagnostic_capture_max_entries"] = max_entries;
  config["OpenAIHttp"]["diagnostic_capture_max_content_bytes"] = max_content_bytes;
  return config;
}

std::vector<Json::Value> ReadCaptureRecords(const std::string& path) {
  std::vector<Json::Value> records;
  std::ifstream input(path.c_str());
  std::string line;
  while (std::getline(input, line)) {
    records.push_back(JsonHelper::ParseJsonFromString(line));
  }
  return records;
}

std::string MakeEnvelope(const std::string& content) {
  Json::Value envelope(Json::objectValue);
  envelope["choices"] = Json::Value(Json::arrayValue);
  Json::Value choice(Json::objectValue);
  choice["message"]["role"] = "assistant";
  choice["message"]["content"] = content;
  envelope["choices"].append(choice);
  return JsonHelper::ToString(envelope);
}

void ExpectDecodedContentFailure(const Json::Value& result,
                                 const std::string& content) {
  ASSERT_TRUE(result.isObject());
  ASSERT_EQ(1u, result.size());
  ASSERT_TRUE(result["nlu_result"].isString());
  EXPECT_EQ(content, result["nlu_result"].asString());
  EXPECT_FALSE(result.isMember("frames"));
  EXPECT_FALSE(result.isMember("is_rejected"));
  EXPECT_FALSE(result.isMember("is_multi_intent"));
  EXPECT_FALSE(result.isMember("stale"));
}

std::unique_ptr<Nlu06BBackend> MakeBackend(
    const Json::Value& config, int result_code, long status_code,
    const std::string& body, FakeTransport** fake) {
  std::unique_ptr<FakeTransport> transport(
      new FakeTransport(result_code, status_code, body));
  *fake = transport.get();
  return CreateNlu06BHttpBackend(
      config, TransportFixtureRoot(), std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
}

Nlu06BRequest MakeRequest() {
  Nlu06BRequest request;
  request.request_id = "request-id-not-sent";
  request.query = "副驾驶座椅加热降到1档";
  request.histories = Json::Value(Json::arrayValue);
  request.model_last_context = Json::Value(Json::objectValue);
  request.model_last_context["last_domain"] = "vehicle";
  return request;
}

Json::Value MakeProjectedHistory(const std::string& query,
                                 const std::string& domain,
                                 const std::string& intent,
                                 const Json::Value& slots) {
  Json::Value semantic(Json::objectValue);
  semantic["query"] = query;
  semantic["domain"] = domain;
  semantic["intent"] = intent;
  semantic["slots"] = slots;
  Json::Value history(Json::objectValue);
  history["v3_nlu_semantics"] = Json::Value(Json::arrayValue);
  history["v3_nlu_semantics"].append(semantic);
  return history;
}

Json::Value ReadPayload(const FakeTransport* fake) {
  if (fake == nullptr) {
    return Json::Value();
  }
  return JsonHelper::ParseJsonFromString(fake->request_.body);
}

TEST(Nlu06BHttpBackendTest, LogsBoundedContentSchemaDetails) {
  struct FailureCase {
    const char* content;
    const char* detail;
  };
  const FailureCase failures[] = {
      {"vehicle", "missing_tab"},
      {"multi:fm\tstop;\tstop", "empty_domain"},
      {"vehicle\t\tname=window", "empty_intent"},
      {"unknown\tstop", "invalid_domain_field"},
      {"vehicle\top\x01" "en", "invalid_intent_field"},
      {"vehicle\topen\tname", "invalid_slot_pair"},
      {"vehicle\topen\t=window", "empty_slot_name"},
      {"vehicle\topen\tname=,area=driver", "empty_slot_value"},
      {"vehicle\topen\tname=window,name=roof", "duplicate_slot"},
      {"vehicle\topen\tname=window,", "trailing_slot_separator"},
      {"vehicle\topen\tname=window\textra", "extra_tab"},
      {"`vehicle\topen`", "invalid_wrapper"}};
  for (size_t i = 0; i < sizeof(failures) / sizeof(failures[0]); ++i) {
    ScopedLogCapture capture;
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        MakeConfig(), 0, 200, MakeEnvelope(failures[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    ExpectDecodedContentFailure(result, failures[i].content);

    const std::string messages = capture.messages();
    EXPECT_NE(std::string::npos,
              messages.find("event=nlu06b_http_failure stage=content"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find("request_id=request-id-not-sent"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find("backend=openai_http reason=content_schema"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find(std::string("schema_detail=") +
                            failures[i].detail))
        << i;
    EXPECT_NE(std::string::npos, messages.find("http_status=200")) << i;
    EXPECT_NE(std::string::npos, messages.find("response_bytes=")) << i;
    EXPECT_NE(std::string::npos, messages.find("content_bytes=")) << i;
    EXPECT_EQ(std::string::npos, messages.find(failures[i].content)) << i;
    EXPECT_EQ(std::string::npos,
              messages.find("副驾驶座椅加热降到1档"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find("http://127.0.0.1:1/v1/chat/completions"))
        << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     LogsOnlySanitizedBackendIdentityOnContentSchemaFailure) {
  Json::Value config = MakeConfig();
  const std::string unsafe_endpoint =
      std::string("https://route-user:route-password@example.com:8443/v1/chat") +
      static_cast<char>(10) +
      "/completions?access_token=query-secret#private-fragment";
  const std::string unsafe_model =
      std::string("qwen3") + static_cast<char>(9) + "vehicle" +
      static_cast<char>(10) + "model-" +
      std::string(160u, static_cast<char>(120)) + "model-tail-secret";
  config["OpenAIHttp"]["endpoint"] = unsafe_endpoint;
  Json::Value catalog = JsonHelper::ParseJsonFromFile(
      TransportFixtureRoot() + "/transport-catalog.json");
  catalog["profiles"]["transport-fixture"]["model"] = unsafe_model;
  {
    std::ofstream output((TransportFixtureRoot() + "/transport-catalog.json").c_str());
    output << JsonHelper::ToString(catalog);
  }
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle"), &fake);
  ASSERT_TRUE(backend);

  ScopedLogCapture capture;
  Json::Value result;
  EXPECT_LT(backend->Process(MakeRequest(), &result), 0);
  const std::string messages = capture.messages();
  EXPECT_NE(std::string::npos,
            messages.find(
                "endpoint_url=https://example.com:8443/v1/"
                "chat_/completions"));
  EXPECT_NE(std::string::npos,
            messages.find("model=qwen3_vehicle_model-"));
  EXPECT_NE(std::string::npos,
            messages.find("response_protocol=nlu_10"));
  EXPECT_EQ(std::string::npos, messages.find("route-user"));
  EXPECT_EQ(std::string::npos, messages.find("route-password"));
  EXPECT_EQ(std::string::npos, messages.find("access_token"));
  EXPECT_EQ(std::string::npos, messages.find("query-secret"));
  EXPECT_EQ(std::string::npos, messages.find("private-fragment"));
  EXPECT_EQ(std::string::npos, messages.find("model-tail-secret"));
  EXPECT_EQ(std::string::npos,
            messages.find(std::string("qwen3") + static_cast<char>(9) +
                          "vehicle"));
}

TEST(Nlu06BHttpBackendTest, TransportEnvelopeStatusAndSizeFailuresClearResult) {
  struct FailureCase {
    int transport_code;
    long status_code;
    std::string body;
  };
  Json::Value small_config = MakeConfig();
  small_config["OpenAIHttp"]["max_response_bytes"] = 16;
  std::vector<FailureCase> failures;
  failures.push_back(FailureCase{-1, 0, ""});
  failures.push_back(FailureCase{0, 500, MakeEnvelope("d	i")});
  failures.push_back(FailureCase{0, 200, "not-json"});
  failures.push_back(FailureCase{0, 200, "{}"});
  failures.push_back(
      FailureCase{0, 200, MakeEnvelope("d	i")});
  const char* stages[] = {"transport", "http_status", "envelope", "envelope", "response"};
  const char* reasons[] = {"transport", "http_status", "envelope_parse", "envelope_schema", "response_too_large"};
  for (size_t i = 0; i < failures.size(); ++i) {
    FakeTransport* fake = nullptr;
    const Json::Value& config = i + 1 == failures.size() ? small_config
                                                         : MakeConfig();
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, failures[i].transport_code, failures[i].status_code,
        failures[i].body, &fake);
    ASSERT_TRUE(backend);
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    ScopedLogCapture logs;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    EXPECT_TRUE(result.isNull()) << i;
    const std::string messages = logs.messages();
    EXPECT_NE(std::string::npos, messages.find(std::string("stage=") + stages[i]));
    EXPECT_NE(std::string::npos, messages.find(std::string("reason=") + reasons[i]));
    EXPECT_NE(std::string::npos, messages.find("request_id=request-id-not-sent"));
    EXPECT_NE(std::string::npos, messages.find("model=qwen3"));
    EXPECT_NE(std::string::npos, messages.find("response_protocol=nlu_10"));
    EXPECT_EQ(std::string::npos, messages.find(MakeRequest().query));
  }
}

TEST(Nlu06BHttpBackendTest, DiagnosticCaptureDefaultsOff) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("default_off.jsonl");
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeConfig(), 0, 200,
      MakeEnvelope("vehicle	open_window"), &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  EXPECT_EQ(0, backend->Process(MakeRequest(), &result));
  EXPECT_NE(0, access(path.c_str(), F_OK));
}

TEST(Nlu06BHttpBackendTest, CapturesExactSuccessAndFailureJsonl) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());

  const std::string success_path = directory.NewFile("success.jsonl");
  const std::string success_content =
      "vehicle	open_window	note=say \\\"hi\\\"\\nnow";
  FakeTransport* success_fake = nullptr;
  std::unique_ptr<Nlu06BBackend> success_backend = MakeBackend(
      MakeCaptureConfig(success_path, "capture-", 2, 4096), 0, 200,
      MakeEnvelope(success_content), &success_fake);
  ASSERT_TRUE(success_backend);
  Nlu06BRequest success_request = MakeRequest();
  success_request.request_id = "capture-success";
  Json::Value success_result;
  ASSERT_EQ(0, success_backend->Process(success_request, &success_result));
  std::vector<Json::Value> success_records = ReadCaptureRecords(success_path);
  ASSERT_EQ(1u, success_records.size());
  EXPECT_EQ("capture-success", success_records[0u]["request_id"].asString());
  EXPECT_EQ(success_request.query, success_records[0u]["query"].asString());
  EXPECT_EQ(success_content, success_records[0u]["content"].asString());
  EXPECT_EQ("success", success_records[0u]["schema_detail"].asString());
  EXPECT_EQ(success_content, success_result["nlu_result"].asString());
  EXPECT_FALSE(success_records[0u]["parsed_result"].isMember("nlu_result"));
  Json::Value business_result = success_result;
  business_result.removeMember("nlu_result");
  EXPECT_EQ(business_result, success_records[0u]["parsed_result"]);
  EXPECT_FALSE(success_records[0u]["truncated"].asBool());

  const std::string failure_path = directory.NewFile("failure.jsonl");
  const std::string failure_content = "prefix\\nwithout pipes";
  FakeTransport* failure_fake = nullptr;
  std::unique_ptr<Nlu06BBackend> failure_backend = MakeBackend(
      MakeCaptureConfig(failure_path, "capture-", 2, 4096), 0, 200,
      MakeEnvelope(failure_content), &failure_fake);
  ASSERT_TRUE(failure_backend);
  Nlu06BRequest failure_request = MakeRequest();
  failure_request.request_id = "capture-failure";
  Json::Value failure_result;
  ASSERT_LT(failure_backend->Process(failure_request, &failure_result), 0);
  std::vector<Json::Value> failure_records = ReadCaptureRecords(failure_path);
  ASSERT_EQ(1u, failure_records.size());
  EXPECT_EQ(failure_content, failure_records[0u]["content"].asString());
  EXPECT_EQ("missing_tab", failure_records[0u]["schema_detail"].asString());
  EXPECT_TRUE(failure_records[0u]["parsed_result"].isNull());
  ExpectDecodedContentFailure(failure_result, failure_content);
}

TEST(Nlu06BHttpBackendTest, EnforcesCaptureEntryAndContentBounds) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("bounded.jsonl");
  const std::string content =
      "vehicle	open_window	position=front";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeCaptureConfig(path, "bounded-", 1, 8), 0, 200,
      MakeEnvelope(content), &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest first = MakeRequest();
  first.request_id = "bounded-first";
  Nlu06BRequest second = MakeRequest();
  second.request_id = "bounded-second";
  Json::Value result;
  ScopedLogCapture logs;
  EXPECT_EQ(0, backend->Process(first, &result));
  EXPECT_EQ(0, backend->Process(second, &result));
  EXPECT_EQ(std::string::npos,
            logs.messages().find("nlu06b_diagnostic_capture_failure"));
  std::vector<Json::Value> records = ReadCaptureRecords(path);
  ASSERT_EQ(1u, records.size());
  EXPECT_TRUE(records[0u]["truncated"].asBool());
  EXPECT_EQ(8u, records[0u]["captured_content_bytes"].asUInt());
  EXPECT_EQ(content.size(), records[0u]["content_bytes"].asUInt());
  EXPECT_EQ(content.substr(0, 8), records[0u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, TruncatesCaptureAtUtf8Boundaries) {
  struct Utf8Case {
    const char* name;
    std::string content;
    int limit;
    std::string expected;
  };
  const Utf8Case cases[] = {
      {"three-byte-1", "车辆", 1, ""},
      {"three-byte-2", "车辆", 2, ""},
      {"three-byte-boundary", "车辆", 3, "车"},
      {"four-byte-1", "😀ok", 1, ""},
      {"four-byte-2", "😀ok", 2, ""},
      {"four-byte-3", "😀ok", 3, ""},
      {"four-byte-boundary", "😀ok", 4, "😀"}};
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    const std::string path = directory.NewFile(
        std::string("utf8-") + cases[i].name + ".jsonl");
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        MakeCaptureConfig(path, "utf8-", 1, cases[i].limit), 0, 200,
        MakeEnvelope(cases[i].content), &fake);
    ASSERT_TRUE(backend) << cases[i].name;
    Nlu06BRequest request = MakeRequest();
    request.request_id = std::string("utf8-") + cases[i].name;
    Json::Value result;
    EXPECT_LT(backend->Process(request, &result), 0) << cases[i].name;
    std::vector<Json::Value> records = ReadCaptureRecords(path);
    ASSERT_EQ(1u, records.size()) << cases[i].name;
    ASSERT_TRUE(records[0u].isObject()) << cases[i].name;
    EXPECT_EQ(cases[i].expected, records[0u]["content"].asString())
        << cases[i].name;
    EXPECT_EQ(cases[i].expected.size(),
              records[0u]["captured_content_bytes"].asUInt())
        << cases[i].name;
    EXPECT_TRUE(records[0u]["truncated"].asBool()) << cases[i].name;
  }
}

TEST(Nlu06BHttpBackendTest, WritesConcurrentCaptureRecordsWithoutInterleaving) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("concurrent.jsonl");
  const std::string content = "vehicle	open_window";
  std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
      MakeCaptureConfig(path, "parallel-", 8, 4096), TransportFixtureRoot(),
      std::unique_ptr<Nlu06BHttpTransport>(
          new ConstantTransport(200, MakeEnvelope(content))));
  ASSERT_TRUE(backend);
  std::vector<std::thread> threads;
  for (int i = 0; i < 8; ++i) {
    threads.push_back(std::thread([&backend, i]() {
      Nlu06BRequest request = MakeRequest();
      request.request_id = "parallel-" + std::to_string(i);
      Json::Value result;
      EXPECT_EQ(0, backend->Process(request, &result));
    }));
  }
  for (size_t i = 0; i < threads.size(); ++i) {
    threads[i].join();
  }
  std::vector<Json::Value> records = ReadCaptureRecords(path);
  ASSERT_EQ(8u, records.size());
  std::set<std::string> request_ids;
  for (size_t i = 0; i < records.size(); ++i) {
    ASSERT_TRUE(records[i].isObject());
    request_ids.insert(records[i]["request_id"].asString());
  }
  EXPECT_EQ(8u, request_ids.size());
  struct stat status;
  ASSERT_EQ(0, stat(path.c_str(), &status));
  EXPECT_EQ(0600, status.st_mode & 0777);
}

TEST(Nlu06BHttpBackendTest, DecodedDiagnosticsPreserveExactBytesAndReset) {
  struct Case { std::string content; int code; };
  const Case cases[] = {
      {"  vehicle\topen_window  \n", 0},
      {"vehicle\topen_window\tname=车窗,position=副驾", 0},
      {"vehicle\topen_window\tname：车窗；position：副驾\n", -1},
      {"vehicle\topen_window\tfirst=1,second:2", -1},
      {"", -1}, {"未解析\t原文\n：；=|", -1}};
  EXPECT_EQ(std::string(u8"："), std::string("\xEF\xBC\x9A"));
  EXPECT_EQ(std::string(u8"；"), std::string("\xEF\xBC\x9B"));
  EXPECT_EQ(0x09, static_cast<unsigned char>('\t'));
  EXPECT_EQ(0x0a, static_cast<unsigned char>('\n'));
  for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    Json::Value config = MakeConfig();
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, 0, 200, MakeEnvelope(cases[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    Json::Value result;
    ASSERT_EQ(cases[i].code, backend->Process(MakeRequest(), &result)) << i;
    ASSERT_TRUE(result["nlu_result"].isString()) << i;
    EXPECT_EQ(cases[i].content, result["nlu_result"].asString()) << i;
    const Json::Value round_trip = JsonHelper::ParseJsonFromString(
        JsonHelper::ToString(result));
    EXPECT_EQ(cases[i].content, round_trip["nlu_result"].asString()) << i;
    if (cases[i].code < 0) {
      ExpectDecodedContentFailure(result, cases[i].content);
    }
    // Reuse the same carrier and backend. Envelope failure has no decoded text.
    fake->SetResponseBody("{}");
    ASSERT_LT(backend->Process(MakeRequest(), &result), 0);
    EXPECT_TRUE(result.isNull());
    EXPECT_EQ(2, fake->post_count());
  }
}

TEST(Nlu06BHttpBackendTest, ResponseDiagnosticsDoNotUseCaptureTruncation) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("exact-response.jsonl");
  const std::string content = "unparseable\t" + std::string(65536u, 'x') + "\n尾";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeCaptureConfig(path, "capture-", 1, 16), 0, 200,
      MakeEnvelope(content), &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeRequest();
  request.request_id = "capture-exact-response";
  Json::Value result;
  ASSERT_LT(backend->Process(request, &result), 0);
  ExpectDecodedContentFailure(result, content);
  const std::vector<Json::Value> records = ReadCaptureRecords(path);
  ASSERT_EQ(1u, records.size());
  EXPECT_TRUE(records[0u]["truncated"].asBool());
  EXPECT_LE(records[0u]["content"].asString().size(), 16u);
  EXPECT_TRUE(records[0u]["parsed_result"].isNull());
}

TEST(Nlu06BHttpBackendTest, EnvelopeSchemaErrorsHaveNoDecodedDiagnosticText) {
  FakeTransport* fake = nullptr;
  const std::string valid = MakeEnvelope("vehicle	open_window");
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeConfig(), 0, 200, valid, &fake);
  ASSERT_TRUE(backend);
  const char* invalid[] = {
      "{\"choices\":[]}",
      "{\"choices\":[{\"message\":{\"content\":null}}]}",
      "{\"choices\":[{\"message\":{\"content\":false}}]}",
      "{\"choices\":[{\"message\":{\"content\":\"one\"}},"
      "{\"message\":{\"content\":\"two\"}}]}"};
  Json::Value result;
  for (const char* body : invalid) {
    fake->SetResponseBody(valid);
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
    ASSERT_TRUE(result["nlu_result"].isString());
    fake->SetResponseBody(body);
    ASSERT_LT(backend->Process(MakeRequest(), &result), 0);
    EXPECT_TRUE(result.isNull());
  }
}

TEST(Nlu06BHttpBackendTest, InvalidConfigurationFailsBeforeTransportUse) {
  std::vector<Json::Value> invalid;
  Json::Value missing_endpoint = MakeConfig();
  missing_endpoint["OpenAIHttp"].removeMember("endpoint");
  invalid.push_back(missing_endpoint);
  Json::Value bad_scheme = MakeConfig();
  bad_scheme["OpenAIHttp"]["endpoint"] = "file:///tmp/model";
  invalid.push_back(bad_scheme);
  Json::Value bad_timeout = MakeConfig();
  bad_timeout["OpenAIHttp"]["connect_timeout_ms"] = 100;
  bad_timeout["OpenAIHttp"]["total_timeout_ms"] = 50;
  invalid.push_back(bad_timeout);
  Json::Value bad_response_limit = MakeConfig();
  bad_response_limit["OpenAIHttp"]["max_response_bytes"] = 0;
  invalid.push_back(bad_response_limit);
  Json::Value unknown_response_protocol = MakeConfig();
  unknown_response_protocol["OpenAIHttp"]["response_protocol"] = "future_v2";
  invalid.push_back(unknown_response_protocol);
  Json::Value non_string_response_protocol = MakeConfig();
  non_string_response_protocol["OpenAIHttp"]["response_protocol"] = 1;
  invalid.push_back(non_string_response_protocol);
  Json::Value missing_endpoint_env = MakeConfig();
  missing_endpoint_env["OpenAIHttp"]["endpoint"] =
      "${WTP184_NLU06B_TEST_DEFINITELY_MISSING_ENDPOINT}";
  invalid.push_back(missing_endpoint_env);
  Json::Value missing_key_env = MakeConfig();
  missing_key_env["OpenAIHttp"]["api_key_env"] =
      "WTP184_NLU06B_TEST_DEFINITELY_MISSING_KEY";
  invalid.push_back(missing_key_env);
  Json::Value capture_missing_path = MakeConfig();
  capture_missing_path["OpenAIHttp"]["diagnostic_capture_enabled"] = true;
  capture_missing_path["OpenAIHttp"]["diagnostic_capture_request_id_prefix"] = "capture-";
  capture_missing_path["OpenAIHttp"]["diagnostic_capture_max_entries"] = 1;
  capture_missing_path["OpenAIHttp"]["diagnostic_capture_max_content_bytes"] = 16;
  invalid.push_back(capture_missing_path);
  Json::Value capture_relative_path = capture_missing_path;
  capture_relative_path["OpenAIHttp"]["diagnostic_capture_output_path"] = "relative.jsonl";
  invalid.push_back(capture_relative_path);
  Json::Value capture_bad_prefix = capture_missing_path;
  capture_bad_prefix["OpenAIHttp"]["diagnostic_capture_output_path"] = "/tmp/capture.jsonl";
  capture_bad_prefix["OpenAIHttp"]["diagnostic_capture_request_id_prefix"] = "bad.prefix";
  invalid.push_back(capture_bad_prefix);
  Json::Value capture_zero_entries = capture_missing_path;
  capture_zero_entries["OpenAIHttp"]["diagnostic_capture_output_path"] =
      "/tmp/capture-zero.jsonl";
  capture_zero_entries["OpenAIHttp"]["diagnostic_capture_max_entries"] = 0;
  invalid.push_back(capture_zero_entries);
  for (size_t i = 0; i < invalid.size(); ++i) {
    FakeTransport* fake = nullptr;
    EXPECT_FALSE(MakeBackend(invalid[i], 0, 200, "{}", &fake)) << i;
  }
}

}  // namespace

const char kV10SystemPromptForTest[] =
    u8"你是智能座舱的语义算法专家，你接受用户的Query，进行深度分析，给出语义标签理解结果。对于符合：不完整，不通顺，无意义，结构混乱的无效句式，输出标签:unknown；多意图句式，输出标签：multi";

Json::Value MakeProfileSelector(const std::string& profile) {
  Json::Value config(Json::objectValue);
  config["Model"]["profile"] = profile;
  config["Model"]["profile_catalog_path"] = "catalog.json";
  config["OpenAIHttp"]["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  config["OpenAIHttp"]["connect_timeout_ms"] = 1200;
  config["OpenAIHttp"]["total_timeout_ms"] = 3400;
  return config;
}

Json::Value MakeProfileProtocol(const std::string& protocol_id,
                                const Json::Value& assignments) {
  Json::Value protocol(Json::objectValue);
  protocol["protocol"] = protocol_id;
  protocol["request_field_prefixes"] = Json::Value(Json::arrayValue);
  protocol["request_field_prefixes"].append("history:");
  protocol["request_field_prefixes"].append("query: ");
  protocol["field_delimiter"] = "\t";
  protocol["request_slot_assignment"] = "=";
  protocol["request_slot_separator"] = ",";
  protocol["response_slot_assignment"] = assignments;
  protocol["response_slot_separator"] = ",";
  protocol["response_frame_separator"] = ";";
  protocol["response_unknown_marker"] = "unknown";
  protocol["response_multi_marker"] = "multi:";
  return protocol;
}

void WriteProfileProtocol(const std::string& root, const Json::Value& protocol) {
  std::ofstream output((root + "/protocol.json").c_str());
  output << JsonHelper::ToString(protocol);
}

std::unique_ptr<Nlu06BBackend> MakeProfileBackend(
    const std::string& root, const std::string& profile,
    const std::string& content, FakeTransport** fake) {
  std::unique_ptr<FakeTransport> transport(
      new FakeTransport(0, 200, MakeEnvelope(content)));
  *fake = transport.get();
  return CreateNlu06BHttpBackend(
      MakeProfileSelector(profile), root,
      std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
}

Nlu06BRequest MakeProfileHistoryRequest() {
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  Json::Value slots(Json::objectValue);
  slots["zeta"] = "last";
  slots["alpha"] = "first";
  Json::Value history = MakeProjectedHistory(
      "history query", "vehicle", "open_window", slots);
  history["v3_nlu_semantics"][0u]["tts"] = "spoken";
  request.histories.append(history);
  return request;
}

void WriteProfileFiles(const std::string& root, const std::string& profile,
                       const std::string& protocol_id, bool allow_multi,
                       const Json::Value& assignments = Json::Value("=")) {
  Json::Value selected(Json::objectValue);
  selected["model"] = "qwen3_nlu";
  selected["system_prompt"] = kV10SystemPromptForTest;
  selected["protocol_path"] = "protocol.json";
  selected["stream"] = false;
  selected["temperature"] = 0.2;
  selected["top_p"] = 0.8;
  selected["top_k"] = 12;
  selected["max_tokens"] = 256;
  selected["enable_thinking"] = false;
  selected["allow_multi_intent_output"] = allow_multi;
  Json::Value catalog(Json::objectValue);
  catalog["profiles"][profile] = selected;
  std::ofstream output((root + "/catalog.json").c_str());
  output << JsonHelper::ToString(catalog);
  WriteProfileProtocol(root, MakeProfileProtocol(protocol_id, assignments));
}

Json::Value MakeEmptyHistoryOptionForTest(
    const std::string& history_field, const std::string& query_prefix) {
  Json::Value option(Json::objectValue);
  option["history_field"] = history_field;
  option["query_prefix"] = query_prefix;
  return option;
}

namespace {

std::string WriteV10FilesForTest(ScopedCaptureDirectory* directory,
                                bool allow_multi = true) {
  const std::string catalog_path = directory->NewFile("catalog.json");
  directory->NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "v10", "nlu_10", allow_multi);
  return root;
}

// Filenames are test-owned paths, never layout/version selectors.
void WriteSelectedProtocolForTest(const std::string& root,
                                  const std::string& profile,
                                  const std::string& filename,
                                  const Json::Value& protocol) {
  {
    std::ofstream output((root + "/" + filename).c_str());
    output << JsonHelper::ToString(protocol);
  }
  Json::Value catalog = JsonHelper::ParseJsonFromFile(root + "/catalog.json");
  catalog["profiles"][profile]["protocol_path"] = filename;
  std::ofstream output((root + "/catalog.json").c_str());
  output << JsonHelper::ToString(catalog);
}

Nlu06BRequest MakeV10RequestForTest() {
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  return request;
}

}  // namespace

TEST(Nlu06BHttpBackendTest, ProfileV10DefaultNoneAndConfiguredPromptBytes) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "intelligent_car_control\tcancel_hud_set\tname=hud,mode=歌词",
      &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = u8"hud不显示歌词";
  const std::string query_bytes("hud\xE4\xB8\x8D\xE6\x98\xBE\xE7\xA4\xBA"
                                "\xE6\xAD\x8C\xE8\xAF\x8D");
  ASSERT_EQ(query_bytes, request.query);
  for (size_t i = 0u; i < 2u; ++i) {
    SCOPED_TRACE(i);
    request.histories = i == 0u ? Json::Value() : Json::Value(Json::arrayValue);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result));
    const Json::Value payload = ReadPayload(fake);
    const std::string wire = payload["messages"][1u]["content"].asString();
    EXPECT_EQ("history:None;query: " + query_bytes, wire);
    EXPECT_EQ(0x3bu, static_cast<unsigned char>(wire[12u]));
    EXPECT_EQ(0x3au, static_cast<unsigned char>(wire[7u]));
    EXPECT_EQ(std::string::npos, wire.find('\t'));
    EXPECT_EQ("qwen3_nlu", payload["model"].asString());
    const std::string system = payload["messages"][0u]["content"].asString();
    EXPECT_EQ(kV10SystemPromptForTest, system);
    EXPECT_NE(std::string::npos, system.find("unknown\xEF\xBC\x9B"));
    EXPECT_NE(std::string::npos, system.find(u8"标签" +
                                            std::string("\xEF\xBC\x9A") + "multi"));
    EXPECT_EQ(std::string::npos, system.find("unknown;"));
    EXPECT_FALSE(payload["stream"].asBool());
    EXPECT_FALSE(payload["enable_thinking"].asBool());
    EXPECT_FALSE(payload.isMember("chat_template_kwargs"));
    EXPECT_EQ(1200, fake->request_.connect_timeout_ms);
    EXPECT_EQ(3400, fake->request_.total_timeout_ms);
    EXPECT_EQ("歌词", result["frames"][0u]["slots"]["mode"].asString());
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10UsesChangedProfileValuesNotConstants) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Json::Value catalog = JsonHelper::ParseJsonFromFile(root + "/catalog.json");
  catalog["profiles"]["v10"]["model"] = "other-configured-model";
  catalog["profiles"]["v10"]["system_prompt"] = "other configured prompt";
  catalog["profiles"]["v10"]["temperature"] = 0.6;
  catalog["profiles"]["v10"]["max_tokens"] = 123;
  catalog["profiles"]["v10"]["enable_thinking"] = true;
  {
    std::ofstream output((root + "/catalog.json").c_str());
    output << JsonHelper::ToString(catalog);
  }
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  const Json::Value payload = ReadPayload(fake);
  EXPECT_EQ("other-configured-model", payload["model"].asString());
  EXPECT_EQ("other configured prompt",
            payload["messages"][0u]["content"].asString());
  EXPECT_DOUBLE_EQ(0.6, payload["temperature"].asDouble());
  EXPECT_EQ(123, payload["max_tokens"].asInt());
  EXPECT_TRUE(payload["enable_thinking"].asBool());
}

TEST(Nlu06BHttpBackendTest, ProfileV10DocumentHistoryRowsAndAllProjectedOrder) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = u8"太阳晒的坐凳好热给我打开座椅通风";
  const std::string q1 = u8"现在的环境有点暗，能帮我把氛围灯调亮一点吗？";
  const std::string q2 = u8"列表中的歌曲，能不能设置成循环播放呢";
  Json::Value slots(Json::objectValue);
  slots["gear_direction"] = "调亮";
  Json::Value first = MakeProjectedHistory(q1, "intelligent_car_control",
                                          "atlights_control", slots);
  // V10 never serializes TTS, even when the legacy optional field is present.
  first["v3_nlu_semantics"][0u]["tts"] = "not sent";
  request.histories.append(first);
  const std::string first_row = q1 +
      "\tintelligent_car_control\tatlights_control\tgear_direction=调亮";
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:" + first_row + ";query: " + request.query,
            ReadPayload(fake)["messages"][1u]["content"].asString());

  request.histories.append(MakeProjectedHistory(
      q2, "music", "ctrl_list_cycle", Json::Value(Json::objectValue)));
  const std::string two_rows = first_row + ";" + q2 + "\tmusic\tctrl_list_cycle\t";
  ASSERT_EQ(0, backend->Process(request, &result));
  const std::string wire = ReadPayload(fake)["messages"][1u]["content"].asString();
  EXPECT_EQ("history:" + two_rows + ";query: " + request.query, wire);
  EXPECT_NE(std::string::npos, wire.find("ctrl_list_cycle\t;query: "));
  EXPECT_EQ(6, std::count(wire.begin(), wire.end(), '\t'));
  EXPECT_EQ(2, std::count(wire.begin(), wire.end(), ';'));
  EXPECT_EQ(std::string::npos, wire.find("not sent"));
  EXPECT_EQ(std::string::npos, wire.find("Query1"));

  // The backend does not add a second cap of one or two after projection.
  request.histories.append(MakeProjectedHistory(
      "third", "fm", "stop", Json::Value(Json::objectValue)));
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:" + two_rows + ";third\tfm\tstop\t;query: " + request.query,
            ReadPayload(fake)["messages"][1u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10CleansOnlyQueryControlBytesCallLocally) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = "current\t\r\n  query;keep：；＝";
  Json::Value slots(Json::objectValue);
  slots["zeta"] = "a=b|c";
  slots["alpha"] = "原样：；，＝";
  request.histories.append(MakeProjectedHistory(
      "past\t\r\n  query；", "music", "play", slots));
  const std::string saved_query = request.query;
  const std::string saved_histories = JsonHelper::ToString(request.histories);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:past     query；\tmusic\tplay\t"
            "alpha=原样：；，＝,zeta=a=b|c;query: current     query;keep：；＝",
            ReadPayload(fake)["messages"][1u]["content"].asString());
  EXPECT_EQ(saved_query, request.query);
  EXPECT_EQ(saved_histories, JsonHelper::ToString(request.histories));

  // Successful normalization is repeatable, never written back into a request.
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ(saved_query, request.query);
  EXPECT_EQ(saved_histories, JsonHelper::ToString(request.histories));
  request.query = "current\f\v query";
  request.histories = Json::Value();
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:None;query: current\f\v query",
            ReadPayload(fake)["messages"][1u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10RejectsMalformedHistoriesBeforeTransport) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  const Json::Value valid = MakeProjectedHistory(
      "past", "music", "play", Json::Value(Json::objectValue));
  std::vector<Json::Value> bad;
  bad.push_back(Json::Value());
  bad.push_back(Json::Value("row"));
  bad.push_back(Json::Value(Json::objectValue));
  Json::Value entry = valid;
  entry["v3_nlu_semantics"] = Json::Value(Json::arrayValue);
  bad.push_back(entry);
  entry["v3_nlu_semantics"] = "bad";
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"].append(valid["v3_nlu_semantics"][0u]);
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u] = "bad";
  bad.push_back(entry);
  const char* fields[] = {"query", "domain", "intent", "slots"};
  for (size_t i = 0u; i < 4u; ++i) {
    entry = valid;
    entry["v3_nlu_semantics"][0u].removeMember(fields[i]);
    bad.push_back(entry);
    entry = valid;
    entry["v3_nlu_semantics"][0u][fields[i]] = 7;
    bad.push_back(entry);
    entry = valid;
    entry["v3_nlu_semantics"][0u][fields[i]] = "";
    bad.push_back(entry);
  }
  const char collision_bytes[] = {';', '\t', '\r', '\n', '\0'};
  for (size_t f = 0u; f < 3u; ++f) {
    for (size_t b = 0u; b < 5u; ++b) {
      // Historical query TAB/CR/LF is cleaned, not rejected.
      if (f == 0u && b > 0u && b < 4u) continue;
      entry = valid;
      entry["v3_nlu_semantics"][0u][fields[f]] =
          std::string("a") + collision_bytes[b] + "b";
      bad.push_back(entry);
    }
  }
  const char* bad_keys[] = {"", "a=b", "a,b", "a;b", "a\tb", "a\rb", "a\nb"};
  for (size_t i = 0u; i < 7u; ++i) {
    entry = valid;
    entry["v3_nlu_semantics"][0u]["slots"][bad_keys[i]] = "value";
    bad.push_back(entry);
  }
  const char* bad_values[] = {"", "a,b", "a;b", "a\tb", "a\rb", "a\nb"};
  for (size_t i = 0u; i < 6u; ++i) {
    entry = valid;
    entry["v3_nlu_semantics"][0u]["slots"]["name"] = bad_values[i];
    bad.push_back(entry);
  }
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"]["name"] = std::string("a\0b", 3u);
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"]["name"] = 1;
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"][std::string("a\0b", 3u)] = "value";
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"]["name"] = "   ";
  bad.push_back(entry);
  // Unknown training-history records are not synthesized or admitted here.
  entry = valid;
  entry["v3_nlu_semantics"][0u]["domain"] = "unknown";
  bad.push_back(entry);
  entry["v3_nlu_semantics"][0u].removeMember("intent");
  bad.push_back(entry);
  for (size_t i = 0u; i < bad.size(); ++i) {
    for (size_t position = 0u; position < 2u; ++position) {
      SCOPED_TRACE(i);
      SCOPED_TRACE(position);
      Nlu06BRequest request = MakeV10RequestForTest();
      request.histories.append(position == 0u ? bad[i] : valid);
      request.histories.append(position == 0u ? valid : bad[i]);
      const std::string saved = JsonHelper::ToString(request.histories);
      Json::Value result(Json::objectValue);
      result["stale"] = true;
      EXPECT_EQ(-1, backend->Process(request, &result));
      EXPECT_TRUE(result.isNull());
      EXPECT_EQ(saved, JsonHelper::ToString(request.histories));
      EXPECT_EQ(0, fake->post_count());
    }
  }
  const Json::Value wrong_arrays[] = {Json::Value("history"), Json::Value(1),
      Json::Value(false), Json::Value(Json::objectValue)};
  for (size_t i = 0u; i < 4u; ++i) {
    Nlu06BRequest request = MakeV10RequestForTest();
    request.histories = wrong_arrays[i];
    Json::Value result;
    EXPECT_EQ(-1, backend->Process(request, &result));
  }
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = std::string("a\0b", 3u);
  Json::Value result;
  EXPECT_EQ(-1, backend->Process(request, &result));
  EXPECT_EQ(0, fake->post_count());
}

TEST(Nlu06BHttpBackendTest, ProfileV10SingleNoSlotAndLosslessValues) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  const char* no_slots[] = {"fm\tstop", "fm\tstop\t",
      " \r\n\tfm\tstop\t \r\n\f\v", "intelligent_car_control\tset"};
  for (size_t i = 0u; i < 4u; ++i) {
    SCOPED_TRACE(i);
    fake->SetResponseBody(MakeEnvelope(no_slots[i]));
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
    ASSERT_EQ(1u, result["frames"].size());
    EXPECT_TRUE(result["frames"][0u]["slots"].isObject());
    EXPECT_TRUE(result["frames"][0u]["slots"].empty());
    EXPECT_FALSE(result["is_rejected"].asBool());
    EXPECT_FALSE(result["is_multi_intent"].asBool());
    EXPECT_EQ(no_slots[i], result["nlu_result"].asString());
  }
  const std::string content = "music\tplay\tsong=喀什葛尔的|原核,"
                              "payload=a=b=c|d,words=原样：；，＝";
  fake->SetResponseBody(MakeEnvelope(content));
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  EXPECT_EQ("喀什葛尔的|原核", result["frames"][0u]["slots"]["song"].asString());
  EXPECT_EQ("a=b=c|d", result["frames"][0u]["slots"]["payload"].asString());
  EXPECT_EQ("原样：；，＝", result["frames"][0u]["slots"]["words"].asString());
  EXPECT_TRUE(result["frames"][0u]["slots"]["song"].isString());
  EXPECT_EQ(content, result["nlu_result"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10MultiPrefixOnceAndIndependentOutputGate) {
  const char* responses[] = {
      "multi:fm\tplay\tcategory=搞笑段子;app_agent\tapp_call\tapp=航旅纵横",
      "multi:intelligent_car_control\tseat_position_control\tarea=座椅,"
      "gear_direction=向后,position=主驾;intelligent_car_control\tturn_on_device\t"
      "name=座椅加热,position=主驾;intelligent_car_control\tseat_massage_control\t"
      "position=主驾,time=20",
      "multi:fm\tstop\t;music\tplay\tsong=a|b,expression=x=y;help\thelp"};
  for (size_t gate = 0u; gate < 2u; ++gate) {
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string root = WriteV10FilesForTest(&directory, gate != 0u);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", responses[0u], &fake);
    ASSERT_TRUE(backend);
    // Requests still contain only singleton historical semantics. The input
    // history policy and this output gate have independent responsibilities.
    Nlu06BRequest request = MakeProfileHistoryRequest();
    for (size_t i = 0u; i < 3u; ++i) {
      SCOPED_TRACE(gate);
      SCOPED_TRACE(i);
      fake->SetResponseBody(MakeEnvelope(responses[i]));
      Json::Value result;
      ASSERT_EQ(0, backend->Process(request, &result));
      EXPECT_EQ(gate == 0u, result["is_rejected"].asBool());
      EXPECT_EQ(gate != 0u, result["is_multi_intent"].asBool());
      EXPECT_EQ(gate == 0u ? "multi_intent_disabled" : "",
                result["reject_reason"].asString());
      EXPECT_EQ(gate == 0u ? 0u : (i == 0u ? 2u : 3u), result["frames"].size());
      if (gate != 0u && i == 2u) {
        EXPECT_EQ("a|b", result["frames"][1u]["slots"]["song"].asString());
        EXPECT_EQ("x=y", result["frames"][1u]["slots"]["expression"].asString());
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10LeadingReasoningAndExactUnknown) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "unknown", &fake);
  ASSERT_TRUE(backend);
  const char* prefixes[] = {"", "<think></think>",
      " \n<think>analysis\nwith\ttabs</think>\r\n",
      "<reasoning>bounded analysis</reasoning>\n"};
  const char* payloads[] = {"unknown", "fm\tstop", "multi:fm\tstop;music\tplay"};
  for (size_t p = 0u; p < 4u; ++p) {
    for (size_t c = 0u; c < 3u; ++c) {
      SCOPED_TRACE(p);
      SCOPED_TRACE(c);
      const std::string raw = std::string(prefixes[p]) + payloads[c] + " \r\n";
      fake->SetResponseBody(MakeEnvelope(raw));
      Json::Value result;
      ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
      EXPECT_EQ(raw, result["nlu_result"].asString());
      EXPECT_EQ(c == 0u, result["is_rejected"].asBool());
      EXPECT_EQ(c == 0u ? "unknown" : "", result["reject_reason"].asString());
      EXPECT_EQ(c == 2u, result["is_multi_intent"].asBool());
      EXPECT_EQ(c == 0u ? 0u : (c == 1u ? 1u : 2u), result["frames"].size());
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10MalformedContentNeverReturnsPartialFrames) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  const char* invalid[] = {
      "", " \r\n", "Unknown", "unknown!", "unknown\tfm", "flag:unknown",
      "fm", "\tstop", "fm\t\tname=window", "fm\tstop\tname=window\textra",
      "fm\tstop\tname", "fm\tstop\tname:", "fm\tstop\t=window",
      "fm\tstop\tname=", "fm\tstop\tname=   ,area=driver",
      "fm\tstop\tname=window,name=door",
      "fm\tstop\tname=window,", "fm\tstop\t,name=window",
      "fm\tstop\tname=window,,area=driver", "fm\tstop\tname=window,area:driver",
      "fm\tstop\tname：window", "fm\tstop\tname＝window",
      "fm\tstop\tname:window,area:driver", "fm\tstop\tname=window;area=driver",
      "fm\tstop;music\tplay", "multi:", "multi:fm\tstop", "multi:;fm\tstop",
      "multi:fm\tstop;", "multi:fm\tstop;;music\tplay",
      "multi:fm\tstop;unknown", "multi:unknown;fm\tstop",
      "multi:fm\tstop;multi:music\tplay", "multi:fm\tstop|music\tplay",
      "multi：fm\tstop;music\tplay", "multi:fm\tstop；music\tplay",
      "fm\tstop\tname=window;music\tplay", "multi:fm\tstop;music\tplay\tbad",
      "```\nfm\tstop\n```", "`fm\tstop`", "Here is the answer: fm stop",
      "fm stop explanation", "fm\tstop\nextra prose", "{fm\tstop}",
      "<think>unclosed", "<reasoning>unclosed", "</think>fm\tstop",
      "<think>x</reasoning>fm\tstop", "<think><think>x</think></think>fm\tstop",
      "<think><reasoning>x</reasoning></think>fm\tstop",
      "<reasoning><think>x</think></reasoning>fm\tstop",
      "<think>x</think><reasoning>y</reasoning>fm\tstop",
      "<think>x</think><think>y</think>fm\tstop", "<think>x</think>",
      "fm\tstop<think>x</think>", "fm\tstop\tname=<reasoning>x</reasoning>",
      "multi:fm\tstop;<think>x</think>music\tplay",
      "<think>x</think>Here is the answer: fm stop",
      "<think>x</think>```fm\tstop```"};
  for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
    SCOPED_TRACE(i);
    const std::string raw(invalid[i]);
    fake->SetResponseBody(MakeEnvelope(raw));
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
    ExpectDecodedContentFailure(result, raw);
  }
  const std::string nul = std::string("fm\tstop\tname=a") + '\0' + "b";
  fake->SetResponseBody(MakeEnvelope(nul));
  Json::Value result;
  EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
  ExpectDecodedContentFailure(result, nul);
  // Invalid multi output is not hidden by the disabled-output business gate.
  WriteProfileFiles(root, "v10", "nlu_10", false);
  backend = MakeProfileBackend(root, "v10", "multi:fm\tstop;music\tplay\tbad", &fake);
  ASSERT_TRUE(backend);
  EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
  ExpectDecodedContentFailure(result, "multi:fm\tstop;music\tplay\tbad");
}

TEST(Nlu06BHttpBackendTest, ProfileV10RejectsConflictingMissingAndWrongTypeGrammar) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  // Assert codepoints and bytes, not merely visually similar glyphs.
  ASSERT_EQ(std::string(1u, static_cast<char>(0x09)), "\t");  // U+0009
  ASSERT_EQ(std::string(1u, static_cast<char>(0x3b)), u8";");  // U+003B
  ASSERT_EQ(std::string(1u, static_cast<char>(0x3a)), u8":");  // U+003A
  ASSERT_EQ(std::string(1u, static_cast<char>(0x3d)), u8"=");  // U+003D
  ASSERT_EQ(std::string("\xEF\xBC\x9B"), u8"；");  // U+FF1B
  ASSERT_EQ(std::string("\xEF\xBC\x9A"), u8"：");  // U+FF1A
  ASSERT_EQ(std::string("\xEF\xBC\x9D"), u8"＝");  // U+FF1D
  ASSERT_EQ(std::string("\xEF\xBC\x8C"), u8"，");  // U+FF0C
  const Json::Value valid = MakeProfileProtocol("nlu_10", Json::Value("="));
  std::vector<Json::Value> invalid;
  const char* fields[] = {"protocol", "request_field_prefixes", "field_delimiter",
      "request_slot_assignment", "request_slot_separator",
      "response_slot_assignment", "response_slot_separator",
      "response_frame_separator", "response_unknown_marker", "response_multi_marker"};
  const Json::Value wrong_types[] = {Json::Value(), Json::Value(1),
      Json::Value(false), Json::Value(Json::objectValue)};
  for (size_t f = 0u; f < sizeof(fields) / sizeof(fields[0]); ++f) {
    Json::Value missing = valid;
    missing.removeMember(fields[f]);
    invalid.push_back(missing);
    for (size_t t = 0u; t < 4u; ++t) {
      Json::Value changed = valid;
      changed[fields[f]] = wrong_types[t];
      invalid.push_back(changed);
    }
  }
  const char* scalar_delimiters[] = {"field_delimiter",
      "request_slot_assignment", "request_slot_separator"};
  const Json::Value bad_scalars[] = {Json::Value(""), Json::Value("ab"),
      Json::Value(u8"；"), Json::Value("\n"), Json::Value(" "),
      Json::Value(Json::arrayValue)};
  for (size_t f = 0u; f < 3u; ++f) {
    for (size_t i = 0u; i < sizeof(bad_scalars) / sizeof(bad_scalars[0]); ++i) {
      Json::Value changed = valid;
      changed[scalar_delimiters[f]] = bad_scalars[i];
      invalid.push_back(changed);
    }
  }
  const char* response_roles[] = {"response_slot_assignment",
      "response_slot_separator", "response_frame_separator"};
  const Json::Value bad_candidates[] = {Json::Value(""), Json::Value(u8"；"),
      Json::Value("\t"), Json::Value(" "), Json::Value(Json::arrayValue)};
  for (size_t f = 0u; f < 3u; ++f) {
    for (size_t i = 0u; i < sizeof(bad_candidates) / sizeof(bad_candidates[0]); ++i) {
      Json::Value changed = valid;
      changed[response_roles[f]] = bad_candidates[i];
      invalid.push_back(changed);
    }
    Json::Value changed = valid;
    changed[response_roles[f]] = Json::Value(Json::arrayValue);
    changed[response_roles[f]].append(valid[response_roles[f]]);
    changed[response_roles[f]].append(valid[response_roles[f]]);
    invalid.push_back(changed);  // Duplicate candidates, not a singleton array.
    changed[response_roles[f]][0u] = 1;
    invalid.push_back(changed);
    changed[response_roles[f]][0u] = "ab";
    invalid.push_back(changed);
  }
  const char* collisions[] = {"request_slot_assignment", "request_slot_separator",
      "response_slot_assignment", "response_slot_separator",
      "response_frame_separator"};
  const char* collision_values[] = {",", "=", ",", "=", "="};
  for (size_t f = 0u; f < 5u; ++f) {
    Json::Value changed = valid;
    changed[collisions[f]] = collision_values[f];
    invalid.push_back(changed);
  }
  Json::Value changed = valid;
  changed["request_field_prefixes"][0u] = "bad;prefix";
  invalid.push_back(changed);
  changed = valid;
  changed["request_field_prefixes"][1u] = "bad\tprefix";
  invalid.push_back(changed);
  changed["request_field_prefixes"][1u] = 1;
  invalid.push_back(changed);
  changed = valid;
  changed["request_field_prefixes"].append("");
  invalid.push_back(changed);
  changed = valid;
  changed["request_field_prefixes"] = Json::Value(Json::arrayValue);
  invalid.push_back(changed);
  changed = valid;
  changed["request_field_prefixes"][0u] = std::string(129u, 'h');
  invalid.push_back(changed);
  const char* marker_fields[] = {"response_unknown_marker", "response_multi_marker"};
  const std::string bad_markers[] = {"", std::string(129u, 'm'), "bad;marker",
      "bad\tmarker", "bad\rmarker", "bad\nmarker", "bad\fmarker",
      "bad\vmarker", std::string("bad\0marker", 10u),
      std::string("bad") + static_cast<char>(0x7f) + "marker"};
  for (size_t f = 0u; f < 2u; ++f) {
    for (size_t i = 0u; i < sizeof(bad_markers) / sizeof(bad_markers[0]); ++i) {
      changed = valid;
      changed[marker_fields[f]] = bad_markers[i];
      invalid.push_back(changed);
    }
  }
  changed = valid;
  changed["response_multi_marker"] = "unknown";
  invalid.push_back(changed);
  changed = valid;
  changed["response_flag_prefix"] = "flag:";  // Mutually exclusive forms.
  invalid.push_back(changed);
  changed.removeMember("response_unknown_marker");
  invalid.push_back(changed);
  changed = valid;
  changed["response_flag_prefix"] = "flag:";
  changed.removeMember("response_multi_marker");
  invalid.push_back(changed);
  changed.removeMember("response_unknown_marker");
  changed["response_flag_prefix"] = "";
  invalid.push_back(changed);
  changed["response_flag_prefix"] = std::string(122u, 'p');
  invalid.push_back(changed);
  for (size_t i = 0u; i < invalid.size(); ++i) {
    SCOPED_TRACE(i);
    WriteProfileProtocol(root, invalid[i]);
    FakeTransport* fake = nullptr;
    EXPECT_FALSE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  }
  WriteProfileProtocol(root, valid);
  FakeTransport* fake = nullptr;
  EXPECT_TRUE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  Json::Value flat = MakeConfig();
  flat["response_protocol"] = "nlu_10";
  EXPECT_FALSE(MakeBackend(flat, 0, 200, MakeEnvelope("fm\tstop"), &fake));
}

TEST(Nlu06BHttpBackendTest, ProfileV10PreservesRawCaptureAndSanitizedFailureIdentity) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  const std::string capture_path = directory.NewFile("v10-capture.jsonl");
  Json::Value config = MakeProfileSelector("v10");
  Json::Value& profile = config["OpenAIHttp"];
  profile["diagnostic_capture_enabled"] = true;
  profile["diagnostic_capture_output_path"] = capture_path;
  profile["diagnostic_capture_request_id_prefix"] = "v10-capture-";
  profile["diagnostic_capture_max_entries"] = 1;
  profile["diagnostic_capture_max_content_bytes"] = 1024;
  const std::string raw = "<think>synthetic-private-analysis</think>"
                          "multi:fm\tstop;music\tplay\tbad";
  FakeTransport* fake = nullptr;
  std::unique_ptr<FakeTransport> transport(new FakeTransport(0, 200, MakeEnvelope(raw)));
  fake = transport.get();
  std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
      config, root, std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.request_id = "v10-capture-test";
  request.query = "synthetic-private-query";
  ScopedLogCapture logs;
  Json::Value result;
  ASSERT_EQ(-1, backend->Process(request, &result));
  ExpectDecodedContentFailure(result, raw);
  const std::vector<Json::Value> records = ReadCaptureRecords(capture_path);
  ASSERT_EQ(1u, records.size());
  EXPECT_EQ(raw, records[0u]["content"].asString());
  EXPECT_EQ("invalid_slot_pair", records[0u]["schema_detail"].asString());
  EXPECT_TRUE(records[0u]["parsed_result"].isNull());
  const std::string messages = logs.messages();
  EXPECT_NE(std::string::npos, messages.find("request_id=v10-capture-test"));
  EXPECT_NE(std::string::npos, messages.find("response_protocol=nlu_10"));
  EXPECT_NE(std::string::npos, messages.find("schema_detail=invalid_slot_pair"));
  EXPECT_EQ(std::string::npos, messages.find("synthetic-private-analysis"));
  EXPECT_EQ(std::string::npos, messages.find(request.query));
  EXPECT_EQ(std::string::npos, messages.find(kV10SystemPromptForTest));
  EXPECT_EQ(std::string::npos, messages.find(raw));
}

TEST(Nlu06BHttpBackendTest, ProfileV10RequestAndResponseSeparatorsAreIndependent) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
  protocol["request_history_separator"] = "~";  // U+007E / 7E, not response 3B.
  protocol["request_field_prefixes"][0u] = "H>";
  protocol["request_field_prefixes"][1u] = "Q>";
  WriteProfileProtocol(root, protocol);
  const std::string response = "multi:fm\tstop;music\tplay\tsong=a|b=x";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", response, &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  Json::Value result;
  for (size_t i = 0u; i < 2u; ++i) {
    request.histories = i == 0u ? Json::Value() : Json::Value(Json::arrayValue);
    ASSERT_EQ(0, backend->Process(request, &result));
    const std::string wire = ReadPayload(fake)["messages"][1u]["content"].asString();
    EXPECT_EQ("H>None~Q>current query", wire);
    EXPECT_EQ(0x7eu, static_cast<unsigned char>(wire[6u]));
    EXPECT_EQ(2u, result["frames"].size());
    EXPECT_EQ("a|b=x", result["frames"][1u]["slots"]["song"].asString());
  }
  Json::Value slots(Json::objectValue);
  slots["z"] = "a=b|c;d";  // Old request record byte is data with this config.
  slots["a"] = "first";
  request.histories.append(MakeProjectedHistory(
      "past;one", "music:radio=unit,1|x", "play:now,then=1", slots));
  request.histories.append(MakeProjectedHistory(
      "past;two", "fm", "stop", Json::Value(Json::objectValue)));
  const std::string saved = JsonHelper::ToString(request.histories);
  const std::string golden = "H>past;one\tmusic:radio=unit,1|x\tplay:now,then=1\t"
                             "a=first,z=a=b|c;d~past;two\tfm\tstop\t~Q>current query";
  for (size_t i = 0u; i < 2u; ++i) {
    ASSERT_EQ(0, backend->Process(request, &result));
    EXPECT_EQ(golden, ReadPayload(fake)["messages"][1u]["content"].asString());
    EXPECT_EQ(saved, JsonHelper::ToString(request.histories));
    EXPECT_EQ(response, result["nlu_result"].asString());
  }
  // Normalized configuration is immutable after initialization.
  protocol["request_history_separator"] = "^";
  WriteProfileProtocol(root, protocol);
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ(golden, ReadPayload(fake)["messages"][1u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10RequestSeparatorOmissionKeepsDefaultBytes) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.histories.append(MakeProjectedHistory(
      "first", "fm", "stop", Json::Value(Json::objectValue)));
  request.histories.append(MakeProjectedHistory(
      "second", "music", "play", Json::Value(Json::objectValue)));
  for (size_t explicit_default = 0u; explicit_default < 2u; ++explicit_default) {
    Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
    if (explicit_default != 0u) protocol["request_history_separator"] = ";";
    WriteProfileProtocol(root, protocol);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", "fm\tstop", &fake);
    ASSERT_TRUE(backend);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result));
    const std::string wire = ReadPayload(fake)["messages"][1u]["content"].asString();
    EXPECT_EQ("history:first\tfm\tstop\t;second\tmusic\tplay\t;query: current query",
              wire);
    EXPECT_EQ(2, std::count(wire.begin(), wire.end(), static_cast<char>(0x3b)));
    Nlu06BRequest empty = MakeV10RequestForTest();
    ASSERT_EQ(0, backend->Process(empty, &result));
    EXPECT_EQ("history:None;query: current query",
              ReadPayload(fake)["messages"][1u]["content"].asString());
  }
}

TEST(Nlu06BHttpBackendTest, ProfileRequestSeparatorValidationAndLiteralCollisions) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  const Json::Value valid = MakeProfileProtocol("nlu_10", Json::Value("="));
  const Json::Value bad_values[] = {Json::Value(), Json::Value(1), Json::Value(true),
      Json::Value(Json::objectValue), Json::Value(Json::arrayValue),
      Json::Value(""), Json::Value("ab"), Json::Value(u8"；"), Json::Value(" "),
      Json::Value("\t"), Json::Value("\r"), Json::Value("\n"), Json::Value("\f"),
      Json::Value("\v"), Json::Value(std::string(1u, '\0')),
      Json::Value(std::string(1u, static_cast<char>(0x01))),
      Json::Value(std::string(1u, static_cast<char>(0x7f))),
      Json::Value(std::string(1u, static_cast<char>(0x80))),
      Json::Value("="), Json::Value(","), Json::Value(":"), Json::Value("N")};
  for (size_t i = 0u; i < sizeof(bad_values) / sizeof(bad_values[0]); ++i) {
    SCOPED_TRACE(i);
    Json::Value protocol = valid;
    protocol["request_history_separator"] = bad_values[i];
    WriteProfileProtocol(root, protocol);
    FakeTransport* fake = nullptr;
    EXPECT_FALSE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  }
  // Explicit single-element arrays are not the request-side scalar schema.
  Json::Value protocol = valid;
  protocol["request_history_separator"] = Json::Value(Json::arrayValue);
  protocol["request_history_separator"].append("~");
  WriteProfileProtocol(root, protocol);
  FakeTransport* fake = nullptr;
  EXPECT_FALSE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  const char* collision_roles[] = {"field_delimiter", "request_slot_assignment",
      "request_slot_separator"};
  for (size_t i = 0u; i < 3u; ++i) {
    protocol = valid;
    protocol["request_history_separator"] = "~";
    protocol[collision_roles[i]] = "~";
    WriteProfileProtocol(root, protocol);
    EXPECT_FALSE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  }
  // ':' is legal when prefixes do not reserve it; response roles are independent.
  protocol = valid;
  protocol["request_history_separator"] = ":";
  protocol["request_field_prefixes"][0u] = "H>";
  protocol["request_field_prefixes"][1u] = "Q>";
  WriteProfileProtocol(root, protocol);
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  EXPECT_EQ("H>None:Q>current query",
            ReadPayload(fake)["messages"][1u]["content"].asString());
  // The complete empty-history option can replace an otherwise colliding None.
  protocol["request_history_separator"] = "N";
  protocol["empty_history_request"] = MakeEmptyHistoryOptionForTest("ABSENT", "Q>");
  WriteProfileProtocol(root, protocol);
  EXPECT_FALSE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));  // N in ABSENT.
  protocol["empty_history_request"]["history_field"] = "absent";
  WriteProfileProtocol(root, protocol);
  backend = MakeProfileBackend(root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  EXPECT_EQ("absentNQ>current query",
            ReadPayload(fake)["messages"][1u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, SelectedProtocolFilenameDoesNotSelectLayout) {
  const char* filenames[] = {"v3.json", "v42.json", "v10.json", "v11.json"};
  for (size_t i = 0u; i < 4u; ++i) {
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string root = WriteV10FilesForTest(&directory);
    directory.NewFile(filenames[i]);
    Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
    protocol["request_history_separator"] = "~";
    WriteSelectedProtocolForTest(root, "v10", filenames[i], protocol);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", "multi:fm\tstop;music\tplay", &fake);
    ASSERT_TRUE(backend);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeProfileHistoryRequest(), &result));
    EXPECT_EQ(2u, result["frames"].size());
    EXPECT_EQ("history:history query\tvehicle\topen_window\talpha=first,zeta=last~query: current query",
              ReadPayload(fake)["messages"][1u]["content"].asString());
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10FrameAlternativesAreOrderIndependent) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  const char* alternatives[] = {";", "~", ";~", "~;"};
  for (size_t i = 0u; i < 5u; ++i) {
    Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
    if (i < 2u) {
      protocol["response_frame_separator"] = alternatives[i];
    } else {
      protocol["response_frame_separator"] = Json::Value(Json::arrayValue);
      const std::string order = i == 4u ? "~" : alternatives[i];
      for (size_t c = 0u; c < order.size(); ++c)
        protocol["response_frame_separator"].append(std::string(1u, order[c]));
    }
    WriteProfileProtocol(root, protocol);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", "fm\tstop", &fake);
    ASSERT_TRUE(backend) << i;
    const std::string styles = i < 2u ? alternatives[i] : (i == 4u ? "~" : ";~");
    for (size_t c = 0u; c < styles.size(); ++c) {
      SCOPED_TRACE(i);
      SCOPED_TRACE(c);
      const std::string raw = std::string("multi:fm\tstop\t") + styles[c] +
          "music\tplay\tsong=a|b=x" + styles[c] + "help\thelp";
      fake->SetResponseBody(MakeEnvelope(raw));
      Json::Value result;
      ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
      EXPECT_EQ(3u, result["frames"].size());
      EXPECT_TRUE(result["is_multi_intent"].asBool());
      EXPECT_EQ("fm", result["frames"][0u]["domain"].asString());
      EXPECT_EQ("help", result["frames"][2u]["domain"].asString());
      EXPECT_EQ("a|b=x", result["frames"][1u]["slots"]["song"].asString());
      EXPECT_EQ(raw, result["nlu_result"].asString());
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10FrameAlternativesRejectMixedAndPartialOutput) {
  const char* invalid[] = {
      "multi:fm\tstop;music\tplay~help\thelp",
      "multi:fm\tstop~music\tplay;help\thelp",
      "multi:fm\tstop\tname=a~b;music\tplay",
      "multi:fm\tstop\tname=a;b~music\tplay",
      "multi:fm\tstop", "multi:", "multi:fm\tstop|music\tplay",
      "multi:fm\tstop~", "multi:~fm\tstop", "multi:fm\tstop~~music\tplay",
      "fm\tstop~music\tplay", "fm\tstop;music\tplay",
      "multi:fm\tstop~music\tplay~bad", "multi:fm\tstop;music\tplay\tbad",
      "multi:fm\tstop~music\tplay\tname=a,name=b",
      "multi:fm\tstop~unknown", "multi:fm\tstop~multi:music\tplay"};
  for (size_t gate = 0u; gate < 2u; ++gate) {
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string root = WriteV10FilesForTest(&directory, gate != 0u);
    Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
    protocol["response_frame_separator"] = Json::Value(Json::arrayValue);
    protocol["response_frame_separator"].append("~");
    protocol["response_frame_separator"].append(";");
    WriteProfileProtocol(root, protocol);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", "fm\tstop", &fake);
    ASSERT_TRUE(backend);
    for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
      SCOPED_TRACE(gate);
      SCOPED_TRACE(i);
      fake->SetResponseBody(MakeEnvelope(invalid[i]));
      Json::Value result(Json::objectValue);
      result["stale"] = true;
      EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
      ExpectDecodedContentFailure(result, invalid[i]);
    }
    fake->SetResponseBody(MakeEnvelope("multi:fm\tstop~music\tplay"));
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
    EXPECT_EQ(gate == 0u, result["is_rejected"].asBool());
    EXPECT_EQ(gate == 0u ? "multi_intent_disabled" : "", result["reject_reason"].asString());
    EXPECT_EQ(gate == 0u ? 0u : 2u, result["frames"].size());
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10ConfiguredRolesMarkersAndEmptyHistoryBytes) {
  ASSERT_EQ(std::string("multi\x3A"), u8"multi:");  // U+003A / 3A.
  ASSERT_EQ(std::string("multi\xEF\xBC\x9A"), u8"multi：");  // U+FF1A.
  const std::string markers[] = {"multi:", u8"multi：", "status/multi"};
  const std::string unknowns[] = {u8"未知：", "not-known", "status/unknown"};
  for (size_t m = 0u; m < 3u; ++m) {
    SCOPED_TRACE(m);
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string root = WriteV10FilesForTest(&directory);
    Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("@:"));
    protocol["field_delimiter"] = "#";
    protocol["request_slot_assignment"] = "@";
    protocol["request_slot_separator"] = "^";
    protocol["request_history_separator"] = "~";
    protocol["response_slot_separator"] = Json::Value(Json::arrayValue);
    protocol["response_slot_separator"].append("!");
    protocol["response_slot_separator"].append("$");
    protocol["response_frame_separator"] = "%";
    protocol["request_field_prefixes"][0u] = u8"history：";
    protocol["request_field_prefixes"][1u] = "query> ";
    protocol["empty_history_request"] = MakeEmptyHistoryOptionForTest(u8"空：", "now> ");
    protocol["response_unknown_marker"] = unknowns[m];
    protocol["response_multi_marker"] = markers[m];
    WriteProfileProtocol(root, protocol);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", unknowns[m], &fake);
    ASSERT_TRUE(backend);
    Nlu06BRequest request = MakeV10RequestForTest();
    Json::Value result;
    for (size_t h = 0u; h < 2u; ++h) {
      request.histories = h == 0u ? Json::Value() : Json::Value(Json::arrayValue);
      ASSERT_EQ(0, backend->Process(request, &result));
      EXPECT_TRUE(result["is_rejected"].asBool());
      EXPECT_EQ("unknown", result["reject_reason"].asString());
      EXPECT_TRUE(result["frames"].empty());
      EXPECT_EQ(u8"空：~now> current query",
                ReadPayload(fake)["messages"][1u]["content"].asString());
    }
    Json::Value slots(Json::objectValue);
    slots["name"] = "x@y|z,;";
    slots["area"] = u8"主驾";
    request.histories.append(MakeProjectedHistory("past;query", "d=:,", "i=:,", slots));
    const std::string golden = u8"history：past;query#d=:,#i=:,#area@主驾^name@x@y|z,;"
                                "~query> current query";
    const std::string raw = markers[m] + "vehicle#open#name@x@y|z!area@driver%music#play";
    fake->SetResponseBody(MakeEnvelope(raw));
    ASSERT_EQ(0, backend->Process(request, &result));
    EXPECT_EQ(golden, ReadPayload(fake)["messages"][1u]["content"].asString());
    ASSERT_EQ(2u, result["frames"].size());
    EXPECT_EQ("x@y|z", result["frames"][0u]["slots"]["name"].asString());
    EXPECT_EQ("driver", result["frames"][0u]["slots"]["area"].asString());
    EXPECT_EQ(raw, result["nlu_result"].asString());
    // Each alternative assignment/pair role is usable, but one response is uniform.
    const std::string other = markers[m] + "vehicle#open#name:x|y$area:driver%music#play";
    fake->SetResponseBody(MakeEnvelope(other));
    ASSERT_EQ(0, backend->Process(request, &result));
    EXPECT_EQ("x|y", result["frames"][0u]["slots"]["name"].asString());
    const std::string invalid[] = {
        markers[m] + "vehicle#open#name@x!area@driver%music#play#song:y",
        markers[m] + "vehicle#open#name@x!area@driver%music#play#a@1$b@2",
        markers[m] + "vehicle#open#name@x:y%music#play",
        markers[m] + "%%vehicle#open%music#play",  // Repeated leading separator.
        markers[m] + "vehicle#open", unknowns[m] + "x", "unknown",
        markers[(m + 1u) % 3u] + "vehicle#open%music#play"};
    for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
      SCOPED_TRACE(i);
      fake->SetResponseBody(MakeEnvelope(invalid[i]));
      EXPECT_EQ(-1, backend->Process(request, &result));
      ExpectDecodedContentFailure(result, invalid[i]);
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10EmptyHistoryOptionUsesExistingStrictSchema) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Json::Value valid = MakeProfileProtocol("nlu_10", Json::Value("="));
  valid["request_history_separator"] = "~";
  valid["empty_history_request"] = MakeEmptyHistoryOptionForTest("H>absent", "Q> ");
  std::vector<Json::Value> invalid;
  const Json::Value bad_options[] = {Json::Value(), Json::Value(1), Json::Value(true),
      Json::Value(""), Json::Value(Json::arrayValue), Json::Value(Json::objectValue)};
  for (size_t i = 0u; i < sizeof(bad_options) / sizeof(bad_options[0]); ++i) {
    Json::Value changed = valid;
    changed["empty_history_request"] = bad_options[i];
    invalid.push_back(changed);
  }
  const char* fields[] = {"history_field", "query_prefix"};
  const Json::Value bad_text[] = {Json::Value(), Json::Value(1), Json::Value(false),
      Json::Value(Json::arrayValue), Json::Value(Json::objectValue),
      Json::Value(std::string(129u, 'x')), Json::Value("bad~field"),
      Json::Value("bad\tfield"), Json::Value("bad\rfield"), Json::Value("bad\nfield"),
      Json::Value("bad\ffield"), Json::Value("bad\vfield"),
      Json::Value(std::string("bad\0field", 9u)),
      Json::Value(std::string("bad") + static_cast<char>(0x7f) + "field")};
  for (size_t f = 0u; f < 2u; ++f) {
    Json::Value changed = valid;
    changed["empty_history_request"].removeMember(fields[f]);
    invalid.push_back(changed);
    for (size_t i = 0u; i < sizeof(bad_text) / sizeof(bad_text[0]); ++i) {
      changed = valid;
      changed["empty_history_request"][fields[f]] = bad_text[i];
      invalid.push_back(changed);
    }
    // The same request record boundaries apply to ordinary configured prefixes.
    for (size_t i = 5u; i < sizeof(bad_text) / sizeof(bad_text[0]); ++i) {
      changed = valid;
      changed["request_field_prefixes"][static_cast<Json::ArrayIndex>(f)] = bad_text[i];
      invalid.push_back(changed);
    }
  }
  Json::Value changed = valid;
  changed["empty_history_request"]["history_field"] = "";
  invalid.push_back(changed);
  changed = valid;
  changed["empty_history_request"]["extra"] = "not allowed";
  invalid.push_back(changed);
  changed = valid;
  changed["field_delimiter"] = "#";
  changed["empty_history_request"]["query_prefix"] = "bad#prefix";
  invalid.push_back(changed);
  for (size_t i = 0u; i < invalid.size(); ++i) {
    SCOPED_TRACE(i);
    WriteProfileProtocol(root, invalid[i]);
    FakeTransport* fake = nullptr;
    EXPECT_FALSE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  }
  // Existing bounds permit 128-byte literals and an empty query prefix.
  valid["empty_history_request"]["history_field"] = std::string(128u, 'h');
  valid["empty_history_request"]["query_prefix"] = "";
  valid["request_field_prefixes"][0u] = std::string(128u, 'p');
  WriteProfileProtocol(root, valid);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  EXPECT_EQ(std::string(128u, 'h') + "~current query",
            ReadPayload(fake)["messages"][1u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10LabelsKeepNonstructuralPunctuationAndSpaces) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
  protocol["request_history_separator"] = "~";
  protocol["response_frame_separator"] = "^";
  WriteProfileProtocol(root, protocol);
  const std::string domain = u8"domain:,;=|<>\"'{}[] ：；＝， with space";
  const std::string intent = u8"intent:,;=|<>\"'{}[] ：；＝， with space";
  const std::string name = u8"name:;|<>\"'{}[] ：；＝， with space";
  const std::string value = u8"value:=;|<>\"'{}[] ：；＝， with space";
  const std::string raw = domain + "\t" + intent + "\t" + name + "=" + value;
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(root, "v10", raw, &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  Json::Value slots(Json::objectValue);
  slots[name] = value;
  request.histories.append(MakeProjectedHistory("past", domain, intent, slots));
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ(domain, result["frames"][0u]["domain"].asString());
  EXPECT_EQ(intent, result["frames"][0u]["intents"][0u].asString());
  EXPECT_EQ(value, result["frames"][0u]["slots"][name].asString());
  EXPECT_EQ("history:past\t" + raw + "~query: current query",
            ReadPayload(fake)["messages"][1u]["content"].asString());
  EXPECT_EQ(raw, result["nlu_result"].asString());
  EXPECT_NE(std::string::npos, raw.find("\xEF\xBC\x9A"));
  EXPECT_NE(std::string::npos, raw.find("\xEF\xBC\x9B"));
  EXPECT_NE(std::string::npos, raw.find("\xEF\xBC\x9D"));
  EXPECT_NE(std::string::npos, raw.find("\xEF\xBC\x8C"));

  const char* valid[][3] = {
      {"Here is the answer: fm\tstop", "Here is the answer: fm", "stop"},
      {"fm\tstop explanation", "fm", "stop explanation"},
      {"<think>x</think>Here is the answer: fm\tstop",
       "Here is the answer: fm", "stop"}};
  for (size_t i = 0u; i < sizeof(valid) / sizeof(valid[0]); ++i) {
    SCOPED_TRACE(i);
    fake->SetResponseBody(MakeEnvelope(valid[i][0]));
    ASSERT_EQ(0, backend->Process(request, &result));
    EXPECT_FALSE(result["is_rejected"].asBool());
    EXPECT_FALSE(result["is_multi_intent"].asBool());
    ASSERT_EQ(1u, result["frames"].size());
    EXPECT_EQ(valid[i][1], result["frames"][0u]["domain"].asString());
    ASSERT_EQ(1u, result["frames"][0u]["intents"].size());
    EXPECT_EQ(valid[i][2], result["frames"][0u]["intents"][0u].asString());
    EXPECT_TRUE(result["frames"][0u]["slots"].empty());
    EXPECT_EQ(valid[i][0], result["nlu_result"].asString());
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10RequestCollisionChecksFollowConfiguredRoles) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
  protocol["field_delimiter"] = "#";
  protocol["request_history_separator"] = "~";
  protocol["request_slot_assignment"] = "@";
  protocol["request_slot_separator"] = "^";
  WriteProfileProtocol(root, protocol);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(root, "v10", "fm#stop", &fake);
  ASSERT_TRUE(backend);
  Json::Value slots(Json::objectValue);
  slots["key:;"] = "v@w|x,:;";
  const Json::Value valid = MakeProjectedHistory("past;query", "d@^,:;", "i@^,:;", slots);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = "current#~\t\r\n";  // Terminal query remains payload, cleaned locally.
  request.histories.append(valid);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:past;query#d@^,:;#i@^,:;#key:;@v@w|x,:;~query: current#~   ",
            ReadPayload(fake)["messages"][1u]["content"].asString());
  const int posts = fake->post_count();
  const char* fields[] = {"query", "domain", "intent", "name", "value"};
  const char bad_bytes[] = {'#', '~', '\0', '\x01', '\x1f', '\x7f'};
  for (size_t f = 0u; f < 5u; ++f) {
    for (size_t b = 0u; b < sizeof(bad_bytes); ++b) {
      SCOPED_TRACE(fields[f]);
      SCOPED_TRACE(b);
      Json::Value history = valid;
      Json::Value& semantic = history["v3_nlu_semantics"][0u];
      const std::string bad = std::string("a") + bad_bytes[b] + "b";
      if (f < 3u) {
        semantic[fields[f]] = bad;
      } else {
        semantic["slots"] = Json::Value(Json::objectValue);
        semantic["slots"][f == 3u ? bad : "key"] = f == 4u ? bad : "value";
      }
      request.histories[0u] = history;
      result["stale"] = true;
      EXPECT_EQ(-1, backend->Process(request, &result));
      EXPECT_TRUE(result.isNull());
      EXPECT_EQ(posts, fake->post_count());
    }
  }
  const char* bad_keys[] = {"k@x", "k^x"};
  for (size_t i = 0u; i < 2u; ++i) {
    request.histories[0u] = valid;
    Json::Value& semantic = request.histories[0u]["v3_nlu_semantics"][0u];
    semantic["slots"] = Json::Value(Json::objectValue);
    semantic["slots"][bad_keys[i]] = "value";
    EXPECT_EQ(-1, backend->Process(request, &result));
    EXPECT_TRUE(result.isNull());
  }
  request.histories[0u] = valid;
  request.histories[0u]["v3_nlu_semantics"][0u]["slots"]["key:;"] = "bad^value";
  EXPECT_EQ(-1, backend->Process(request, &result));
  EXPECT_EQ(posts, fake->post_count());
}

TEST(Nlu06BHttpBackendTest, ProfileV10CustomResponseRolesKeepSchemaAndControlSafety) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("@"));
  protocol["field_delimiter"] = "#";
  protocol["response_slot_separator"] = "!";
  protocol["response_frame_separator"] = "%";
  WriteProfileProtocol(root, protocol);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "d@!:#i@!:#k:;@a@b|c:;", &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  EXPECT_EQ("d@!:", result["frames"][0u]["domain"].asString());
  EXPECT_EQ("i@!:", result["frames"][0u]["intents"][0u].asString());
  EXPECT_EQ("a@b|c:;", result["frames"][0u]["slots"]["k:;"].asString());
  const char* invalid[] = {"d", "#i", "d##k@v", "d#i#k@v#extra",
      "d#i#k@v!k@x", "d#i#k@v!junk", "d#i#!k@v", "d#i#k@v!",
      "d#i#k@v!!z@x", "d#i#@v", "d#i#k@", "d#i#k@   !z@x",
      "d#i%other#intent", "multi:d#i%other#intent#bad", "`d#i`",
      "{d#i}", "unstructured response prose", "unknown#i"};
  for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
    SCOPED_TRACE(i);
    fake->SetResponseBody(MakeEnvelope(invalid[i]));
    EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
    ExpectDecodedContentFailure(result, invalid[i]);
  }
  const char controls[] = {'\0', '\x01', '\x1f', '\x7f', '\t', '\r', '\n'};
  for (size_t f = 0u; f < 4u; ++f) {
    for (size_t c = 0u; c < sizeof(controls); ++c) {
      SCOPED_TRACE(f);
      SCOPED_TRACE(c);
      std::string fields[] = {"domain", "intent", "name", "value"};
      fields[f] = std::string("a") + controls[c] + "b";
      const std::string raw = fields[0u] + "#" + fields[1u] + "#" + fields[2u] + "@" + fields[3u];
      fake->SetResponseBody(MakeEnvelope(raw));
      result["stale"] = true;
      EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
      ExpectDecodedContentFailure(result, raw);
    }
  }
}

TEST(Nlu06BHttpBackendTest, ExactUserGoldenMatchesSharedCodecWithZeroOrOneLeadingSeparator) {
  const std::string rows =
      "intelligent_car_control\tturn_on_device\tname=空调;"
      "intelligent_car_control\tAC_control\twind_direction=面;"
      "intelligent_car_control\tturn_on_device\tname=车窗";
  ASSERT_EQ(6, std::count(rows.begin(), rows.end(), '\t'));
  const char* markers[] = {"multi:", u8"multi：", "status/multi"};
  const char* orders[] = {";", ";~", "~;"};
  for (const char* marker : markers) {
    for (size_t order = 0u; order < 3u; ++order) {
      ScopedCaptureDirectory directory;
      ASSERT_TRUE(directory.valid());
      const std::string root = WriteV10FilesForTest(&directory);
      Json::Value protocol = MakeProfileProtocol("nlu_10", Json::Value("="));
      protocol["response_multi_marker"] = marker;
      if (order != 0u) {
        protocol["response_frame_separator"] = Json::Value(Json::arrayValue);
        for (const char* p = orders[order]; *p; ++p)
          protocol["response_frame_separator"].append(std::string(1u, *p));
      }
      WriteProfileProtocol(root, protocol);
      const Json::Value config = MakeProfileSelector("v10");
      std::unique_ptr<LlmProtocol> codec = CreateLlmProtocol(config["Model"], root);
      ASSERT_TRUE(codec);
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(root, "v10", "fm\tstop", &fake);
      ASSERT_TRUE(backend);
      const Nlu06BRequest request = MakeProfileHistoryRequest();
      Json::Value payload;
      ASSERT_TRUE(codec->BuildRequest(request, &payload));
      for (const char* p = orders[order]; *p; ++p) {
        std::string frames = rows;
        std::replace(frames.begin(), frames.end(), ';', *p);
        for (size_t leading = 0u; leading < 2u; ++leading) {
          const std::string raw = std::string(marker) + (leading ? std::string(1u, *p) : "") + frames;
          fake->SetResponseBody(MakeEnvelope(raw));
          Json::Value result;
          ASSERT_EQ(0, backend->Process(request, &result));
          ASSERT_EQ(3u, result["frames"].size());
          EXPECT_EQ("空调", result["frames"][0u]["slots"]["name"].asString());
          EXPECT_EQ("面", result["frames"][1u]["slots"]["wind_direction"].asString());
          EXPECT_EQ("车窗", result["frames"][2u]["slots"]["name"].asString());
          EXPECT_EQ(raw, result["nlu_result"].asString());
          EXPECT_EQ(payload, ReadPayload(fake));
          Json::Value shared;
          ASSERT_EQ(kContentSuccess, codec->ParseResponse(raw, &shared));
          result.removeMember("nlu_result");
          EXPECT_EQ(shared, result);
        }
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, BuildsBoundedRequestWithoutTransportOrCorrelationInModelPayload) {
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeConfig(), 0, 200, MakeEnvelope("vehicle\topen_window\tname=车窗"), &fake);
  ASSERT_TRUE(backend);
  EXPECT_STREQ("nlu06b", backend->result_source());
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
  EXPECT_EQ(5000, fake->request_.connect_timeout_ms);
  EXPECT_EQ(30000, fake->request_.total_timeout_ms);
  EXPECT_EQ(1024u * 1024u, fake->request_.max_response_bytes);
  ASSERT_EQ(1u, fake->request_.headers.size());
  EXPECT_EQ("Content-Type: application/json", fake->request_.headers[0u]);
  const Json::Value payload = ReadPayload(fake);
  EXPECT_EQ(8u, payload.size());
  EXPECT_EQ("qwen3", payload["model"].asString());
  EXPECT_EQ("history:None;query: " + MakeRequest().query,
            payload["messages"][1u]["content"].asString());
  EXPECT_EQ(std::string::npos, fake->request_.body.find("request-id-not-sent"));
  EXPECT_EQ(std::string::npos, fake->request_.body.find("last_domain"));
  EXPECT_FALSE(payload.isMember("chat_template_kwargs"));
}

class ScopedTestEnvironment {
 public:
  ScopedTestEnvironment(const char* name, const char* value) : name_(name) {
    const char* previous = std::getenv(name);
    present_ = previous != nullptr;
    if (present_) previous_ = previous;
    setenv(name, value, 1);
  }
  ~ScopedTestEnvironment() {
    if (present_) setenv(name_.c_str(), previous_.c_str(), 1);
    else unsetenv(name_.c_str());
  }
 private:
  ScopedTestEnvironment(const ScopedTestEnvironment&) = delete;
  ScopedTestEnvironment& operator=(const ScopedTestEnvironment&) = delete;
  std::string name_;
  std::string previous_;
  bool present_;
};

TEST(Nlu06BHttpBackendTest, ResolvesExecutionEnvironmentWithoutLeakingCredentials) {
  ScopedTestEnvironment endpoint("WTP184_CODEC_TEST_ENDPOINT", "https://example.com/v1/chat");
  ScopedTestEnvironment key("WTP184_CODEC_TEST_KEY", "synthetic-api-key-not-a-secret");
  Json::Value config = MakeConfig();
  config["OpenAIHttp"]["endpoint"] = "${WTP184_CODEC_TEST_ENDPOINT}";
  config["OpenAIHttp"]["api_key_env"] = "WTP184_CODEC_TEST_KEY";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("bad-model-output"), &fake);
  ASSERT_TRUE(backend);
  ScopedLogCapture logs;
  Json::Value result;
  EXPECT_LT(backend->Process(MakeRequest(), &result), 0);
  EXPECT_EQ("https://example.com/v1/chat", fake->request_.endpoint);
  ASSERT_EQ(2u, fake->request_.headers.size());
  EXPECT_EQ("Authorization: Bearer synthetic-api-key-not-a-secret", fake->request_.headers[1u]);
  EXPECT_EQ(std::string::npos, fake->request_.body.find("synthetic-api-key-not-a-secret"));
  EXPECT_EQ(std::string::npos, logs.messages().find("synthetic-api-key-not-a-secret"));
  EXPECT_EQ(std::string::npos, logs.messages().find("bad-model-output"));
  const char* obsolete[] = {"profile", "profile_catalog_path", "model", "system_prompt",
      "temperature", "stream", "response_protocol", "version", "response_flag_prefix"};
  for (const char* field : obsolete) {
    Json::Value stale = config;
    stale["OpenAIHttp"][field] = "obsolete";
    EXPECT_FALSE(MakeBackend(stale, 0, 200, "{}", &fake)) << field;
  }
}

struct ParityProvider {
  std::string request;
  std::string text;
  bool delta;
};

int ParityInfer(const char* request, void* owner, void* context,
                Nlu06BOutputCallback callback) {
  ParityProvider* provider = static_cast<ParityProvider*>(owner);
  provider->request = request;
  if (provider->delta) {
    for (size_t i = 0u; i < provider->text.size(); ++i) {
      const std::string chunk = provider->text.substr(i, 1u);
      callback(chunk.c_str(), context);
    }
  } else {
    callback(provider->text.c_str(), context);
  }
  return 0;
}

TEST(Nlu06BHttpBackendTest, HttpAndOfflineRequestBytesAndBusinessAreIdentical) {
  const std::string frames =
      "intelligent_car_control\tturn_on_device\tname=空调;"
      "intelligent_car_control\tAC_control\twind_direction=面;"
      "intelligent_car_control\tturn_on_device\tname=车窗";
  EXPECT_EQ(6, std::count(frames.begin(), frames.end(), '\t'));
  EXPECT_EQ(0x09u, static_cast<unsigned char>('\t'));
  for (int marker = 0; marker < 2; ++marker) {
    for (int gate = 0; gate < 2; ++gate) {
      Json::Value config = MakeConfig();
      const std::string root = TransportFixtureRoot();
      ASSERT_FALSE(root.empty());
      Json::Value descriptor = JsonHelper::ParseJsonFromFile(root + "/transport-protocol.json");
      descriptor["response_multi_marker"] = marker == 0 ? "multi:" : "multi：";
      descriptor["response_unknown_marker"] = marker == 0 ? "unknown" : "未知";
      std::ofstream d((root + "/transport-protocol.json").c_str());
      d << JsonHelper::ToString(descriptor);
      d.close();
      Json::Value catalog = JsonHelper::ParseJsonFromFile(root + "/transport-catalog.json");
      catalog["profiles"]["transport-fixture"]["allow_multi_intent_output"] = gate != 0;
      std::ofstream c((root + "/transport-catalog.json").c_str());
      c << JsonHelper::ToString(catalog);
      c.close();
      const std::string multi = descriptor["response_multi_marker"].asString();
      const std::string unknown = descriptor["response_unknown_marker"].asString();
      const std::string texts[] = {"music\tplay\tname=歌曲", unknown,
          multi + frames, multi + ";" + frames, multi + ";;" + frames,
          multi + "music\tplay;bad"};
      for (size_t item = 0u; item < 6u; ++item) {
        for (int delta = 0; delta < 2; ++delta) {
          FakeTransport* fake = nullptr;
          std::unique_ptr<Nlu06BBackend> http = MakeBackend(config, 0, 200,
              MakeEnvelope(texts[item]), &fake);
          ParityProvider provider;
          provider.text = texts[item];
          provider.delta = delta != 0;
          Json::Value offline_config = config;
          offline_config["Backend"]["type"] = "offline";
          offline_config.removeMember("OpenAIHttp");
          std::unique_ptr<Nlu06BBackend> offline = CreateNlu06BOfflineBackend(
              offline_config, root, Nlu06BInferenceBinding(&ParityInfer, &provider));
          ASSERT_TRUE(http);
          ASSERT_TRUE(offline);
          Nlu06BRequest request = MakeRequest();
          Json::Value slots(Json::objectValue);
          slots["name"] = "收音机";
          request.histories.append(MakeProjectedHistory("先前\t查询", "fm", "play", slots));
          request.histories.append(MakeProjectedHistory("second", "music", "stop",
                                                       Json::Value(Json::objectValue)));
          Json::Value a;
          Json::Value b;
          const int http_code = http->Process(request, &a);
          const int offline_code = offline->Process(request, &b);
          EXPECT_EQ(http_code, offline_code);
          EXPECT_EQ(fake->request_.body, provider.request);
          EXPECT_EQ(a, b);
          EXPECT_STREQ(http->result_source(), offline->result_source());
          if (item < 4u) {
            ASSERT_EQ(0, offline_code);
            if (item >= 2u && !gate) {
              ASSERT_TRUE(b["is_rejected"].isBool());
              EXPECT_TRUE(b["is_rejected"].asBool());
              ASSERT_TRUE(b["reject_reason"].isString());
              EXPECT_EQ("multi_intent_disabled", b["reject_reason"].asString());
              ASSERT_TRUE(b["is_multi_intent"].isBool());
              EXPECT_FALSE(b["is_multi_intent"].asBool());
              ASSERT_TRUE(b["frames"].isArray());
              EXPECT_TRUE(b["frames"].empty());
            } else if (item >= 2u) {
              ASSERT_EQ(3u, b["frames"].size());
              EXPECT_EQ("空调", b["frames"][0u]["slots"]["name"].asString());
              EXPECT_EQ("面", b["frames"][1u]["slots"]["wind_direction"].asString());
              EXPECT_EQ("车窗", b["frames"][2u]["slots"]["name"].asString());
            }
          } else {
            EXPECT_LT(offline_code, 0);
            ExpectDecodedContentFailure(b, provider.text);
          }
        }
      }
    }
  }
}

}  // namespace nlptk
