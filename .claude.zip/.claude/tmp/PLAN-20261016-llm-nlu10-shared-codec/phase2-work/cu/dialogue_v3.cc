// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/dialogue_v3.h"
#include "cu/dialogue_internal.h"
#include "cu/v3_query_history_policy.h"

#include <cassert>
#include <map>
#include <memory>
#include <set>
#include <utility>
#include <vector>

#include "base/json_helper.h"
#include "base/logging.h"
#include "base/path.h"
#include "base/rtti.h"
#include "base/string_util.h"
#include "common/query.h"
#include "common/slot_utils.h"
#include "common/sub_query.h"
#include "curl/curl.h"
#include "dialog/dialogue_utils.h"
#include "dialog/flow_task.h"
#include "dialog/flow_task_def.h"
#include "dialog/form_task_def.h"
#include "dialog/input.h"
#include "dialog/task_base.h"
#include "dialog/turn.h"
#include "nlu/semantic_frame.h"
#include "nlu/semantic_frames.h"
#include "nlu/timex.h"
#include "rule/cre_matcher.h"
#include "semantic_modifier/modifier_factory.h"

namespace nlptk {

using std::shared_ptr;
using std::string;
using std::vector;
using dialog::ContextManager;
using dialog::DialogueManager;
using dialog::DialogueUtils;
using dialog::EventInput;
using dialog::Turn;
using nlu::SemanticFrames;

namespace {

const char kDelimiter[] = "|";
const char kVAD[] = "VAD";
const char kInactiveVad[] = "inactive";
const char kValidSlotName[] = "NULL";
const std::string kRejected = "kRejected";
const std::string kSensitiveMsg = "我们换个话题聊聊";
const std::string kDomainOther = "other";
const std::string kDomainChat = "chat";
const std::string kDomainSensitive = "sensitive";
const std::string kWakeUp = "isWakeUp";

struct zp_entity {
  std::string name;
  std::string type;
  std::string normal;
  std::string value;
};

class DialogueQueryGuardAdapter : public DialogueV3Guard {
 public:
  explicit DialogueQueryGuardAdapter(const clu::QueryGuard* guard)
      : guard_(guard) {}

  bool IsGuarded(
      const std::string& request_id, const std::string& original_query,
      std::vector<std::pair<std::string, std::string> >* slots) const override {
    if (guard_ == nullptr || slots == nullptr) {
      return false;
    }
    const clu::CreMatcher::CreQuery query{request_id, original_query};
    return guard_->IsOk(query, slots);
  }

 private:
  const clu::QueryGuard* guard_;
};

class DialogueNlu06BAdapter : public DialogueV3NluProcessor {
 public:
  explicit DialogueNlu06BAdapter(const Nlu06BManager* manager)
      : manager_(manager) {}

  int Process(const Nlu06BRequest& request, nlu::SemanticFrames* output,
              Nlu06BResultInfo* info) const override {
    return manager_ == nullptr ? -1 : manager_->Process(request, output, info);
  }

 private:
  const Nlu06BManager* manager_;
};

void BuildSemanticJson(const Json::Value &results, const std::string &text,
                       const std::string &vad_status, bool is_multi_intent,
                       Json::Value *semantic) {
  assert(semantic);
  (*semantic)["Query"] = text;
  (*semantic)["Results"] = results;
  (*semantic)["SessionStatus"] = 0;
  (*semantic)["VadStatus"] = vad_status;
  (*semantic)["IsMultiIntent"] = is_multi_intent;
}

bool IsSlotInAction(const nlu::Slot &slot,
                    const std::vector<shared_ptr<dialog::Action>> &actions) {
  for (auto &action : actions) {
    for (auto &arg : action->args) {
      if (slot.name == arg.first && slot.value == arg.second) {
        return true;
      }
    }
  }
  return false;
}

void BuildStatus(const clu::SubQuery &sub_query, Json::Value *status) {
  assert(status);
  if (sub_query.is_sensitive) {
    (*status)["Msg"] = kSensitiveMsg;
    (*status)["Code"] = 10019;
  } else {
    (*status)["Msg"] = "";
    (*status)["Code"] = 0;
  }
}

}  // namespace

namespace dialogue_internal {

Json::Value GetDispatchJsonResult(const Turn &cur_turn,
                                  const clu::SubQuery &dispatch_info) {
  Json::Value result_obj;
  Json::Value nlu_obj;
  std::string domain = dispatch_info.category;
  std::string intent = "";
  bool is_rejected = dispatch_info.is_rejected;
  auto slot_objs = JsonHelper::MakeJsonArray();
  if (!cur_turn.frames.empty() && cur_turn.frames.front()) {
    domain = cur_turn.frames.front()->domain.value;
    if (dispatch_info.is_first_rejected || domain != kDomainOther) {
      is_rejected = false;
    }
    if (!cur_turn.frames.front()->intents.empty() && cur_turn.frames.front()->intents.front().value != "other") {
      intent = cur_turn.frames.front()->intents.front().value;
    }
    std::vector<nlu::Slot*> slot_list;
    cur_turn.frames.front()->slots.List("", &slot_list);
    for (auto &slot : slot_list) {
      Json::Value slot_obj;
      slot_obj["Name"] = slot->name;
      slot_obj["Value"] = clu::SlotUtils::GetSlotNormalValue(*slot);
      slot_obj["RawValue"] = slot->value;
      slot_obj["Type"] = "entity";
      slot_objs.append(slot_obj);
    }
  }
  nlu_obj["Domain"] = domain;
  nlu_obj["Confidence"] = 1.0f;
  nlu_obj["Intent"] = intent.empty() ? domain: intent;
  for(auto &slot : dispatch_info.extra_slots) {
    Json::Value slot_obj;
    slot_obj["Name"] = slot.first;
    slot_obj["Value"] = slot.second;
    slot_obj["RawValue"] = slot.second;
    if (dispatch_info.is_sensitive) {
      slot_obj["Type"] = "sensitive_words";
    } else {
      slot_obj["Type"] = "extra_info";
    }
    slot_objs.append(slot_obj);
  }
  nlu_obj["Slots"] = slot_objs;
  Json::Value dm_obj;
  dm_obj["SessionID"] = cur_turn.session_id;
  dm_obj["Text"] = cur_turn.text;
  Json::Value skill_obj;
  Json::Value command_obj;
  Json::Value text_list(Json::arrayValue);
  command_obj["TextList"] = text_list;
  skill_obj["Command"] = command_obj;
  dm_obj["Skill"] = skill_obj;
  dm_obj["IsLocalEntity"] = 0;
  dm_obj["SessionComplete"] = cur_turn.session_complete;
  result_obj["Nlu"] = nlu_obj;
  result_obj["Dm"] = dm_obj;
  result_obj["IsRejected"] = is_rejected;
  Json::Value status_obj;
  BuildStatus(dispatch_info, &status_obj);
  result_obj["Status"] = status_obj;
  result_obj["SubQuery"] = dispatch_info.generate_text;
  result_obj["Index"] = dispatch_info.index;
  return result_obj;
}

}  // namespace dialogue_internal

namespace {

Json::Value GetResultJsonForZP(const Turn &cur_turn,
                               const clu::SubQuery &dispatch_info,
                               std::string *vad_status) {
  assert(vad_status);
  bool is_rejected = dispatch_info.is_rejected;
  std::string query = cur_turn.query;
  if (!dispatch_info.is_nlu_domain) {
    return dialogue_internal::GetDispatchJsonResult(cur_turn, dispatch_info);
  }
  Json::Value result_obj;
  Json::Value nlu_obj;
  std::string domain;
  float domain_confidence;
  std::string intent;
  auto slot_objs = JsonHelper::MakeJsonArray();
  auto active_task = cur_turn.selected_task;
  if (active_task->type == dialog::FlowTaskDef::kType) {
    auto flow_task = std::dynamic_pointer_cast<dialog::FlowTask>(active_task);
    if (*vad_status == kInactiveVad) {
      for (auto &var : flow_task->variables) {
        if (var->GetName() == kVAD) {
          *vad_status = var->AsString();
        }
      }
    }

    if (!flow_task->related_domain.empty()) {
      domain = flow_task->related_domain;
      domain_confidence = 1.0f;
      if (domain == kRejected) {
        is_rejected = true;
        domain = kDomainOther;
        intent = kDomainOther;
      }
    }
  }
  auto active_frame = active_task->GetActiveFrame();
  if (active_frame) {
    if (domain.empty()) {
      domain = active_frame->domain.value;
      domain_confidence = active_frame->domain.score;
    }
    if (intent.empty() && (active_task->type == dialog::FormTaskDef::kType ||
                           active_task->type == dialog::FlowTaskDef::kType)) {
      auto form_task = std::dynamic_pointer_cast<dialog::FormTask>(active_task);
      intent = form_task->focus;
      std::map<std::string, zp_entity> slot_map;
      for (auto &nlu_slots : form_task->slots) {
        if (!nlu_slots->required || domain == kDomainOther) {
          continue;
        }
        for (auto &slot : nlu_slots->slot_values) {
          std::string normal;
          if (slot->properties.size() > 0) {
            for (auto &prop : slot->properties) {
              if (prop->Type() == typeid(nlu::CanonicalString)) {
                auto p_prop = static_cast<nlu::CanonicalString *>(prop);
                normal = p_prop->Value();
                break;
              } else if (prop->Type() == typeid(nlu::TimeX)) {
                auto p_prop = static_cast<nlu::TimeX *>(prop);
                normal = p_prop->value;
                break;
              } else {
                LOGE << "Not implement property type";
              }
            }
          } else {
            normal = slot->value;
          }
          auto found = slot_map.find(slot->name);
          if (found != slot_map.end()) {
            // found->second.value =
            //     found->second.value + kDelimiter + slot->value;
            // if (!IsValueExist(found->second.normal, normal)) {
            //   found->second.normal = found->second.normal + kDelimiter +
            //   normal;
            // }
            // 此处需求变更，出现同名槽不同值的情况，则下发other
            if (found->second.normal == normal) {
              continue;
            } else {
              LOGI << "component=v3 event=semantic_merge stage=slot_merge "
                      << "outcome=degraded reason=conflicting_slot_values";
              slot_map.clear();
              domain = kDomainOther;
              intent = kDomainOther;
              break;
            }
          } else {
            slot_map[slot->name] = {slot->name, "entity", normal, slot->value};
          }
        }
      }
      for (auto &item : slot_map) {
        if (item.second.name == kValidSlotName) {
          continue;
        }
        Json::Value slot_obj;
        slot_obj["Name"] = item.second.name;
        slot_obj["Value"] = item.second.normal;
        slot_obj["RawValue"] = item.second.value;
        slot_obj["Type"] = item.second.type;
        slot_objs.append(slot_obj);
      }
    } else if (intent.empty() && active_frame->intents.size() > 0) {
      intent = active_frame->intents[0].value;
      std::vector<nlu::Slot *> list;
      if (active_frame->slots.List("", &list) > 0) {
        for (auto &slot : list) {
          if (!IsSlotInAction(*slot, cur_turn.actions)) {
            continue;
          }
          Json::Value slot_obj;
          slot_obj["Name"] = slot->name;
          std::string normal;
          if (slot->properties.size() > 0) {
            auto prop =
                static_cast<nlu::CanonicalString *>(slot->properties[0]);
            normal = prop->Value();
          } else {
            normal = slot->value;
          }
          slot_obj["Value"] = normal;
          slot_obj["RawValue"] = slot->value;
          slot_obj["Type"] = "entity";
          slot_objs.append(slot_obj);
        }
      }
    }
    nlu_obj["Domain"] = domain;
    nlu_obj["Confidence"] = domain_confidence;
    nlu_obj["Intent"] = intent;
    nlu_obj["Slots"] = slot_objs;
  } else {
    nlu_obj["Domain"] = kDomainOther;
    nlu_obj["Confidence"] = 1.0f;
    nlu_obj["Intent"] = kDomainOther;
    nlu_obj["Slots"] = JsonHelper::MakeJsonArray();
  }
  result_obj["Nlu"] = nlu_obj;
  Json::Value dm_obj;
  dm_obj["SessionID"] = cur_turn.session_id;
  dm_obj["Text"] = cur_turn.text;
  Json::Value skill_obj;
  Json::Value command_obj;
  Json::Value text_list(Json::arrayValue);
  for (auto &action : cur_turn.actions) {
    for (auto &text_obj : action->text_list) {
      Json::Value text_json;
      text_json["Status"] = text_obj->status;
      text_json["Text"] = text_obj->text;
      Json::Value holders(Json::arrayValue);
      for (auto &holder : text_obj->place_holders) {
        holders.append(holder);
      }
      text_json["PlaceHolderList"] = holders;
      text_list.append(text_json);
    }
  }
  command_obj["TextList"] = text_list;
  skill_obj["Command"] = command_obj;
  dm_obj["Skill"] = skill_obj;
  dm_obj["IsLocalEntity"] = 0;
  dm_obj["SessionComplete"] = cur_turn.session_complete;
  result_obj["Dm"] = dm_obj;
  result_obj["IsRejected"] = is_rejected;
  Json::Value status_obj;
  BuildStatus(dispatch_info, &status_obj);
  result_obj["Status"] = status_obj;
  result_obj["SubQuery"] = query;
  result_obj["Index"] = dispatch_info.index;
  return result_obj;
}

void CleanFrames(nlu::SemanticFrames *frames) {
  assert(frames);
  for (size_t i = 0; i < frames->size(); ++i) {
    frames->at(i) = nullptr;
  }
  frames->clear();
}

int ApplySemanticsModifiers(
    const std::vector<clu::SemanticModifier *> &modifiers, Turn *cur_turn) {
  assert(cur_turn);
  if (!cur_turn->selected_task) {
    return 0;
  }
  auto active_frame = cur_turn->selected_task->GetActiveFrame();
  if (!active_frame) {
    return 0;
  }
  LOGI << "Start to process semantic modifier after DM.";
  std::vector<nlu::Slot *> slots;
  auto form_task =
      std::dynamic_pointer_cast<dialog::FormTask>(cur_turn->selected_task);
  if (form_task) {
    for (auto &nlu_slots : form_task->slots) {
      slots.insert(slots.end(), nlu_slots->slot_values.begin(),
                   nlu_slots->slot_values.end());
    }
  }

  for (auto &modifier : modifiers) {
    if (modifier->IsWorksAfterDm() &&
        modifier->Process(&active_frame->domain.value, &form_task->focus,
                          &slots) < 0) {
      LOG(ERROR) << "component=v3 event=semantic_modifier stage=after_dm "
                 << "outcome=error reason=modifier_process_failed";
      return -1;
    }
  }
  LOGI << "SemanticMapper process frames after DM successfully!";
  return 0;
}

void GetTurnSoundPosition(const dialog::Turn &turn, std::string *position) {
  for (auto &input : turn.inputs) {
    if (input->InputMode() == dialog::Input::Mode::kEvent) {
      auto p_input = std::dynamic_pointer_cast<dialog::EventInput>(input);
      if (p_input->GetName() == "microphone") {
        auto p_postion = p_input->GetChildByName("position");
        if (p_postion) {
          *position = p_postion->AsString();
        }
        return;
      }
    }
  }
  LOGI << "component=v3 event=sound_position stage=input "
       << "outcome=skipped reason=microphone_position_missing";
}

void SetHistorySemantics(const dialog::Turn &cur_turn,
                         const std::vector<dialog::Turn *> &history,
                         DialogueResponse *response) {
  if (!history.empty()) {
    // 只要最后一条query的语义信息
    auto &turn = history.front();
    if (turn->selected_task && turn->selected_task->GetActiveFrame()) {
      auto frame = turn->selected_task->GetActiveFrame();
      auto semantic = std::make_shared<clu::SimpleSemantic>();
      semantic->domain = frame->domain.value;
      if (!frame->intents.empty()) {
        semantic->intent = frame->intents.front().value;
      } else {
        semantic->intent = semantic->domain;
      }
      if (turn->selected_task->type == dialog::FlowTaskDef::kType ||
          turn->selected_task->type == dialog::FormTaskDef::kType) {
        auto form_task =
            std::dynamic_pointer_cast<dialog::FormTask>(turn->selected_task);
        for (auto &dl_slot : form_task->slots) {
          for (auto &slot : dl_slot->slot_values) {
            semantic->slots.emplace_back(
                slot->name, clu::SlotUtils::GetSlotNormalValue(*slot));
          }
        }
      }
      semantic->query = turn->query;
      response->history_semantics.emplace_back(semantic);
    } else {
      for (auto &frame : turn->frames) {
        auto semantic = std::make_shared<clu::SimpleSemantic>();
        semantic->domain = frame->domain.value;
        if (!frame->intents.empty()) {
          semantic->intent = frame->intents.front().value;
        } else {
          semantic->intent = semantic->domain;
        }
        semantic->query = turn->query;
        response->history_semantics.emplace_back(semantic);
      }
    }
    if (!response->history_semantics.empty()) {
      response->query_histories.back()->SetLastSemantic(
          response->history_semantics.back());
      LOGI << "component=v3 event=history_semantic stage=projection "
           << "outcome=selected request_id=" << response->request_id
           << " semantic_count=" << response->history_semantics.size();
    }
    // 为当前轮设置最近一轮非拒识的语义
    if (!response->query_histories.empty() &&
        !response->query_histories.back()->GetLastSemantic()) {
      std::shared_ptr<clu::SimpleSemantic> last_semantic = nullptr;
      for (auto it = response->query_histories.rbegin() + 1;
           it != response->query_histories.rend(); ++it) {
        if ((*it)->GetLastSemantic()) {
          last_semantic = (*it)->GetLastSemantic();
          break;
        }
      }
      if (last_semantic) {
        response->query_histories.back()->SetLastSemantic(last_semantic);
      }
    }
  }
}

void SetResponseRejectionInfo(const DialogueRequest &request,
                              DialogueResponse *response) {
  if (response->query_histories.empty()) {
    return;
  }
  auto query = response->query_histories.back();
  response->rejection_result.SetQuery(query->GetQuery());
  response->rejection_result.SetFirstWakeup(request.first_wakeup);
  response->rejection_result.SetRepeatQuery(
      response->query_histories.size() >= 2 &&
      query->GetQuery() ==
          response->query_histories[response->query_histories.size() - 2]
              ->GetQuery());
  response->context_variables["is_repeat_query"] = std::to_string(response->rejection_result.IsRepeatQuery());
  auto iter = response->context_variables.find(kWakeUp);
  if (iter != response->context_variables.end() && iter->second == "1") {
    response->rejection_result.SetWakeUp(true);
  }
}

void SetQuerySoundPosition(const dialog::Turn &cur_turn,
                           DialogueResponse *response) {
  if (response->query_histories.empty()) {
    return;
  }
  std::string position;
  GetTurnSoundPosition(cur_turn, &position);
#if defined(__linux__) && !defined(__ANDROID__)
  if (position.empty()) {
    position = "主驾";
  }
#endif
  response->query_histories.back()->SetSoundPosition(position);
}

void FlatEventInput(const std::shared_ptr<dialog::EventInput> &input,
                    const std::string &base_name,
                    std::map<std::string, std::string> *vars) {
  assert(vars);
  if (input->GetType() == EventInput::DataType::kObject ||
      input->GetType() == EventInput::DataType::kArray) {
    for (auto &child : input->GetChildren()) {
      auto new_base_name = input->GetName();
      if (!base_name.empty()) {
        new_base_name = base_name + new_base_name;
      }
      new_base_name.push_back('.');
      FlatEventInput(child, new_base_name, vars);
    }
  } else {
    vars->insert({base_name + input->GetName(), input->AsString()});
  }
}

void UpdateContextVariables(const dialog::Turn &cur_turn,
                            const DialogueRequest &request,
                            DialogueResponse *response) {
  assert(response);
  for (auto &input : cur_turn.inputs) {
    if (input->InputMode() == EventInput::Mode::kEvent ||
        input->InputMode() == EventInput::Mode::kReference) {
      auto p_input = std::dynamic_pointer_cast<dialog::EventInput>(input);
      FlatEventInput(p_input, "", &response->context_variables);
    }
  }
  std::string first_wakeup_str = "false";
  if (request.first_wakeup) {
    first_wakeup_str = "true";
  }
  response->context_variables.insert({"first_wakeup", first_wakeup_str});
  if (!response->history_semantics.empty()) {
    auto semantic = response->history_semantics.back();
    response->context_variables.insert({"last_domain", semantic->domain});
    response->context_variables.insert({"last_intent", semantic->intent});
    for (auto &slot : semantic->slots) {
      response->context_variables.insert(
          {"last_slot_" + slot.first, slot.second});
    }
    response->context_variables.insert(
        {"last_slots_size", std::to_string(semantic->slots.size())});
  }
  if (response->query_histories.size() >= 2) {
    auto last_query =
        response->query_histories.at(response->query_histories.size() - 2);
    if (!last_query->GetResponse().empty()) {
      response->context_variables.insert(
          {"last_response", last_query->GetResponse()});
    }
    response->context_variables.insert(
      {"last_query", last_query->GetQuery()});
    response->context_variables.insert(
      {"last_query.microphone.position", last_query->GetSoundPosition()});
  }
}


int FilterContextV3(const std::shared_ptr<clu::CtxFilter>& filter,
                    dialog::Turn* current_turn, DialogueResponse* response) {
  assert(current_turn);
  assert(response);
  if (response->query_histories.empty()) {
    return -1;
  }
  std::set<std::string> query_ids;
  for (const std::shared_ptr<clu::Query>& query : response->query_histories) {
    if (!query || !query_ids.insert(query->GetRequestId()).second) {
      continue;
    }
  }
  response->query_histories.back()->SetQueryContext(query_ids);
  if (filter && filter->Filter(response->query_histories, &query_ids) < 0) {
    return -1;
  }
  response->query_histories.back()->SetQueryContext(query_ids);
  for (const std::shared_ptr<dialog::TaskBase>& task :
       current_turn->active_tasks) {
    if (task && query_ids.find(task->request_id) != query_ids.end()) {
      current_turn->executable_tasks.insert(task->request_id);
    }
  }
  return 0;
}

int BuildModelRequest(const DialogueV3Input& input,
                      const DialogueResponse& response,
                      size_t max_history_rounds,
                      size_t max_history_bytes,
                      bool allow_multi_intent_history,
                      Nlu06BRequest* model_request) {
  if (model_request == nullptr || input.request_id.empty() ||
      input.query.empty() || response.query_histories.empty()) {
    return -1;
  }
  model_request->request_id = input.request_id;
  model_request->query = input.query;
  model_request->enable_hotfix = input.enable_hotfix;
  model_request->hotfix_query = input.query;
  model_request->hotfix_context = input.hotfix_context;
  model_request->histories = Json::Value(Json::arrayValue);
  model_request->model_last_context = Json::Value(Json::objectValue);
  Json::Value selected_semantics(Json::arrayValue);
  if (ProjectV3QueryHistories(
          response.query_histories, input.request_id, max_history_rounds,
          max_history_bytes, allow_multi_intent_history,
          &model_request->histories, &selected_semantics) < 0 ||
      BuildV3ModelLastContext(response.context_variables, selected_semantics,
                              &model_request->model_last_context) < 0) {
    return -1;
  }
  return 0;
}

int BuildSubQueries(const nlu::SemanticFrames& frames,
                    DialogueResponse* response) {
  if (response == nullptr || frames.empty()) {
    return -1;
  }
  response->sub_queries.clear();
  for (size_t i = 0; i < frames.size(); ++i) {
    if (frames[i] == nullptr || frames[i]->domain.value.empty()) {
      return -1;
    }
    std::shared_ptr<clu::SubQuery> sub_query(
        new clu::SubQuery(response->normalized_query));
    sub_query->request_id = response->request_id;
    sub_query->index = static_cast<int>(i + 1);
    sub_query->is_last = i + 1 == frames.size();
    sub_query->category = frames[i]->domain.value;
    response->sub_queries.push_back(sub_query);
  }
  response->is_multi_intent = frames.size() > 1;
  return 0;
}

int BuildHotQuerySubQueries(const dialog::Turn& turn,
                            DialogueResponse* response) {
  if (!dialogue_internal::AreCompleteSemanticFrames(turn.frames)) {
    return -1;
  }
  return BuildSubQueries(turn.frames, response);
}

int PublishStreamResult(DialogueResponse* response) {
  if (response == nullptr || !response->stream) {
    return 0;
  }
  if (!response->stream_content) {
    return -1;
  }
  const std::string content = JsonHelper::ToString(response->ToJson());
  if (response->stream_content->ProduceMessage(content) < 0) {
    response->stream_content->WaitForStop();
    LOG(ERROR) << "component=v3 event=v3_stream_publish stage=produce "
               << "outcome=error request_id=" << response->request_id
               << " reason=produce_failed response_bytes=" << content.size();
    return -1;
  }
  response->stream_content->WaitForStop();
  LOGI << "component=v3 event=v3_stream_publish stage=complete outcome=ok "
       << "request_id=" << response->request_id
       << " response_bytes=" << content.size();
  return 0;
}

void StopStream(DialogueResponse* response) {
  if (response != nullptr && response->stream && response->stream_content) {
    response->stream_content->WaitForStop();
  }
}

}  // namespace


void Dialogue::Initialize() { nlptk::dialog::BindBuildinTasks(); }

Dialogue::Dialogue()
    : valid_(false),
      turn_history_size_(2u),
      query_history_size_(4u),
      dst_manager_(nullptr),
      semantics_processor_(nullptr),
      semantic_processor_(nullptr),
      normalizer_(nullptr),
      plugin_manager_(nullptr),
      thread_pool_(nullptr),
      hot_queries_cache_(nullptr),
      query_normalizer_(nullptr),
      ctx_filter_(nullptr),
      query_guard_(nullptr),
#if defined(__linux__) && !defined(__ANDROID__)
      qr_manager_(nullptr),
#endif
      nlu_0_6b_manager_(nullptr),
      v3_pipeline_(nullptr),
      model_history_rounds_(1u),
      model_history_bytes_(65536u),
      allow_multi_intent_history_(false) {}

Dialogue::~Dialogue() { Destruction(); }

int Dialogue::Initialize(const string& config_path) {
  // Do not discard a binding installed by the additive initializer.
  if (inference_binding_) return Initialize(config_path, *inference_binding_);
  return InitializeImpl(config_path, Nlu06BInferenceBinding());
}

int Dialogue::Initialize(const string& config_path,
                         Nlu06BInferenceBinding binding) {
  if (binding.inference == nullptr || config_path.empty() ||
      config_path.find('\0') != string::npos) return -1;
  if (valid_.load() || inference_binding_) {
    return valid_.load() && inference_binding_ && config_path == config_file_ &&
        binding.inference == inference_binding_->inference &&
        binding.owner_context == inference_binding_->owner_context ? 0 : -1;
  }
  std::unique_ptr<const Nlu06BInferenceBinding> snapshot(
      new Nlu06BInferenceBinding(binding));
  const int code = InitializeImpl(config_path, *snapshot);
  if (code == 0) inference_binding_ = std::move(snapshot);
  return code;
}

int Dialogue::InitializeImpl(const string& config_path,
                             Nlu06BInferenceBinding binding) {
  curl_global_init(CURL_GLOBAL_ALL);
  config_file_ = config_path;
  Path path(config_path);
  path = path.AbsolutePath();
  if (!path.IsExisted()) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=config "
               << "outcome=error reason=config_not_found";
    return -1;
  }
  const Json::Value config = JsonHelper::ParseJsonFromFile(path.ToString());
  const Path base_path = path.Directory();
  if (!config.isObject() || config.empty()) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=config "
               << "outcome=error reason=config_invalid";
    return -1;
  }

  string default_scenario =
      JsonHelper::ResolveJPath<string>(config, ".DefaultScenario", "");
  if (StringUtil::EmptyOrSpaces(default_scenario)) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=config "
               << "outcome=error reason=missing_default_scenario";
    return -1;
  }
  default_scenario = StringUtil::ToLower(StringUtil::Trim(default_scenario));
  const Json::Value nlu_config =
      JsonHelper::ResolveJPath(config, "LanguageUnderstanding");
  if (!nlu_config.isObject() || nlu_config.empty()) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=nlu_config "
               << "outcome=error reason=config_invalid";
    return -1;
  }
  const string nlu_config_file =
      JsonHelper::ResolveJPath<string>(nlu_config, "NluConfig", "");
  const Path nlu_path = base_path.Append(nlu_config_file);
  if (nlu_config_file.empty() || !nlu_path.IsFile()) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=nlu_config "
               << "outcome=error reason=config_not_found";
    return -1;
  }
  const Json::Value nlu_object =
      JsonHelper::ParseJsonFromFile(nlu_path.ToString());
  nlu_0_6b_manager_.reset(new Nlu06BManager());
  if (nlu_0_6b_manager_->Initialize(nlu_object, base_path.ToString(), binding) < 0) {
    return -1;
  }
  v3_pipeline_.reset(new DialogueV3Pipeline());

#if defined(__linux__) && !defined(__ANDROID__)
  qr_manager_ = std::make_shared<clu::QrManager>();
  const string qr_config = JsonHelper::ResolveJPath<string>(
      nlu_config, "QueryRejectionConfig", "");
  if (qr_config.empty()) {
    LOG(WARNING) << "component=v3 event=v3_init_result stage=rejection "
                 << "outcome=default reason=config_not_set";
  } else {
    const Path qr_path = base_path.Append(qr_config);
    if (!qr_path.IsFile()) {
      LOG(ERROR) << "component=v3 event=v3_init_result stage=rejection "
                 << "outcome=error reason=config_not_found";
      return -1;
    }
    const Json::Value qr_object =
        JsonHelper::ParseJsonFromFile(qr_path.ToString());
    if (qr_manager_->Initialize(qr_object, base_path.ToString()) < 0) {
      VLOG(3) << "component=v3 event=v3_init_result stage=rejection "
              << "outcome=error reason=initialize_failed";
      return -1;
    }
  }
#endif

  const string query_normalizer_command =
      JsonHelper::ResolveJPath<string>(nlu_config, "QueryNormalizer", "");
  if (!query_normalizer_command.empty()) {
    query_normalizer_ = std::make_shared<clu::QueryProcessor>();
    if (query_normalizer_->Initialize(query_normalizer_command) < 0) {
      return -1;
    }
  }

  Json::Value process_config =
      JsonHelper::ResolveJPath(nlu_config, "SemanticsProcessConfig");
  if (!process_config.isNull()) {
    const Path process_path = base_path.Append(process_config.asString());
    if (!process_path.IsFile()) {
      return -1;
    }
    semantics_processor_ = std::make_shared<clu::MultiSemanticProcessor>();
    if (semantics_processor_->Initialize(
            JsonHelper::ParseJsonFromFile(process_path.ToString())) < 0) {
      return -1;
    }
  }
  process_config =
      JsonHelper::ResolveJPath(nlu_config, "SemanticProcessConfig");
  if (!process_config.isNull()) {
    const Path process_path = base_path.Append(process_config.asString());
    if (!process_path.IsFile()) {
      return -1;
    }
    semantic_processor_ = std::make_shared<clu::SingleSemanticProcessor>();
    if (semantic_processor_->Initialize(
            JsonHelper::ParseJsonFromFile(process_path.ToString())) < 0) {
      return -1;
    }
  }

  const Json::Value modifier_configs =
      JsonHelper::ResolveJPath(nlu_config, "SemanticModifierConfigs");
  if (!modifier_configs.isNull()) {
    if (!modifier_configs.isArray()) {
      return -1;
    }
    for (const Json::Value& modifier_config : modifier_configs) {
      const Path modifier_path = base_path.Append(modifier_config.asString());
      if (!modifier_path.IsFile()) {
        return -1;
      }
      const Json::Value modifier_items =
          JsonHelper::ParseJsonFromFile(modifier_path.ToString());
      if (!modifier_items.isArray()) {
        return -1;
      }
      for (const Json::Value& item : modifier_items) {
        const string type =
            JsonHelper::ResolveJPath<string>(item, "type", "");
        clu::SemanticModifier* modifier = clu::ModifierFactory::Get(type);
        if (modifier == nullptr || modifier->Load(item) < 0) {
          delete modifier;
          return -1;
        }
        semantic_modifiers_.push_back(modifier);
      }
    }
  }

  const Json::Value normalizer_config =
      JsonHelper::ResolveJPath(nlu_config, "SlotNormalizerConfig");
  if (!normalizer_config.isNull()) {
    normalizer_ = new clu::SlotNormalizer();
    if (normalizer_->Initialize(normalizer_config, base_path.ToString()) < 0) {
      return -1;
    }
  }

  plugin_manager_ = std::make_shared<clu::PluginManager>();
  const string plugins_config =
      JsonHelper::ResolveJPath<string>(nlu_config, "PluginsConfig", "");
  if (!plugins_config.empty()) {
    const Path plugin_path = base_path.Append(plugins_config);
    if (!plugin_path.IsFile() ||
        plugin_manager_->Initialize(
            JsonHelper::ParseJsonFromFile(plugin_path.ToString()),
            base_path.ToString()) < 0) {
      return -1;
    }
  }

  dst_manager_ = std::make_shared<clu::DstManager>();
  const Json::Value dst_config =
      JsonHelper::ResolveJPath(nlu_config, "DialogueStateTracking");
  if (dst_manager_->Initialize(dst_config, base_path.ToString()) < 0) {
    return -1;
  }

  turn_history_size_ = JsonHelper::ResolveJPath<size_t>(
      config, "ContextManager.max_turn_size", 2);
  query_history_size_ = JsonHelper::ResolveJPath<size_t>(
      config, "ContextManager.max_query_records", 4);
  model_history_rounds_ = JsonHelper::ResolveJPath<size_t>(
      config, "Nlu06B.max_history_rounds", 1u);
  model_history_bytes_ = JsonHelper::ResolveJPath<size_t>(
      config, "Nlu06B.max_history_bytes", 65536u);
  allow_multi_intent_history_ = JsonHelper::ResolveJPath<bool>(
      config, "Nlu06B.allow_multi_intent_input", false);
  if (turn_history_size_ == 0 || query_history_size_ == 0 ||
      model_history_rounds_ == 0 || model_history_bytes_ == 0) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=history_config "
               << "outcome=error reason=invalid_limits";
    return -1;
  }
  const int query_ttl_seconds = JsonHelper::ResolveJPath<int>(
      config, "ContextManager.expire_strategy.query_records", 0);
  if (query_ttl_seconds <= 0) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=history_config "
               << "outcome=error reason=invalid_query_ttl";
    return -1;
  }
  const string context_type = JsonHelper::ResolveJPath<string>(
      config, "ContextManager.Type", "local");
  context_manager_.reset(
      ContextManager::Create(context_type, config["ContextManager"]));
  if (!context_manager_) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=context_manager "
               << "outcome=error reason=create_failed";
    return -1;
  }
  personalized_dict_manager_ =
      std::make_shared<dialog::PersonalizedDictManager>(context_manager_);

  const Json::Value dm_config =
      JsonHelper::ResolveJPath(config, "DialogueManager");
  if (!dm_config.isObject() || dm_config.empty()) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=dialogue_manager "
               << "outcome=error reason=config_invalid";
    return -1;
  }
  dialogue_manager_.reset(new DialogueManager());
  if (dialogue_manager_->Initialize(dm_config, context_manager_,
                                    base_path.ToString(),
                                    default_scenario) < 0 ||
      !dialogue_manager_->IsSupportedScenario(default_scenario)) {
    dialogue_manager_.reset();
    LOG(ERROR) << "component=v3 event=v3_init_result stage=dialogue_manager "
               << "outcome=error reason=initialize_failed";
    return -1;
  }
  dialogue_manager_->SetDefaultScenario(default_scenario);
  const size_t thread_pool_size =
      JsonHelper::ResolveJPath<size_t>(config, "ThreadPoolSize", 5);
  thread_pool_.reset(new utils::SimpleThreadPool(thread_pool_size));

  hot_queries_cache_.reset(new HotQueriesCache());
  const Json::Value hot_query_config =
      JsonHelper::ResolveJPath(config, "HotQueriesCacheRules");
  if (hot_queries_cache_->Initialize(hot_query_config,
                                     base_path.ToString()) < 0) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=hotquery "
               << "outcome=error reason=initialize_failed";
    return -1;
  }
  const Json::Value filter_config =
      JsonHelper::ResolveJPath(config, "ContextFilter");
  if (filter_config.isObject()) {
    ctx_filter_ = std::make_shared<clu::CtxFilter>();
    if (ctx_filter_->Initialize(filter_config, base_path.ToString()) < 0) {
      LOG(ERROR) << "component=v3 event=v3_init_result stage=context_filter "
                 << "outcome=error reason=initialize_failed";
      return -1;
    }
  }
  const Json::Value guard_config =
      JsonHelper::ResolveJPath(config, "QueryGuard");
  if (!guard_config.isNull()) {
    query_guard_ = std::make_shared<clu::QueryGuard>();
    if (query_guard_->Initialize(guard_config, base_path.ToString()) < 0) {
      LOG(ERROR) << "component=v3 event=v3_init_result stage=query_guard "
                 << "outcome=error reason=initialize_failed";
      return -1;
    }
  }
  version = JsonHelper::ResolveJPath<string>(config, "version", "null");
  valid_.store(context_manager_ && nlu_0_6b_manager_ && v3_pipeline_ &&
               dialogue_manager_ && plugin_manager_ && hot_queries_cache_);
  if (!valid_.load()) {
    LOG(ERROR) << "component=v3 event=v3_init_result stage=complete "
               << "outcome=error reason=invalid_component_state";
    return -1;
  }
  LOG(INFO) << "component=v3 event=v3_init_result stage=complete outcome=ok "
            << "query_history=stateless_context_manager";
  return 0;
}

int Dialogue::Process(const DialogueRequest& request,
                      DialogueResponse* response) const {
  assert(response);
  // Establish presence and reset diagnostics before any request error return.
  response->debug = request.enable_debug;
  response->debug_info.v3_diagnostics = Json::Value();
#if defined(__linux__) && !defined(__ANDROID__)
  response->rejection_result = clu::MultiClassQueryResult("");
#endif
  if (response->debug) {
    Json::Value& diagnostics = response->debug_info.v3_diagnostics;
    diagnostics["is_hotcachequeries"] = false;
    diagnostics["is_hit_rule"] = false;
    diagnostics["is_rejected"] = false;
    diagnostics["is_multi_intent"] = false;
  }
  if (!valid_.load()) {
    response->code = 503;
    response->error_msg = "Service is unavailable: Failed to initialize!";
    StopStream(response);
    return 503;
  }

  vector<Turn*> history;
  std::unique_ptr<Turn> current_turn(new Turn());
  response->timeline->record(response->request_id, "pre-request",
                             "参数和上下文预处理");
  int code = BeforeProcess(request, current_turn.get(), &history, response);
  if (code != DialogueCode::Success) {
    DialogueUtils::FreePointers(&history);
    StopStream(response);
    return code;
  }

  DialogueV3Input pipeline_input;
  pipeline_input.request_id = request.id;
  pipeline_input.query = response->normalized_query;
  pipeline_input.original_query = response->original_query;
  pipeline_input.enable_hotfix = request.enable_hotfix;
  pipeline_input.hotfix_context = response->context_variables;
  Nlu06BRequest model_request;
  if (BuildModelRequest(pipeline_input, *response, model_history_rounds_,
                        model_history_bytes_, allow_multi_intent_history_,
                        &model_request) < 0) {
    DialogueUtils::FreePointers(&history);
    StopStream(response);
    return DialogueCode::E_Error;
  }

  response->timeline->record(response->request_id, "hot-query",
                             "hot-query模块规则匹配");
  const int hot_query_code = GetHotQueryCache(response, current_turn.get());
  code = ProcessV3(history, current_turn.get(), response, pipeline_input,
                   model_request, hot_query_code);
  if (code != DialogueCode::Success) {
    DialogueUtils::FreePointers(&history);
    StopStream(response);
    return code;
  }
  const dialogue_internal::V3NluHistoryEligibility history_eligibility =
      dialogue_internal::BuildV3NluHistoryEligibility(*response,
                                                      current_turn->frames);
  Json::Value current_semantics(Json::arrayValue);
  const bool store_nlu_history =
      dialogue_internal::IsNluHistoryEligible(history_eligibility) &&
      BuildV3NluHistorySemantics(response->normalized_query,
                                 current_turn->frames,
                                 &current_semantics) == 0 &&
      AttachV3NluHistorySemantics(
          current_semantics, response->query_histories.back().get()) == 0;

  response->timeline->record(response->request_id, "after-request",
                             "上下文回存");
  Turn* persisted_turn = current_turn.release();
  const int after_code =
      AfterProcess(request.session_id, persisted_turn, &history);
  if (after_code != DialogueCode::Success) {
    DialogueUtils::FreePointers(&history);
    StopStream(response);
    return after_code;
  }
  if (PublishStreamResult(response) < 0) {
    DialogueUtils::FreePointers(&history);
    return DialogueCode::E_Error;
  }
  if (StoreV3QueryHistory(
          true, after_code == DialogueCode::Success, store_nlu_history,
          query_history_size_, context_manager_.get(), response) < 0) {
    DialogueUtils::FreePointers(&history);
    StopStream(response);
    return DialogueCode::E_ContextManager;
  }
  DialogueUtils::FreePointers(&history);
  return DialogueCode::Success;
}

int Dialogue::BeforeProcess(const DialogueRequest& request,
                            dialog::Turn* current_turn,
                            std::vector<dialog::Turn*>* history,
                            DialogueResponse* response) const {
  assert(current_turn);
  assert(history);
  assert(response);
  response->request_id = request.id;
  response->original_query = request.query;
  response->normalized_query = request.query;
  response->version = version;
  if (request.id.empty() || request.query.empty()) {
    return DialogueCode::E_EmptyQuery;
  }
  if (query_normalizer_ &&
      query_normalizer_->Process(&response->normalized_query) < 0) {
    return DialogueCode::E_Error;
  }
  if (response->normalized_query.empty()) {
    return DialogueCode::E_EmptyQuery;
  }
  response->debug = request.enable_debug;
  response->stream = request.stream;
  current_turn->session_id = request.session_id;
  response->session_id = request.session_id;
  current_turn->turn_uid = request.id;
  response->debug_info.hot_query_info.enable = request.enable_cache;
  response->rejection_result.SetContextVariables(&response->context_variables);
  if (request.enable_hotfix) {
    current_turn->cache_code += (1 << 1);
  }
  current_turn->query = request.query;
  if (dialogue_internal::BuildInput(request, current_turn) < 0) {
    return DialogueCode::E_EmptyQuery;
  }
  if (!request.app_id.empty() && !request.uid.empty() &&
      personalized_dict_manager_->Get(request.app_id, request.uid,
                                      &current_turn->inputs) < 0) {
    return DialogueCode::E_Error;
  }
  if (dialogue_internal::BuildClientContent(
          request, &current_turn->client_content) < 0) {
    return DialogueCode::E_Error;
  }
  if (!request.first_wakeup &&
      context_manager_->Get(request.session_id, history) < 0) {
    DialogueUtils::FreePointers(history);
    return DialogueCode::E_Invalid;
  }
  if (!request.turn_uid.empty()) {
    dialogue_internal::UpdateTurn(request.turn_uid, history, current_turn,
                                  request.id);
  } else {
    dialogue_internal::UpdateTurn(request.turn_id, history, current_turn,
                                  request.id);
  }
  if (RestoreV3QueryHistory(
          request, query_history_size_, context_manager_.get(),
          &response->query_histories) < 0 ||
      response->query_histories.empty()) {
    return DialogueCode::E_Error;
  }
  response->query_histories.back()->SetNormalizedQuery(
      response->normalized_query);
  response->query_histories.back()->SetEnableLLM(request.enable_llm);
  for (const std::shared_ptr<clu::Query>& query :
       response->query_histories) {
    if (!query) {
      return DialogueCode::E_Error;
    }
    query->SetContextVariables(&response->context_variables);
  }
  SetHistorySemantics(*current_turn, *history, response);
  SetQuerySoundPosition(*current_turn, response);
  if (FilterContextV3(ctx_filter_, current_turn, response) < 0) {
    return DialogueCode::E_Error;
  }
  UpdateContextVariables(*current_turn, request, response);
  SetResponseRejectionInfo(request, response);
  return DialogueCode::Success;
}

int Dialogue::AfterProcess(const std::string& session_id,
                           dialog::Turn* current_turn,
                           std::vector<dialog::Turn*>* history) const {
  assert(current_turn);
  assert(history);
  history->insert(history->begin(), current_turn);
  while (history->size() > turn_history_size_) {
    delete history->back();
    history->pop_back();
  }
  if (!session_id.empty() && context_manager_->Put(session_id, *history) < 0) {
    return DialogueCode::E_ContextManager;
  }
  return DialogueCode::Success;
}

int Dialogue::ProcessV3(const std::vector<dialog::Turn*>& history,
                        dialog::Turn* current_turn,
                        DialogueResponse* response,
                        const DialogueV3Input& pipeline_input,
                        const Nlu06BRequest& model_request,
                        int hot_query_code) const {
  assert(current_turn);
  assert(response);
  if (!v3_pipeline_) {
    return DialogueCode::E_Error;
  }
  nlu::SemanticFrames frames;
  DialogueV3RouteResult route_result;
  DialogueQueryGuardAdapter guard_adapter(query_guard_.get());
  DialogueNlu06BAdapter nlu_adapter(nlu_0_6b_manager_.get());
  int route_code = 0;
#if defined(__linux__) && !defined(__ANDROID__)
  if (hot_query_code == 0) {
    if (QueryRejection(response) != DialogueCode::Success) {
      return DialogueCode::E_Error;
    }
    const clu::MultiClassQueryResult& qr = response->rejection_result;
    // Preserve reported QR metadata. Exceptions affect the business decision
    // and history admission, not genuine matcher provenance.
    route_result.is_rejected =
        qr.isRjected() &&
        !(qr.GetVersion() == "v1.0" && qr.isFirstWakeup()) &&
        !qr.IsRepeatQuery();
    if (route_result.is_rejected) {
      std::unique_ptr<nlu::SemanticFrame> frame(new nlu::SemanticFrame());
      frame->domain = {kDomainOther, 1.0f};
      frame->intents.emplace_back(kDomainOther, 1.0f);
      frames.push_back(frame.release());
      route_result.result_source = "qr";
    }
  }
#endif
  if (!route_result.is_rejected) {
    route_code = v3_pipeline_->Route(
        pipeline_input, model_request, hot_query_code,
        hot_query_code > 0 ? &current_turn->frames : nullptr,
        query_guard_ ? &guard_adapter : nullptr, &nlu_adapter, &frames,
        &route_result);
  }
  if (response->debug) {
    Json::Value& diagnostics = response->debug_info.v3_diagnostics;
    diagnostics["is_hit_rule"] =
        diagnostics["is_hit_rule"].asBool() || route_result.is_hit_rule;
    diagnostics["is_rejected"] = route_result.is_rejected;
    diagnostics["is_multi_intent"] = route_result.nlu_is_multi_intent;
    if (route_result.nlu_result.isString()) {
      diagnostics["nlu_result"].swap(route_result.nlu_result);
    }
  }
  if (route_code < 0) {
    return DialogueCode::E_Error;
  }
  if (route_code > 0) {
    return BuildHotQuerySubQueries(*current_turn, response) < 0
               ? DialogueCode::E_Error
               : DialogueCode::Success;
  }

  if (route_result.is_rejected) {
#if !defined(__linux__) || defined(__ANDROID__)
    // Keep existing non-native behavior, but never treat this synthetic
    // metadata as diagnostic matcher provenance.
    response->rejection_result.SetRejected(true);
    response->rejection_result.SetHitRule(
        route_result.reject_reason, true,
        clu::MultiClassQueryResult::RuleTag::kRejectionTag);
#endif
    response->query_histories.back()->UpdateStatus(
        clu::Query::Status::kRejected);
  }
  current_turn->is_slot_immutable = route_result.is_slot_immutable;
  if (BuildSubQueries(frames, response) < 0) {
    return DialogueCode::E_Error;
  }
  if (route_result.guarded) {
    response->sub_queries.front()->is_sensitive = true;
    response->sub_queries.front()->extra_slots = route_result.guard_slots;
  }
  if (route_result.is_rejected) {
    response->sub_queries.front()->is_rejected = true;
  }
  if (response->debug) {
    Json::Value nlu_info;
    nlu_info["source"] = route_result.result_source;
    nlu_info["matched_rule"] = route_result.matched_rule;
    nlu_info["histories"] = model_request.histories;
    nlu_info["model_last_context"] = model_request.model_last_context;
    nlu_info["reject_reason"] = route_result.reject_reason;
    response->debug_info.nlu_info.append(nlu_info);
  }

  response->timeline->record(response->request_id, "normalize",
                             "调用归一化");
  if (normalizer_ && !current_turn->is_slot_immutable &&
      normalizer_->Process(&frames) < 0) {
    return DialogueCode::E_Error;
  }
  response->timeline->record(response->request_id, "modifier-nlu",
                             "V3 nlu之后调用语义修改器");
  for (clu::SemanticModifier* modifier : semantic_modifiers_) {
    if (modifier == nullptr ||
        (modifier->IsWorksAfterNlu() && modifier->Process(&frames) < 0)) {
      return DialogueCode::E_Error;
    }
  }
  if (semantics_processor_ && semantics_processor_->Process(&frames) < 0) {
    return DialogueCode::E_Error;
  }
  if (semantic_processor_ && frames.size() == 1 &&
      semantic_processor_->Process(response->request_id, frames.front()) < 0) {
    return DialogueCode::E_Error;
  }
  if (!dialogue_internal::AreCompleteSemanticFrames(frames) ||
      BuildSubQueries(frames, response) < 0) {
    return DialogueCode::E_Error;
  }
  if (route_result.guarded && frames.size() == 1) {
    response->sub_queries.front()->is_sensitive = true;
    response->sub_queries.front()->extra_slots = route_result.guard_slots;
  }
  if (route_result.is_rejected) {
    for (const std::shared_ptr<clu::SubQuery>& sub_query :
         response->sub_queries) {
      sub_query->is_rejected = true;
    }
  }
  response->timeline->record(response->request_id, "plugins", "插件调用");
  if (!plugin_manager_ ||
      plugin_manager_->Process(response->query_histories,
                               response->sub_queries, &frames) < 0 ||
      !dialogue_internal::AreCompleteSemanticFrames(frames)) {
    return DialogueCode::E_Error;
  }
  if (frames.size() != response->sub_queries.size()) {
    if (BuildSubQueries(frames, response) < 0) {
      return DialogueCode::E_Error;
    }
  } else {
    for (size_t i = 0; i < frames.size(); ++i) {
      response->sub_queries[i]->category = frames[i]->domain.value;
    }
  }
  if (!route_result.guarded && !route_result.is_rejected) {
    for (size_t i = 0; i < response->sub_queries.size(); ++i) {
      response->sub_queries[i]->is_nlu_domain = true;
    }
  }
  if (route_result.guarded && frames.size() == 1) {
    response->sub_queries.front()->is_sensitive = true;
    response->sub_queries.front()->extra_slots = route_result.guard_slots;
  }
  if (route_result.is_rejected) {
    for (const std::shared_ptr<clu::SubQuery>& sub_query :
         response->sub_queries) {
      sub_query->is_rejected = true;
    }
  }

  Json::Value results(Json::arrayValue);
  std::string vad_status = kInactiveVad;
  for (size_t i = 0; i < frames.size(); ++i) {
    nlu::SemanticFrame* frame = frames[i];
    dialogue_internal::ScopedFrameAlias alias(&current_turn->frames, frame);
    if (!alias.attached()) {
      return DialogueCode::E_Error;
    }
    current_turn->query = response->normalized_query;
    response->timeline->record(response->request_id, "dm", "V3对话管理");
    if (dialogue_manager_->Process(current_turn, history, "default") < 0 ||
        ApplySemanticsModifiers(semantic_modifiers_, current_turn) < 0) {
      return DialogueCode::E_Error;
    }
    results.append(GetResultJsonForZP(
        *current_turn, *response->sub_queries[i], &vad_status));
  }
  BuildSemanticJson(results, response->original_query, vad_status,
                    response->is_multi_intent, &response->semantic_json);
  if (dialogue_internal::TransferFrameOwnership(
          &frames, &current_turn->frames) < 0) {
    return DialogueCode::E_Error;
  }
  if (response->debug) {
    response->debug_info.dm_info = current_turn->Serialize();
  }
  return DialogueCode::Success;
}

#if defined(__linux__) && !defined(__ANDROID__)
int Dialogue::QueryRejection(DialogueResponse* response) const {
  assert(response);
  if (!qr_manager_ || response->query_histories.empty()) {
    return DialogueCode::E_Error;
  }
  response->timeline->record(response->request_id, "rejection", "调用拒识模块");
  const int code = qr_manager_->Process(response->query_histories,
                                       &response->rejection_result);
  if (response->debug) {
    response->debug_info.rejection_info = response->rejection_result.ToJson();
    response->debug_info.v3_diagnostics["is_hit_rule"] =
        response->rejection_result.IsHitRejectedRule() ||
        response->rejection_result.IsHitSemanticClearRule();
  }
  // Negative is an error, not business rejection. QR's timeout-zero policy
  // remains owned by QrManager/LLMRejection.
  return code < 0 ? DialogueCode::E_Error : DialogueCode::Success;
}
#endif

int Dialogue::GetHotQueryCache(DialogueResponse* response,
                               dialog::Turn* turn) const {
  assert(response);
  assert(turn);
  const int cache_code = hot_queries_cache_->GetCache(response);
  if (response->debug) {
    response->debug_info.v3_diagnostics["is_hotcachequeries"] = cache_code > 0;
  }
  if (cache_code <= 0) {
    return cache_code;
  }
  const Json::Value results =
      JsonHelper::ResolveJPath(response->semantic_json, "Results");
  if (!results.isArray() || results.empty()) {
    return -1;
  }
  for (const Json::Value& item : results) {
    const string domain =
        JsonHelper::ResolveJPath<string>(item, "Nlu.Domain", "");
    const string intent =
        JsonHelper::ResolveJPath<string>(item, "Nlu.Intent", "");
    if (domain.empty() || intent.empty()) {
      turn->frames.clear();
      return -1;
    }
    std::unique_ptr<nlu::SemanticFrame> frame(new nlu::SemanticFrame());
    frame->domain = {domain, 1.0f};
    frame->intents.emplace_back(intent, 1.0f);
    const Json::Value slots =
        JsonHelper::ResolveJPath(item, "Nlu.Slots");
    if (!slots.isArray()) {
      turn->frames.clear();
      return -1;
    }
    for (const Json::Value& slot : slots) {
      const string name =
          JsonHelper::ResolveJPath<string>(slot, "Name", "");
      const string value =
          JsonHelper::ResolveJPath<string>(slot, "Value", "");
      if (name.empty()) {
        turn->frames.clear();
        return -1;
      }
      frame->slots.Add(new nlu::Slot(name, value));
    }
    turn->frames.push_back(frame.release());
  }
  return dialogue_internal::AreCompleteSemanticFrames(turn->frames) ? 1 : -1;
}

int Dialogue::ReInitialize() {
  Destruction();
  const int code = InitializeImpl(config_file_, inference_binding_
      ? *inference_binding_ : Nlu06BInferenceBinding());
  if (code < 0) {
    LOG(ERROR) << "component=v3 event=v3_reinit_result stage=complete "
               << "outcome=error reason=initialize_failed";
  } else {
    LOG(INFO) << "component=v3 event=v3_reinit_result stage=complete "
              << "outcome=ok";
  }
  return code;
}

void Dialogue::Destruction() {
  valid_.store(false);
  context_manager_.reset();
#if defined(__linux__) && !defined(__ANDROID__)
  qr_manager_.reset();
#endif
  for (clu::SemanticModifier* modifier : semantic_modifiers_) {
    delete modifier;
  }
  semantic_modifiers_.clear();
  delete normalizer_;
  normalizer_ = nullptr;
  LOG(INFO) << "component=v3 event=v3_destroy stage=complete outcome=ok";
}

Dialogue DialogueInstance::instance_;

bool DialogueInstance::Initialize(const std::string& config) {
  Dialogue::Initialize();
  instance_.Initialize(config);
  return instance_.Valid();
}

const Dialogue& DialogueInstance::Get() { return instance_; }

}  // namespace nlptk
