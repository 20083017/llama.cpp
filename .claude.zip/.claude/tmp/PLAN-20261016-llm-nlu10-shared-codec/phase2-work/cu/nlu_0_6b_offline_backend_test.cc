// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_0_6b_offline_backend.h"

#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <memory>
#include <mutex>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>

#include "base/json_helper.h"
#include "base/logging.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace {

class OfflineFiles {
 public:
  OfflineFiles() {
    char path[] = "/tmp/wtp184_offline_XXXXXX";
    const char* created = mkdtemp(path);
    if (created) root = created;
    profile = JsonHelper::ParseJsonFromString(R"JSON({
      "model":"offline-model", "system_prompt":"synthetic prompt",
      "protocol_path":"v3.json", "stream":false, "temperature":0.1,
      "top_p":0.9,"top_k":12,"max_tokens":256,"enable_thinking":false,
      "allow_multi_intent_output":true})JSON");
    descriptor = JsonHelper::ParseJsonFromString(R"JSON({
      "protocol":"nlu_10","request_field_prefixes":["history:","query: "],
      "field_delimiter":"\t","request_slot_assignment":"=",
      "request_slot_separator":",","response_slot_assignment":"=",
      "response_slot_separator":",","response_frame_separator":";",
      "response_unknown_marker":"unknown","response_multi_marker":"multi:"
    })JSON");
    config["Backend"]["type"] = "offline";
    config["Model"]["profile"] = "friendly-profile";
    config["Model"]["profile_catalog_path"] = "catalog.json";
  }
  ~OfflineFiles() {
    if (root.empty()) return;
    std::remove((root + "/catalog.json").c_str());
    std::remove((root + "/v3.json").c_str());
    rmdir(root.c_str());
  }
  void Save() const {
    Json::Value catalog(Json::objectValue);
    catalog["profiles"]["friendly-profile"] = profile;
    std::ofstream a((root + "/catalog.json").c_str());
    a << JsonHelper::ToString(catalog);
    std::ofstream b((root + "/v3.json").c_str());
    b << JsonHelper::ToString(descriptor);
  }
  std::unique_ptr<Nlu06BBackend> Create(Nlu06BInferenceBinding binding) const {
    Save();
    return CreateNlu06BOfflineBackend(config, root, binding);
  }
  std::string root;
  Json::Value config;
  Json::Value profile;
  Json::Value descriptor;
};

struct Provider {
  Provider() : status(0), null_chunk(false), throw_error(false), calls(0),
               request_context(nullptr) {}
  std::vector<std::string> chunks;
  int status;
  bool null_chunk;
  bool throw_error;
  int calls;
  std::string request_json;
  void* request_context;
};

int Infer(const char* request, void* owner, void* context,
          Nlu06BOutputCallback callback) {
  Provider* provider = static_cast<Provider*>(owner);
  ++provider->calls;
  provider->request_json = request;
  provider->request_context = context;
  for (size_t i = 0u; i < provider->chunks.size(); ++i) {
    // Mutate/release each borrowed chunk immediately after the callback.
    std::string borrowed = provider->chunks[i];
    callback(borrowed.c_str(), context);
    borrowed.assign("overwritten");
  }
  if (provider->null_chunk) {
    callback(nullptr, context);
    callback("must-not-be-appended", context);
  }
  if (provider->throw_error) throw std::runtime_error("must-not-log-provider-text");
  return provider->status;
}

Nlu06BRequest Request() {
  Nlu06BRequest request;
  request.query = "synthetic private query";
  request.request_id = "offline-req-01";
  return request;
}

const char kThreeFrames[] =
    "intelligent_car_control\tturn_on_device\tname=空调;"
    "intelligent_car_control\tAC_control\twind_direction=面;"
    "intelligent_car_control\tturn_on_device\tname=车窗";

TEST(Nlu06BOfflineBackendTest, FullAndByteDeltasCopyBorrowedUtf8AndBindingValues) {
  OfflineFiles files;
  ASSERT_FALSE(files.root.empty());
  for (int leading = 0; leading < 2; ++leading) {
    const std::string text = std::string("multi:") + (leading ? ";" : "") + kThreeFrames;
    for (int split = 0; split < 2; ++split) {
      Provider provider;
      if (split) {
        for (size_t i = 0u; i < text.size(); ++i)
          provider.chunks.push_back(text.substr(i, 1u));
      } else {
        provider.chunks.push_back(text);
      }
      Nlu06BInferenceBinding binding(&Infer, &provider);
      std::unique_ptr<Nlu06BBackend> backend = files.Create(binding);
      ASSERT_TRUE(backend);
      binding.inference = nullptr;
      binding.owner_context = nullptr;  // Backend must own a value copy.
      Json::Value result;
      ASSERT_EQ(0, backend->Process(Request(), &result));
      EXPECT_STREQ("nlu06b", backend->result_source());
      ASSERT_EQ(3u, result["frames"].size());
      EXPECT_EQ("空调", result["frames"][0u]["slots"]["name"].asString());
      EXPECT_EQ("面", result["frames"][1u]["slots"]["wind_direction"].asString());
      EXPECT_EQ("车窗", result["frames"][2u]["slots"]["name"].asString());
      EXPECT_EQ(text, result["nlu_result"].asString());
      EXPECT_EQ(1, provider.calls);
      EXPECT_NE(nullptr, provider.request_context);
      EXPECT_NE(static_cast<void*>(&provider), provider.request_context);
      const Json::Value payload = JsonHelper::ParseJsonFromString(provider.request_json);
      EXPECT_EQ("offline-model", payload["model"].asString());
      EXPECT_FALSE(payload.isMember("endpoint"));
      EXPECT_EQ(std::string::npos, provider.request_json.find(Request().request_id));
    }
  }
}

TEST(Nlu06BOfflineBackendTest, CollectionAndProviderFailuresNeverPublishPartial) {
  OfflineFiles files;
  ASSERT_FALSE(files.root.empty());
  files.config["Offline"]["max_response_bytes"] = 64;
  for (int scenario = 0; scenario < 7; ++scenario) {
    Provider provider;
    if (scenario != 0) provider.chunks.push_back("vehicle\topen\tname=车窗");
    if (scenario == 1) provider.status = 7;
    if (scenario == 2) provider.null_chunk = true;
    if (scenario == 3) provider.chunks.push_back(std::string(65u, 'x'));
    if (scenario == 4) provider.throw_error = true;  // Defensive containment.
    if (scenario == 5) provider.chunks.assign(1u, std::string());
    if (scenario == 6) provider.chunks.assign(1u, std::string(65u, 'x'));
    std::unique_ptr<Nlu06BBackend> backend = files.Create(
        Nlu06BInferenceBinding(&Infer, &provider));
    ASSERT_TRUE(backend);
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(Request(), &result), 0) << scenario;
    EXPECT_TRUE(result.isNull()) << scenario;
  }
}

TEST(Nlu06BOfflineBackendTest, ExactLimitAndParseErrorDiagnosticReset) {
  OfflineFiles files;
  ASSERT_FALSE(files.root.empty());
  Provider provider;
  const std::string text = "vehicle\topen\tname=车窗";
  provider.chunks.push_back(text);
  files.config["Offline"]["max_response_bytes"] = static_cast<int>(text.size());
  std::unique_ptr<Nlu06BBackend> backend = files.Create(
      Nlu06BInferenceBinding(&Infer, &provider));
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(Request(), &result));
  provider.chunks.assign(1u, "multi:music\tplay;bad");
  EXPECT_LT(backend->Process(Request(), &result), 0);
  ASSERT_EQ(1u, result.size());
  EXPECT_EQ(provider.chunks[0], result["nlu_result"].asString());
  provider.chunks.assign(1u, "unknown");
  ASSERT_EQ(0, backend->Process(Request(), &result));
  EXPECT_TRUE(result["is_rejected"].asBool());
  EXPECT_TRUE(result["frames"].empty());
  provider.chunks.clear();
  EXPECT_LT(backend->Process(Request(), &result), 0);
  EXPECT_TRUE(result.isNull());
  EXPECT_LT(backend->Process(Request(), nullptr), 0);
}

TEST(Nlu06BOfflineBackendTest, CanonicalConfigRejectsMissingProviderAndOverrides) {
  OfflineFiles files;
  ASSERT_FALSE(files.root.empty());
  Provider provider;
  const Nlu06BInferenceBinding bound(&Infer, &provider);
  EXPECT_FALSE(files.Create(Nlu06BInferenceBinding()));
  ASSERT_TRUE(files.Create(bound));
  files.Save();
  EXPECT_FALSE(CreateNlu06BOfflineBackend(files.config, "", bound));
  for (const char* key : {"model", "system_prompt", "profile", "endpoint",
                          "api_key_env", "total_timeout_ms", "temperature"}) {
    files.config["Offline"][key] = "not-an-offline-setting";
    EXPECT_FALSE(files.Create(bound)) << key;
    files.config.removeMember("Offline");
  }
  for (const int limit : {0, -1, 16777217}) {
    files.config["Offline"]["max_response_bytes"] = limit;
    EXPECT_FALSE(files.Create(bound));
  }
  for (const int limit : {1, 16777216}) {
    files.config["Offline"]["max_response_bytes"] = limit;
    EXPECT_TRUE(files.Create(bound));
  }
  files.config["Offline"]["max_response_bytes"] = "1024";
  EXPECT_FALSE(files.Create(bound));
  files.config["Offline"] = Json::Value();
  EXPECT_FALSE(files.Create(bound));
  files.config.removeMember("Offline");
  for (const char* key : {"profile", "profile_catalog_path", "version",
                          "response_protocol", "response_flag_prefix"}) {
    files.config[key] = "stale";
    EXPECT_FALSE(files.Create(bound));
    files.config.removeMember(key);
  }
  const Json::Value saved = files.profile;
  for (const char* key : {"endpoint", "api_key_env", "max_response_bytes"}) {
    files.profile[key] = "stale-http-setting";
    EXPECT_FALSE(files.Create(bound));
    files.profile = saved;
  }
  files.config.removeMember("Model");
  EXPECT_FALSE(files.Create(bound));
  EXPECT_EQ(0, provider.calls);
}

struct ConcurrentProvider {
  ConcurrentProvider() : entered(0), overlap(false) {}
  std::mutex mutex;
  std::condition_variable ready;
  int entered;
  bool overlap;
  std::set<void*> contexts;
};

int ConcurrentInfer(const char* request, void* owner, void* context,
                    Nlu06BOutputCallback callback) {
  ConcurrentProvider* provider = static_cast<ConcurrentProvider*>(owner);
  {
    std::unique_lock<std::mutex> lock(provider->mutex);
    provider->contexts.insert(context);
    ++provider->entered;
    provider->ready.notify_all();
    if (!provider->ready.wait_for(lock, std::chrono::seconds(5),
                                 [provider]() { return provider->entered == 2; }))
      return 1;
    provider->overlap = true;
  }
  const Json::Value payload = JsonHelper::ParseJsonFromString(request);
  const std::string content = payload["messages"][1u]["content"].asString();
  const std::string output = std::string("vehicle\topen\tname=") +
      (content.find("query: alpha") != std::string::npos ? "alpha" : "beta");
  callback(output.c_str(), context);
  return 0;
}

TEST(Nlu06BOfflineBackendTest, ConcurrentCompliantProviderHasIndependentContexts) {
  OfflineFiles files;
  ASSERT_FALSE(files.root.empty());
  ConcurrentProvider provider;
  std::unique_ptr<Nlu06BBackend> backend = files.Create(
      Nlu06BInferenceBinding(&ConcurrentInfer, &provider));
  ASSERT_TRUE(backend);
  Json::Value results[2];
  int codes[2] = {-1, -1};
  std::vector<std::thread> threads;
  for (size_t i = 0u; i < 2u; ++i) {
    threads.push_back(std::thread([&backend, &results, &codes, i]() {
      Nlu06BRequest request = Request();
      request.query = i == 0u ? "alpha" : "beta";
      codes[i] = backend->Process(request, &results[i]);
    }));
  }
  for (size_t i = 0u; i < threads.size(); ++i) threads[i].join();
  EXPECT_TRUE(provider.overlap);
  EXPECT_EQ(2u, provider.contexts.size());
  for (size_t i = 0u; i < 2u; ++i) {
    ASSERT_EQ(0, codes[i]);
    EXPECT_EQ(i == 0u ? "alpha" : "beta",
              results[i]["frames"][0u]["slots"]["name"].asString());
  }
}

class LogCapture : public google::LogSink {
 public:
  LogCapture() { google::AddLogSink(this); }
  ~LogCapture() override { google::RemoveLogSink(this); }
  void send(google::LogSeverity, const char*, const char*, int,
            const google::LogMessageTime&, const char* message,
            size_t bytes) override {
    messages.append(message, bytes);
    messages.push_back('\n');
  }
  std::string messages;
};

TEST(Nlu06BOfflineBackendTest, FailureLogsDiscriminateWithoutPayloadLeakage) {
  OfflineFiles files;
  ASSERT_FALSE(files.root.empty());
  Provider provider;
  provider.chunks.push_back("private-generated-text");
  provider.status = 17;
  std::unique_ptr<Nlu06BBackend> backend = files.Create(
      Nlu06BInferenceBinding(&Infer, &provider));
  ASSERT_TRUE(backend);
  Nlu06BRequest request = Request();
  request.request_id = "safe\n\t" + std::string(140u, 'x') + "over-bound-suffix";
  LogCapture capture;
  Json::Value result;
  EXPECT_LT(backend->Process(request, &result), 0);
  provider.status = 0;
  provider.null_chunk = true;
  EXPECT_LT(backend->Process(request, &result), 0);
  provider.null_chunk = false;
  provider.chunks.assign(1u, "invalid-private-model-content");
  EXPECT_LT(backend->Process(request, &result), 0);
  EXPECT_NE(std::string::npos, capture.messages.find("stage=provider"));
  EXPECT_NE(std::string::npos, capture.messages.find("reason=provider_error"));
  EXPECT_NE(std::string::npos, capture.messages.find("provider_status=error"));
  EXPECT_NE(std::string::npos, capture.messages.find("stage=collection"));
  EXPECT_NE(std::string::npos, capture.messages.find("reason=null_chunk"));
  EXPECT_NE(std::string::npos, capture.messages.find("stage=content"));
  EXPECT_NE(std::string::npos, capture.messages.find("schema_detail=missing_tab"));
  EXPECT_NE(std::string::npos, capture.messages.find("schema_detail=not_parsed"));
  EXPECT_NE(std::string::npos, capture.messages.find("request_id=safe__"));
  EXPECT_NE(std::string::npos, capture.messages.find("backend=offline model=offline-model"));
  EXPECT_NE(std::string::npos, capture.messages.find("protocol=nlu_10"));
  EXPECT_NE(std::string::npos, capture.messages.find("max_response_bytes=1048576"));
  for (const char* secret : {"private-generated-text", "invalid-private-model-content",
                            "synthetic private query", "synthetic prompt",
                            "over-bound-suffix", "\t", "safe\n"})
    EXPECT_EQ(std::string::npos, capture.messages.find(secret)) << secret;
}

}  // namespace
}  // namespace nlptk
