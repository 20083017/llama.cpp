// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_NLU_0_6B_MANAGER_H_
#define CU_NLU_0_6B_MANAGER_H_

#include <memory>
#include <string>

#include "cu/nlu_0_6b_backend.h"
#include "cu/nlu_0_6b_offline_inference.h"
#include "json/json.h"
#include "nlu/semantic_frames.h"

namespace nlptk {

struct Nlu06BResultInfo {
  bool is_rejected;
  bool is_multi_intent;
  bool is_slot_immutable;
  std::string reject_reason;
  std::string result_source;
  std::string matched_rule;
  // Diagnostics only: null means no decoded text; an empty string is present.
  Json::Value nlu_result;
  bool is_hit_rule;

  Nlu06BResultInfo()
      : is_rejected(false),
        is_multi_intent(false),
        is_slot_immutable(false),
        is_hit_rule(false) {}
  void Clear();
};

class Nlu06BManager {
 public:
  Nlu06BManager();
  ~Nlu06BManager();

  int Initialize(const Json::Value& config, const std::string& base_path);
  int Initialize(const Json::Value& config, const std::string& base_path,
                 Nlu06BInferenceBinding binding);
  int Process(const Nlu06BRequest& request, nlu::SemanticFrames* output,
              Nlu06BResultInfo* info) const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;

  Nlu06BManager(const Nlu06BManager&) = delete;
  Nlu06BManager& operator=(const Nlu06BManager&) = delete;
};

}  // namespace nlptk

#endif  // CU_NLU_0_6B_MANAGER_H_
