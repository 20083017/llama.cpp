// Copyright 2022 the project authors. All Rights Reserved.

#include "cu/dialogue_system.h"

#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <memory>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>

#include "base/guid.h"
#include "base/json_helper.h"
#include "base/logging.h"
#include "base/string_util.h"
#include "cu/dialogue.h"
#include "cu/dialogue_response.h"
#include "json/json.h"
#ifdef ENABLE_LLAVA
#include <functional>
#include <future>

#include "llava_api2_scheduler.h"
#endif

nlptk::Dialogue *INSTANCE = nullptr;
std::atomic<uint64_t> COUNTER(0);
std::mutex MUTEX;
namespace {
struct dialog_conf {
  bool debug;
  bool first_wakeup;
  bool enable_cache;
  bool enable_hotfix;
  bool enable_llm;
  std::string session_id;
  std::string input_data;
  std::string scenario;
  std::string request_id;
  std::string histories;
  std::string query;

  dialog_conf()
      : debug(false), first_wakeup(false), enable_cache(true),
        enable_hotfix(true), input_data("[]"), histories("[]") {}

  std::string ToString() {
    return "session_id: " + session_id + ", request_id: " + request_id +
           ", query: " + query + ", debug: " + std::to_string(debug) +
           ", enable_cache: " + std::to_string(enable_cache) +
           ", enable_hotfix: " + std::to_string(enable_hotfix) +
           ", enable_llm: " + std::to_string(enable_llm) +
           ", input_data: " + input_data + ", scenario: " + scenario +
           ", first_wakeup: " + std::to_string(first_wakeup) +
           ", histories: " + histories;
  }
  void Deserialize(const std::string &query) {
    std::string json_str = nlptk::StringUtil::Trim(query);
    if (json_str.empty()) {
      return;
    }
    if (json_str[0] != '{' || json_str.back() != '}') {
      // query is not a json string
      this->query = query;
      session_id = nlptk::GUID::NewGUID().ToString();
      LOG(INFO) << "session_id is empty, generate session_id:" << session_id;
      request_id = nlptk::GUID::NewGUID().ToString();
      LOG(INFO) << "request_id is empty, generate request_id:" << request_id;
      enable_llm = false;
      enable_cache = true;
      enable_hotfix = true;
      return;
    }
    auto json_obj = nlptk::JsonHelper::ParseJsonFromString(json_str);
    debug = nlptk::JsonHelper::ResolveJPath<bool>(json_obj, "debug", false);
    first_wakeup =
        nlptk::JsonHelper::ResolveJPath<bool>(json_obj, "first_wakeup", false);
    enable_cache =
        nlptk::JsonHelper::ResolveJPath<bool>(json_obj, "enable_cache", true);
    enable_hotfix =
        nlptk::JsonHelper::ResolveJPath<bool>(json_obj, "enable_hotfix", true);
    enable_llm =
        nlptk::JsonHelper::ResolveJPath<bool>(json_obj, "enable_llm", true);
    session_id = nlptk::JsonHelper::ResolveJPath<std::string>(json_obj,
                                                              "session_id", "");
    if (session_id.empty()) {
      session_id = nlptk::GUID::NewGUID().ToString();
      LOG(INFO) << "session_id is empty, generate session_id:" << session_id;
    }
    auto input_data_str = nlptk::JsonHelper::ResolveJPath<std::string>(
        json_obj, "input_data", "[]");
    auto input_obj = nlptk::JsonHelper::ParseJsonFromString(input_data_str);
    if (input_obj.isArray()) {
      auto input_arr = nlptk::JsonHelper::MakeJsonArray();
      for (auto &obj : input_obj) {
        if (obj.isString()) {
          input_arr.append(
              nlptk::JsonHelper::ParseJsonFromString(obj.asString()));
        } else {
          input_arr.append(obj);
        }
      }
      input_data = nlptk::JsonHelper::ToString(input_arr);
    } else {
      input_data = input_data_str;
    }
    scenario = nlptk::JsonHelper::ResolveJPath<std::string>(
        json_obj, "scenario", "default");
    request_id = nlptk::JsonHelper::ResolveJPath<std::string>(json_obj,
                                                              "request_id", "");
    if (request_id.empty()) {
      request_id = nlptk::GUID::NewGUID().ToString();
      LOG(INFO) << "request_id is empty, generate request_id:" << request_id;
    }
    histories = nlptk::JsonHelper::ResolveJPath<std::string>(json_obj,
                                                             "histories", "[]");
    this->query =
        nlptk::JsonHelper::ResolveJPath<std::string>(json_obj, "query", "");
  }
};

std::string
CreateFailedResponse(const std::string &message = "Not Initialized") {
  Json::Value body;
  Json::Value header;
  Json::Value payload;
  header["RequestID"] = "";
  header["DialogID"] = "";
  header["Code"] = -1;
  header["Message"] = "Not Initialized";
  payload["Semantic"] = nlptk::JsonHelper::MakeJsonObject();
  body["Header"] = header;
  body["Payload"] = payload;
  return nlptk::JsonHelper::ToString(body).c_str();
}

bool ParseRequestBody(const char *query, nlptk::DialogueRequest *request,
                      std::string *fail_response) {
  if (!INSTANCE) {
    *fail_response = CreateFailedResponse();
    return false;
  }
  dialog_conf conf;
  conf.Deserialize(query);
  request->query = conf.query;
  request->enable_debug = conf.debug;
  request->enable_hotfix = conf.enable_hotfix;
  request->input_data = conf.input_data;
  request->session_id = conf.session_id;
  request->scenario = conf.scenario;
  request->stream = false;
  request->id = conf.request_id;
  request->first_wakeup = conf.first_wakeup;
  if (!conf.histories.empty()) {
    auto history_objs = nlptk::JsonHelper::ParseJsonFromString(conf.histories);
    if (history_objs.isArray()) {
      for (auto &his_obj : history_objs) {
        nlptk::HistoryQA his_qa;
        his_qa.request_id =
            nlptk::JsonHelper::ResolveJPath<std::string>(his_obj, "id", "");
        his_qa.query =
            nlptk::JsonHelper::ResolveJPath<std::string>(his_obj, "query", "");
        his_qa.response = nlptk::JsonHelper::ResolveJPath<std::string>(
            his_obj, "response", "");
        request->histories.emplace_back(std::move(his_qa));
      }
    }
  }
  LOG(INFO) << "[" << conf.request_id << "]: Request: " << conf.ToString();
  return true;
}

} // namespace

bool Initialize(const char *config_file) {
  std::lock_guard<std::mutex> lock(MUTEX);
  if (INSTANCE) {
    return true;
  }
  FLAGS_v = 2;
  const char *log_level = std::getenv("FLAGS_v");
  if (log_level != nullptr) {
    FLAGS_v = std::stoi(log_level);
  }
  INSTANCE = new nlptk::Dialogue();
  if (!google::IsGoogleLoggingInitialized()) {
    google::InitGoogleLogging("DialogueSystem");
    google::SetStderrLogging(google::GLOG_INFO);
    LOG(INFO) << "Initialize google logging, FLAGS_v=" << FLAGS_v;
  }
#ifdef __NPU_REFERENCE__
  setenv("ACTIVE_CONTEXT", "local", 1);
#endif
  INSTANCE->Initialize();
  auto code = INSTANCE->Initialize(config_file);
  if (code != 0) {
    LOG(ERROR) << "Initialize failed! ";
  } else {
    LOG(INFO) << "Initialize successfully!";
  }
  return code == 0;
}

bool InitializeWithNlu06BInference(const char* config_file,
                                  Nlu06BInferenceHook inference,
                                  void* owner_context) {
#if defined(DIALOGUE_PIPELINE_V3) && DIALOGUE_PIPELINE_V3
  if (config_file == nullptr || config_file[0] == '\0' || inference == nullptr)
    return false;
  try {
    std::lock_guard<std::mutex> lock(MUTEX);
    const nlptk::Nlu06BInferenceBinding binding(inference, owner_context);
    if (INSTANCE) {
      return INSTANCE->Valid() && INSTANCE->Initialize(config_file, binding) == 0;
    }
    // Do not publish a failed/partially initialized global instance.
    std::unique_ptr<nlptk::Dialogue> candidate(new nlptk::Dialogue());
    if (!google::IsGoogleLoggingInitialized()) {
      google::InitGoogleLogging("DialogueSystem");
      google::SetStderrLogging(google::GLOG_INFO);
    }
    nlptk::Dialogue::Initialize();
    if (candidate->Initialize(config_file, binding) != 0) return false;
    INSTANCE = candidate.release();
    return true;
  } catch (...) {
    LOG(ERROR) << "component=dialogue_api event=inference_init_result"
               << " stage=initialize outcome=error reason=exception";
    return false;
  }
#else
  // V2 has no binding path. Do not change its original initialization APIs.
  (void)config_file;
  (void)inference;
  (void)owner_context;
  return false;
#endif
}

const char *Process(const char *query) {
  nlptk::DialogueResponse cu_response;
  nlptk::DialogueRequest request;
  std::string fail_response;
  if (!ParseRequestBody(query, &request, &fail_response)) {
    LOG(WARNING) << "[" << request.id << "]: Client is not Initialized.";
    return fail_response.c_str();
  }
  COUNTER.fetch_add(1);
  INSTANCE->Process(request, &cu_response);
  COUNTER.fetch_add(-1);
  std::string response = nlptk::JsonHelper::ToString(cu_response.ToJson());
  LOG(INFO) << "[" << request.id << "]: Response: " << response;
  return response.c_str();
}

int SendStreamEvent(nlptk::DialogueResponse *response, void *custom_ptr,
                    StreamingProcessCallback callback) {
  assert(response);
  while (!response->stream_content->IsStop()) {
    try {
      auto content = response->stream_content->ConsumeMessage();
      if (!content.empty()) {
        callback(content.c_str(), custom_ptr);
      }
    } catch (std::runtime_error) {
      break;
    }
  }
  return 0;
}

bool StreamingProcess(const char *query, void *custom_ptr,
                      StreamingProcessCallback callback) {
  nlptk::DialogueResponse cu_response;
  nlptk::DialogueRequest request;
  std::string fail_response;
  if (!ParseRequestBody(query, &request, &fail_response)) {
    LOG(WARNING) << "[" << request.id << "]: Client is not Initialized.";
    callback(fail_response.c_str(), custom_ptr);
    return false;
  }
  request.stream = true;
  COUNTER.fetch_add(1);
  std::thread t(SendStreamEvent, &cu_response, custom_ptr, callback);
  INSTANCE->Process(request, &cu_response);
  t.join();
  COUNTER.fetch_add(-1);
  std::string response = nlptk::JsonHelper::ToString(cu_response.ToJson());
  LOG(INFO) << "[" << request.id << "]: Response: " << response;
  return true;
}

void Release() {
  std::lock_guard<std::mutex> lock(MUTEX);
  auto temp_ptr = INSTANCE;
  INSTANCE = nullptr;
  while (COUNTER.load() > 0) {
    LOGI << "Waiting for all requests to finish...";
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }
  LOG(INFO) << "Start to release resource!";
  delete temp_ptr;
  LOG(INFO) << "Release resource successfully!";
  if (google::IsGoogleLoggingInitialized()) {
    google::ShutdownGoogleLogging();
  }
}

void ReceicedToken(const char *token);

enum InferenceCode {
  kSuccess,
  kFailedToInitialize,
  kTimeOut,
  kOther,
};

struct InferenceResponse {
  int code;
  std::string msg;
  std::string content;
  std::string task_id;
  int priority;

  std::string Serialize() const {
    Json::Value body;
    body["code"] = code;
    body["msg"] = msg;
    body["content"] = content;
    body["task_id"] = task_id;
    body["priority"] = priority;
    return nlptk::JsonHelper::ToString(body);
  }
};

const char *LLMInference(const char *prompt, const char *config,
                         void *custom_ptr, InferenceCallback callback) {
  InferenceResponse response;
  if (!INSTANCE) {
    response.code = InferenceCode::kFailedToInitialize;
    response.msg = "Not Initialized";
    response.task_id = nlptk::GUID::NewGUID().ToString();
    response.priority = 2;
    return response.Serialize().c_str();
  }
#ifdef ENABLE_LLAVA
  llava::LlavaApi2 *llava = llava::LlavaApi2::InitInstance(config, "");

  response.code = InferenceCode::kSuccess;
  response.msg = "ok";
  response.task_id = nlptk::GUID::NewGUID().ToString();
  response.priority = 2;
  if (!llava) {
    LOG(ERROR) << "Llava initialize failed!";
    response.code = InferenceCode::kFailedToInitialize;
    response.msg = "Llava initialize failed!";
    return response.Serialize().c_str();
  }
  int init_timeout = 200;
  llava::Llava_api2_scheduler llava_input(prompt, response.task_id,
                                          response.priority, init_timeout);
  auto future_res = std::async(std::launch::async,
                               std::bind(&llava::LlavaApi2::Inference, llava,
                                         llava_input, custom_ptr, callback));
  auto full_res = future_res.wait_for(std::chrono::seconds(30));
  if (full_res != std::future_status::ready) {
    response.code = InferenceCode::kTimeOut;
    response.msg = "Inference timeout: 30s.";
    LOG(WARNING) << response.msg;
    llava->Delete_task(response.task_id, false);
    return response.Serialize().c_str();
  }
  auto inference_result = future_res.get();
  if (inference_result.error_signal != 0) {
    response.code = inference_result.error_signal;
    response.msg = inference_result.response;
  } else {
    response.content = inference_result.response;
  }
  return response.Serialize().c_str();
#else
  return "Not implemented";
#endif
}
