// Copyright 2022 the project authors. All Rights Reserved.

#ifndef CU_DIALOGUE_SYSTEM_H_
#define CU_DIALOGUE_SYSTEM_H_

#include <string>

#include "cu/nlu_0_6b_offline_inference.h"

extern "C" {

typedef void (*InferenceCallback)(const char *token, void *stream);

typedef void (*StreamingProcessCallback)(const char *content, void *custom_ptr);

bool Initialize(const char *config_file);

// Additive V3-only borrowed provider binding; null hook/config are rejected.
// Host serializes Initialize/ReInitialize/Release against new request admission,
// and retains provider resources through all calls and Release. The existing
// COUNTER/MUTEX do not establish fully race-free request admission.
bool InitializeWithNlu06BInference(const char* config_file,
                                   Nlu06BInferenceHook inference,
                                   void* owner_context);

const char *Process(const char *query);

bool StreamingProcess(const char *query, void *custom_ptr, StreamingProcessCallback callback);

const char *LLMInference(const char *prompt, const char *config, void *custom_ptr, 
                         InferenceCallback callback);

void Release();

}  // extern "C"

#endif  // CU_DIALOGUE_SYSTEM_H_
