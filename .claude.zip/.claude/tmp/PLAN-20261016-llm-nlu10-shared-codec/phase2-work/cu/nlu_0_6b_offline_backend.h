// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_NLU_0_6B_OFFLINE_BACKEND_H_
#define CU_NLU_0_6B_OFFLINE_BACKEND_H_

#include <memory>
#include <string>

#include "cu/nlu_0_6b_backend.h"
#include "cu/nlu_0_6b_offline_inference.h"

namespace nlptk {

// Canonical NluConfig: Model alone selects model/prompt/generation; optional
// Offline accepts max_response_bytes in [1, 16 MiB], default 1 MiB.
// Missing provider fails closed; no mock/network/SDK fallback is installed.
std::unique_ptr<Nlu06BBackend> CreateNlu06BOfflineBackend(
    const Json::Value& config, const std::string& base_path,
    Nlu06BInferenceBinding binding);

}  // namespace nlptk

#endif  // CU_NLU_0_6B_OFFLINE_BACKEND_H_
