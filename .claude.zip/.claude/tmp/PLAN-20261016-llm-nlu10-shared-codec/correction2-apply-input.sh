set -euo pipefail
umask 077
python3 -I - <<'REMOTE_PY'
import os,pathlib,hashlib,subprocess,datetime,shutil,base64,re
root=pathlib.Path('/home/daigd/dialogue')
assert root.resolve()==root and not root.is_symlink()
os.environ['GIT_OPTIONAL_LOCKS']='0';os.environ['GIT_PAGER']='cat'
def git(*a):return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','core.pager=cat','-C',str(root),*a]).strip().decode()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
head='3f086385c81509d40ccb82813758dd1d6d24c0f3';branch='feat/v3-nlu-linux'
assert git('rev-parse','HEAD')==head and git('symbolic-ref','--short','HEAD')==branch
index=root/'.git/index';index_sha=sha(index)
assert index_sha=='5ce26801c99f4784a6913904ce8b1a766fc84d1be0dad7cc00fbfc688e84f179','Index drift; preserve'
target=root/'cu/nlu_0_6b_http_backend_test.cc'
assert target.resolve()==target and target.is_file() and not target.is_symlink()
assert sha(target)=='f13db9ea1fb360e6634883204062338a8538f9c4ed9a93c3eb04a20fff3a862c','Preimage drift; preserve'
attrs=target.stat();assert attrs.st_mode & 0o7777==0o664
parent=pathlib.Path('/home/daigd/.wtp184-transactions');assert parent.resolve()==parent
txn=parent/('PLAN-20261016-llm-nlu10-shared-codec-v1-phase2-correction2-'+datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%S%fZ'))
txn.mkdir(mode=0o700)
print('TRANSACTION='+str(txn),flush=True)
with (txn/'application.log').open('x') as log:
 def emit(s):log.write(s+'\n');log.flush();print(s,flush=True)
 shutil.copy2(str(target),str(txn/'nlu_0_6b_http_backend_test.cc.preimage'))
 assert target.read_bytes()==(txn/'nlu_0_6b_http_backend_test.cc.preimage').read_bytes()
 patch=txn/'phase2-correction2.patch';patch.write_bytes(base64.b64decode('ZGlmZiAtLWdpdCBhL2N1L25sdV8wXzZiX2h0dHBfYmFja2VuZF90ZXN0LmNjIGIvY3Uvbmx1XzBfNmJfaHR0cF9iYWNrZW5kX3Rlc3QuY2MKLS0tIGEvY3Uvbmx1XzBfNmJfaHR0cF9iYWNrZW5kX3Rlc3QuY2MKKysrIGIvY3Uvbmx1XzBfNmJfaHR0cF9iYWNrZW5kX3Rlc3QuY2MKQEAgLTIxNzUsOSArMjE3NSwxOCBAQAogICAgICAgICAgIEVYUEVDVF9FUShmYWtlLT5yZXF1ZXN0Xy5ib2R5LCBwcm92aWRlci5yZXF1ZXN0KTsKICAgICAgICAgICBFWFBFQ1RfRVEoYSwgYik7CiAgICAgICAgICAgRVhQRUNUX1NUUkVRKGh0dHAtPnJlc3VsdF9zb3VyY2UoKSwgb2ZmbGluZS0+cmVzdWx0X3NvdXJjZSgpKTsKLSAgICAgICAgICBpZiAoaXRlbSA8IDJ1IHx8IChnYXRlICYmIGl0ZW0gPCA0dSkpIHsKKyAgICAgICAgICBpZiAoaXRlbSA8IDR1KSB7CiAgICAgICAgICAgICBBU1NFUlRfRVEoMCwgb2ZmbGluZV9jb2RlKTsKLSAgICAgICAgICAgIGlmIChpdGVtID49IDJ1KSB7CisgICAgICAgICAgICBpZiAoaXRlbSA+PSAydSAmJiAhZ2F0ZSkgeworICAgICAgICAgICAgICBBU1NFUlRfVFJVRShiWyJpc19yZWplY3RlZCJdLmlzQm9vbCgpKTsKKyAgICAgICAgICAgICAgRVhQRUNUX1RSVUUoYlsiaXNfcmVqZWN0ZWQiXS5hc0Jvb2woKSk7CisgICAgICAgICAgICAgIEFTU0VSVF9UUlVFKGJbInJlamVjdF9yZWFzb24iXS5pc1N0cmluZygpKTsKKyAgICAgICAgICAgICAgRVhQRUNUX0VRKCJtdWx0aV9pbnRlbnRfZGlzYWJsZWQiLCBiWyJyZWplY3RfcmVhc29uIl0uYXNTdHJpbmcoKSk7CisgICAgICAgICAgICAgIEFTU0VSVF9UUlVFKGJbImlzX211bHRpX2ludGVudCJdLmlzQm9vbCgpKTsKKyAgICAgICAgICAgICAgRVhQRUNUX0ZBTFNFKGJbImlzX211bHRpX2ludGVudCJdLmFzQm9vbCgpKTsKKyAgICAgICAgICAgICAgQVNTRVJUX1RSVUUoYlsiZnJhbWVzIl0uaXNBcnJheSgpKTsKKyAgICAgICAgICAgICAgRVhQRUNUX1RSVUUoYlsiZnJhbWVzIl0uZW1wdHkoKSk7CisgICAgICAgICAgICB9IGVsc2UgaWYgKGl0ZW0gPj0gMnUpIHsKICAgICAgICAgICAgICAgQVNTRVJUX0VRKDN1LCBiWyJmcmFtZXMiXS5zaXplKCkpOwogICAgICAgICAgICAgICBFWFBFQ1RfRVEoIuepuuiwgyIsIGJbImZyYW1lcyJdWzB1XVsic2xvdHMiXVsibmFtZSJdLmFzU3RyaW5nKCkpOwogICAgICAgICAgICAgICBFWFBFQ1RfRVEoIumdoiIsIGJbImZyYW1lcyJdWzF1XVsic2xvdHMiXVsid2luZF9kaXJlY3Rpb24iXS5hc1N0cmluZygpKTsK'))
 emit('Exact current preimage verified; literal-byte backup matched; existing0664/owner/group/rawindex/branch/HEAD frozen')
 for dry in [True,False]:
  cmd=['patch','--batch','--verbose','--fuzz=0','--no-backup-if-mismatch','-p1','-d',str(root),'-i',str(patch)]
  if dry:cmd.insert(1,'--dry-run')
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20)
  out=r.stdout.decode();emit(('DRY_RUN' if dry else 'APPLY')+' exit='+str(r.returncode)+'\n'+out)
  assert r.returncode==0 and not re.search(r'offset|fuzz|FAILED|reject',out,re.I),'Patch failed; preserve, no rollback'
 assert sha(target)=='1a0d8a44a9658bc499184226b35fefbc1d6c19ca6df2a649cbf02c31fb8b1ddb','Postimage mismatch; preserve, no rollback'
 after=target.stat();assert (after.st_mode,after.st_uid,after.st_gid)==(attrs.st_mode,attrs.st_uid,attrs.st_gid)
 assert sha(index)==index_sha and git('rev-parse','HEAD')==head and git('symbolic-ref','--short','HEAD')==branch
 emit('PASS: expected corrected bytes exact; mode0664/owner/group/rawindex/branch/HEAD unchanged; applied one correction hunk only')
 emit('APPLICATION_LOG='+str(txn/'application.log'))
REMOTE_PY
