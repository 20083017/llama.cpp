set -u

name="$EXPECT_NAME"
if [[ -z "$SELECTED_EXPLICIT" ]]; then
latest_file="$REMOTE_DIR/LATEST"
[[ -f "$latest_file" ]] || {
  echo "REMOTE_VERIFY_ERROR=LATEST_MISSING"
  exit 41
}

name="$(head -n 1 "$latest_file" | tr -d '\r\n')"
echo "REMOTE_LATEST=$name"

[[ "$name" == "$EXPECT_NAME" ]] || {
  echo "REMOTE_VERIFY_ERROR=LATEST_MISMATCH"
  exit 42
}
fi

artifact="$REMOTE_DIR/$name"
[[ -f "$artifact" ]] || {
  echo "REMOTE_VERIFY_ERROR=ARTIFACT_MISSING"
  exit 43
}

size="$(stat -c '%s' "$artifact")"
sha="$(sha256sum "$artifact" | awk '{print $1}')"

echo "REMOTE_ARTIFACT=$artifact"
echo "REMOTE_SIZE=$size"
echo "REMOTE_SHA256=$sha"

[[ "$size" == "$EXPECT_SIZE" ]] || {
  echo "REMOTE_VERIFY_ERROR=SIZE_MISMATCH"
  exit 44
}

[[ "$sha" == "$EXPECT_SHA" ]] || {
  echo "REMOTE_VERIFY_ERROR=SHA256_MISMATCH"
  exit 45
}

if [[ -n "$EXPECT_V2" ]]; then
  [[ "$name" == "$EXPECT_V2" && "$name" =~ ^server-v2[.][A-Za-z0-9._-]+$ ]] || { echo "REMOTE_VERIFY_ERROR=V2_NAME_MISMATCH"; exit 46; }
  metadata="$artifact.meta"
  [[ -f "$metadata" ]] || { echo "REMOTE_VERIFY_ERROR=METADATA_MISSING"; exit 46; }
  records=("artifact=$EXPECT_NAME" "sha256=$EXPECT_SHA" "size=$EXPECT_SIZE"
     'bazel_target=//cu:server' "build_profile=$EXPECT_PROFILE" "release_stripped=$EXPECT_STRIPPED")
  for record in "${records[@]}"; do
    key="${record%%=*}"
    [[ "$(grep -c "^$key=" "$metadata")" == 1 ]] && grep -Fqx "$record" "$metadata" || { echo "REMOTE_VERIFY_ERROR=METADATA_MISMATCH field=$key"; exit 46; }
  done
  for key in dialogue_pipeline_variant dialogue_pipeline_define; do
    if grep -q "^$key=" "$metadata"; then
      [[ "$(grep -c "^$key=" "$metadata")" == 1 ]] || { echo "REMOTE_VERIFY_ERROR=METADATA_DUPLICATE field=$key"; exit 46; }
      record="$(sed -n "s/^$key=//p" "$metadata")"
      case "$key:$record" in
        dialogue_pipeline_variant:default|dialogue_pipeline_variant:v2|dialogue_pipeline_define:|dialogue_pipeline_define:dialogue_pipeline_v3=false) ;;
        *) echo "REMOTE_VERIFY_ERROR=METADATA_VARIANT_MISMATCH"; exit 46 ;;
      esac
    fi
  done
fi
echo "REMOTE_SYNC_OK=1"
