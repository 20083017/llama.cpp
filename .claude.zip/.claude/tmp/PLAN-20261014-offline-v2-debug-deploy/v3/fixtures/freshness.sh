#!/usr/bin/env bash
set -euo pipefail
T="$1"; v="$2"; RUN="$T/fixtures/freshness-v$v-${3:-01}"
[[ ! -e "$RUN" ]] || exit 2
export PACKAGE_ROOT="$RUN/local" BUILD_LOG_DIR="$RUN/logs" LOCAL_ARTIFACT_DIR="$RUN/local"
source "$T/fixtures/controller-v$v-definitions.sh"
log() { printf '%s\n' "$*"; }
prepare_gcc_env() { printf 'FORBIDDEN\n' > "$RUN/forbidden-build"; exit 99; }
kinds=(artifact meta artifact-link meta-link)
if [[ "${4:-}" == files-only ]]; then kinds=(artifact meta); fi
for profile in debug release; do
  if [[ "$v" == 2 ]]; then ARTIFACT_PREFIX=server-v2; else ARTIFACT_PREFIX="server-v3-$profile"; fi
  for kind in "${kinds[@]}"; do
    BUILD_REQUESTED_NAME="$ARTIFACT_PREFIX.$profile-$kind"
    target="$LOCAL_ARTIFACT_DIR/$BUILD_REQUESTED_NAME"
    [[ "$kind" != meta && "$kind" != meta-link ]] || target+='.meta'
    if [[ "$kind" == *-link ]]; then
      ln -s -- "$RUN/no-such-target" "$target"
      [[ -L "$target" && ! -e "$target" ]] || { printf 'ISOLATED_LINK_FIXTURE_UNAVAILABLE\n'; exit 3; }
    else printf 'EXISTING-WINNER\n' > "$target"; fi
    set +e; out=$(build_server 2>&1); rc=$?; set -e
    printf 'COMMAND=build_server prebuild-%s-%s V%s\n%s\nEXIT=%s\n' "$profile" "$kind" "$v" "$out" "$rc"
    [[ "$rc" == 1 && "$out" == *'already exists'* && ! -e "$RUN/forbidden-build" ]] || exit 4
    if [[ "$kind" == *-link ]]; then [[ -L "$target" ]] || exit 5
    else [[ "$(cat "$target")" == EXISTING-WINNER ]] || exit 5; fi
    printf 'PASS fresh-output refusal no-product/no-clobber %s %s\n' "$profile" "$kind"
  done
  BUILD_REQUESTED_NAME='../unsafe'
  set +e; out=$(build_server 2>&1); rc=$?; set -e
  printf 'COMMAND=build_server unsafe V%s %s\n%s\nEXIT=%s\n' "$v" "$profile" "$out" "$rc"
  [[ "$rc" == 1 && "$out" == *'variant/profile prefix'* ]] || exit 6
  if [[ "$v" == 3 ]]; then
    BUILD_REQUESTED_NAME="server-v3-$( [[ "$profile" == debug ]] && printf release || printf debug ).wrong-profile"
    set +e; out=$(build_server 2>&1); rc=$?; set -e
    printf 'COMMAND=build_server wrong-profile V3 %s\n%s\nEXIT=%s\n' "$profile" "$out" "$rc"
    [[ "$rc" == 1 && "$out" == *'variant/profile prefix'* ]] || exit 7
  fi
done
printf 'ACCEPTANCE=freshness executed-cases-only files/meta/prebuild PASS V%s EXIT=0\n' "$v"
