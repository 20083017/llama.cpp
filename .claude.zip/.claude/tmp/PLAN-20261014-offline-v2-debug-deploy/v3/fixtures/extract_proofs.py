#!/usr/bin/env python3
import argparse,pathlib
p=argparse.ArgumentParser();p.add_argument('root');a=p.parse_args();root=pathlib.Path(a.root)
for v,n in [(2,'cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh'),(3,'cu-dev-pipeline-v17-dialogue-workspaces_offline.sh')]:
    source=(root/'staged'/n).read_text(encoding='utf-8');start=source.index('sync_artifacts() {');start=source.index("<<'EOS'\n",start)+len("<<'EOS'\n");end=source.index('\nEOS\n',start)
    with (root/'fixtures'/f'remote-sync-proof-v{v}.sh').open('x',encoding='utf-8',newline='\n') as out:out.write(source[start:end]+'\n')
print('PASS extracted actual remote sync proofs EXIT=0')
