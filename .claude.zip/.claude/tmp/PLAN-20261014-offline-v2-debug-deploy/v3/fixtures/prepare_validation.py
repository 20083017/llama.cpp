#!/usr/bin/env python3
import argparse,pathlib
parser=argparse.ArgumentParser();parser.add_argument('root');args=parser.parse_args();root=pathlib.Path(args.root)
def function(data,name):
    a=data.index(name+b'() {');e=data.index(b'\n}\n',a)+3;return data[a:e]
for v,name in [(2,'cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh'),(3,'cu-dev-pipeline-v17-dialogue-workspaces_offline.sh')]:
    old=(root/'acquisition-01'/(name+'.ORIGINAL')).read_bytes();new=(root/'staged'/name).read_bytes()
    # Sourced fixture is definitions/config only, extracted from staged source.
    prefix=new[:new.index(b'CMD="${1:-}"')]
    output=root/'fixtures'/('controller-v'+str(v)+'-definitions.sh')
    with output.open('xb') as f:f.write(prefix)
    for n in [b'prepare_package_profile_libraries',b'validate_package_link_provenance',b'validate_package_runtime_closure',b'select_build_profile',b'run_v'+str(v).encode()+b'_debug_deploy']:
        assert function(old,n)==function(new,n),n
    h='auto_build_offline_v'+str(v)+'.sh'
    oldh=(root/'acquisition-01'/(h+'.ORIGINAL')).read_bytes();newh=(root/'staged'/h).read_bytes()
    assert function(oldh,b'publish_metadata')==function(newh,b'publish_metadata'),'Redis writer changed'
    assert function(oldh,b'inspect_owned_port')==function(newh,b'inspect_owned_port'),'slot safety changed'
    marker=b'if (( publish_only )); then\n  verify_publication_target'
    assert oldh[oldh.index(marker):]==newh[newh.index(marker):],'helper lifecycle/runtime changed'
    print('PASS byte-identical writer, ownership/stop10/rm/runtime tail, build/library policy and debug-deploy flow V'+str(v))
print('EXIT=0 ACCEPTANCE=invariants PASS')
