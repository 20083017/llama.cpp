#!/usr/bin/env bash
set -euo pipefail
T="$1"; v="$2"; profile="$3"; naming="$4"; RUN="$5"
[[ "$RUN" == "$T/fixtures/runs/"* && ! -e "$RUN" ]] || exit 2
mkdir -p "$RUN/project/bazel-bin/cu" "$RUN/project/third_party" "$RUN/remote/server" "$RUN/remote/lib" "$RUN/remote/release_dialogue" "$RUN/state" "$RUN/model dir 稳定性"
export PROJECT_DIR="$RUN/project" THIRD_PARTY_DIR="$RUN/project/third_party" PACKAGE_ROOT="$RUN/local" BUILD_LOG_DIR="$RUN/logs" REMOTE_PACKAGE_ROOT="$RUN/remote"
export LOCAL_ARTIFACT_DIR="$PACKAGE_ROOT/server" V3_ARTIFACT_ROOT="$PACKAGE_ROOT/server-v3"
export V3_PROJECT_DIR="$PROJECT_DIR" V3_THIRD_PARTY_DIR="$THIRD_PARTY_DIR"
export REMOTE_MODEL_DIR="$RUN/model dir 稳定性" REMOTE_AUTO_BUILD='' MOCK_STATE="$RUN/state" MOCK_TRACE="$RUN/trace"
export MOCK_PROJECT='Display 项目 ; $(not-run) & space' MOCK_DESCRIPTION='稳定性 ; $(touch NEVER) "quoted" & | UTF8' MOCK_PORT=9531
export METADATA_PYTHON="$T/fixtures/bin/mock-metadata-python"
export PATH="$T/fixtures/bin:$PATH"
: > "$PROJECT_DIR/WORKSPACE"; printf 'model\n' > "$REMOTE_MODEL_DIR/model"
for f in startup.sh stop.sh del_logs.sh cron_task nlu.data.Dockerfile .dockerignore; do printf 'fixture\n' > "$RUN/remote/release_dialogue/$f"; done
cat "$T/staged/auto_build_offline_v$v.sh" > "$RUN/remote/auto_build_offline_v$v.sh"
source "$T/fixtures/controller-v$v-definitions.sh"
# Mock only compilation/ABI/toolchain and transport/runtime boundaries.
log() { printf '%s
' "$*"; }
prepare_gcc_env() { CC=fixture_cc; CXX=fixture_cc; }
prepare_package_profile_libraries() { PACKAGE_PROFILE_ACTIVE=0; }
validate_third_party() { :; }
check_linux_bazel_config() { :; }
maybe_reset_bazel_toolchain_cache() { :; }
refresh_and_validate_local_config_cc() { :; }
validate_built_abi() { :; }
validate_package_link_provenance() { :; }
validate_package_runtime_closure() { :; }
inspect_built_elf() { :; }
cleanup_package_profile_libraries() { :; }
elf_max_version_requirement() { printf '2.17\n'; }
elf_max_version_provided() { printf '3.4.19\n'; }
elf_max_glibc_requirement() { printf '2.17\n'; }
third_party_revision() { printf 'fixture-third-party\n'; }
fixture_cc() { case "$1" in -dumpversion) printf '4.9.3\n' ;; -dumpmachine) printf 'x86_64-linux-gnu\n' ;; -print-file-name=*) printf '%s\n' "$RUN/library" ;; *) printf 'mock compiler\n' ;; esac; }
git() { case "$*" in *'rev-parse HEAD') printf '0123456789abcdef0123456789abcdef01234567\n' ;; *--abbrev-ref*) printf 'fixture-branch\n' ;; *) printf 'fixture-message\n' ;; esac; }
file() { printf 'ELF mock stripped\n'; }
have() { [[ "$1" != readelf ]] && command -v "$1" >/dev/null 2>&1; }
mock_bazel() {
  printf 'BAZEL_ARG=%s\n' "$@" >> "$MOCK_TRACE"
  [[ " $* " == *' //cu:server '* ]] || return 80
  if [[ "$v" == 3 ]]; then [[ " $* " == *' --define=dialogue_pipeline_v3=true '* ]] || return 81; fi
  if [[ "$profile" == release ]]; then [[ " $* " == *' --compilation_mode=opt '* && " $* " == *' --strip=always '* ]] || return 82
  else [[ " $* " == *' --compilation_mode=dbg '* && " $* " == *' --strip=never '* ]] || return 83; fi
  printf '#!/usr/bin/env bash\n# new mock executable variant=%s profile=%s naming=%s\n' "$v" "$profile" "$naming" > "$BAZEL_OUTPUT"
  chmod +x "$BAZEL_OUTPUT"
}
check_batch_ssh() { :; }
ssh_base_args() { SSH_ARGS=(); }
ssh_batch_args() { SSH_BATCH_ARGS=(); }
rsync_ssh_string() { printf 'mock-ssh\n'; }
ssh() {
  local cmd="${!#}"
  [[ "$cmd" == *"$RUN/remote"* ]] || { printf 'UNSAFE MOCK SSH\n' >&2; return 84; }
  printf 'MOCK_SSH=%s\n' "$cmd" >> "$MOCK_TRACE"
  # Controller-generated commands with paths restricted to this test sandbox.
  command bash -c "$cmd"
}
rsync() {
  local -a args=("$@")
  local a dest="${args[-1]#*:}"
  [[ "$dest" == "$RUN/remote/server/" ]] || return 85
  for a in "${args[@]:0:${#args[@]}-1}"; do
    if [[ "$a" == "$LOCAL_ARTIFACT_DIR/" ]]; then cp -a "$a". "$dest"
    elif [[ "$a" == "$LOCAL_ARTIFACT_DIR/"* && -f "$a" ]]; then cp "$a" "$dest"; fi
  done
}
remote_http_smoke() { printf 'MOCK_HTTP_ONLY SMOKE_OK=1\n'; }
export -f fixture_cc
printf 'mock-library\n' > "$RUN/library"
BAZEL_BIN=mock_bazel; STRIP_BIN="$T/fixtures/bin/mock-strip"
DEPLOY_METADATA=1; DEPLOY_PROJECT_EXPLICIT=1; DEPLOY_PROJECT_NAME="$MOCK_PROJECT"; DEPLOY_DESCRIPTION="$MOCK_DESCRIPTION"; TEST_PORT="$MOCK_PORT"
CMD="${profile}_all"
if [[ "$naming" == explicit ]]; then
  if [[ "$v" == 2 ]]; then SERVER_VERSION=server-v2.fresh-explicit; else SERVER_VERSION="server-v3-$profile.fresh-explicit"; fi
fi
mkdir -p "$LOCAL_ARTIFACT_DIR"
printf 'old sample\n' > "$LOCAL_ARTIFACT_DIR/server-v2.sample-debug"
printf 'old metadata\n' > "$LOCAL_ARTIFACT_DIR/server-v2.sample-debug.meta"
printf 'unrelated-LATEST\n' > "$REMOTE_ARTIFACT_DIR/LATEST"
# Optional publication-race scenarios exercise the real producer's atomic links.
if [[ "${6:-}" == race-artifact || "${6:-}" == race-meta ]]; then
  race="$6"
  ln() {
    local target="${!#}"
    if [[ "$race" == race-artifact && "$target" != *.meta || "$race" == race-meta && "$target" == *.meta ]]; then
      printf 'RACE-WINNER
' > "$target"
    fi
    command ln "$@"
  }
fi
run_profile_all "$profile"
selected=$(selected_deployment_name)
[[ "$selected" == "$SERVER_VERSION" ]] || exit 86
[[ "$(cat "$REMOTE_ARTIFACT_DIR/LATEST")" == unrelated-LATEST ]] || exit 87
[[ "$naming" != explicit || "$selected" == *fresh-explicit ]] || exit 88
[[ "$naming" != auto || "$selected" == "$ARTIFACT_PREFIX."*-01234567 ]] || exit 89
[[ "$(cat "$PACKAGE_ROOT/server/server-v2.sample-debug")" == 'old sample' ]] || exit 90
printf 'unrelated-later-name\n' > "$LOCAL_ARTIFACT_DIR/LATEST"
prepare_selected_deployment
[[ "$(selected_deployment_name)" == "$selected" ]] || exit 91
printf 'PASS V%s %s_all %s actual_producer+sync+helper+runtime_verify+publish; pinned=%s\nEXIT=0\n' "$v" "$profile" "$naming" "$selected"
