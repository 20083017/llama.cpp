import pathlib,sys
root=pathlib.Path(sys.argv[1])
def rep(s,a,b):
    assert s.count(a)==1,(a[:80],s.count(a));return s.replace(a,b)
def fun(s,n,b):
    a=s.index(n+'() {');e=s.index('\n}\n',a)+3;return s[:a]+b.rstrip()+'\n'+s[e:]
for v,filename in [(2,'cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh'),(3,'cu-dev-pipeline-v17-dialogue-workspaces_offline.sh')]:
    p=root/filename;s=p.read_text(encoding='utf-8');V=f'V{v}'
    regex='^server-v2[.][A-Za-z0-9._-]+$' if v==2 else '^server-v3-${DEPLOY_EXPECT_PROFILE}[.][A-Za-z0-9._-]+$'
    extra='' if v==2 else '''
    'dialogue_pipeline_variant=v3' 'dialogue_pipeline_define=dialogue_pipeline_v3=true'
    "latest_pointer=$LOCAL_ARTIFACT_DIR/LATEST" 'package_onnxruntime_selected=0' '''
    optional='''
  # Generic V2 producers omit V3-only fields; any declarations must be unique
  # and compatible. Absence is not runtime activation proof.
  for key in dialogue_pipeline_variant dialogue_pipeline_define; do
    if grep -q "^$key=" "$metadata"; then
      [[ "$(grep -c "^$key=" "$metadata")" == 1 ]] || die "duplicate V2 metadata field: $key"
      record="$(sed -n "s/^$key=//p" "$metadata")"
      case "$key:$record" in
        dialogue_pipeline_variant:default|dialogue_pipeline_variant:v2|dialogue_pipeline_define:|dialogue_pipeline_define:dialogue_pipeline_v3=false) ;;
        *) die "conflicting V2 metadata field: $key" ;;
      esac
    fi
  done''' if v==2 else ''
    n=f'validate_v{v}_debug_deploy_artifact'
    body=r'''@NAME@() {
  local latest_file="$LOCAL_ARTIFACT_DIR/LATEST" latest_name
  [[ -n "$SERVER_VERSION" || -f "$latest_file" ]] || die "@V@ $DEPLOY_EXPECT_PROFILE LATEST missing: $latest_file"
  if [[ -n "$SERVER_VERSION" ]]; then
    latest_name="$SERVER_VERSION"
  else
    latest_name="$(head -n1 "$latest_file" | tr -d '\r\n')"
  fi
  [[ "$latest_name" =~ @REGEX@ ]] || die "selected artifact must match @V@ $DEPLOY_EXPECT_PROFILE executable namespace"
  local artifact="$LOCAL_ARTIFACT_DIR/$latest_name" metadata="$LOCAL_ARTIFACT_DIR/$latest_name.meta"
  [[ -f "$artifact" && -x "$artifact" ]] || die "@V@ artifact missing/not executable: $artifact"
  [[ -f "$metadata" ]] || die "@V@ metadata missing: $metadata"
  local artifact_sha artifact_size record key
  artifact_sha="$(sha256_file "$artifact")"
  artifact_size="$(stat -c '%s' "$artifact")"
  [[ "$artifact_sha" =~ ^[a-f0-9]{64}$ && "$artifact_size" =~ ^[1-9][0-9]*$ ]] || die "@V@ artifact integrity proof invalid"
  local -a records=("artifact=$latest_name" "sha256=$artifact_sha" "size=$artifact_size"
    'bazel_target=//cu:server' "build_profile=$DEPLOY_EXPECT_PROFILE" "release_stripped=$DEPLOY_EXPECT_STRIPPED"@EXTRA@)
  for record in "${records[@]}"; do
    key="${record%%=*}"
    [[ "$(grep -c "^$key=" "$metadata")" == 1 ]] &&
      grep -Fqx "$record" "$metadata" || die "@V@ metadata mismatch: $key"
  done@OPTIONAL@
  @V@_DEPLOY_PINNED_NAME="$latest_name"
  @V@_DEPLOY_PINNED_SHA="$artifact_sha"
  @V@_DEPLOY_PINNED_SIZE="$artifact_size"
  log "@V@_DEPLOY_ARTIFACT=$latest_name"
  log "@V@_DEPLOY_SHA256=$artifact_sha"
  log "@V@_DEPLOY_SIZE=$artifact_size"
  log "@V@_DEPLOY_PROFILE=$DEPLOY_EXPECT_PROFILE release_stripped=$DEPLOY_EXPECT_STRIPPED"
  log "@V@_DEPLOY_LOCAL_DIR=$LOCAL_ARTIFACT_DIR"
  log "@V@_DEPLOY_REMOTE_DIR=$REMOTE_ARTIFACT_DIR"
}'''
    for a,b in [('@NAME@',n),('@V@',V),('@REGEX@',regex),('@EXTRA@',extra),('@OPTIONAL@',optional)]:body=body.replace(a,b)
    s=fun(s,n,body)
    s=rep(s,f'    resolve_v{v}_debug_deploy_action\n    local old_name=',f'    if (( ! BUILD_PIN_OUTPUT )); then resolve_v{v}_debug_deploy_action; fi\n    local old_name=')
    if v==3:s=rep(s,'  (( DEPLOY_METADATA )) || return 0\n  [[ "$DEPLOY_VERIFIED_ID"','  (( DEPLOY_METADATA )) || return 0\n  prepare_selected_deployment\n  selected_deployment_name >/dev/null\n  [[ "$DEPLOY_VERIFIED_ID"')
    s=rep(s,"--expected-size %q'", "--expected-size %q --expected-profile %q'")
    s=rep(s,f'"$DEPLOY_VERIFIED_ID" "${V}_DEPLOY_PINNED_SHA" "${V}_DEPLOY_PINNED_SIZE"',f'"$DEPLOY_VERIFIED_ID" "${V}_DEPLOY_PINNED_SHA" "${V}_DEPLOY_PINNED_SIZE" "$DEPLOY_EXPECT_PROFILE"')
    a=s.index('remote_auto_build_deploy() {');e=s.index('\n}\n',a)+3;block=s[a:e]
    block=rep(block,'  local rc\n  set +e\n  ssh -tt',f'''  if [[ -n "${{{V}_DEPLOY_PINNED_NAME:-}}" ]]; then
    printf -v remote_cmd '%s --expected-profile %q' "$remote_cmd" "$DEPLOY_EXPECT_PROFILE"
  fi
  local rc
  set +e
  ssh -tt''');s=s[:a]+block+s[e:]
    marker=f'EXPECT_{V}=$(printf';pos=s.index(marker)
    s=s[:pos]+s[pos:].replace(marker,'EXPECT_PROFILE=$(printf \'%q\' "$DEPLOY_EXPECT_PROFILE") EXPECT_STRIPPED=$(printf \'%q\' "$DEPLOY_EXPECT_STRIPPED") '+marker,1)
    s=rep(s,"'bazel_target=//cu:server' 'build_profile=debug' 'release_stripped=0'",''' 'bazel_target=//cu:server' "build_profile=$EXPECT_PROFILE" "release_stripped=$EXPECT_STRIPPED"''')
    if v==3:
        s=rep(s,'if [[ -n "$EXPECT_V3" ]]; then\n  metadata=', '''if [[ -n "$EXPECT_V3" ]]; then
  [[ "$name" == "$EXPECT_V3" && "$name" =~ ^server-v3-${EXPECT_PROFILE}[.][A-Za-z0-9._-]+$ ]] || { echo "REMOTE_VERIFY_ERROR=V3_NAME_MISMATCH"; exit 46; }
  metadata=''')
        s=rep(s,'    grep -Fqx "$record" "$metadata" || { echo "REMOTE_VERIFY_ERROR=METADATA_MISMATCH"; exit 46; }','''    key="${record%%=*}"
    [[ "$(grep -c "^$key=" "$metadata")" == 1 ]] && grep -Fqx "$record" "$metadata" || { echo "REMOTE_VERIFY_ERROR=METADATA_MISMATCH field=$key"; exit 46; }''')
    p.write_text(s,encoding='utf-8',newline='\n')
