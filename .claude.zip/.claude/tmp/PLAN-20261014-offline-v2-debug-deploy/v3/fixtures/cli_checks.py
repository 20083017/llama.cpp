#!/usr/bin/env python3
import argparse,os,pathlib,subprocess,sys
sys.stdout.reconfigure(encoding="utf-8")
parser=argparse.ArgumentParser();parser.add_argument('root');parser.add_argument('--bash',required=True);args=parser.parse_args();root=pathlib.Path(args.root)
def posix(p):
    s=p.as_posix();return '/'+s[0].lower()+s[2:] if len(s)>1 and s[1]==':' else s
sandbox=root/'fixtures'/'cli-03';sandbox.mkdir(exist_ok=False)
count=0
def check(script,env,argv,expected,contains):
    global count
    cmd=[args.bash,posix(script)]+argv
    print('COMMAND='+repr(cmd),flush=True)
    result=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=35,text=True,encoding='utf-8',errors='replace')
    print(result.stdout,end='');print('EXIT='+str(result.returncode),flush=True)
    assert (result.returncode==0)==expected,(argv,result.returncode)
    for text in contains:assert text in result.stdout,(argv,text)
    count+=1;print('PASS case='+str(count),flush=True)
for v,name in [(2,'cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh'),(3,'cu-dev-pipeline-v17-dialogue-workspaces_offline.sh')]:
    script=root/'staged'/name
    env=os.environ.copy()
    for k in ['PROJECT_DIR','THIRD_PARTY_DIR','V3_PROJECT_DIR','V3_THIRD_PARTY_DIR','SERVER_VERSION','DEPLOY_PROJECT_NAME','DEPLOY_DESCRIPTION']:env.pop(k,None)
    env.update(PACKAGE_ROOT=posix(sandbox/f'v{v}'),BUILD_LOG_DIR=posix(sandbox/f'v{v}'/'logs'),REMOTE_AUTO_BUILD='')
    for profile in ['debug','release']:
        prefix='server-v2' if v==2 else 'server-v3-'+profile
        fields=['--model-dir','/models/car space 稳定性','--project-name','display ; $(NO) &','--description','稳定性 "literal" ; $(NO) | &','--service-port','9531']
        for naming in ['auto','explicit']:
            version=[] if naming=='auto' else ['--server-version',prefix+'.fresh-cli']
            expected=['DRY_RUN build_profile='+profile,'DRY_RUN server_version='+('GENERATED' if naming=='auto' else prefix+'.fresh-cli'),'DRY_RUN release_stripped='+('1' if profile=='release' else '0'),'DRY_RUN project_dir=/home/daigd/dialogue','DRY_RUN third_party_dir=/home/daigd/dialogue/third_party','DRY_RUN remote_auto_build=/home/daigd/packages/auto_build_offline_v'+str(v)+'.sh','DRY_RUN model_dir=/models/car space 稳定性','DRY_RUN project_name=display ; $(NO) &','DRY_RUN description=稳定性 "literal" ; $(NO) | &','DRY_RUN service_port=9531','pin-produced-name']
            if v==3:expected+=['dialogue_pipeline_variant=v3','--define=dialogue_pipeline_v3=true','selected-v3-no-onnxruntime']
            else:expected+=['dialogue_pipeline_variant=default','libonnxruntime.so.1.14.0']
            check(script,env,[profile+'_all','--dry-run']+fields+version,True,expected)
        for suffix in ['', '.meta']:
            artifact_dir=sandbox/f'v{v}'/('server' if v==2 else 'server-v3/'+profile)
            artifact_dir.mkdir(parents=True,exist_ok=True)
            (artifact_dir/(prefix+'.collision'+suffix)).write_text('existing output',encoding='utf-8')
            check(script,env,[profile+'_all','--dry-run','--server-version',prefix+'.collision'],False,['new build output already exists'])
        check(script,env,[profile+'_all','--dry-run','--server-version','../unsafe'],False,['server version'])
        if v==3:check(script,env,[profile+'_all','--dry-run','--server-version','server-v3-'+('release' if profile=='debug' else 'debug')+'.wrong'],False,['namespace'])
    for option,value in [('--service-port','09530'),('--service-port','65536'),('--service-port','1;NO'),('--model-dir',''),('--project-name',''),('--server-version','')]:
        check(script,env,['debug_all','--dry-run',option,value],False,['[ERROR]'])
    check(script,env,['debug_all','--dry-run','--description','one','--description','two'],False,['duplicate option'])
    check(script,env,['debug_all','--dry-run','--unknown'],False,['unknown option'])
    action='debug_deploy' if v==2 else 'v3_debug_deploy'
    check(script,env,[action,'--dry-run','--server-version',('server-v2' if v==2 else 'server-v3-debug')+'.existing'],True,['build=never'])
    check(script,env,['debug_all','--help'],True,['FRESH NEW','GENERATED','EXISTING debug'])
    # Existing valid explicit source roots remain respected.
    override=env.copy();override['PROJECT_DIR']='/custom/dialogue';override['THIRD_PARTY_DIR']='/custom/deps'
    check(script,override,['debug_all','--dry-run'],True,['project_dir=/custom/dialogue','third_party_dir=/custom/deps','DRY_RUN metadata=0'])
print('ACCEPTANCE=CLI matrix/refusals/help/defaults PASS cases='+str(count)+' EXIT=0')
