#!/usr/bin/env bash
set -euo pipefail
T="$1"; v="$2"; RUN="$T/fixtures/negative-v$v-01"
[[ ! -e "$RUN" ]] || exit 2
mkdir -p "$RUN/local" "$RUN/remote/server" "$RUN/state"
export PACKAGE_ROOT="$RUN/local" BUILD_LOG_DIR="$RUN/logs" LOCAL_ARTIFACT_DIR="$RUN/local" REMOTE_PACKAGE_ROOT="$RUN/remote" REMOTE_ARTIFACT_DIR="$RUN/remote/server"
export MOCK_STATE="$RUN/state" MOCK_TRACE="$RUN/trace" PATH="$T/fixtures/bin:$PATH"
source "$T/fixtures/controller-v$v-definitions.sh"
log() { printf '%s\n' "$*"; }
validate() { if [[ "$v" == 2 ]]; then validate_v2_debug_deploy_artifact; else validate_v3_debug_deploy_artifact; fi; }
profile=debug
if [[ "$v" == 2 ]]; then
  GOOD="$T/fixtures/runs/v2-debug-auto-03/local/server"; name=$(find "$GOOD" -maxdepth 1 -type f -name 'server-v2.2*' ! -name '*.meta' -printf '%f\n')
else
  GOOD="$T/fixtures/runs/v3-debug-auto-01/local/server-v3/debug"; name=$(find "$GOOD" -maxdepth 1 -type f -name 'server-v3-debug.2*' ! -name '*.meta' -printf '%f\n')
fi
[[ -n "$name" && "$name" != *$'\n'* ]] || exit 3
cp "$GOOD/$name" "$LOCAL_ARTIFACT_DIR/$name"
cp "$GOOD/$name.meta" "$RUN/base.meta"
if [[ "$v" == 3 ]]; then sed -i "s|^latest_pointer=.*|latest_pointer=$LOCAL_ARTIFACT_DIR/LATEST|" "$RUN/base.meta"; fi
cp "$RUN/base.meta" "$LOCAL_ARTIFACT_DIR/$name.meta"
cp "$LOCAL_ARTIFACT_DIR/$name" "$REMOTE_ARTIFACT_DIR/$name"
SERVER_VERSION="$name"
export EXPECT_NAME="$name" EXPECT_SHA="$(sha256_file "$LOCAL_ARTIFACT_DIR/$name")" EXPECT_SIZE="$(stat -c '%s' "$LOCAL_ARTIFACT_DIR/$name")" EXPECT_POINTER="$LOCAL_ARTIFACT_DIR/LATEST" EXPECT_PROFILE=debug EXPECT_STRIPPED=0 SELECTED_EXPLICIT="$name" REMOTE_DIR="$REMOTE_ARTIFACT_DIR"
if [[ "$v" == 2 ]]; then export EXPECT_V2="$name"; else export EXPECT_V3="$name"; fi
validate
cp "$RUN/base.meta" "$REMOTE_ARTIFACT_DIR/$name.meta"
bash "$T/fixtures/remote-sync-proof-v$v.sh"
export METADATA_PYTHON="$T/fixtures/bin/mock-metadata-python" MOCK_PROJECT=fixture MOCK_DESCRIPTION=fixture MOCK_PORT=9531
helper() { PACKAGE_ROOT="$RUN/remote" bash "$T/staged/auto_build_offline_v$v.sh" /fixture "$name" 9531 --publish-only --project-name fixture --description fixture --verified-id aaaaaaaaaaaa --expected-sha "$EXPECT_SHA" --expected-size "$EXPECT_SIZE" "$@"; }
count=0
expect_fail() {
  local label="$1" expected="$2" out rc; shift 2
  printf 'COMMAND case=%s' "$label"; printf ' %q' "$@"; printf '\n'
  set +e
  out=$("$@" 2>&1); rc=$?
  set -e
  printf '%s\nEXIT=%s\n' "$out" "$rc"
  [[ "$rc" != 0 && "$out" == *"$expected"* ]] || { printf 'FAIL expected refusal %s\n' "$label"; exit 4; }
  count=$((count+1)); printf 'PASS refusal=%s\n' "$label"
}
for key in artifact sha256 size bazel_target build_profile release_stripped dialogue_pipeline_variant dialogue_pipeline_define; do
  for kind in duplicate conflict; do
    cp "$RUN/base.meta" "$LOCAL_ARTIFACT_DIR/$name.meta"
    if [[ "$kind" == duplicate ]]; then
      if grep -q "^$key=" "$RUN/base.meta"; then grep "^$key=" "$RUN/base.meta" >> "$LOCAL_ARTIFACT_DIR/$name.meta"
      else printf '%s=default\n%s=default\n' "$key" "$key" >> "$LOCAL_ARTIFACT_DIR/$name.meta"; fi
    else
      sed -i "/^$key=/d" "$LOCAL_ARTIFACT_DIR/$name.meta"
      printf '%s=conflicting\n' "$key" >> "$LOCAL_ARTIFACT_DIR/$name.meta"
    fi
    cp "$LOCAL_ARTIFACT_DIR/$name.meta" "$REMOTE_ARTIFACT_DIR/$name.meta"
    expect_fail "local-$key-$kind" "$key" validate
    expect_fail "remote-$key-$kind" METADATA bash "$T/fixtures/remote-sync-proof-v$v.sh"
    expect_fail "helper-$key-$kind" "$key" helper
  done
done
if [[ "$v" == 3 ]]; then
  for key in latest_pointer package_onnxruntime_selected; do
    cp "$RUN/base.meta" "$LOCAL_ARTIFACT_DIR/$name.meta"
    grep "^$key=" "$RUN/base.meta" >> "$LOCAL_ARTIFACT_DIR/$name.meta"
    cp "$LOCAL_ARTIFACT_DIR/$name.meta" "$REMOTE_ARTIFACT_DIR/$name.meta"
    expect_fail "local-$key-duplicate" "$key" validate
    expect_fail "remote-$key-duplicate" "$key" bash "$T/fixtures/remote-sync-proof-v$v.sh"
    expect_fail "helper-$key-duplicate" 'metadata' helper
  done
fi
cp "$RUN/base.meta" "$LOCAL_ARTIFACT_DIR/$name.meta"
cp "$RUN/base.meta" "$REMOTE_ARTIFACT_DIR/$name.meta"
# Changed bytes with truthful updated metadata still cannot replace the pinned tuple.
BUILD_PIN_OUTPUT=1
printf '# drift\n' >> "$LOCAL_ARTIFACT_DIR/$name"
newsha=$(sha256_file "$LOCAL_ARTIFACT_DIR/$name"); newsize=$(stat -c '%s' "$LOCAL_ARTIFACT_DIR/$name")
sed -i "s/^sha256=.*/sha256=$newsha/;s/^size=.*/size=$newsize/" "$LOCAL_ARTIFACT_DIR/$name.meta"
expect_fail tuple-drift 'tuple changed' prepare_selected_deployment
cp "$GOOD/$name" "$LOCAL_ARTIFACT_DIR/$name"; cp "$RUN/base.meta" "$LOCAL_ARTIFACT_DIR/$name.meta"
# Remote transfer drift remains refused without trusting metadata.
printf 'drift\n' >> "$REMOTE_ARTIFACT_DIR/$name"
expect_fail remote-byte-drift SIZE_MISMATCH bash "$T/fixtures/remote-sync-proof-v$v.sh"
cp "$LOCAL_ARTIFACT_DIR/$name" "$REMOTE_ARTIFACT_DIR/$name"
# Legacy publication defaults to debug and refuses release metadata without opt-in.
sed -i 's/^build_profile=debug/build_profile=release/;s/^release_stripped=0/release_stripped=1/' "$REMOTE_ARTIFACT_DIR/$name.meta"
expect_fail helper-default-debug 'build_profile' helper
cp "$RUN/base.meta" "$REMOTE_ARTIFACT_DIR/$name.meta"
# Fresh-output producer refusal precedes all compiler/toolchain work.
BUILD_REQUESTED_NAME="$name"; ARTIFACT_PREFIX="${name%%.*}"
prepare_gcc_env() { printf 'SHOULD-NOT-BUILD\n' > "$RUN/forbidden-build"; exit 99; }
expect_fail prebuild-collision 'already exists' build_server
[[ ! -e "$RUN/forbidden-build" ]] || exit 5
# Existing debug-only deployment never builds or changes Ubuntu LATEST.
BUILD_PIN_OUTPUT=0; BUILD_REQUESTED_NAME=''; DEPLOY_EXPECT_PROFILE=debug; DEPLOY_EXPECT_STRIPPED=0
build_server() { printf 'SHOULD-NOT-BUILD\n' > "$RUN/forbidden-build"; exit 99; }
deploy_pipeline() { prepare_selected_deployment; [[ "$(selected_deployment_name)" == "$name" ]] || exit 6; }
if [[ "$v" == 3 ]]; then
  V3_ARTIFACT_ROOT="$RUN/regression/server-v3"; mkdir -p "$V3_ARTIFACT_ROOT/debug"
  cp "$GOOD/$name" "$V3_ARTIFACT_ROOT/debug/$name"
  cp "$RUN/base.meta" "$V3_ARTIFACT_ROOT/debug/$name.meta"
  sed -i "s|^latest_pointer=.*|latest_pointer=$V3_ARTIFACT_ROOT/debug/LATEST|" "$V3_ARTIFACT_ROOT/debug/$name.meta"
  LOCAL_ARTIFACT_DIR="$V3_ARTIFACT_ROOT/debug"
fi
printf 'unrelated-pointer\n' > "$LOCAL_ARTIFACT_DIR/LATEST"
unset V2_DEPLOY_PINNED_NAME V2_DEPLOY_PINNED_SHA V2_DEPLOY_PINNED_SIZE V3_DEPLOY_PINNED_NAME V3_DEPLOY_PINNED_SHA V3_DEPLOY_PINNED_SIZE
if [[ "$v" == 2 ]]; then resolve_v2_debug_deploy_action; run_v2_debug_deploy; else resolve_v3_debug_deploy_action; run_v3_debug_deploy; fi
[[ ! -e "$RUN/forbidden-build" && "$(cat "$LOCAL_ARTIFACT_DIR/LATEST")" == unrelated-pointer ]] || exit 7
printf 'PASS debug-deploy exact existing/no-build/no-Ubuntu-pointer V%s\n' "$v"
sed -i 's/^build_profile=debug/build_profile=release/;s/^release_stripped=0/release_stripped=1/' "$LOCAL_ARTIFACT_DIR/$name.meta"
expect_fail debug-deploy-release-refusal build_profile validate
printf 'ACCEPTANCE=negative-proof+drift+debug-regression PASS V%s cases=%s EXIT=0\n' "$v" "$count"
