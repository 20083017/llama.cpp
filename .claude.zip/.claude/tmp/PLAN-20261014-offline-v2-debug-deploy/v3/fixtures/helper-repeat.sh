#!/usr/bin/env bash
set -euo pipefail
T="$1"; v="$2"; RUN="$T/fixtures/helper-repeat-v$v-01"
[[ ! -e "$RUN" ]] || exit 2
mkdir -p "$RUN/remote" "$RUN/state"
if [[ "$v" == 2 ]]; then source_dir="$T/fixtures/runs/v2-debug-explicit-01/remote"; name=server-v2.fresh-explicit; profile=debug
else source_dir="$T/fixtures/runs/v3-release-explicit-01/remote"; name=server-v3-release.fresh-explicit; profile=release; fi
cp -r "$source_dir/server" "$source_dir/lib" "$source_dir/release_dialogue" "$RUN/remote/"
mkdir -p "$RUN/model dir 稳定性"; printf 'model\n' > "$RUN/model dir 稳定性/model"
export MOCK_STATE="$RUN/state" MOCK_TRACE="$RUN/trace" PATH="$T/fixtures/bin:$PATH"
export PACKAGE_ROOT="$RUN/remote" METADATA_PYTHON="$T/fixtures/bin/mock-metadata-python" MOCK_PROJECT='display ; UTF8 稳定性' MOCK_DESCRIPTION='opaque ; $(NO) "literal" & |' MOCK_PORT=9531
for repeat in 1 2; do
  printf 'COMMAND=helper V%s same-input deploy repeat=%s\n' "$v" "$repeat"
  bash "$T/staged/auto_build_offline_v$v.sh" "$RUN/model dir 稳定性" "$name" "$MOCK_PORT" --expected-profile "$profile"
  printf 'EXIT=0\n'
  [[ -f "$MOCK_STATE/running" && ! -e "$RUN/remote/release" ]] || exit 3
done
[[ "$(grep -c '^docker run ' "$MOCK_TRACE")" == 2 && "$(grep -c '^docker stop ' "$MOCK_TRACE")" == 1 && "$(grep -c '^docker rm ' "$MOCK_TRACE")" == 1 ]] || exit 4
printf 'ORDER EVIDENCE\n'; grep -E '^docker (build|stop|rm|run) ' "$MOCK_TRACE"
# Verified-runtime metadata failure remains 50, with no automatic runtime rollback.
sha=$(sha256sum "$RUN/remote/server/$name" | awk '{print $1}'); size=$(stat -c '%s' "$RUN/remote/server/$name")
export MOCK_METADATA_FAIL=1
set +e
bash "$T/staged/auto_build_offline_v$v.sh" "$RUN/model dir 稳定性" "$name" "$MOCK_PORT" --publish-only --expected-profile "$profile" --project-name "$MOCK_PROJECT" --description "$MOCK_DESCRIPTION" --verified-id aaaaaaaaaaaa --expected-sha "$sha" --expected-size "$size"
rc=$?
set -e
printf 'EXIT=%s expected_metadata_failure=50\n' "$rc"
[[ "$rc" == 50 && -f "$MOCK_STATE/running" && "$(grep -c '^docker rm ' "$MOCK_TRACE")" == 1 ]] || exit 5
printf 'ACCEPTANCE=repeat/helper-slot-order/metadata-failure50/no-runtime-rollback PASS V%s EXIT=0\n' "$v"
