#!/usr/bin/env python3
"""Approved Phase6 four-file source installation, with no pipeline action."""
import datetime
import os
from pathlib import Path
import runpy
import shlex
import subprocess
import sys

ROOT = Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261014-offline-v2-debug-deploy/v3')
ACQUIRE = runpy.run_path(str(ROOT / 'tools/acquire_sources.py'))
OPTIONS = ACQUIRE['OUTER_OPTIONS']
ALIAS = 'new2_wtp184-server'
PLAN = 'PLAN-20261014-offline-v2-debug-deploy'
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
STAGE = '/home/daigd/.' + PLAN + '-v3-phase6-' + STAMP
VERIFY = ROOT / ('downloaded-installed-phase6-' + STAMP)
NAMES = [Path(p).name for role in ['ubuntu', 'centos'] for p in ACQUIRE['FILES'][role]]
LOG = ROOT / 'logs/phase6-source-install-correction-02.log'
CONTROLLER = ROOT / 'tools/phase6-controller-input.sh'


def posix(path):
    return subprocess.run(['cygpath', '-u', '--', str(path)], timeout=10, check=True,
                          capture_output=True, text=True).stdout.strip()


def main():
    with LOG.open('x', encoding='utf-8') as log:
        os.chmod(LOG, 0o600)

        def record(text):
            log.write(text + '\n'); log.flush(); print(text, flush=True)

        def execute(label, args, input_data=None, bound=90):
            record('ACTION=' + label)
            result = subprocess.run(args, input=input_data, capture_output=True, timeout=bound)
            for data in [result.stdout, result.stderr]:
                text = data.decode('utf-8', errors='replace')
                log.write(text); log.flush()
                if len(text) > 1048576:
                    raise RuntimeError('Output bound exceeded: ' + label)
                if text:
                    print(text, end='' if text.endswith('\n') else '\n', flush=True)
            record(label + '_EXIT=' + str(result.returncode))
            if result.returncode:
                raise RuntimeError(label + ' failed; stop without fallback or source correction')

        def controller(phase):
            seconds = 90 if phase in ['transfer', 'fetch'] else 20
            cmd = 'timeout ' + str(seconds) + 's /bin/bash --noprofile --norc -s -- ' + shlex.quote(phase) + ' ' + STAMP
            execute('CONTROLLER_' + phase.upper(), ['ssh'] + OPTIONS + [ALIAS, cmd],
                    CONTROLLER.read_bytes(), 100 if seconds == 90 else 90)

        try:
            record('PLAN=' + PLAN + ' VERSION=3 PHASE=6 SOURCE_ONLY=yes STAMP=' + STAMP)
            record('LOCAL_EXECUTOR_CORRECTION=log01 retained; native Python selected WSL bash and GBK diagnostic printing failed before any remote connection; same Git Bash executor pinned and stdout UTF-8 enabled; payloads and SSH contract unchanged')
            ACQUIRE['validate_outer']()
            record('OUTER_PINNED_CONTRACT=PASS alias=new2_wtp184-server destination=daigd@10.1.120.40:22 configured_identity_readable=yes trusted_key=yes actual_strict=yes proxy=none forwarding=off tty=off multiplex=off')
            for name in NAMES:
                for directory, suffix in [('staged', ''), ('acquisition-01', '.ORIGINAL')]:
                    path = ROOT / directory / (name + suffix)
                    if path.is_symlink() or not path.is_file() or path.resolve().parent != (ROOT / directory).resolve():
                        raise RuntimeError('Unexpected local input path: ' + str(path))
                    record('LOCAL_INPUT=' + str(path.resolve()) + ' bytes=' + str(path.stat().st_size))
            bash_exe = subprocess.run(['cygpath', '-w', '--', '/usr/bin/bash'], timeout=10, check=True, capture_output=True, text=True).stdout.strip()
            execute('LOCAL_CONTROLLER_BASH_N', [bash_exe, '-n', posix(CONTROLLER)])
            # New task-owned directory only; do not replace earlier verification evidence.
            VERIFY.mkdir(mode=0o700)
            record('LOCAL_VERIFICATION_DIRECTORY=' + str(VERIFY.resolve()))
            controller('prepare')
            uploads = []
            for name in NAMES:
                uploads += [posix(ROOT / 'staged' / name), posix(ROOT / 'acquisition-01' / (name + '.ORIGINAL'))]
            execute('OUTER_SOURCE_UPLOAD', ['scp', '-P', '22'] + OPTIONS + uploads + [ALIAS + ':' + STAGE + '/'], bound=60)
            controller('transfer')
            controller('check')
            controller('backups')
            controller('replace')
            controller('fetch')
            for index, name in enumerate(NAMES):
                remote = '/home/daigd/' + name if index < 2 else STAGE + '/' + name + '.installed-verification'
                dest = VERIFY / name
                execute('OUTER_INSTALLED_DOWNLOAD_' + name, ['scp', '-P', '22'] + OPTIONS + [ALIAS + ':' + remote, posix(dest)], bound=60)
                execute('LOCAL_DOWNLOADED_REVIEWED_CMP_' + name, ['cmp', '-s', '--', posix(dest), posix(ROOT / 'staged' / name)], bound=20)
                record('DOWNLOADED_EXACT_REVIEWED path=' + str(dest.resolve()) + ' bytes=' + str(dest.stat().st_size) + ' cmp_exit=0')
            record('PHASE6_SOURCE_INSTALLATION=PASS controller_exit=0 all_four_exact_bytes=yes backups_verified=yes modes_owners_preserved=yes phase7_started=no runtime_deployment_model_activation=UNRUN')
            return 0
        except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
            record('PHASE6_SOURCE_INSTALLATION=PARTIAL reason=' + str(exc)[:600])
            record('STOP=yes no_auth_variants=yes no_automatic_source_remediation=yes retained_staging=' + STAGE)
            return 1


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    sys.exit(main())
