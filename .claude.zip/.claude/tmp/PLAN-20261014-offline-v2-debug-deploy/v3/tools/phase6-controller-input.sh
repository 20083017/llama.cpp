set -euo pipefail
phase=$1; stamp=$2
[[ $stamp =~ ^[0-9]{8}T[0-9]{6}Z$ ]]
plan=PLAN-20261014-offline-v2-debug-deploy
suffix=${plan}-v3-phase6-${stamp}
us=/home/daigd/.${suffix}
cs=/home/daigd/packages/.${suffix}
opts=(-p 22 -o ConnectTimeout=8 -o ServerAliveInterval=15 -o ServerAliveCountMax=2 -o BatchMode=yes -o StrictHostKeyChecking=yes -o IdentitiesOnly=yes -o PasswordAuthentication=no -o KbdInteractiveAuthentication=no -o GSSAPIAuthentication=no -o ForwardAgent=no -o ForwardX11=no -o ClearAllForwardings=yes -o RequestTTY=no -o ControlMaster=no -o ControlPath=none -o ControlPersist=no)
trap 'rc=$?; printf "SOURCE_CONTROLLER_ERROR phase=%s line=%s exit=%s\n" "$phase" "$LINENO" "$rc" >&2; exit "$rc"' ERR
nested() {
  local quoted result=0
  printf -v quoted '%q' "$1"
  timeout 20s ssh -n "${opts[@]}" daigd@10.1.122.21 "timeout 20s /bin/bash --noprofile --norc -c $quoted" || result=$?
  printf 'NESTED_COMMAND_EXIT=%s phase=%s\n' "$result" "$phase"
  return "$result"
}
regular() { [[ -f $1 && ! -L $1 && $(readlink -f -- "$1") == "$1" ]]; }
staging() { [[ -d $1 && ! -L $1 && $(readlink -f -- "$1") == "$1" && $(stat -c '%a %u' -- "$1") == "700 $(id -u)" ]]; }
proof_cmp() {
  local rc=0
  cmp -s -- "$2" "$3" || rc=$?
  printf '%s path=%s exit=%s\n' "$1" "$2" "$rc"
  return "$rc"
}
proof_syntax() {
  local rc=0
  bash -n -- "$1" || rc=$?
  printf 'BASH_N path=%s exit=%s\n' "$1" "$rc"
  return "$rc"
}
bind_role() {
  role=$1
  if [[ $role == ubuntu ]]; then
    root=/home/daigd; s=$us; uid=1004; mode=664
    names=(cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh cu-dev-pipeline-v17-dialogue-workspaces_offline.sh)
    original_sizes=(130308 128368); reviewed_sizes=(134030 133049)
  else
    [[ $role == centos ]]
    root=/home/daigd/packages; s=$cs; uid=1000; mode=775
    names=(auto_build_offline_v2.sh auto_build_offline_v3.sh)
    original_sizes=(15782 14273); reviewed_sizes=(16760 16395)
  fi
  [[ $(id -un) == daigd && $(id -u) == "$uid" && $(id -g) == "$uid" ]]
  [[ -d $root && ! -L $root && $(readlink -f -- "$root") == "$root" ]]
  staging "$s"
}
check_role() {
  bind_role "$1"
  for i in 0 1; do
    n=${names[$i]}; p=$root/$n; o=$s/$n.ORIGINAL; a=$s/$n
    regular "$p"; regular "$o"; regular "$a"
    [[ $(stat -c '%a %u %g %U:%G %s' -- "$p") == "$mode $uid $uid daigd:daigd ${original_sizes[$i]}" ]]
    [[ $(stat -c %s -- "$o") == "${original_sizes[$i]}" && $(stat -c %s -- "$a") == "${reviewed_sizes[$i]}" ]]
    stat -c 'TARGET_BIND path=%n mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$p"
    proof_cmp CURRENT_FRESH_ORIGINAL_CMP "$p" "$o"
    proof_syntax "$a"
  done
}
backup_role() {
  check_role "$1"
  for i in 0 1; do
    n=${names[$i]}; p=$root/$n; b=$p.$suffix.bak; r=$s/$n.atomic-replacement.tmp
    [[ ! -e $b && ! -L $b && ! -e $r && ! -L $r ]]
    cp -p -- "$p" "$b"
    regular "$b"; proof_cmp BACKUP_FRESH_ORIGINAL_CMP "$b" "$s/$n.ORIGINAL"
    [[ $(stat -c '%a %u %g %U:%G %s' -- "$b") == "$mode $uid $uid daigd:daigd ${original_sizes[$i]}" ]]
    stat -c 'BACKUP path=%n mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$b"
    cp -p -- "$p" "$r"
    cat -- "$s/$n" > "$r"
    regular "$r"; proof_cmp ATOMIC_PREPARED_UPLOADED_CMP "$r" "$s/$n"; proof_syntax "$r"
    [[ $(stat -c '%a %u %g %U:%G' -- "$r") == "$mode $uid $uid daigd:daigd" ]]
    printf 'PREPARED_RECOVERY_PATH=%s\n' "$r"
  done
}
replace_role() {
  check_role "$1"
  for i in 0 1; do
    n=${names[$i]}; p=$root/$n; b=$p.$suffix.bak; r=$s/$n.atomic-replacement.tmp
    regular "$b"; regular "$r"
    proof_cmp BACKUP_RECHECK_CMP "$b" "$s/$n.ORIGINAL"
    proof_cmp ATOMIC_RECHECK_CMP "$r" "$s/$n"
    [[ $(stat -c '%a %u %g %U:%G' -- "$r") == "$mode $uid $uid daigd:daigd" ]]
    proof_cmp IMMEDIATE_CURRENT_BASELINE_CMP "$p" "$s/$n.ORIGINAL"
    mv -T -- "$r" "$p"
    printf 'ATOMIC_REPLACEMENT path=%s exit=0\n' "$p"
    regular "$p"; proof_cmp INSTALLED_UPLOADED_CMP "$p" "$s/$n"; proof_syntax "$p"
    [[ $(stat -c '%a %u %g %U:%G %s' -- "$p") == "$mode $uid $uid daigd:daigd ${reviewed_sizes[$i]}" ]]
    stat -c 'INSTALLED path=%n mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$p"
  done
}
nested_role() {
  local cmd
  cmd="set -euo pipefail; us='$us'; cs='$cs'; suffix='$suffix'; $(declare -f regular staging proof_cmp proof_syntax bind_role check_role backup_role replace_role); $1 centos"
  nested "$cmd"
}
printf 'STEP=%s UTC=%s\n' "$phase" "$(date -u +%FT%TZ)"
case $phase in
prepare)
  [[ -z ${SSH_IDENTITY:-} && $(id -un) == daigd && $(id -u) == 1004 && $(id -g) == 1004 ]]
  config=$(ssh -G "${opts[@]}" daigd@10.1.122.21 | awk '$1 ~ /^(hostname|user|port|identitiesonly|identityfile|stricthostkeychecking|userknownhostsfile|proxycommand|proxyjump)$/ {print}')
  host= user= port= proxy= jump= key= known= identity_count=0
  while IFS=' ' read -r field value; do
    case "$field" in
      hostname) host=$value;; user) user=$value;; port) port=$value;;
      proxycommand) proxy=$value;; proxyjump) jump=$value;;
      identitiesonly) [[ $value == yes ]];;
      stricthostkeychecking) [[ $value == true || $value == yes ]];;
      identityfile) key=$value; identity_count=$((identity_count+1));;
      userknownhostsfile) known=$value;;
    esac
  done <<< "$config"
  [[ $host == 10.1.122.21 && $user == daigd && $port == 22 ]]
  [[ -z $proxy || $proxy == none ]]; [[ -z $jump || $jump == none ]]
  key=${key/#\~/$HOME}; known=${known//\~/$HOME}
  [[ $identity_count == 1 && $key == /home/daigd/.ssh/id_rsa && -r $key ]]
  [[ $known == '/home/daigd/.ssh/known_hosts /home/daigd/.ssh/known_hosts2' || $known == /home/daigd/.ssh/known_hosts ]]
  [[ -r /home/daigd/.ssh/known_hosts ]]
  ssh-keygen -F 10.1.122.21 -f /home/daigd/.ssh/known_hosts >/dev/null
  printf 'NESTED_PINNED_CONTRACT=PASS destination=daigd@10.1.122.21:22 configured_identity_readable=yes trusted_key=yes actual_strict=yes GSSAPIAuthentication=no proxy=none\n'
  [[ -d /home/daigd && ! -L /home/daigd && $(readlink -f /home/daigd) == /home/daigd ]]
  [[ ! -e $us && ! -L $us ]]
  nested "set -euo pipefail; [[ \$(id -un) == daigd && \$(id -u) == 1000 && \$(id -g) == 1000 ]]; [[ -d /home/daigd/packages && ! -L /home/daigd/packages && \$(readlink -f /home/daigd/packages) == /home/daigd/packages ]]; [[ ! -e '$cs' && ! -L '$cs' ]]; mkdir -m 700 -- '$cs'; printf 'CENTOS_STAGING=%s\\n' '$cs'"
  mkdir -m 700 -- "$us"; printf 'UBUNTU_STAGING=%s\n' "$us"
  ;;
transfer)
  staging "$us"
  files=("$us/auto_build_offline_v2.sh.ORIGINAL" "$us/auto_build_offline_v2.sh" "$us/auto_build_offline_v3.sh.ORIGINAL" "$us/auto_build_offline_v3.sh")
  for f in "${files[@]}"; do regular "$f"; done
  timeout 30s scp -P 22 "${opts[@]:2}" "${files[@]}" "daigd@10.1.122.21:$cs/"
  printf 'NESTED_SOURCE_UPLOAD_EXIT=0\n'
  ;;
check)
  check_role ubuntu; nested_role check_role
  printf 'ALL_FOUR_BASELINES_AND_REVIEWED_UPLOAD_SYNTAX=PASS replacements=0\n'
  ;;
backups)
  backup_role ubuntu; nested_role backup_role
  printf 'ALL_FOUR_BACKUPS_VERIFIED_AND_ATOMIC_FILES_PREPARED=PASS replacements=0\n'
  ;;
replace)
  replace_role ubuntu; nested_role replace_role
  printf 'ALL_FOUR_SOURCE_INSTALLATION=PASS\n'
  ;;
fetch)
  staging "$us"
  for n in auto_build_offline_v2.sh auto_build_offline_v3.sh; do
    dest=$us/$n.installed-verification
    [[ ! -e $dest && ! -L $dest ]]
    timeout 30s scp -P 22 "${opts[@]:2}" "daigd@10.1.122.21:/home/daigd/packages/$n" "$dest"
    printf 'NESTED_INSTALLED_FETCH path=%s exit=0\n' "$dest"
    regular "$dest"; proof_cmp FETCHED_INSTALLED_UPLOADED_CMP "$dest" "$us/$n"
  done
  ;;
*) printf 'ERROR=unsupported source-only step\n'; exit 64;;
esac
