#!/usr/bin/env python3
"""Bounded non-mutating WTP184 source acquisition, never executes originals."""
import argparse
import base64
import hashlib
import os
from pathlib import Path
import shlex
import subprocess

OUTER_OPTIONS = ['-o', 'ConnectTimeout=8', '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=2', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'IdentitiesOnly=yes', '-o', 'PasswordAuthentication=no', '-o', 'KbdInteractiveAuthentication=no', '-o', 'ForwardAgent=no', '-o', 'ForwardX11=no', '-o', 'ClearAllForwardings=yes', '-o', 'RequestTTY=no', '-o', 'ControlMaster=no', '-o', 'ControlPath=none', '-o', 'ControlPersist=no']
NESTED_OPTIONS = ['-p', '22'] + OUTER_OPTIONS + ['-o', 'GSSAPIAuthentication=no']
FILES = {
    'ubuntu': ['/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh', '/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh'],
    'centos': ['/home/daigd/packages/auto_build_offline_v2.sh', '/home/daigd/packages/auto_build_offline_v3.sh'],
}


def run(args, **kwargs):
    return subprocess.run(args, timeout=90, check=True, capture_output=True, **kwargs)


def native_configured_path(raw):
    path = os.path.expanduser(raw)
    if os.name == 'nt':
        result = subprocess.run(['cygpath', '-w', '--', path],
                                timeout=10, check=True, capture_output=True, text=True)
        path = result.stdout.strip()
        if not path:
            raise RuntimeError('Configured SSH path conversion returned no path')
    return Path(path)


def validate_outer():
    fields = ['WTP184_SSH_HOST', 'WTP184_SSH_USER', 'WTP184_SSH_KEY', 'WTP184_SSH_KNOWN_HOSTS']
    if any(os.environ.get(field) for field in fields):
        raise RuntimeError('Unexpected explicit SSH contract; stop without alias fallback')
    config = run(['ssh', '-G'] + OUTER_OPTIONS + ['new2_wtp184-server']).stdout.decode()
    needed = {'hostname', 'user', 'port', 'identitiesonly', 'identityfile', 'stricthostkeychecking', 'userknownhostsfile', 'proxycommand', 'proxyjump'}
    effective = {}
    for line in config.splitlines():
        key, _, value = line.partition(' ')
        if key in needed:
            effective.setdefault(key, []).append(value)
    for key, expected in [('hostname', '10.1.120.40'), ('user', 'daigd'), ('port', '22'), ('identitiesonly', 'yes')]:
        if effective.get(key) != [expected]:
            raise RuntimeError('SSH effective destination/identity ambiguity: ' + key)
    if effective.get('stricthostkeychecking') not in [['true'], ['yes']]:
        raise RuntimeError('Actual SSH strict checking is not enforced')
    for key in ['proxycommand', 'proxyjump']:
        if effective.get(key, ['none']) != ['none']:
            raise RuntimeError('Unapproved proxy routing')
    identities = effective.get('identityfile', [])
    if not identities:
        raise RuntimeError('Configured identity unavailable')
    for raw in identities:
        native = native_configured_path(raw)
        if not native.is_file() or not os.access(native, os.R_OK):
            raise RuntimeError('Configured identity unavailable')
    trusted = False
    for entry in effective.get('userknownhostsfile', []):
        for raw in shlex.split(entry):
            path = os.path.expanduser(raw)
            native = native_configured_path(raw)
            if native.is_file() and os.access(native, os.R_OK):
                result = subprocess.run(['ssh-keygen', '-F', '10.1.120.40', '-f', path], capture_output=True, timeout=10)
                trusted = trusted or result.returncode == 0
    if not trusted:
        raise RuntimeError('Trusted Ubuntu host-key entry missing')


def read_command(paths):
    commands = ['set -euo pipefail']
    for path in paths:
        commands.append('p=' + shlex.quote(path))
        commands += [
            '[[ -f "$p" && ! -L "$p" && $(readlink -f -- "$p") == "$p" ]]',
            '[[ $(stat -c %s -- "$p") -le 500000 ]]',
            'before=$(stat -c "%a|%u|%g|%U:%G|%s" -- "$p"); digest=$(sha256sum -- "$p"); digest=${digest%% *}',
            'printf "SOURCE|%s|%s|%s\\n" "$p" "$before" "$digest"',
            'base64 -w 0 -- "$p"; printf "\\nEND\\n"',
            '[[ $(stat -c "%a|%u|%g|%U:%G|%s" -- "$p") == "$before" ]]',
            'after=$(sha256sum -- "$p"); [[ ${after%% *} == "$digest" ]]',
        ]
    return '\n'.join(commands)


NESTED_VALIDATE = '''set -euo pipefail
opts=(__OPTIONS__)
config=$(ssh -G "${opts[@]}" daigd@10.1.122.21 | awk '$1 ~ /^(hostname|user|port|identitiesonly|identityfile|stricthostkeychecking|userknownhostsfile|proxycommand|proxyjump)$/ {print}')
host= user= port= proxy= jump= key= known= identity_count=0
while IFS=' ' read -r field value; do
  case "$field" in
    hostname) host=$value;; user) user=$value;; port) port=$value;;
    proxycommand) proxy=$value;; proxyjump) jump=$value;;
    identitiesonly) [[ "$value" == yes ]];;
    stricthostkeychecking) [[ "$value" == true || "$value" == yes ]];;
    identityfile) key=$value; identity_count=$((identity_count+1));;
    userknownhostsfile) known=$value;;
  esac
done <<< "$config"
[[ "$host" == 10.1.122.21 && "$user" == daigd && "$port" == 22 ]]
[[ -z "$proxy" || "$proxy" == none ]]; [[ -z "$jump" || "$jump" == none ]]
key=${key/#\\~/$HOME}; known=${known//\\~/$HOME}
[[ "$identity_count" == 1 && "$key" == /home/daigd/.ssh/id_rsa && -r "$key" ]]
[[ "$known" == '/home/daigd/.ssh/known_hosts /home/daigd/.ssh/known_hosts2' || "$known" == /home/daigd/.ssh/known_hosts ]]
[[ -r /home/daigd/.ssh/known_hosts ]]
ssh-keygen -F 10.1.122.21 -f /home/daigd/.ssh/known_hosts >/dev/null
printf 'NESTED_PINNED_CONTRACT=PASS destination=daigd@10.1.122.21:22 configured_identity_readable=yes trusted_key=yes actual_strict=yes GSSAPIAuthentication=no proxy=none\\n' >&2
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', choices=FILES, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--log', type=Path, required=True)
    args = parser.parse_args()
    with args.log.open('a', encoding='utf-8') as log:
        def record(text):
            log.write(text + '\n'); log.flush(); print(text)
        try:
            validate_outer()
            record('OUTER_PINNED_CONTRACT=PASS alias=new2_wtp184-server destination=daigd@10.1.120.40:22 configured_identity_readable=yes trusted_key=yes actual_strict=yes proxy=none forwarding=off tty=off multiplex=off')
            command = read_command(FILES[args.role])
            if args.role == 'centos':
                prefix = NESTED_VALIDATE.replace('__OPTIONS__', shlex.join(NESTED_OPTIONS))
                remote = 'timeout 20s /bin/bash --noprofile --norc -c ' + shlex.quote(command)
                command = prefix + '\ntimeout 20s ssh -n "${opts[@]}" daigd@10.1.122.21 ' + shlex.quote(remote)
            result = run(['ssh'] + OUTER_OPTIONS + ['new2_wtp184-server', 'timeout 20s /bin/bash --noprofile --norc -s'], input=command.encode())
            record('SOURCE_COMMAND_EXIT=0 role=' + args.role)
            record(result.stderr.decode(errors='replace').strip())
            lines = result.stdout.decode('ascii').splitlines()
            if len(lines) != 3 * len(FILES[args.role]):
                raise RuntimeError('Unexpected acquisition protocol')
            for index, path in enumerate(FILES[args.role]):
                header, payload, end = lines[index * 3:index * 3 + 3]
                fields = header.split('|')
                if len(fields) != 8 or fields[0:2] != ['SOURCE', path] or end != 'END':
                    raise RuntimeError('Acquisition source binding mismatch')
                data = base64.b64decode(payload, validate=True)
                if len(data) != int(fields[6]) or hashlib.sha256(data).hexdigest() != fields[7]:
                    raise RuntimeError('Source bytes/integrity mismatch')
                dest = args.output_dir / (Path(path).name + '.ORIGINAL')
                with dest.open('xb') as output:
                    output.write(data)
                os.chmod(dest, 0o400)
                record(header)
                record('LOCAL_ORIGINAL=' + str(dest.resolve()) + ' disposition=read-only/nonexecution bytes_verified=yes')
            record('ACQUISITION_STATUS=PASS role=' + args.role)
        except subprocess.CalledProcessError as exc:
            record('SOURCE_COMMAND_EXIT=' + str(exc.returncode) + ' role=' + args.role)
            record(exc.stderr.decode(errors='replace')[:4000])
            raise SystemExit(exc.returncode)
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as exc:
            record('ACQUISITION_STATUS=FAIL role=' + args.role + ' reason=' + str(exc))
            raise SystemExit(1)


if __name__ == '__main__':
    main()
