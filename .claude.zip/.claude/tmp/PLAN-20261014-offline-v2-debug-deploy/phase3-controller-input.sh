set -euo pipefail
phase=$1; stamp=$2
plan=PLAN-20261014-offline-v2-debug-deploy
us=/home/daigd/.${plan}-phase3-${stamp}
cs=/home/daigd/packages/.${plan}-phase3-${stamp}
u=/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh
c=/home/daigd/packages/auto_build_offline_v2.sh
opts=(-p 22 -o ConnectTimeout=8 -o ServerAliveInterval=15 -o ServerAliveCountMax=2 -o BatchMode=yes -o StrictHostKeyChecking=yes -o IdentitiesOnly=yes -o PasswordAuthentication=no -o KbdInteractiveAuthentication=no -o GSSAPIAuthentication=no -o ForwardAgent=no -o ForwardX11=no -o ClearAllForwardings=yes -o RequestTTY=no -o ControlMaster=no -o ControlPath=none -o ControlPersist=no)
nested() {
  local quoted result=0
  printf -v quoted '%q' "$1"
  timeout 20s ssh -n "${opts[@]}" daigd@10.1.122.21 "timeout 20s /bin/bash --noprofile --norc -c $quoted" || result=$?
  printf 'NESTED_COMMAND_EXIT=%s\n' "$result"
  return "$result"
}
printf 'STEP=%s UTC=%s\n' "$phase" "$(date -u +%FT%TZ)"
case "$phase" in
prepare)
  [[ -z "${SSH_IDENTITY:-}" ]]
  config=$(ssh -G "${opts[@]}" daigd@10.1.122.21 | awk '$1 ~ /^(hostname|user|port|identitiesonly|identityfile|stricthostkeychecking|userknownhostsfile|proxycommand|proxyjump)$/ {print}')
  host= user= port= proxy= jump= key= known= identity_count=0
  while IFS=' ' read -r field value; do
    case "$field" in
      hostname) host=$value;; user) user=$value;; port) port=$value;;
      proxycommand) proxy=$value;; proxyjump) jump=$value;;
      identitiesonly) [[ "$value" == yes ]];;
      stricthostkeychecking) [[ "$value" == true || "$value" == yes ]];;
      identityfile) key=$value; identity_count=$((identity_count+1));;
      userknownhostsfile) known=$value;;
    esac
  done <<< "$config"
  [[ "$host" == 10.1.122.21 && "$user" == daigd && "$port" == 22 ]]
  [[ -z "$proxy" || "$proxy" == none ]]; [[ -z "$jump" || "$jump" == none ]]
  key=${key/#\~/$HOME}; known=${known//\~/$HOME}
  [[ "$identity_count" == 1 && "$key" == /home/daigd/.ssh/id_rsa && -r "$key" ]]
  [[ "$known" == '/home/daigd/.ssh/known_hosts /home/daigd/.ssh/known_hosts2' || "$known" == /home/daigd/.ssh/known_hosts ]]
  [[ -r /home/daigd/.ssh/known_hosts ]]
  ssh-keygen -F 10.1.122.21 -f /home/daigd/.ssh/known_hosts >/dev/null
  printf 'NESTED_PINNED_CONTRACT=PASS destination=daigd@10.1.122.21:22 configured_identity_readable=yes trusted_key=yes actual_strict=yes GSSAPIAuthentication=no proxy=none\n'
  [[ $(readlink -f -- /home/daigd) == /home/daigd ]]
  ls -ld -- /home/daigd
  [[ ! -e "$us" && ! -L "$us" ]]
  nested "set -euo pipefail; [[ \$(readlink -f -- /home/daigd/packages) == /home/daigd/packages ]]; ls -ld -- /home/daigd/packages; [[ ! -e '$cs' && ! -L '$cs' ]]; mkdir -m 700 -- '$cs'; printf 'CENTOS_STAGING=%s\\n' '$cs'"
  mkdir -m 700 -- "$us"
  printf 'UBUNTU_STAGING=%s\n' "$us"
  ;;
install)
  [[ -d "$us" && ! -L "$us" && $(readlink -f -- "$us") == "$us" ]]
  timeout 20s scp -P 22 "${opts[@]:2}" "$us/auto_build_offline_v2.sh.ORIGINAL" "$us/auto_build_offline_v2.sh" "daigd@10.1.122.21:$cs/"
  printf 'NESTED_SOURCE_UPLOAD_EXIT=0\n'
  [[ -f "$u" && ! -L "$u" && $(readlink -f -- "$u") == "$u" ]]
  um=$(stat -c '%a %u %g' -- "$u")
  stat -c 'UBUNTU_TARGET_BIND path=%n mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$u"
  result=0; cmp -s -- "$u" "$us/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh.ORIGINAL" || result=$?
  printf 'UBUNTU_CURRENT_ACQUISITION_BASELINE_CMP_EXIT=%s\n' "$result"
  if [[ "$result" != 0 ]]; then
    cp -p -- "$u" "$us/current-drift-preserved.sh"
    printf 'DRIFT_PRESERVED=%s source_replacements=0\n' "$us/current-drift-preserved.sh"
    exit 41
  fi
  bash -n -- "$us/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh"
  printf 'UBUNTU_UPLOADED_REVIEWED_BASH_N_EXIT=0\n'
  read -r -d '' command <<'CENTOS_CHECK' || [[ $? == 1 ]]
set -euo pipefail
c=/home/daigd/packages/auto_build_offline_v2.sh
s=__STAGE__
[[ -f "$c" && ! -L "$c" && $(readlink -f -- "$c") == "$c" ]]
[[ -d "$s" && ! -L "$s" && $(readlink -f -- "$s") == "$s" ]]
stat -c 'CENTOS_TARGET_BIND path=%n mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$c"
stat -c 'CENTOS_BOUND_NUMERIC %a %u %g' -- "$c"
result=0; cmp -s -- "$c" "$s/auto_build_offline_v2.sh.ORIGINAL" || result=$?
printf 'CENTOS_CURRENT_ACQUISITION_BASELINE_CMP_EXIT=%s\n' "$result"
if [[ "$result" != 0 ]]; then
  cp -p -- "$c" "$s/current-drift-preserved.sh"
  printf 'DRIFT_PRESERVED=%s source_replacements=0\n' "$s/current-drift-preserved.sh"
  exit 41
fi
bash -n -- "$s/auto_build_offline_v2.sh"
printf 'CENTOS_UPLOADED_REVIEWED_BASH_N_EXIT=0\n'
CENTOS_CHECK
  command=${command//__STAGE__/$cs}
  result=0; centos_check=$(nested "$command") || result=$?
  printf '%s\n' "$centos_check"
  [[ "$result" == 0 ]] || exit "$result"
  cm=$(awk '$1 == "CENTOS_BOUND_NUMERIC" {print $2 " " $3 " " $4}' <<< "$centos_check")
  [[ "$cm" =~ ^[0-7]{3,4}\ [0-9]+\ [0-9]+$ ]]
  printf 'BOTH_CURRENT_BASELINES_AND_STAGED_SYNTAX=PASS source_replacements=0\n'
  ub=${u}.${plan}-${stamp}.bak
  ur=$us/ubuntu-atomic-replacement.tmp
  [[ ! -e "$ub" && ! -L "$ub" && ! -e "$ur" && ! -L "$ur" ]]
  cp -p -- "$u" "$ub"
  printf 'UBUNTU_EXACT_BACKUP=%s\n' "$ub"
  cmp -s -- "$ub" "$us/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh.ORIGINAL"
  [[ $(stat -c '%a %u %g' -- "$ub") == "$um" ]]
  printf 'UBUNTU_BACKUP_BASELINE_CMP_EXIT=0 MODE_OWNER_PRESERVED=PASS\n'
  cp -p -- "$u" "$ur"
  cat -- "$us/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh" > "$ur"
  [[ $(stat -c '%a %u %g' -- "$ur") == "$um" ]]
  cmp -s -- "$ur" "$us/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh"
  mv -T -- "$ur" "$u"
  printf 'UBUNTU_ATOMIC_REPLACEMENT_EXIT=0\n'
  cmp -s -- "$u" "$us/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh"
  printf 'UBUNTU_INSTALLED_UPLOADED_CMP_EXIT=0\n'
  bash -n -- /home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline_v2.sh
  printf 'UBUNTU_INSTALLED_BASH_N_EXIT=0\n'
  [[ $(stat -c '%a %u %g' -- "$u") == "$um" ]]
  stat -c 'UBUNTU_INSTALLED mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$u"
  printf 'UBUNTU_MODE_OWNER_PRESERVED=PASS\n'
  read -r -d '' command <<'CENTOS_INSTALL' || [[ $? == 1 ]]
set -euo pipefail
c=/home/daigd/packages/auto_build_offline_v2.sh
s=__STAGE__
m='__METADATA__'
b=${c}.PLAN-20261014-offline-v2-debug-deploy-__STAMP__.bak
r=$s/centos-atomic-replacement.tmp
[[ -f "$c" && ! -L "$c" && $(readlink -f -- "$c") == "$c" ]]
[[ -d "$s" && ! -L "$s" && $(readlink -f -- "$s") == "$s" ]]
[[ ! -e "$b" && ! -L "$b" && ! -e "$r" && ! -L "$r" ]]
cp -p -- "$c" "$b"
printf 'CENTOS_EXACT_BACKUP=%s\n' "$b"
cmp -s -- "$b" "$s/auto_build_offline_v2.sh.ORIGINAL"
[[ $(stat -c '%a %u %g' -- "$b") == "$m" ]]
printf 'CENTOS_BACKUP_BASELINE_CMP_EXIT=0 MODE_OWNER_PRESERVED=PASS\n'
cp -p -- "$c" "$r"
cat -- "$s/auto_build_offline_v2.sh" > "$r"
[[ $(stat -c '%a %u %g' -- "$r") == "$m" ]]
cmp -s -- "$r" "$s/auto_build_offline_v2.sh"
mv -T -- "$r" "$c"
printf 'CENTOS_ATOMIC_REPLACEMENT_EXIT=0\n'
cmp -s -- "$c" "$s/auto_build_offline_v2.sh"
printf 'CENTOS_INSTALLED_UPLOADED_CMP_EXIT=0\n'
bash -n -- /home/daigd/packages/auto_build_offline_v2.sh
printf 'CENTOS_INSTALLED_BASH_N_EXIT=0\n'
[[ $(stat -c '%a %u %g' -- "$c") == "$m" ]]
stat -c 'CENTOS_INSTALLED mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$c"
printf 'CENTOS_MODE_OWNER_PRESERVED=PASS\n'
CENTOS_INSTALL
  command=${command//__STAGE__/$cs}; command=${command//__STAMP__/$stamp}; command=${command//__METADATA__/$cm}
  nested "$command"
  ;;
fetch)
  timeout 20s scp -P 22 "${opts[@]:2}" "daigd@10.1.122.21:$c" "$us/centos-installed-verification.sh"
  printf 'NESTED_INSTALLED_SOURCE_FETCH_EXIT=0\n'
  ;;
*) printf 'ERROR=unsupported source installation step\n'; exit 64;;
esac
