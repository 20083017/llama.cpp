set -euo pipefail
phase=$1
stamp=$2
plan=PLAN-20261013-pipeline-deployment-fields
u=/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh
c=/home/daigd/packages/auto_build_offline_v3.sh
us=/home/daigd/.${plan}-phase3-${stamp}
cs=/home/daigd/packages/.${plan}-phase3-${stamp}
opts=(-p 22 -o ConnectTimeout=8 -o ServerAliveInterval=15 -o ServerAliveCountMax=2 -o BatchMode=yes -o StrictHostKeyChecking=yes -o IdentitiesOnly=yes -o PasswordAuthentication=no -o KbdInteractiveAuthentication=no -o GSSAPIAuthentication=no -o ForwardAgent=no -o ForwardX11=no -o ClearAllForwardings=yes -o RequestTTY=no -o ControlMaster=no -o ControlPath=none -o ControlPersist=no)
nested() {
  local quoted cmd result=0
  printf -v quoted '%q' "$1"
  cmd="timeout 20s /bin/bash --noprofile --norc -c $quoted"
  timeout 20s ssh -n "${opts[@]}" daigd@10.1.122.21 "$cmd" || result=$?
  printf 'NESTED_COMMAND_EXIT=%s\n' "$result"
  return "$result"
}
printf 'PHASE3_STEP=%s UTC=%s\n' "$phase" "$(date -u +%FT%TZ)"
case "$phase" in
prepare)
  [[ $(readlink -f -- /home/daigd) == /home/daigd ]]
  ls -ld -- /home/daigd
  [[ ! -e "$us" && ! -L "$us" ]]
  host= user= port= proxy= jump= key= known= identity_count=0
  while IFS=' ' read -r field value; do
    case "$field" in
      hostname) host=$value;; user) user=$value;; port) port=$value;;
      proxycommand) proxy=$value;; proxyjump) jump=$value;;
      identityfile) key=$value; identity_count=$((identity_count+1));;
      userknownhostsfile) known=$value;;
    esac
  done < <(ssh -G "${opts[@]}" daigd@10.1.122.21 2>/dev/null)
  [[ "$host" == 10.1.122.21 && "$user" == daigd && "$port" == 22 ]]
  [[ -z "$proxy" || "$proxy" == none ]]
  [[ -z "$jump" || "$jump" == none ]]
  key=${key/#\~/$HOME}
  known=${known//\~/$HOME}
  [[ "$identity_count" == 1 && "$key" == /home/daigd/.ssh/id_rsa && -r "$key" ]]
  [[ "$known" == '/home/daigd/.ssh/known_hosts /home/daigd/.ssh/known_hosts2' || "$known" == /home/daigd/.ssh/known_hosts ]]
  ssh-keygen -F 10.1.122.21 -f /home/daigd/.ssh/known_hosts >/dev/null
  printf 'NESTED_PINNED_CONTRACT=PASS host=10.1.122.21 user=daigd port=22 configured_key_readable=yes trusted_entry=yes proxy=none\n'
  nested "set -euo pipefail; [[ \$(readlink -f -- /home/daigd/packages) == /home/daigd/packages ]]; ls -ld -- /home/daigd/packages; [[ ! -e '$cs' && ! -L '$cs' ]]; mkdir -m 700 -- '$cs'; printf 'CENTOS_STAGING=%s\\n' '$cs'"
  mkdir -m 700 -- "$us"
  printf 'UBUNTU_STAGING=%s\n' "$us"
  ;;
bind)
  [[ -d "$us" && ! -L "$us" && $(readlink -f -- "$us") == "$us" ]]
  scp_opts=(-P 22 "${opts[@]:2}")
  result=0
  timeout 20s scp "${scp_opts[@]}" "$us/auto_build_offline_v3.sh" "$us/centos-auto_build_offline_v3.original-read-only.sh" "daigd@10.1.122.21:$cs/" || result=$?
  printf 'NESTED_SCP_EXIT=%s\n' "$result"
  [[ "$result" == 0 ]]
  [[ -f "$u" && ! -L "$u" && $(readlink -f -- "$u") == "$u" ]]
  stat -c 'UBUNTU_TARGET_BIND path=%n mode=%a owner=%U:%G uidgid=%u:%g' -- "$u"
  stat -c '%a %u %g %d %i' -- "$u" > "$us/ubuntu-bound-stat.txt"
  result=0
  cmp -s -- "$u" "$us/ubuntu-cu-dev-pipeline-v17-dialogue-workspaces_offline.original-read-only.sh" || result=$?
  printf 'UBUNTU_BASELINE_CMP_EXIT=%s\n' "$result"
  if [[ "$result" != 0 ]]; then
    cp -p -- "$u" "$us/ubuntu-current-mismatch.sh"
    printf 'DRIFT_PRESERVED=%s\n' "$us/ubuntu-current-mismatch.sh"
    exit 41
  fi
  bash -n -- "$us/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh"
  printf 'UBUNTU_STAGED_BASH_N_EXIT=0\n'
  read -r -d '' probe <<'PROBE' || [[ $? == 1 ]]
set -euo pipefail
c=__C__
cs=__CS__
[[ -f "$c" && ! -L "$c" && $(readlink -f -- "$c") == "$c" ]]
[[ -d "$cs" && ! -L "$cs" && $(readlink -f -- "$cs") == "$cs" ]]
stat -c 'CENTOS_TARGET_BIND path=%n mode=%a owner=%U:%G uidgid=%u:%g' -- "$c"
stat -c '%a %u %g %d %i' -- "$c" > "$cs/centos-bound-stat.txt"
result=0
cmp -s -- "$c" "$cs/centos-auto_build_offline_v3.original-read-only.sh" || result=$?
printf 'CENTOS_BASELINE_CMP_EXIT=%s\n' "$result"
if [[ "$result" != 0 ]]; then
  cp -p -- "$c" "$cs/centos-current-mismatch.sh"
  printf 'DRIFT_PRESERVED=%s\n' "$cs/centos-current-mismatch.sh"
  exit 41
fi
bash -n -- "$cs/auto_build_offline_v3.sh"
printf 'CENTOS_STAGED_BASH_N_EXIT=0\n'
PROBE
  probe=${probe//__C__/$c}; probe=${probe//__CS__/$cs}
  nested "$probe"
  printf 'BOTH_BASELINES_AND_STAGED_SYNTAX=PASS source_replacements=0\n'
  ;;
install-centos|install-ubuntu)
  read -r -d '' install <<'INSTALL' || [[ $? == 1 ]]
set -euo pipefail
target=__TARGET__
stage=__STAGE__
name=__NAME__
role=__ROLE__
backup=${target}.__PLAN__-__STAMP__.bak
replacement=${target}.__PLAN__-__STAMP__.install-tmp
[[ -f "$target" && ! -L "$target" && $(readlink -f -- "$target") == "$target" ]]
[[ -d "$stage" && ! -L "$stage" && $(readlink -f -- "$stage") == "$stage" ]]
[[ $(stat -c '%a %u %g %d %i' -- "$target") == "$(cat "$stage/${role}-bound-stat.txt")" ]]
[[ ! -e "$backup" && ! -L "$backup" && ! -e "$replacement" && ! -L "$replacement" ]]
cp -p -- "$target" "$backup"
printf '%s_BACKUP=%s\n' "$role" "$backup"
stat -c 'BACKUP_METADATA path=%n mode=%a owner=%U:%G uidgid=%u:%g' -- "$backup"
cmp -s -- "$backup" "$stage/${role}-__BASELINE__"
printf '%s_BACKUP_CMP_EXIT=0\n' "$role"
cp -p -- "$target" "$replacement"
cat -- "$stage/$name" > "$replacement"
[[ $(stat -c '%a %u %g' -- "$replacement") == "$(stat -c '%a %u %g' -- "$backup")" ]]
cmp -s -- "$replacement" "$stage/$name"
printf '%s_REPLACEMENT_CMP_EXIT=0\n' "$role"
bash -n -- "$replacement"
printf '%s_REPLACEMENT_BASH_N_EXIT=0\n' "$role"
mv -T -- "$replacement" "$target"
printf '%s_ATOMIC_REPLACEMENT_EXIT=0\n' "$role"
cmp -s -- "$target" "$stage/$name"
printf '%s_INSTALLED_CMP_EXIT=0\n' "$role"
bash -n -- "$target"
printf '%s_INSTALLED_BASH_N_EXIT=0\n' "$role"
[[ $(stat -c '%a %u %g' -- "$target") == "$(stat -c '%a %u %g' -- "$backup")" ]]
printf '%s_MODE_OWNER_PRESERVED=PASS\n' "$role"
stat -c 'INSTALLED_METADATA path=%n mode=%a owner=%U:%G uidgid=%u:%g' -- "$target"
INSTALL
  if [[ "$phase" == install-centos ]]; then
    install=${install//__TARGET__/$c}; install=${install//__STAGE__/$cs}; install=${install//__NAME__/auto_build_offline_v3.sh}; install=${install//__ROLE__/centos}; install=${install//__BASELINE__/auto_build_offline_v3.original-read-only.sh}
  else
    install=${install//__TARGET__/$u}; install=${install//__STAGE__/$us}; install=${install//__NAME__/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh}; install=${install//__ROLE__/ubuntu}; install=${install//__BASELINE__/cu-dev-pipeline-v17-dialogue-workspaces_offline.original-read-only.sh}
  fi
  install=${install//__PLAN__/$plan}; install=${install//__STAMP__/$stamp}
  if [[ "$phase" == install-centos ]]; then nested "$install"; else /bin/bash --noprofile --norc -c "$install"; fi
  ;;
fetch-centos)
  scp_opts=(-P 22 "${opts[@]:2}")
  result=0
  timeout 20s scp "${scp_opts[@]}" "daigd@10.1.122.21:$c" "$us/centos-installed-verification.sh" || result=$?
  printf 'NESTED_FETCH_INSTALLED_EXIT=%s\n' "$result"
  exit "$result"
  ;;
*) printf 'ERROR=unsupported controller phase\n'; exit 64;;
esac
