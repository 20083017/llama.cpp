set -euo pipefail
phase=$1
stamp=$2
us=/home/daigd/.PLAN-20261013-pipeline-deployment-fields-v5-phase3-${stamp}
cs=/home/daigd/packages/.PLAN-20261013-pipeline-deployment-fields-v5-phase3-${stamp}
t=/home/daigd/packages/auto_build_offline_v3.sh
opts=(-p 22 -o ConnectTimeout=8 -o ServerAliveInterval=15 -o ServerAliveCountMax=2 -o BatchMode=yes -o StrictHostKeyChecking=yes -o IdentitiesOnly=yes -o PasswordAuthentication=no -o KbdInteractiveAuthentication=no -o GSSAPIAuthentication=no -o ForwardAgent=no -o ForwardX11=no -o ClearAllForwardings=yes -o RequestTTY=no -o ControlMaster=no -o ControlPath=none -o ControlPersist=no)
nested() {
  local quoted result=0
  printf -v quoted '%q' "$1"
  timeout 20s ssh -n "${opts[@]}" daigd@10.1.122.21 "timeout 20s /bin/bash --noprofile --norc -c $quoted" || result=$?
  printf 'NESTED_COMMAND_EXIT=%s\n' "$result"
  return "$result"
}
printf 'STEP=%s UTC=%s\n' "$phase" "$(date -u +%FT%TZ)"
case "$phase" in
prepare)
  [[ -z "${SSH_IDENTITY:-}" ]]
  config=$(ssh -G "${opts[@]}" daigd@10.1.122.21)
  host= user= port= proxy= jump= key= known= identity_count=0
  while IFS=' ' read -r field value; do
    case "$field" in
      hostname) host=$value;; user) user=$value;; port) port=$value;;
      proxycommand) proxy=$value;; proxyjump) jump=$value;;
      identitiesonly) [[ "$value" == yes ]];;
      stricthostkeychecking) [[ "$value" == true || "$value" == yes ]];;
      identityfile) key=$value; identity_count=$((identity_count+1));;
      userknownhostsfile) known=$value;;
    esac
  done <<< "$config"
  [[ "$host" == 10.1.122.21 && "$user" == daigd && "$port" == 22 ]]
  [[ -z "$proxy" || "$proxy" == none ]]; [[ -z "$jump" || "$jump" == none ]]
  key=${key/#\~/$HOME}; known=${known//\~/$HOME}
  [[ "$identity_count" == 1 && "$key" == /home/daigd/.ssh/id_rsa && -r "$key" ]]
  [[ "$known" == '/home/daigd/.ssh/known_hosts /home/daigd/.ssh/known_hosts2' || "$known" == /home/daigd/.ssh/known_hosts ]]
  [[ -r /home/daigd/.ssh/known_hosts ]]
  ssh-keygen -F 10.1.122.21 -f /home/daigd/.ssh/known_hosts >/dev/null
  printf 'NESTED_PINNED_CONTRACT=PASS destination=daigd@10.1.122.21:22 same_configured_identity_readable=yes trusted_key=yes actual_strict=yes GSSAPIAuthentication=no proxy=none\n'
  [[ $(readlink -f -- /home/daigd) == /home/daigd ]]
  ls -ld -- /home/daigd
  [[ ! -e "$us" && ! -L "$us" ]]
  nested "set -euo pipefail; [[ \$(readlink -f -- /home/daigd/packages) == /home/daigd/packages ]]; ls -ld -- /home/daigd/packages; [[ ! -e '$cs' && ! -L '$cs' ]]; mkdir -m 700 -- '$cs'; printf 'CENTOS_STAGING=%s\\n' '$cs'"
  mkdir -m 700 -- "$us"
  printf 'UBUNTU_STAGING=%s\n' "$us"
  ;;
install)
  [[ -d "$us" && ! -L "$us" && $(readlink -f -- "$us") == "$us" ]]
  timeout 20s scp -P 22 "${opts[@]:2}" "$us/installed-v4-baseline.sh" "$us/auto_build_offline_v3.sh" "daigd@10.1.122.21:$cs/"
  printf 'NESTED_UPLOAD_EXIT=0\n'
  read -r -d '' command <<'CENTOS' || [[ $? == 1 ]]
set -euo pipefail
t=/home/daigd/packages/auto_build_offline_v3.sh
s=__STAGE__
b=${t}.PLAN-20261013-pipeline-deployment-fields-v5-__STAMP__.bak
r=${t}.PLAN-20261013-pipeline-deployment-fields-v5-__STAMP__.install-tmp
[[ -f "$t" && ! -L "$t" && $(readlink -f -- "$t") == "$t" ]]
[[ -d "$s" && ! -L "$s" && $(readlink -f -- "$s") == "$s" ]]
metadata=$(stat -c '%a %u %g' -- "$t")
stat -c 'CENTOS_TARGET_BIND path=%n mode=%a owner=%U:%G uidgid=%u:%g' -- "$t"
result=0
cmp -s -- "$t" "$s/installed-v4-baseline.sh" || result=$?
printf 'CURRENT_V4_BASELINE_CMP_EXIT=%s\n' "$result"
if [[ "$result" != 0 ]]; then
  cp -p -- "$t" "$s/current-drift-preserved.sh"
  printf 'DRIFT_PRESERVED=%s source_replacements=0\n' "$s/current-drift-preserved.sh"
  exit 41
fi
[[ ! -e "$b" && ! -L "$b" && ! -e "$r" && ! -L "$r" ]]
bash -n -- "$s/installed-v4-baseline.sh"
printf 'UPLOADED_V4_BASELINE_BASH_N_EXIT=0\n'
bash -n -- "$s/auto_build_offline_v3.sh"
printf 'UPLOADED_V5_BASH_N_EXIT=0\n'
cp -p -- "$t" "$b"
printf 'EXACT_V5_BACKUP=%s\n' "$b"
cmp -s -- "$b" "$s/installed-v4-baseline.sh"
printf 'BACKUP_V4_CMP_EXIT=0\n'
bash -n -- "$b"
printf 'BACKUP_BASH_N_EXIT=0\n'
[[ $(stat -c '%a %u %g' -- "$b") == "$metadata" ]]
cp -p -- "$t" "$r"
cat -- "$s/auto_build_offline_v3.sh" > "$r"
[[ $(stat -c '%a %u %g' -- "$r") == "$metadata" ]]
cmp -s -- "$r" "$s/auto_build_offline_v3.sh"
printf 'REPLACEMENT_REVIEWED_STAGED_CMP_EXIT=0\n'
bash -n -- "$r"
printf 'REPLACEMENT_BASH_N_EXIT=0\n'
mv -T -- "$r" "$t"
printf 'ATOMIC_REPLACEMENT_EXIT=0\n'
cmp -s -- "$t" "$s/auto_build_offline_v3.sh"
printf 'INSTALLED_UPLOADED_V5_CMP_EXIT=0\n'
bash -n -- /home/daigd/packages/auto_build_offline_v3.sh
printf 'INSTALLED_BASH_N_EXIT=0\n'
[[ $(stat -c '%a %u %g' -- "$t") == "$metadata" ]]
printf 'MODE_OWNER_PRESERVED=PASS\n'
stat -c 'INSTALLED_METADATA path=%n mode=%a owner=%U:%G uidgid=%u:%g bytes=%s' -- "$t"
CENTOS
  command=${command//__STAGE__/$cs}; command=${command//__STAMP__/$stamp}
  nested "$command"
  ;;
fetch)
  timeout 20s scp -P 22 "${opts[@]:2}" "daigd@10.1.122.21:$t" "$us/centos-installed-verification.sh"
  printf 'NESTED_INSTALLED_FETCH_EXIT=0\n'
  ;;
*) printf 'ERROR=unsupported source installation step\n'; exit 64;;
esac
