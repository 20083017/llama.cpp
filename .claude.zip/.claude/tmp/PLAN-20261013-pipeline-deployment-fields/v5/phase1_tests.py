#!/usr/bin/env python3
"""Focused v5 fixtures. All Docker/build/Redis boundaries are mocked."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import unittest
BASE = Path(__file__).resolve().parent
HELPER = BASE/'auto_build_offline_v3.sh'
V4 = BASE.parent/'staged-editable/auto_build_offline_v3.sh'
CONTROLLER = BASE.parent/'staged-editable/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh'
HS = HELPER.read_text(encoding='utf-8')
CODE = HS.split("<<'METADATA_PY'\n", 1)[1].split('\nMETADATA_PY', 1)[0]
NAME = 'server-v3-debug.synthetic-v5'
OLD, NEW, OTHER = 'a'*64, 'b'*64, 'c'*64
PORT = '9529'
def posix(path):
    text = str(path).replace('\\', '/')
    return '/'+text[0].lower()+text[2:] if len(text)>2 and text[1]==':' else text
MOCK = r'''
rewrite_row() {
 local action="$1" wanted="$2" row cid state slot pipeline rest
 : > "$MOCK_ROWS.next"
 while IFS= read -r row; do
  IFS='|' read -r cid state slot pipeline rest <<< "$row"
  if [[ "$cid" == "$wanted" ]]; then
   [[ "$action" != remove ]] || continue
   row="$cid|false|$slot|$pipeline|$rest"
  fi
  printf '%s\n' "$row" >> "$MOCK_ROWS.next"
 done < "$MOCK_ROWS"
 command mv -- "$MOCK_ROWS.next" "$MOCK_ROWS"
}
docker() {
 local cmd="$1" cid row count=0 state slot pipeline rest; shift
 case "$cmd" in
 ps)
  [[ "$*" == '-q --no-trunc' ]] || return 96
  printf 'ps running\n' >> "$MOCK_TRACE"
  while IFS='|' read -r cid state slot pipeline rest; do
   [[ -z "$cid" || "$state" != true ]] || printf '%s\n' "$cid"
  done < "$MOCK_ROWS" ;;
 inspect)
  [[ "$1" == --format && "$2" == *'.NetworkSettings.Ports'* && "$2" != *'.HostConfig.'* ]] || return 96
  cid="${@: -1}"
  [[ "$cid" =~ ^[a-f0-9]{64}$ ]] || return 96
  [[ ! -f "$MOCK_COUNT" ]] || read -r count < "$MOCK_COUNT"
  count=$((count+1)); printf '%s\n' "$count" > "$MOCK_COUNT"
  printf 'inspect %s\n' "$cid" >> "$MOCK_TRACE"
  if [[ "${MOCK_RACE_AT:-0}" == "$count" ]]; then printf '%s\n' "$MOCK_RACE_ROW" > "$MOCK_ROWS"; fi
  while IFS= read -r row; do
   if [[ "${row%%|*}" == "$cid" ]]; then printf '%s\n' "$row"; return 0; fi
  done < "$MOCK_ROWS"
  return 1 ;;
 build)
  printf 'build\n' >> "$MOCK_TRACE"
  [[ "${MOCK_FAIL:-}" != build ]] || return 21
  if [[ -n "${MOCK_AFTER_BUILD:-}" ]]; then printf '%s\n' "$MOCK_AFTER_BUILD" > "$MOCK_ROWS"; fi ;;
 stop)
  printf 'stop %s\n' "$*" >> "$MOCK_TRACE"
  [[ "$*" == "--time 10 -- $MOCK_EXPECT_OLD" ]] || return 96
  [[ "${MOCK_FAIL:-}" != stop ]] || return 22
  rewrite_row stop "$MOCK_EXPECT_OLD" ;;
 rm)
  printf 'rm %s\n' "$*" >> "$MOCK_TRACE"
  [[ "$*" == "-- $MOCK_EXPECT_OLD" ]] || return 96
  [[ "${MOCK_FAIL:-}" != rm ]] || return 23
  while IFS='|' read -r cid state rest; do
   [[ "$cid" != "$MOCK_EXPECT_OLD" || "$state" == false ]] || return 96
  done < "$MOCK_ROWS"
  rewrite_row remove "$MOCK_EXPECT_OLD" ;;
 run)
  printf 'run\n' >> "$MOCK_TRACE"
  [[ " $* " == *" --label cu.dev.slot=9529 "* && " $* " == *" --label cu.dev.pipeline=v3 "* && " $* " == *" -p 9529:8080 "* ]] || return 96
  [[ "${MOCK_FAIL:-}" != run ]] || return 24
  printf '%s|true|9529|v3|8080/tcp:0.0.0.0:9529|8080/tcp::::9529\n' "$MOCK_NEW" >> "$MOCK_ROWS"
  printf '%s\n' "$MOCK_NEW" ;;
 exec)
  printf 'exec %s\n' "$*" >> "$MOCK_TRACE"
  [[ "$1" == "$MOCK_NEW" || "$1" == "$MOCK_EXPECT_OLD" ]] || return 96
  shift
  case "$*" in
   'sha256sum /usr/bin/cu-server') printf '%s  /usr/bin/cu-server\n' "${MOCK_RUNTIME_SHA:-$MOCK_SHA}" ;;
   'cat /runtime/version.txt') printf '%s\n' "${MOCK_RUNTIME_VERSION:-$MOCK_SERVER}" ;;
   *) return 96 ;;
  esac ;;
 *) printf 'FORBIDDEN docker %s\n' "$cmd" >> "$MOCK_TRACE"; return 97 ;;
 esac
}
# File copy/permission effects are irrelevant to this mocked image boundary.
cp() { return 0; }
chmod() { return 0; }
date() { printf '20261013_200000\n'; }
mockpython() {
 [[ "$*" == '-I -' ]] || return 96
 printf 'metadata\n' >> "$MOCK_TRACE"
 "$MOCK_PYTHON" -I -X utf8 "$MOCK_TEST" --publisher
}
ssh() { printf 'FORBIDDEN ssh\n' >> "$MOCK_TRACE"; return 97; }
curl() { return 97; }
redis-cli() { return 97; }
bazel() { return 97; }
sudo() { return 97; }
'''
class Cases(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='fixture-', dir=BASE)
        self.root = Path(self.tmp.name)
        self.pkg = self.root/'packages'
        self.model = self.pkg/'model resources'
        for path in (self.model, self.pkg/'server', self.pkg/'lib', self.pkg/'release_dialogue'):
            path.mkdir(parents=True, exist_ok=True)
        self.blob = b'#!/usr/bin/env bash\n# synthetic fixture, not executed\nexit 0\n'
        (self.pkg/'server'/NAME).write_bytes(self.blob)
        self.sha = hashlib.sha256(self.blob).hexdigest()
        (self.model/'data.txt').write_text('synthetic model', encoding='utf-8')
        for name in ('startup.sh','stop.sh','del_logs.sh','cron_task','nlu.data.Dockerfile','.dockerignore'):
            (self.pkg/'release_dialogue'/name).write_text('${APP_NAME}\n', encoding='utf-8')
        self.rows = self.root/'rows.txt'; self.rows.write_text('', encoding='utf-8')
        self.trace = self.root/'trace.txt'; self.trace.write_text('', encoding='utf-8')
        self.mock = self.root/'mock.sh'; self.mock.write_text(MOCK, encoding='utf-8')
        self.state = self.root/'state.json'
        self.state.write_text(json.dumps({'data': {}, 'ttl': {}}), encoding='utf-8')
        self.env = {k:v for k,v in os.environ.items() if k.upper() in
                    ('PATH','SYSTEMROOT','WINDIR','TEMP','TMP','COMSPEC','PATHEXT')}
        self.env.update(HOME=posix(self.root), PACKAGE_ROOT=posix(self.pkg), BASH_ENV=posix(self.mock),
                        METADATA_PYTHON='mockpython', MOCK_TRACE=posix(self.trace), MOCK_ROWS=posix(self.rows),
                        MOCK_COUNT=posix(self.root/'inspect-count.txt'), MOCK_EXPECT_OLD=OLD, MOCK_NEW=NEW,
                        MOCK_SHA=self.sha, MOCK_SERVER=NAME, MOCK_PYTHON=posix(Path(sys.executable)),
                        MOCK_TEST=str(Path(__file__).resolve()), MOCK_STATE=str(self.state),
                        LC_ALL='C.UTF-8', MSYS_NO_PATHCONV='1')
    def tearDown(self): self.tmp.cleanup()
    def row(self, cid=OLD, running='true', slot='<no value>', pipeline='<no value>',
            bindings='8080/tcp:0.0.0.0:9529|8080/tcp::::9529'):
        return f'{cid}|{running}|{slot}|{pipeline}'+('|' + bindings if bindings else '')+'\n'
    def seed(self, rows): self.rows.write_text(rows, encoding='utf-8')
    def events(self): return self.trace.read_text(encoding='utf-8').splitlines()
    def actions(self):
        return [x for x in self.events() if x.split()[0] in ('build','stop','rm','run','metadata','verify','smoke')]
    def reset_trace(self):
        self.trace.write_text('', encoding='utf-8')
        (self.root/'inspect-count.txt').unlink(missing_ok=True)
    def bash(self, args, expected=0, extra=None):
        env = dict(self.env); env.update(extra or {})
        result = subprocess.run([shutil.which('bash'), *args], cwd=self.root, env=env, capture_output=True,
                                text=True, encoding='utf-8', errors='replace', timeout=30)
        self.assertEqual(result.returncode, expected, result.stdout+result.stderr)
        self.assertFalse(any('FORBIDDEN' in x for x in self.events()))
        return result.stdout+result.stderr
    def deploy(self, expected=0, extra=None):
        return self.bash([posix(HELPER),posix(self.model),NAME,PORT], expected, extra)
    def publish(self, expected=0, extra=None, cid=NEW):
        return self.bash([posix(HELPER),posix(self.model),NAME,PORT,'--publish-only',
                          '--project-name','display v5','--description','synthetic text',
                          '--verified-id',cid,'--expected-sha',self.sha,'--expected-size',str(len(self.blob))], expected, extra)
    def test_01_single_exact_tcp_legacy_and_labeled(self):
        for slot,pipeline,internal in (('<no value>','<no value>','8080'),('9529','v3','8080'),('old','v2','9090')):
            with self.subTest(slot=slot, pipeline=pipeline, internal=internal):
                self.seed(self.row(slot=slot,pipeline=pipeline,bindings=f'{internal}/tcp:0.0.0.0:9529|{internal}/tcp::::9529'))
                self.reset_trace(); self.deploy()
                self.assertEqual(self.actions(), ['build',f'stop --time 10 -- {OLD}',f'rm -- {OLD}','run'])
                events = self.events()
                self.assertEqual(events[events.index(f'stop --time 10 -- {OLD}')-1], f'inspect {OLD}')
                self.assertFalse((self.pkg/'release').exists())
                print(f'PROOF single slot={slot} pipeline={pipeline} internal={internal}: build -> full-ID recheck -> stop10 -> rm(no flags) -> labeled run')
    def test_02_free_stopped_near_port_name_and_udp_untouched_repeat(self):
        # Names are never inspected: unrelated 9530 may have any name, including 9529.
        rows = (self.row(cid=OTHER,running='false')+
                self.row(cid='d'*64,bindings='8080/tcp:0.0.0.0:19529')+
                self.row(cid='e'*64,bindings='8080/udp:0.0.0.0:9529')+
                self.row(cid='f'*64,bindings='8080/tcp:0.0.0.0:9530'))
        self.seed(rows); self.deploy()
        self.assertEqual(self.actions(), ['build','run'])
        self.assertNotIn(f'inspect {OTHER}', self.events())
        self.assertTrue(self.rows.read_text(encoding='utf-8').startswith(rows))
        self.reset_trace(); self.deploy(extra={'MOCK_EXPECT_OLD':NEW})
        self.assertEqual(self.actions(), ['build',f'stop --time 10 -- {NEW}',f'rm -- {NEW}','run'])
        self.assertTrue(self.rows.read_text(encoding='utf-8').startswith(rows))
        print('PROOF free/nonoccupants and repeat: stopped, near-port, name-independent unrelated port and UDP-only preserved; repeat replaces only new running ID')
    def test_03_ambiguous_and_additional_bindings_rejected_before_touch(self):
        bad = [self.row()+self.row(cid=OTHER),
               self.row(bindings='8080/tcp:0.0.0.0:9529|8080/tcp:0.0.0.0:9530'),
               self.row(bindings='8080/tcp:0.0.0.0:9529|8080/udp:0.0.0.0:9529')]
        for rows in bad:
            with self.subTest(rows=rows):
                self.seed(rows); self.reset_trace(); self.deploy(expected=1)
                self.assertEqual(self.actions(), [])
                self.assertEqual(self.rows.read_text(encoding='utf-8'), rows)
        print('PROOF ambiguous / additional port / additional protocol: reject before build/stop/rm/run')
    def test_04_failure_order_and_exact_exit_status(self):
        expected = {'build':(21,['build']), 'stop':(22,['build',f'stop --time 10 -- {OLD}']),
                    'rm':(23,['build',f'stop --time 10 -- {OLD}',f'rm -- {OLD}']),
                    'run':(24,['build',f'stop --time 10 -- {OLD}',f'rm -- {OLD}','run'])}
        for stage,(status,actions) in expected.items():
            with self.subTest(stage=stage):
                self.seed(self.row()); self.reset_trace()
                self.deploy(expected=status,extra={'MOCK_FAIL':stage})
                self.assertEqual(self.actions(), actions)
                self.assertNotIn('metadata', self.events())
                self.assertFalse((self.pkg/'release').exists())
                print(f'PROOF failure={stage} exit={status}: {actions}; no later action/metadata/recreation')
    def test_05_refresh_after_build_and_exact_id_binding_races(self):
        self.seed(self.row())
        self.deploy(extra={'MOCK_AFTER_BUILD':self.row(cid=OTHER).rstrip(),'MOCK_EXPECT_OLD':OTHER})
        self.assertEqual(self.actions(), ['build',f'stop --time 10 -- {OTHER}',f'rm -- {OTHER}','run'])
        print('PROOF after-build selector refresh: current full ID replaces pre-build candidate')
        for row in (self.row(bindings='8080/tcp:0.0.0.0:9529|8080/tcp:0.0.0.0:9530'),self.row(running='false'),self.row(cid=OTHER)):
            with self.subTest(row=row):
                self.seed(self.row()); self.reset_trace()
                self.deploy(expected=1,extra={'MOCK_RACE_AT':'4','MOCK_RACE_ROW':row.rstrip()})
                self.assertEqual(self.actions(), ['build'])
        self.seed(self.row()); self.reset_trace()
        self.deploy(expected=1,extra={'MOCK_AFTER_BUILD':(self.row()+self.row(cid=OTHER)).rstrip()})
        self.assertEqual(self.actions(), ['build'])
        print('PROOF immediate recheck binding/state/ID races and refreshed ambiguity: no stop/rm/run')
    def test_06_publication_strict_guards_no_mutation_or_redis(self):
        rows = [self.row(cid=NEW),self.row(cid=NEW,slot='9529',pipeline='v2'),
                self.row(cid=NEW,slot='9530',pipeline='v3'),
                self.row(cid=NEW,slot='9529',pipeline='v3',bindings='9090/tcp:0.0.0.0:9529'),
                self.row(cid=NEW,slot='9529',pipeline='v3',running='false'),
                self.row(cid=NEW,slot='9529',pipeline='v3',bindings='8080/tcp:0.0.0.0:9530')]
        for row in rows:
            with self.subTest(row=row):
                self.seed(row); self.reset_trace(); self.publish(expected=1)
                self.assertEqual(self.actions(), [])
                self.assertEqual(self.rows.read_text(encoding='utf-8'), row)
        self.seed(self.row(cid=NEW,slot='9529',pipeline='v3'))
        for extra,cid in (({},OLD),({'MOCK_RUNTIME_SHA':'f'*64},NEW),({'MOCK_RUNTIME_VERSION':'wrong-version'},NEW)):
            self.reset_trace(); self.publish(expected=1,extra=extra,cid=cid)
            self.assertEqual(self.actions(), [])
        print('PROOF publication rejects unlabelled/wrong pipeline/slot/internal port/stopped/binding/ID/SHA/version; no Docker mutation/Redis')
    def test_07_new_labeled_publication_stopped_ignored_metadata_unchanged(self):
        self.seed(self.row(cid=OTHER,running='false')); self.deploy(); self.reset_trace()
        self.assertIn('METADATA_STATUS=PUBLISHED', self.publish(cid=NEW[:12]))
        self.assertEqual(self.actions(), ['metadata'])
        self.assertNotIn(f'inspect {OTHER}', self.events())
        data = json.loads(self.state.read_text(encoding='utf-8'))
        self.assertEqual(json.loads(data['data']['container_list']),
                         [{'id':NEW[:12],'path':'display v5','desc':'synthetic text','server':NAME,'port':PORT}])
        self.assertEqual(json.loads(data['data']['container:9529']),
                         {'project':'display v5','port':PORT,'server':NAME,'desc':'synthetic text'})
        self.assertEqual(data['ttl'], {'container_list':-1,'container:9529':250})
        self.assertEqual(CODE, V4.read_text(encoding='utf-8').split("<<'METADATA_PY'\n",1)[1].split('\nMETADATA_PY',1)[0])
        self.assertIn('runtime_rollback=none', self.publish(expected=50,extra={'MOCK_REDIS_MODE':'clientfail'}))
        print('PROOF new labeled exact ID (short/full), SHA/size/version before unchanged Redis schema/TTL; stopped ignored; metadata failure50 retains runtime')
    def test_08_unchanged_controller_verify_first_and_failed_run_no_publication(self):
        # Execute only existing deploy_pipeline; surrounding infra is mocked.
        cs = CONTROLLER.read_text(encoding='utf-8')
        function = 'deploy_pipeline() {'+cs.split('deploy_pipeline() {',1)[1].split('\n}\n',1)[0]+'\n}\n'
        local = self.root/'controller-order.sh'
        local.write_text('''set -euo pipefail
prepare_selected_deployment() { :; }
log() { :; }
hostname() { printf 'fixture\n'; }
sync_artifacts() { :; }
die() { printf '%s\n' "$*" >&2; exit 1; }
remote_auto_build_deploy() { bash "$MOCK_HELPER" "$MOCK_MODEL" "$MOCK_SERVER" 9529; }
verify_remote_auto_build_deploy() {
 printf 'verify\n' >> "$MOCK_TRACE"
 [[ "${MOCK_VERIFY_FAIL:-0}" == 0 ]] || die 'synthetic verifier failure'
}
publish_verified_deployment() {
 bash "$MOCK_HELPER" "$MOCK_MODEL" "$MOCK_SERVER" 9529 --publish-only --verified-id "$MOCK_NEW" --expected-sha "$MOCK_SHA" --expected-size "$MOCK_SIZE"
}
remote_http_smoke() { printf 'smoke\n' >> "$MOCK_TRACE"; }
SELF=fixture LOCAL_ARTIFACT_DIR=fixture TARGET_SSH=mock REMOTE_PACKAGE_ROOT=fixture REMOTE_ARTIFACT_DIR=fixture REMOTE_MODEL_DIR=fixture TEST_PORT=9529
'''+function+'\ndeploy_pipeline\n',encoding='utf-8')
        extra = {'MOCK_HELPER':posix(HELPER),'MOCK_MODEL':posix(self.model),'MOCK_SIZE':str(len(self.blob))}
        self.seed(self.row()); self.bash([posix(local)],extra=extra)
        self.assertEqual(self.actions(), ['build',f'stop --time 10 -- {OLD}',f'rm -- {OLD}','run','verify','metadata','smoke'])
        self.seed(self.row()); self.reset_trace()
        self.bash([posix(local)],expected=1,extra=dict(extra,MOCK_FAIL='run'))
        self.assertEqual(self.actions(), ['build',f'stop --time 10 -- {OLD}',f'rm -- {OLD}','run'])
        self.seed(self.row()); self.reset_trace()
        self.bash([posix(local)],expected=1,extra=dict(extra,MOCK_VERIFY_FAIL='1'))
        self.assertNotIn('metadata', self.actions()); self.assertNotIn('smoke', self.actions())
        print('PROOF unchanged controller order deploy -> verify -> publish -> smoke; failed run/verification cannot publish; no live HTTP')
    def test_09_compilation_and_staged_proof_inputs(self):
        compile(CODE, '<unchanged-embedded-publisher>', 'exec')
        self.seed(self.row(cid=NEW,slot='9529',pipeline='v3'))
        for flag,value in (('--expected-sha','f'*64),('--expected-size','999')):
            args = [posix(HELPER),posix(self.model),NAME,PORT,'--publish-only','--verified-id',NEW,
                    '--expected-sha',self.sha,'--expected-size',str(len(self.blob))]
            args[args.index(flag)+1] = value
            self.bash(args,expected=1); self.assertEqual(self.actions(), [])
        print('PROOF embedded Python compile and staged SHA/size mismatch: reject before Redis')
def publisher_bootstrap():
    # Reuse v4 FakeTx/metadata only, not its suite/evidence/bootstrap.
    prior = runpy.run_path(str(BASE.parent/'tests/phase2_tests.py'),run_name='v4_fixture_library')
    state_path = Path(os.environ['MOCK_STATE'])
    state = json.loads(state_path.read_text(encoding='utf-8'))
    status,output = prior['metadata'](CODE,state,os.environ.get('MOCK_REDIS_MODE',''))
    if status == 0: state_path.write_text(json.dumps(state),encoding='utf-8')
    print(output,end=''); return status
if __name__ == '__main__':
    if sys.argv[1:] == ['--publisher']: sys.exit(publisher_bootstrap())
    unittest.main(verbosity=2)
