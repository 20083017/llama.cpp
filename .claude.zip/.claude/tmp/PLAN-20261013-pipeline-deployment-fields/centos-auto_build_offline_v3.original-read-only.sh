#! /bin/bash

#$set -x

cd ~/packages/
temp_file=$(pwd)/.service.building
if [ -z ${app_name+x} ]; then
  app_name=cu-server
fi

if [[ $# -ne 3 ]];then
  echo "required 3 paramters"
  exit 1
fi

# server=cu-server-1intent-centos-20221025
#server=cu-server-centos-20221123
server=$2
release_folder=release_dialogue
model=$1
port=$3
log_base_dir=~/packages/logs
name=cu-server
tag=$(date +"%y%m%d.%H%M%S")

root=release
mkdir -p ${root}

# bazel clean
# bazel build -c opt contact:contact-server --distdir=~/bazel-1.2.1-dist/derived/distdir
# cp -f bazel-bin/contact/contact-server ${root}/contact-server
cp -f server/${server} ${root}/cu-server
sed 's/${APP_NAME}/'${app_name}'/g' ${release_folder}/startup.sh > ${root}/start.sh
cp -f ${release_folder}/stop.sh ${root}/stop.sh
cp -f ${release_folder}/del_logs.sh ${root}/del_logs.sh
cp -f ${release_folder}/cron_task ${root}/cron_task
chmod +x ${root}/start.sh
chmod +x ${root}/stop.sh
chmod +x ${root}/del_logs.sh
echo ${server} > ${root}/version.txt
cp -rf lib ${root}/
# cp -rf /lib64/libgomp.so.1.0.0 ${root}/libgomp.so.1
# cp -rf /usr/lib/x86_64-linux-gnu/libgomp.so.1 ${root}

mkdir -p ${root}/data
cp -rf ${model}/* ${root}/data/

cp -rf ${release_folder}/nlu.data.Dockerfile ./Dockerfile
cp -rf ${release_folder}/.dockerignore ./.dockerignore
# # BUILD docker image
# sed 's/${APP_NAME}/'${app_name}'/g' ${release_folder}/osu.cloud.dockerfile > ./Dockerfile
docker build -t $name:$tag .

if [ $? -ne 0 ]; then
  echo Failed to build docker image!
else
  # docker save $name:$tag -o $name.$tag.image.tar
#  docker save $name:$tag | gzip > $name.$tag.image.tar.gz
  echo done!
fi

# clean
rm -f Dockerfile
rm -rf ${root}

restartFile=.$port-restart.log
rm -rf ${restartFile}

echo "Excute: bash dsm.sh --rmi --port $port && docker run --name cu-server-$(date +%Y%m%d) -d -p $port:8080 $name:$tag"
#bash dsm.sh --rmi --port $port && docker run  --name cu-server-$(date +%Y%m%d_%H%M%S) -d -p $port:8080 -e LLM_URL=https://llm-v2.auto-pai.cn/v1/chat/completions  -e ACTIVE_CONTEXT=redis -e REDIS_HOST=10.1.122.21 -e REDIS_PORT=6379 -e REDIS_DB=0 $name:$tag
echo "bash dsm.sh --rmi --port $port && docker run  --name cu-server-$(date +%Y%m%d_%H%M%S) --ulimit core=-1:-1  -d -p $port:8080 -e REJECTION_LLM_URL=http://82.157.133.222:8000/v1/chat/completions -e LLM_URL_V2=http://10.1.122.21:7000/v1/nlu/inference -e LLM_URL=https://llm-v2.auto-pai.cn/v1/chat/completions  -e ACTIVE_CONTEXT=redis -e REDIS_HOST=10.1.122.21 -e REDIS_PORT=6379 -e REDIS_DB=0 $name:$tag"


bash dsm.sh --rmi --port $port && docker run  --name cu-server-$(date +%Y%m%d_%H%M%S) --ulimit core=-1:-1  -d -p $port:8080 -e REJECTION_LLM_URL=http://82.157.133.222:8000/v1/chat/completions -e LLM_URL_V2=http://10.1.122.21:7000/v1/nlu/inference -e LLM_URL=https://llm-v2.auto-pai.cn/v1/chat/completions  -e ACTIVE_CONTEXT=local -e REDIS_HOST=10.1.122.21 -e REDIS_PORT=6379 -e REDIS_DB=0 $name:$tag

rm -rf $temp_file
