#!/usr/bin/env bash
set -Eeuo pipefail

# ==============================================================================
# cu-dev-pipeline-v17-final-bazel121.sh
#
# Run this script on build server 10.1.120.40.
#
# Pipeline:
#
#   10.1.120.40
#     GCC 4.9.3 -> bazel build //cu:server
#       -> /home/daigd/packages/server/server-v2.<timestamp>-<gitsha>
#       -> rsync
#   10.1.122.21
#       -> /home/daigd/packages/server/
#       -> /home/daigd/packages/auto_build.sh
#          MODEL=/home/shared/models/car_v2.0
#          SERVER=<LATEST artifact basename>
#          PORT=9530
#       -> docker image build + replace only the :9530 slot
#       -> POST /zp/update JSON smoke test
#       -> optional :9999 vs :9530 A/B
#
# Deployment policy:
#   * :9999 is the baseline and is never passed to auto_build.sh by default.
#   * :9530 uses server-21's existing /home/daigd/packages/auto_build.sh.
#   * auto_build.sh internally calls dsm.sh --rmi --port 9530, so the previous
#     :9530 container/image is NOT retained by this pipeline for rollback.
#   * rsync does NOT use --delete.
#   * build/toolchain/ABI validation remains on build server 10.1.120.40.
#
# Main commands:
#   diagnose
#   setup-ssh
#   build [--clean] [--message TEXT]
#   sync
#   deploy
#   test
#   compare
#   rollback
#   all [--clean] [--message TEXT]
#   watch-sync
#   install-sync-service
#   uninstall-sync-service
#   status
#
# ==============================================================================

# ------------------------------------------------------------------------------
# 0. Configuration
# ------------------------------------------------------------------------------

# Build server facts.
BUILD_SERVER_IP="${BUILD_SERVER_IP:-10.1.120.40}"
PROJECT_DIR="${PROJECT_DIR:-/home/daigd/workspaces/dialogue}"
PACKAGE_ROOT="${PACKAGE_ROOT:-/home/daigd/packages}"
LOCAL_ARTIFACT_DIR="${LOCAL_ARTIFACT_DIR:-$PACKAGE_ROOT/server}"
RELEASE_NOTE_FILE="${RELEASE_NOTE_FILE:-$PACKAGE_ROOT/release_notes.txt}"
BUILD_LOG_DIR="${BUILD_LOG_DIR:-$PACKAGE_ROOT/logs}"
V3_PROJECT_DIR="${V3_PROJECT_DIR:-/home/daigd/dialogue}"
V3_THIRD_PARTY_DIR="${V3_THIRD_PARTY_DIR:-$V3_PROJECT_DIR/third_party}"
V3_ARTIFACT_ROOT="${V3_ARTIFACT_ROOT:-$PACKAGE_ROOT/server-v3}"
V3_RELEASE_NOTE_FILE="${V3_RELEASE_NOTE_FILE:-$V3_ARTIFACT_ROOT/release_notes.txt}"

# WTP184 Bazel third-party repository on server 40.
# This remains a BUILD-TIME dependency tree and is NOT replaced by GCC/sysroot.
#
# Current WORKSPACE layout:
#   /home/daigd/workspaces/dialogue/WORKSPACE
#     local_repository(name = "third_party", path = "../third_party")
#
# Resolves to:
#   /home/daigd/workspaces/third_party
#
# Runtime libraries on server 21 remain sourced from the known-good baseline
# Docker /runtime snapshot. This pipeline does NOT silently overwrite runtime
# .so files from this build-host third_party directory.
THIRD_PARTY_DIR="${THIRD_PARTY_DIR:-/home/daigd/workspaces/third_party}"

# GCC 4.9.3 migrated from server 21 CentOS7 / glibc 2.17.
# Do NOT fall back to the older compiler built on server 40.
#
# Created by:
#   sync-wtp184-toolchain-21-to-40-v2.sh
#
# Expected:
#   /home/daigd/tools/gcc-4.9.3-centos7/bin/gcc
#   /home/daigd/tools/gcc-4.9.3-centos7/bin/g++
#   /home/daigd/tools/gcc-4.9.3-centos7/lib64/libstdc++.so.6
GCC_HOME="${GCC_HOME:-/home/daigd/tools/gcc-4.9.3-centos7}"

# Target ABI sysroot exported from the real server 21 CentOS 7 host.
#
# This keeps server 40's newer host glibc out of the target //cu:server ABI.
# The sysroot and compiler are expected to be created together by:
#   sync-wtp184-toolchain-21-to-40-v2.sh
#
# Source baseline currently verified on server 21:
#   CentOS 7 x86_64
#   glibc/glibc-devel/glibc-headers 2.17-326.el7_9
USE_SYSROOT="${USE_SYSROOT:-1}"
WTP184_SYSROOT="${WTP184_SYSROOT:-/home/daigd/sysroots/wtp184-centos7}"
MAX_TARGET_GLIBC="${MAX_TARGET_GLIBC:-2.17}"

# Stable compiler wrappers used by Bazel 1.2.1 cc_autoconf.
# The wrapper makes --sysroot and target startfile prefixes part of the compiler identity so
# @local_config_cc records the CentOS7 target headers as builtin includes.
BAZEL_CC_WRAPPER_ROOT="${BAZEL_CC_WRAPPER_ROOT:-/home/daigd/tools/wtp184-gcc493-sysroot}"
BAZEL_CC_WRAPPER="$BAZEL_CC_WRAPPER_ROOT/bin/gcc"
BAZEL_CXX_WRAPPER="$BAZEL_CC_WRAPPER_ROOT/bin/g++"

BAZEL_BIN="${BAZEL_BIN:-bazel}"
STRIP_BIN="${STRIP_BIN:-strip}"
BAZEL_TARGET="${BAZEL_TARGET:-//cu:server}"
# WTP184 BUILD files select Linux x86_64 branches with cpu=k8.
BAZEL_CPU="${BAZEL_CPU:-k8}"
BAZEL_HOST_CPU="${BAZEL_HOST_CPU:-k8}"

# Opt-in build profiles. Defaults preserve the existing build behavior.
BAZEL_DEBUG_MODE="${BAZEL_DEBUG_MODE:-0}"
BAZEL_RELEASE_MODE="${BAZEL_RELEASE_MODE:-0}"
BAZEL_ASAN_MODE="${BAZEL_ASAN_MODE:-0}"

# Allow unresolved symbols that belong to linked shared libraries.
# This is intentionally narrower than --unresolved-symbols=ignore-all:
# cu-server's own unresolved symbols must still be resolved at final link.
#
# Rationale:
#   120.40 is a build host, while 21 Docker is the real runtime.
#   Some prebuilt DSOs (notably librdkafka.so) may reference OpenSSL/glibc
#   versions unavailable on 120.40. The deploy helper performs `ldd` inside
#   the derived Docker runtime BEFORE starting/replacing the test service.
ALLOW_SHLIB_UNDEFINED="${ALLOW_SHLIB_UNDEFINED:-1}"

BAZEL_OUTPUT="${BAZEL_OUTPUT:-$PROJECT_DIR/bazel-bin/cu/server}"
ARTIFACT_PREFIX="${ARTIFACT_PREFIX:-server-v2}"
BUILD_LOG_PREFIX="${BUILD_LOG_PREFIX:-bazel-cu-server}"
DIALOGUE_PIPELINE_VARIANT=default
DIALOGUE_PIPELINE_DEFINE=""
V3_BUILD_PROFILE=""
V3_COMPAT_ALIAS=0

# Debug/release package-runtime contract. The full directory is never placed on
# LD_LIBRARY_PATH because it also contains libc/OpenSSL3/zstd entries outside
# the selected CentOS7-compatible closure.
PACKAGE_LIBRARY_DIR="${PACKAGE_LIBRARY_DIR:-$PACKAGE_ROOT/lib}"
PACKAGE_LIBSTDCPP="$PACKAGE_LIBRARY_DIR/libstdc++.so.6.0.26"
PACKAGE_LIBGCC="$PACKAGE_LIBRARY_DIR/libgcc_s.so.1"
PACKAGE_ONNXRUNTIME="$PACKAGE_LIBRARY_DIR/libonnxruntime.so.1.14.0"
PACKAGE_RDKAFKA="$PACKAGE_LIBRARY_DIR/librdkafka.so.1"
PACKAGE_SASL="$PACKAGE_LIBRARY_DIR/libsasl2.so.3"
PACKAGE_SSL="$PACKAGE_LIBRARY_DIR/libssl.so.10"
readonly PACKAGE_LIBSTDCPP_SHA256='61686be7963bd3830a9cb1f74510f249ed617ac1815b6604e142c5db6f84238d'
readonly PACKAGE_LIBGCC_SHA256='c5072f2b71fb61e1159ce0642b7bcc11baf8313fffaa7b65f6cafc28a3e11cba'
readonly PACKAGE_ONNXRUNTIME_SHA256='535abc9e9908093b0e2fbb621db6d9a66b36d477288c3d75085fda171233d214'
readonly PACKAGE_RDKAFKA_SHA256='1ea9492c3d52e56be7f79e1d1082f0a508725775539b906db6feeca02e4431f6'
readonly PACKAGE_SASL_SHA256='84219a89b635c809c66b297f2970df52f1f38dd429426c213d0340dea5e7ec9d'
readonly PACKAGE_SSL_SHA256='cd1d62209c3e14cd9809d76cc446fdf54c2a272f4e9cba24278a38e72254931b'
PACKAGE_PROFILE_TMP=""
PACKAGE_LIBRARY_VIEW=""
PACKAGE_LINKER_PREFIX=""
PACKAGE_MANIFEST_SHA256=""
PACKAGE_PROFILE_ACTIVE=0

# Target server 21.
TARGET_USER="${TARGET_USER:-daigd}"
TARGET_HOST="${TARGET_HOST:-10.1.122.21}"
TARGET_PORT="${TARGET_PORT:-22}"
TARGET_SSH="${TARGET_USER}@${TARGET_HOST}"

# Server-21 release layout used by the existing auto_build.sh.
REMOTE_PACKAGE_ROOT="${REMOTE_PACKAGE_ROOT:-/home/daigd/packages}"
REMOTE_ARTIFACT_DIR="${REMOTE_ARTIFACT_DIR:-$REMOTE_PACKAGE_ROOT/server}"
REMOTE_AUTO_BUILD="${REMOTE_AUTO_BUILD:-$REMOTE_PACKAGE_ROOT/auto_build_offline_v3.sh}"
REMOTE_MODEL_DIR="${REMOTE_MODEL_DIR:-/home/shared/models/car_v3.0}"
# Optional display metadata is independent of model resources.
DEPLOY_METADATA=0
[[ -z "${DEPLOY_PROJECT_NAME+x}${DEPLOY_DESCRIPTION+x}" ]] || DEPLOY_METADATA=1
DEPLOY_PROJECT_EXPLICIT=0
[[ -z "${DEPLOY_PROJECT_NAME+x}" ]] || DEPLOY_PROJECT_EXPLICIT=1
DEPLOY_PROJECT_NAME="${DEPLOY_PROJECT_NAME-}"
DEPLOY_DESCRIPTION="${DEPLOY_DESCRIPTION-}"
SERVER_VERSION="${SERVER_VERSION:-}"
DEPLOY_VERIFIED_ID=''
DEPLOY_FIELD_OPTIONS='|'

# Docker slot policy on server 21.
# 9999 is only the runtime BASELINE TEMPLATE. Requests to the new build go to 9530.
BASELINE_PORT="${BASELINE_PORT:-9999}"
TEST_PORT="${TEST_PORT:-9530}"
CONTAINER_HTTP_PORT="${CONTAINER_HTTP_PORT:-8080}"
CURL_PATH="${CURL_PATH:-/zp/update}"

# Smoke request.
TEST_QUERY="${TEST_QUERY:-打开空调}"
CURL_MAX_TIME="${CURL_MAX_TIME:-30}"

# Established quick-test resources and bounded defaults.
STRESS_ROOT="${STRESS_ROOT:-/home/daigd/stress_test}"
STRESS_RUNNER="${STRESS_RUNNER:-$STRESS_ROOT/zp_update_soak_csv_v5_2.5.sh}"
STRESS_CSV="${STRESS_CSV:-$STRESS_ROOT/2w_data.csv}"
STRESS_CASES="${STRESS_CASES:-$STRESS_ROOT/history_replay_cases_verified_full.json}"
WTP184_CONCURRENCY="${WTP184_CONCURRENCY:-4}"
WTP184_MONITOR_SSH="${WTP184_MONITOR_SSH:-$TARGET_SSH}"
WTP184_HISTORY_CASE_ID="${WTP184_HISTORY_CASE_ID:-C005_case1_car_info_tire_pressure}"
SMOKE_RETRIES="${SMOKE_RETRIES:-15}"
SMOKE_INTERVAL="${SMOKE_INTERVAL:-1}"

# Near-real-time rsync service.
SYNC_INTERVAL="${SYNC_INTERVAL:-2}"

# SSH settings.
SSH_IDENTITY="${SSH_IDENTITY:-}"
SSH_CONNECT_TIMEOUT="${SSH_CONNECT_TIMEOUT:-8}"

# Remote helper path.
REMOTE_HELPER="${REMOTE_HELPER:-/home/${TARGET_USER}/.local/bin/cu-dev-remote-deploy}"

# Local service name.
SYNC_SERVICE_NAME="${SYNC_SERVICE_NAME:-cu-dev-artifact-sync.service}"

# ------------------------------------------------------------------------------
# 1. Generic helpers
# ------------------------------------------------------------------------------

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
SCRIPT_NAME="$(basename "$SELF")"
DEBUG=0
CLEAN=0
DRY_RUN=0
MESSAGE=""

mkdir -p "$BUILD_LOG_DIR" "$LOCAL_ARTIFACT_DIR"

LOG_FILE="$BUILD_LOG_DIR/cu-dev-pipeline-$(date '+%Y%m%d-%H%M%S').log"

log() {
  local msg="[$(date '+%Y-%m-%d %H:%M:%S')] $*"
  echo "$msg"
  printf '%s\n' "$msg" >> "$LOG_FILE"
}

debug() {
  [[ "$DEBUG" -eq 1 ]] && log "[DEBUG] $*" || true
}

die() {
  log "[ERROR] $*"
  exit 1
}

have() {
  command -v "$1" >/dev/null 2>&1
}

run_logged() {
  local label="$1"
  shift
  local start end rc
  start="$(date +%s)"
  log "[RUN] $label"
  debug "command: $(printf '%q ' "$@")"

  set +e
  "$@" 2>&1 | tee -a "$LOG_FILE"
  rc=${PIPESTATUS[0]}
  set -e

  end="$(date +%s)"
  log "[DONE] $label rc=$rc elapsed=$((end-start))s"
  return "$rc"
}

sha256_file() {
  local file="$1"
  if have sha256sum; then
    sha256sum "$file" | awk '{print $1}'
  else
    python3 - "$file" <<'PY'
import hashlib, sys
h = hashlib.sha256()
with open(sys.argv[1], "rb") as f:
    for block in iter(lambda: f.read(1024 * 1024), b""):
        h.update(block)
print(h.hexdigest())
PY
  fi
}

package_profile_enabled() {
  [[ "$BAZEL_DEBUG_MODE" == "1" || "$BAZEL_RELEASE_MODE" == "1" ]]
}

is_v3_build() {
  [[ "$DIALOGUE_PIPELINE_VARIANT" == "v3" ]]
}

cleanup_package_profile_libraries() {
  if [[ -n "$PACKAGE_PROFILE_TMP" && -d "$PACKAGE_PROFILE_TMP" ]]; then
    case "$PACKAGE_PROFILE_TMP" in
      "$PACKAGE_ROOT"/.wtp184-profile-libs.*)
        rm -rf -- "$PACKAGE_PROFILE_TMP"
        ;;
      *)
        printf '[WARN] refusing unexpected package-profile cleanup path: %s\n' \
          "$PACKAGE_PROFILE_TMP" >&2
        ;;
    esac
  fi
  PACKAGE_PROFILE_TMP=""
  PACKAGE_LIBRARY_VIEW=""
  PACKAGE_LINKER_PREFIX=""
  PACKAGE_MANIFEST_SHA256=""
  PACKAGE_PROFILE_ACTIVE=0
}

validate_package_library() {
  local path="$1" expected_sha="$2" expected_soname="$3"
  [[ -f "$path" ]] || die "selected package library missing: $path"

  local actual_sha actual_soname max_glibc file_desc
  actual_sha="$(sha256_file "$path")"
  [[ "$actual_sha" == "$expected_sha" ]] || \
    die "selected package library hash mismatch: $path expected=$expected_sha actual=$actual_sha"

  file_desc="$(file -b "$path" 2>/dev/null || true)"
  [[ "$file_desc" == *"ELF 64-bit LSB shared object, x86-64"* ]] || \
    die "selected package library is not an x86-64 shared object: $path ($file_desc)"

  actual_soname="$(readelf -d "$path" 2>/dev/null | sed -n 's/.*(SONAME).*\[\([^]]*\)\].*/\1/p' | head -n1)"
  [[ "$actual_soname" == "$expected_soname" ]] || \
    die "selected package SONAME mismatch: $path expected=$expected_soname actual=${actual_soname:-EMPTY}"

  max_glibc="$(elf_max_version_requirement "$path" GLIBC)"
  [[ -n "$max_glibc" ]] || die "unable to determine selected package GLIBC requirement: $path"
  version_le "$max_glibc" "$MAX_TARGET_GLIBC" || \
    die "selected package library requires GLIBC_$max_glibc > GLIBC_$MAX_TARGET_GLIBC: $path"

  log "[OK] PACKAGE_LIBRARY path=$path soname=$actual_soname sha256=$actual_sha glibc_max=$max_glibc"
}

write_package_linker_interposer() {
  local real_ld real_gold="" gold_candidate gold_version compiler prefix_path
  local linker_name backend require_onnx=1
  prefix_path="$(readlink -e -- "$PACKAGE_LINKER_PREFIX")" || \
    die "package linker prefix missing: $PACKAGE_LINKER_PREFIX"
  real_ld="$(command -v ld)" || die "real linker missing: ld"
  real_ld="$(readlink -e -- "$real_ld")" || die "unable to resolve real ld"
  [[ -f "$real_ld" && -x "$real_ld" && "$real_ld" != "$prefix_path/"* ]] || \
    die "real ld missing/not executable or inside package linker prefix: $real_ld"

  # Probe the established compiler wrappers before adding the package prefix.
  # Both drivers must agree; never substitute BFD for the selected gold backend.
  for compiler in "$BAZEL_CC_WRAPPER" "$BAZEL_CXX_WRAPPER"; do
    [[ -x "$compiler" ]] || die "compiler wrapper missing/not executable: $compiler"
    gold_candidate="$(WTP184_PACKAGE_LINKER_PREFIX= "$compiler" \
      -B"$BAZEL_CC_WRAPPER_ROOT/bin/" -print-prog-name=ld.gold)" || \
      die "compiler could not resolve ld.gold: $compiler"
    [[ -n "$gold_candidate" && "$gold_candidate" != *$'\n'* ]] || \
      die "ambiguous compiler ld.gold resolution: $compiler"
    if [[ "$gold_candidate" != */* ]]; then
      gold_candidate="$(command -v -- "$gold_candidate")" || \
        die "compiler-selected ld.gold missing from PATH"
    fi
    gold_candidate="$(readlink -e -- "$gold_candidate")" || \
      die "unable to resolve compiler-selected gold"
    [[ -f "$gold_candidate" && -x "$gold_candidate" && \
       "$gold_candidate" != "$prefix_path/"* && "$gold_candidate" != "$real_ld" ]] || \
      die "compiler-selected gold missing, recursive or identical to ordinary ld: $gold_candidate"
    [[ -z "$real_gold" || "$real_gold" == "$gold_candidate" ]] || \
      die "compiler wrappers disagree on selected gold: $real_gold vs $gold_candidate"
    real_gold="$gold_candidate"
  done
  gold_version="$("$real_gold" --version)" || die "selected gold version probe failed: $real_gold"
  [[ "$gold_version" == "GNU gold "* ]] || die "selected ld.gold is not GNU gold: $real_gold"
  if is_v3_build; then
    require_onnx=0
  fi

  for linker_name in ld ld.gold; do
    backend="$real_ld"
    [[ "$linker_name" != ld.gold ]] || backend="$real_gold"
    cat > "$PACKAGE_LINKER_PREFIX/$linker_name" <<EOF
#!/usr/bin/env bash
set -euo pipefail
readonly REAL_LD=$(printf '%q' "$backend")
readonly VIEW=$(printf '%q' "$PACKAGE_LIBRARY_VIEW")
readonly SYSROOT=$(printf '%q' "$WTP184_SYSROOT")
readonly REQUIRE_ONNX=$require_onnx
args=()
scratch_files=()
cleanup_scratch() {
  local path
  for path in "\${scratch_files[@]}"; do
    case "\$path" in
      "\${TMPDIR:-/tmp}"/wtp184-ld-*) rm -f -- "\$path" ;;
    esac
  done
}
trap cleanup_scratch EXIT
onnx_seen=0
kafka_seen=0
final_link=0
expect_output=0
scan_arg() {
  local arg="\$1"
  if [[ "\$expect_output" -eq 1 ]]; then
    [[ "\$arg" == */cu/server || "\$arg" == cu/server ]] && final_link=1
    expect_output=0
  elif [[ "\$arg" == -o ]]; then
    expect_output=1
  elif [[ "\$arg" == -o* && "\${arg#-o}" == */cu/server ]]; then
    final_link=1
  fi
  case "\$arg" in
    -l:libonnxruntime.so.1.14.0|-lonnxruntime|*/libonnxruntime.so|*/libonnxruntime.so.1.14.0) onnx_seen=1 ;;
    -lrdkafka|-l:librdkafka.so.1|*/librdkafka.so|*/librdkafka.so.1) kafka_seen=1 ;;
  esac
}
rewrite_arg() {
  local arg="\$1"
  case "\$arg" in
    */libonnxruntime.so|*/libonnxruntime.so.1.14.0)
      printf '%s' "\$VIEW/libonnxruntime.so.1.14.0" ;;
    */librdkafka.so|*/librdkafka.so.1)
      printf '%s' "\$VIEW/librdkafka.so.1" ;;
    *) printf '%s' "\$arg" ;;
  esac
}
for arg in "\$@"; do
  if [[ "\$arg" == @* && -r "\${arg#@}" ]]; then
    src="\${arg#@}"
    dst="\$(mktemp "\${TMPDIR:-/tmp}/wtp184-ld-response.XXXXXX")"
    scratch_files+=("\$dst")
    while IFS= read -r line || [[ -n "\$line" ]]; do
      scan_arg "\$line"
      rewrite_arg "\$line" >> "\$dst"
      printf '\n' >> "\$dst"
    done < "\$src"
    args+=("@\$dst")
  else
    scan_arg "\$arg"
    args+=("\$(rewrite_arg "\$arg")")
  fi
done
link_args=(-L"\$VIEW" -rpath-link "\$VIEW" -rpath-link "\$SYSROOT/lib64" -rpath-link "\$SYSROOT/usr/lib64")
if [[ "\$final_link" -eq 1 ]]; then
  if [[ "\$REQUIRE_ONNX" -eq 1 ]]; then
    [[ "\$onnx_seen" -eq 1 ]] || { echo '[ERROR] final link did not contain ONNX Runtime input' >&2; exit 71; }
  else
    [[ "\$onnx_seen" -eq 0 ]] || { echo '[ERROR] V3 final link unexpectedly contains ONNX Runtime input' >&2; exit 71; }
  fi
  [[ "\$kafka_seen" -eq 1 ]] || { echo '[ERROR] final link did not contain Kafka input' >&2; exit 72; }
  local_trace="\$(mktemp "\${TMPDIR:-/tmp}/wtp184-ld-final.XXXXXX")"
  scratch_files+=("\$local_trace")
  set +e
  "\$REAL_LD" -t "\${link_args[@]}" "\${args[@]}" >"\$local_trace" 2>&1
  rc=\$?
  set -e
  cat "\$local_trace"
  [[ "\$rc" -eq 0 ]] || exit "\$rc"
  selected_inputs=(libstdc++.so libgcc_s.so librdkafka.so)
  if [[ "\$REQUIRE_ONNX" -eq 1 ]]; then
    selected_inputs+=(libonnxruntime.so.1.14.0)
  fi
  for selected in "\${selected_inputs[@]}"; do
    grep -Fq "\$VIEW/\$selected" "\$local_trace" || {
      echo "[ERROR] package linker provenance missing: \$selected" >&2
      exit 73
    }
  done
  if grep -E '_solib_k8/.*(onnxruntime|librdkafka)' "\$local_trace" >/dev/null; then
    echo '[ERROR] targeted DSO linked from Bazel _solib_k8 instead of selected package view' >&2
    exit 74
  fi
  printf 'PACKAGE_FINAL_LINK=PASS\n'
  printf 'PACKAGE_VIEW=%s\n' "\$VIEW"
  printf 'ONNX_REPLACEMENT_SEEN=%s\n' "\$onnx_seen"
  printf 'KAFKA_REPLACEMENT_SEEN=%s\n' "\$kafka_seen"
  exit 0
fi
exec "\$REAL_LD" "\${link_args[@]}" "\${args[@]}"
EOF
    chmod 700 "$PACKAGE_LINKER_PREFIX/$linker_name"
    /bin/bash -n "$PACKAGE_LINKER_PREFIX/$linker_name" || \
      die "generated package linker interposer has invalid syntax: $linker_name"
  done
}

prepare_package_profile_libraries() {
  package_profile_enabled || return 0

  log "===== DEBUG/RELEASE PACKAGE LIBRARY PREFLIGHT ====="
  log "PACKAGE_LIBRARY_DIR=$PACKAGE_LIBRARY_DIR"
  [[ -d "$PACKAGE_LIBRARY_DIR" ]] || die "package library directory missing: $PACKAGE_LIBRARY_DIR"

  validate_package_library "$PACKAGE_LIBSTDCPP" "$PACKAGE_LIBSTDCPP_SHA256" libstdc++.so.6
  validate_package_library "$PACKAGE_LIBGCC" "$PACKAGE_LIBGCC_SHA256" libgcc_s.so.1
  if ! is_v3_build; then
    validate_package_library "$PACKAGE_ONNXRUNTIME" "$PACKAGE_ONNXRUNTIME_SHA256" libonnxruntime.so.1.14.0
  fi
  validate_package_library "$PACKAGE_RDKAFKA" "$PACKAGE_RDKAFKA_SHA256" librdkafka.so.1
  validate_package_library "$PACKAGE_SASL" "$PACKAGE_SASL_SHA256" libsasl2.so.3
  validate_package_library "$PACKAGE_SSL" "$PACKAGE_SSL_SHA256" libssl.so.10

  PACKAGE_PROFILE_TMP="$(mktemp -d "$PACKAGE_ROOT/.wtp184-profile-libs.XXXXXX")"
  PACKAGE_LIBRARY_VIEW="$PACKAGE_PROFILE_TMP/selected"
  PACKAGE_LINKER_PREFIX="$PACKAGE_PROFILE_TMP/linker"
  mkdir -m 700 "$PACKAGE_LIBRARY_VIEW" "$PACKAGE_LINKER_PREFIX"
  trap cleanup_package_profile_libraries EXIT

  ln -s "$PACKAGE_LIBSTDCPP" "$PACKAGE_LIBRARY_VIEW/libstdc++.so"
  ln -s "$PACKAGE_LIBSTDCPP" "$PACKAGE_LIBRARY_VIEW/libstdc++.so.6"
  ln -s "$PACKAGE_LIBGCC" "$PACKAGE_LIBRARY_VIEW/libgcc_s.so"
  ln -s "$PACKAGE_LIBGCC" "$PACKAGE_LIBRARY_VIEW/libgcc_s.so.1"
  if ! is_v3_build; then
    ln -s "$PACKAGE_ONNXRUNTIME" "$PACKAGE_LIBRARY_VIEW/libonnxruntime.so"
    ln -s "$PACKAGE_ONNXRUNTIME" "$PACKAGE_LIBRARY_VIEW/libonnxruntime.so.1.14.0"
  fi
  ln -s "$PACKAGE_RDKAFKA" "$PACKAGE_LIBRARY_VIEW/librdkafka.so"
  ln -s "$PACKAGE_RDKAFKA" "$PACKAGE_LIBRARY_VIEW/librdkafka.so.1"
  ln -s "$PACKAGE_SASL" "$PACKAGE_LIBRARY_VIEW/libsasl2.so.3"
  ln -s "$PACKAGE_SSL" "$PACKAGE_LIBRARY_VIEW/libssl.so.10"

  local -a manifest_lines=(
    "libstdc++.so.6=$PACKAGE_LIBSTDCPP_SHA256"
    "libgcc_s.so.1=$PACKAGE_LIBGCC_SHA256"
    "librdkafka.so.1=$PACKAGE_RDKAFKA_SHA256"
    "libsasl2.so.3=$PACKAGE_SASL_SHA256"
    "libssl.so.10=$PACKAGE_SSL_SHA256"
  )
  if ! is_v3_build; then
    manifest_lines+=("libonnxruntime.so.1.14.0=$PACKAGE_ONNXRUNTIME_SHA256")
  fi
  PACKAGE_MANIFEST_SHA256="$(printf '%s\n' "${manifest_lines[@]}" | sha256sum | awk '{print $1}')"

  write_package_linker_interposer
  PACKAGE_PROFILE_ACTIVE=1

  log "PACKAGE_LIBRARY_POLICY=selected-debug-release-only"
  log "PACKAGE_MANIFEST_SHA256=$PACKAGE_MANIFEST_SHA256"
  log "PACKAGE_LIBRARY_VIEW=$PACKAGE_LIBRARY_VIEW"
  log "PACKAGE_LINKER_PREFIX=$PACKAGE_LINKER_PREFIX"
  log "[OK] selected package-library view and linker interposer prepared"
}

validate_package_link_provenance() {
  local build_log="$1"
  [[ "$PACKAGE_PROFILE_ACTIVE" == "1" ]] || return 0
  [[ -s "$build_log" ]] || die "Bazel build log missing for package link provenance: $build_log"
  grep -Fq 'PACKAGE_FINAL_LINK=PASS' "$build_log" || \
    die "package final-link provenance marker missing"
  local -a selected_inputs=(libstdc++.so libgcc_s.so librdkafka.so)
  if is_v3_build; then
    grep -Fq 'ONNX_REPLACEMENT_SEEN=0' "$build_log" || \
      die "V3 package link unexpectedly contains ONNX Runtime"
  else
    grep -Fq 'ONNX_REPLACEMENT_SEEN=1' "$build_log" || \
      die "package ONNX final-link provenance missing"
    selected_inputs+=(libonnxruntime.so.1.14.0)
  fi
  grep -Fq 'KAFKA_REPLACEMENT_SEEN=1' "$build_log" || \
    die "package Kafka final-link provenance missing"
  local selected
  for selected in "${selected_inputs[@]}"; do
    grep -Fq "$PACKAGE_LIBRARY_VIEW/$selected" "$build_log" || \
      die "package linker trace missing selected input: $selected"
  done
  log "[OK] final link selected package libstdc++, libgcc_s, Kafka; variant=$DIALOGUE_PIPELINE_VARIANT"
}

validate_package_runtime_closure() {
  local elf="$1"
  [[ "$PACKAGE_PROFILE_ACTIVE" == "1" ]] || return 0

  log "===== SELECTED PACKAGE RUNTIME CLOSURE ====="
  local loader="$WTP184_SYSROOT/lib64/ld-linux-x86-64.so.2"
  [[ -x "$loader" ]] || die "target loader missing/not executable: $loader"

  local output rc
  set +e
  output="$(
    env -u LD_LIBRARY_PATH -u LD_PRELOAD -u LD_AUDIT LD_BIND_NOW=1 LD_WARN=1 \
      "$loader" \
      --library-path "$PACKAGE_LIBRARY_VIEW:$WTP184_SYSROOT/lib64:$WTP184_SYSROOT/usr/lib64" \
      --list "$elf" 2>&1
  )"
  rc=$?
  set -e
  printf '%s\n' "$output" | tee -a "$LOG_FILE"
  [[ "$rc" -eq 0 ]] || die "target-loader selected closure failed rc=$rc"
  if grep -Eqi 'not found|undefined symbol|version .* not found' <<<"$output"; then
    die "target-loader selected closure contains unresolved dependency/symbol/version"
  fi

  local -a expected_sonames=(libstdc++.so.6 libgcc_s.so.1 librdkafka.so.1 libsasl2.so.3 libssl.so.10)
  if ! is_v3_build; then
    expected_sonames+=(libonnxruntime.so.1.14.0)
  fi
  local soname
  for soname in "${expected_sonames[@]}"; do
    grep -F "$soname => $PACKAGE_LIBRARY_VIEW/$soname" <<<"$output" >/dev/null || \
      die "package-owned SONAME did not resolve through selected view: $soname"
  done

  local resolved
  while IFS= read -r resolved; do
    [[ -n "$resolved" ]] || continue
    case "$resolved" in
      "$PACKAGE_LIBRARY_VIEW"/*|"$WTP184_SYSROOT"/*) ;;
      *) die "selected closure escaped package view/sysroot: $resolved" ;;
    esac
  done < <(printf '%s\n' "$output" | sed -n 's/.*=> \([^ (]*\).*/\1/p' | grep '^/' || true)

  if grep -E '_solib_k8.*(onnxruntime|librdkafka)' <<<"$output" >/dev/null; then
    die "selected closure fell back to Bazel _solib_k8"
  fi

  local required_glibcxx required_cxxabi provided_glibcxx provided_cxxabi
  required_glibcxx="$(elf_max_version_requirement "$elf" GLIBCXX)"
  required_cxxabi="$(elf_max_version_requirement "$elf" CXXABI)"
  provided_glibcxx="$(elf_max_version_provided "$PACKAGE_LIBSTDCPP" GLIBCXX)"
  provided_cxxabi="$(elf_max_version_provided "$PACKAGE_LIBSTDCPP" CXXABI)"
  [[ -n "$required_glibcxx" && -n "$provided_glibcxx" ]] || die "unable to compare GLIBCXX contract"
  [[ -n "$required_cxxabi" && -n "$provided_cxxabi" ]] || die "unable to compare CXXABI contract"
  version_le "$required_glibcxx" "$provided_glibcxx" || \
    die "final ELF requires GLIBCXX_$required_glibcxx but package provides only GLIBCXX_$provided_glibcxx"
  version_le "$required_cxxabi" "$provided_cxxabi" || \
    die "final ELF requires CXXABI_$required_cxxabi but package provides only CXXABI_$provided_cxxabi"

  if nm -D -C "$elf" 2>/dev/null | grep -F 'std::__cxx11' >/dev/null; then
    die "final ELF unexpectedly depends on the GCC5 std::__cxx11 ABI"
  fi
  log "[OK] selected package closure: GLIBCXX required=$required_glibcxx provided=$provided_glibcxx; CXXABI required=$required_cxxabi provided=$provided_cxxabi"
}

ssh_base_args() {
  SSH_ARGS=(
    -p "$TARGET_PORT"
    -o ConnectTimeout="$SSH_CONNECT_TIMEOUT"
    -o ServerAliveInterval=15
    -o ServerAliveCountMax=2
  )

  if [[ -n "$SSH_IDENTITY" ]]; then
    SSH_ARGS+=(-i "$SSH_IDENTITY")
  fi

  # Important: argument-builder helpers must always return success.
  # With `set -e`, a final `[[ ... ]] && ...` would return 1 when
  # SSH_IDENTITY is empty and terminate callers such as sync_artifacts().
  return 0
}

ssh_batch_args() {
  ssh_base_args || return $?
  SSH_BATCH_ARGS=("${SSH_ARGS[@]}" -o BatchMode=yes)
  return 0
}

rsync_ssh_string() {
  ssh_base_args || return $?
  local out="ssh"
  local arg
  for arg in "${SSH_ARGS[@]}"; do
    printf -v out '%s %q' "$out" "$arg"
  done
  printf '%s' "$out"
  return 0
}

usage() {
  cat <<'EOF'
Usage:
  ./cu-dev-pipeline.sh diagnose
  ./cu-dev-pipeline.sh setup-ssh
  ./cu-dev-pipeline.sh build [--clean] [--message "note"] [--dry-run]  # release profile
  ./cu-dev-pipeline.sh debug_build [--clean] [--message "note"] [--dry-run]
  ./cu-dev-pipeline.sh release_build [--clean] [--message "note"] [--dry-run]
  ./cu-dev-pipeline.sh v3_build [--clean] [--message "note"] [--dry-run]  # V3 release alias
  ./cu-dev-pipeline.sh v3_debug_build [--clean] [--message "note"] [--dry-run]
  ./cu-dev-pipeline.sh v3_debug_deploy [--dry-run]  # deploy current V3 debug package
  ./cu-dev-pipeline.sh v3_release_build [--clean] [--message "note"] [--dry-run]
  ./cu-dev-pipeline.sh asan_build [--clean] [--message "note"] [--dry-run]
  ./cu-dev-pipeline.sh sync
  ./cu-dev-pipeline.sh deploy       # sync + deploy + verify current LATEST
  ./cu-dev-pipeline.sh v3_debug_deploy --model-dir DIR --project-name NAME
    --description TEXT --service-port PORT --server-version server-v3-debug.TIMESTAMP-SHA

Deployment options: --model-dir (REMOTE_MODEL_DIR), --service-port (TEST_PORT),
 --server-version (SERVER_VERSION; exact V3 debug executable, not an image tag).
 --project-name / --description opt in to post-verification webpage publication.
 Environment equivalents: DEPLOY_PROJECT_NAME / DEPLOY_DESCRIPTION (presence opts in).
 Display defaults to model basename; description defaults empty. Existing defaults remain.
 Metadata failure exits 50 after verified runtime; no Redis-only rollback.
 CentOS client settings are METADATA_PYTHON / METADATA_REDIS_* in helper environment.
 Existing web GET overwrite race and arbitrary-description push quoting remain unfixed.
  ./cu-dev-pipeline.sh debug_all [--clean] [--message "note"] [--dry-run]
  ./cu-dev-pipeline.sh release_all [--clean] [--message "note"] [--dry-run]
  ./cu-dev-pipeline.sh test_2w_non_stream [--dry-run]
  ./cu-dev-pipeline.sh test_multi_round [--dry-run]
  ./cu-dev-pipeline.sh test_2w_stream [--dry-run]
  ./cu-dev-pipeline.sh test
  ./cu-dev-pipeline.sh compare
  ./cu-dev-pipeline.sh rollback   # unsupported in auto_build mode; exits with explanation
  ./cu-dev-pipeline.sh all [--clean] [--message "note"]
  ./cu-dev-pipeline.sh watch-sync
  ./cu-dev-pipeline.sh install-sync-service
  ./cu-dev-pipeline.sh uninstall-sync-service
  ./cu-dev-pipeline.sh status

Environment overrides:
  GCC_HOME=/home/daigd/tools/gcc-4.9.3-centos7
  USE_SYSROOT=1
  WTP184_SYSROOT=/home/daigd/sysroots/wtp184-centos7
  MAX_TARGET_GLIBC=2.17
  BAZEL_CC_WRAPPER_ROOT=/home/daigd/tools/wtp184-gcc493-sysroot
  STRIP_BIN=strip
  PACKAGE_LIBRARY_DIR=/home/daigd/packages/lib
  THIRD_PARTY_DIR=/home/daigd/workspaces/third_party
  BAZEL_CPU=k8
  BAZEL_HOST_CPU=k8
  BAZEL_DEBUG_MODE=0
  BAZEL_RELEASE_MODE=0
  BAZEL_ASAN_MODE=0
  ALLOW_SHLIB_UNDEFINED=1
  WTP184_CONCURRENCY=4
  WTP184_MONITOR_SSH=daigd@10.1.122.21
  WTP184_HISTORY_CASE_ID=C005_case1_car_info_tire_pressure
  TARGET_USER=daigd
  TARGET_HOST=10.1.122.21
  REMOTE_PACKAGE_ROOT=/home/daigd/packages
  REMOTE_ARTIFACT_DIR=/home/daigd/packages/server
  REMOTE_AUTO_BUILD=/home/daigd/packages/auto_build.sh
  REMOTE_MODEL_DIR=/home/shared/models/car_v2.0
  TEST_PORT=9530
  BASELINE_PORT=9999
  TEST_QUERY="打开空调"
EOF
}

# ------------------------------------------------------------------------------
# 2. GCC 4.9.3 resolution and Bazel build
# ------------------------------------------------------------------------------

version_le() {
  local a="$1" b="$2"
  [[ -n "$a" && -n "$b" ]] || return 1
  [[ "$(printf '%s\n%s\n' "$a" "$b" | sort -V | head -n1)" == "$a" ]]
}

elf_max_glibc_requirement() {
  local elf="$1"
  local versions=""

  if have readelf; then
    versions="$(
      readelf --version-info "$elf" 2>/dev/null \
        | grep -Eo 'GLIBC_[0-9]+(\.[0-9]+)+' \
        | sed 's/^GLIBC_//' \
        | sort -Vu \
        || true
    )"
  fi

  if [[ -z "$versions" ]] && have strings; then
    versions="$(
      strings "$elf" 2>/dev/null \
        | grep -Eo 'GLIBC_[0-9]+(\.[0-9]+)+' \
        | sed 's/^GLIBC_//' \
        | sort -Vu \
        || true
    )"
  fi

  printf '%s\n' "$versions" | sed '/^$/d' | tail -n1
}

elf_max_version_requirement() {
  local elf="$1" prefix="$2"
  local versions=""

  if have readelf; then
    versions="$(
      readelf --version-info "$elf" 2>/dev/null \
        | grep -Eo "${prefix}_[0-9]+(\.[0-9]+)+" \
        | sed "s/^${prefix}_//" \
        | sort -Vu \
        || true
    )"
  fi

  printf '%s\n' "$versions" | sed '/^$/d' | tail -n1
}

elf_max_version_provided() {
  local elf="$1" prefix="$2"
  local versions=""

  if have strings; then
    versions="$(
      strings "$elf" 2>/dev/null \
        | grep -Eo "${prefix}_[0-9]+(\.[0-9]+)+" \
        | sed "s/^${prefix}_//" \
        | sort -Vu \
        || true
    )"
  fi

  printf '%s\n' "$versions" | sed '/^$/d' | tail -n1
}

sysroot_glibc_max() {
  local versions=""

  for f in \
    "$WTP184_SYSROOT/lib64/libc.so.6" \
    "$WTP184_SYSROOT/lib64/libm.so.6"; do
    [[ -e "$f" ]] || continue

    if have strings; then
      strings "$f" 2>/dev/null \
        | grep -Eo 'GLIBC_[0-9]+(\.[0-9]+)+' \
        | sed 's/^GLIBC_//' \
        || true
    fi
  done | sort -Vu | tail -n1
}

validate_sysroot() {
  [[ "$USE_SYSROOT" == "1" ]] || {
    log "[WARN] USE_SYSROOT=$USE_SYSROOT; target build will use server 40 host ABI"
    return 0
  }

  log "===== SYSROOT PREFLIGHT ====="
  log "WTP184_SYSROOT=$WTP184_SYSROOT"
  log "MAX_TARGET_GLIBC=$MAX_TARGET_GLIBC"

  [[ -d "$WTP184_SYSROOT" ]] || {
    cat >&2 <<EOF
[ERROR] WTP184 sysroot is missing:

  $WTP184_SYSROOT

Create/sync it from server 21 first:
  ~/sync-wtp184-sysroot-21-to-40.sh
EOF
    return 1
  }

  local required=(
    "$WTP184_SYSROOT/lib64/libc.so.6"
    "$WTP184_SYSROOT/lib64/libm.so.6"
    "$WTP184_SYSROOT/lib64/ld-linux-x86-64.so.2"
    "$WTP184_SYSROOT/usr/include/stdio.h"
    "$WTP184_SYSROOT/usr/include/features.h"
    "$WTP184_SYSROOT/usr/lib64/crt1.o"
    "$WTP184_SYSROOT/usr/lib64/crti.o"
    "$WTP184_SYSROOT/usr/lib64/crtn.o"
    "$WTP184_SYSROOT/usr/lib64/libc.so"
    "$WTP184_SYSROOT/usr/lib64/libc_nonshared.a"
    "$WTP184_SYSROOT/.wtp184/provenance.txt"
  )

  local f
  for f in "${required[@]}"; do
    if [[ ! -e "$f" ]]; then
      echo "[ERROR] sysroot required file missing: $f" >&2
      return 1
    fi
  done

  local source_host source_os source_ver glibc_pkg identity
  source_host="$(sed -n 's/^SOURCE_HOST=//p' "$WTP184_SYSROOT/.wtp184/provenance.txt" | tail -n1)"
  source_os="$(sed -n 's/^SOURCE_OS=//p' "$WTP184_SYSROOT/.wtp184/provenance.txt" | tail -n1)"
  source_ver="$(sed -n 's/^SOURCE_OS_VERSION=//p' "$WTP184_SYSROOT/.wtp184/provenance.txt" | tail -n1)"
  glibc_pkg="$(sed -n 's/^GLIBC_PKG=//p' "$WTP184_SYSROOT/.wtp184/provenance.txt" | tail -n1)"
  identity="$(
    sed -n -e 's/^TOOLCHAIN_IDENTITY=//p' -e 's/^SYSROOT_IDENTITY=//p'       "$WTP184_SYSROOT/.wtp184/provenance.txt" | tail -n1
  )"

  log "SYSROOT_SOURCE_HOST=${source_host:-unknown}"
  log "SYSROOT_SOURCE_OS=${source_os:-unknown} ${source_ver:-unknown}"
  log "SYSROOT_GLIBC_PKG=${glibc_pkg:-unknown}"
  log "SYSROOT_IDENTITY=${identity:-unknown}"

  local max
  max="$(sysroot_glibc_max)"
  [[ -n "$max" ]] || {
    echo "[ERROR] unable to determine sysroot GLIBC baseline" >&2
    return 1
  }

  log "SYSROOT_GLIBC_MAX=$max"

  if ! version_le "$max" "$MAX_TARGET_GLIBC"; then
    echo "[ERROR] sysroot GLIBC_$max exceeds target GLIBC_$MAX_TARGET_GLIBC" >&2
    return 1
  fi

  log "[OK] sysroot ABI preflight passed"
  return 0
}

validate_built_abi() {
  local elf="$1"

  [[ "$USE_SYSROOT" == "1" ]] || {
    log "[WARN] skipping target GLIBC ceiling because USE_SYSROOT != 1"
    return 0
  }

  log "===== TARGET ABI GATE ====="

  local max
  max="$(elf_max_glibc_requirement "$elf")"

  [[ -n "$max" ]] || die "could not determine GLIBC requirement of built ELF: $elf"

  log "BUILT_ELF_GLIBC_MAX=$max"
  log "MAX_TARGET_GLIBC=$MAX_TARGET_GLIBC"

  if ! version_le "$max" "$MAX_TARGET_GLIBC"; then
    cat >&2 <<EOF
[ERROR] Built cu-server requires GLIBC_$max, which is newer than the allowed
server-21 baseline GLIBC_$MAX_TARGET_GLIBC.

Artifact packaging/sync/deploy is blocked.

Check whether the final Bazel link actually received:
  --sysroot=$WTP184_SYSROOT
and verify crt/libc resolution against the sysroot.
EOF
    return 1
  fi

  log "[OK] built ELF GLIBC requirement <= GLIBC_$MAX_TARGET_GLIBC"
  return 0
}

validate_migrated_gcc_runtime() {
  local gcc="$GCC_HOME/bin/gcc"
  local gxx="$GCC_HOME/bin/g++"

  log "===== MIGRATED GCC 4.9.3 PREFLIGHT ====="
  log "GCC_HOME=$GCC_HOME"

  [[ -x "$gcc" ]] || {
    echo "[ERROR] migrated gcc missing: $gcc" >&2
    echo "Run first: ~/sync-wtp184-toolchain-21-to-40-v2.sh" >&2
    return 1
  }
  [[ -x "$gxx" ]] || {
    echo "[ERROR] migrated g++ missing: $gxx" >&2
    return 1
  }

  [[ "$("$gcc" -dumpversion 2>/dev/null)" == "4.9.3" ]] || {
    echo "[ERROR] migrated gcc is not 4.9.3" >&2
    return 1
  }
  [[ "$("$gcc" -dumpmachine 2>/dev/null)" == "x86_64-unknown-linux-gnu" ]] || {
    echo "[ERROR] migrated gcc target mismatch: $("$gcc" -dumpmachine 2>/dev/null)" >&2
    return 1
  }

  local cc1 cc1plus collect2 libgcc libstdcpp
  cc1="$("$gcc" -print-prog-name=cc1)"
  cc1plus="$("$gxx" -print-prog-name=cc1plus)"
  collect2="$("$gcc" -print-prog-name=collect2)"
  libgcc="$("$gcc" -print-file-name=libgcc_s.so.1)"
  libstdcpp="$("$gxx" -print-file-name=libstdc++.so)"

  log "CC1=$cc1"
  log "CC1PLUS=$cc1plus"
  log "COLLECT2=$collect2"
  log "LIBGCC=$libgcc"
  log "LIBSTDCPP=$libstdcpp"

  local f resolved
  for f in "$cc1" "$cc1plus" "$collect2" "$libgcc" "$libstdcpp"; do
    [[ -e "$f" || -L "$f" ]] || {
      echo "[ERROR] migrated GCC component missing: $f" >&2
      return 1
    }
    resolved="$(readlink -f "$f")"
    case "$resolved" in
      "$GCC_HOME"/*) ;;
      *)
        echo "[ERROR] GCC component escaped migrated prefix:" >&2
        echo "  $f -> $resolved" >&2
        echo "This could silently reuse server40's old GCC runtime." >&2
        return 1
        ;;
    esac
  done

  local max
  for f in "$gcc" "$cc1" "$cc1plus" "$libgcc" "$(readlink -f "$libstdcpp")"; do
    max="$(elf_max_version_requirement "$f" GLIBC)"
    log "GCC_COMPONENT_GLIBC_MAX ${f}=${max:-UNKNOWN}"
    if [[ -n "$max" ]] && ! version_le "$max" "$MAX_TARGET_GLIBC"; then
      echo "[ERROR] migrated GCC component requires GLIBC_$max > GLIBC_$MAX_TARGET_GLIBC: $f" >&2
      return 1
    fi
  done

  local glibcxx cxxabi
  glibcxx="$(elf_max_version_provided "$(readlink -f "$libstdcpp")" GLIBCXX)"
  cxxabi="$(elf_max_version_provided "$(readlink -f "$libstdcpp")" CXXABI)"

  log "MIGRATED_LIBSTDCPP_GLIBCXX_MAX=${glibcxx:-UNKNOWN}"
  log "MIGRATED_LIBSTDCPP_CXXABI_MAX=${cxxabi:-UNKNOWN}"

  if [[ -f "$GCC_HOME/.wtp184/provenance.txt" ]]; then
    log "GCC provenance:"
    sed 's/^/  /' "$GCC_HOME/.wtp184/provenance.txt" | tee -a "$LOG_FILE"
  else
    log "[WARN] GCC provenance missing: $GCC_HOME/.wtp184/provenance.txt"
  fi

  log "[OK] migrated GCC runtime preflight passed"
  return 0
}

resolve_gcc() {
  local gcc="$GCC_HOME/bin/gcc"
  local gxx="$GCC_HOME/bin/g++"

  if [[ ! -x "$gcc" || ! -x "$gxx" ]]; then
    cat >&2 <<EOF
[ERROR] GCC 4.9.3 executables were not found under:

  GCC_HOME=$GCC_HOME
  expected:
    $gcc
    $gxx

The pipeline requires the GCC 4.9.3 toolchain migrated from server 21.

Create it first:
  ~/sync-wtp184-toolchain-21-to-40-v2.sh

Expected:
  /home/daigd/tools/gcc-4.9.3-centos7

No fallback to /home/daigd/tools/gcc-4.9.3 or /usr/bin/gcc is performed.
EOF
    return 1
  fi

  local version
  version="$("$gcc" -dumpversion 2>/dev/null || true)"
  [[ "$version" == 4.9.3* ]] || {
    echo "[ERROR] $gcc is not GCC 4.9.3; -dumpversion returned: $version" >&2
    return 1
  }

  CC_PATH="$gcc"
  CXX_PATH="$gxx"
}

write_atomic_executable() {
  local dst="$1"
  local content="$2"
  local dir tmp

  dir="$(dirname "$dst")"
  mkdir -p "$dir"
  tmp="${dst}.tmp.$$"

  printf '%s' "$content" > "$tmp"
  chmod 755 "$tmp"
  mv -f "$tmp" "$dst"
}

prepare_bazel_cc_wrappers() {
  log "===== BAZEL 1.2.1 SYSROOT COMPILER WRAPPERS ====="

  [[ -x "$CC_PATH" ]] || {
    echo "[ERROR] underlying gcc missing: $CC_PATH" >&2
    return 1
  }
  [[ -x "$CXX_PATH" ]] || {
    echo "[ERROR] underlying g++ missing: $CXX_PATH" >&2
    return 1
  }

  local gcc_content gxx_content
  gcc_content="$(cat <<EOF
#!/usr/bin/env bash
set -e
extra=()
if [[ -n "\${WTP184_PACKAGE_LINKER_PREFIX:-}" ]]; then
  [[ -x "\${WTP184_PACKAGE_LINKER_PREFIX}/ld" ]] || exit 86
  extra+=("-B\${WTP184_PACKAGE_LINKER_PREFIX}/")
fi
exec "$CC_PATH" \
  --sysroot="$WTP184_SYSROOT" \
  "\${extra[@]}" \
  -B"$WTP184_SYSROOT/usr/lib64/" \
  -B"$WTP184_SYSROOT/lib64/" \
  "\$@"
EOF
)"
  gxx_content="$(cat <<EOF
#!/usr/bin/env bash
set -e
extra=()
if [[ -n "\${WTP184_PACKAGE_LINKER_PREFIX:-}" ]]; then
  [[ -x "\${WTP184_PACKAGE_LINKER_PREFIX}/ld" ]] || exit 86
  extra+=("-B\${WTP184_PACKAGE_LINKER_PREFIX}/")
fi
exec "$CXX_PATH" \
  --sysroot="$WTP184_SYSROOT" \
  "\${extra[@]}" \
  -B"$WTP184_SYSROOT/usr/lib64/" \
  -B"$WTP184_SYSROOT/lib64/" \
  "\$@"
EOF
)"

  write_atomic_executable "$BAZEL_CC_WRAPPER" "$gcc_content"
  write_atomic_executable "$BAZEL_CXX_WRAPPER" "$gxx_content"

  log "BAZEL_CC_WRAPPER=$BAZEL_CC_WRAPPER"
  log "BAZEL_CXX_WRAPPER=$BAZEL_CXX_WRAPPER"

  local crt1 libc_link libstdcpp
  crt1="$("$BAZEL_CC_WRAPPER" -print-file-name=crt1.o)"
  libc_link="$("$BAZEL_CC_WRAPPER" -print-file-name=libc.so)"
  libstdcpp="$("$BAZEL_CXX_WRAPPER" -print-file-name=libstdc++.so)"

  log "WRAPPER_SYSROOT=$("$BAZEL_CC_WRAPPER" -print-sysroot 2>/dev/null || true)"
  log "WRAPPER_CRT1=$crt1"
  log "WRAPPER_LIBC_SO=$libc_link"
  log "WRAPPER_LIBSTDCPP=$libstdcpp"

  if [[ "$DEBUG" == "1" ]]; then
    "$BAZEL_CC_WRAPPER" -print-search-dirs 2>&1 |       sed 's/^/[WRAPPER SEARCH] /' | tee -a "$LOG_FILE" || true
  fi

  local printed_sysroot
  printed_sysroot="$("$BAZEL_CC_WRAPPER" -print-sysroot 2>/dev/null || true)"
  if [[ "$printed_sysroot" != "$WTP184_SYSROOT" ]]; then
    echo "[ERROR] wrapper -print-sysroot mismatch:" >&2
    echo "  expected=$WTP184_SYSROOT" >&2
    echo "  actual=${printed_sysroot:-EMPTY}" >&2
    return 1
  fi

  case "$(readlink -f "$crt1" 2>/dev/null || printf '%s' "$crt1")" in
    "$WTP184_SYSROOT"/*) ;;
    *)
      echo "[ERROR] wrapper crt1.o escaped sysroot: $crt1" >&2
      return 1
      ;;
  esac

  case "$(readlink -f "$libc_link" 2>/dev/null || printf '%s' "$libc_link")" in
    "$WTP184_SYSROOT"/*) ;;
    *)
      echo "[ERROR] wrapper libc.so escaped sysroot: $libc_link" >&2
      return 1
      ;;
  esac

  case "$(readlink -f "$libstdcpp" 2>/dev/null || printf '%s' "$libstdcpp")" in
    "$GCC_HOME"/*) ;;
    *)
      echo "[ERROR] wrapper libstdc++.so escaped migrated GCC_HOME: $libstdcpp" >&2
      return 1
      ;;
  esac

  local raw
  raw="$(
    LC_ALL=C LANG=C "$BAZEL_CC_WRAPPER" \
      -E -xc - -v </dev/null 2>&1 || true
  )"

  if [[ "$DEBUG" == "1" ]]; then
    while IFS= read -r line; do
      log "WRAPPER_GCC_V $line"
    done <<< "$raw"
  fi

  if ! printf '%s\n' "$raw" | grep -Fq "$WTP184_SYSROOT/usr/include"; then
    echo "[ERROR] wrapper GCC does not report target sysroot /usr/include:" >&2
    echo "  $WTP184_SYSROOT/usr/include" >&2
    return 1
  fi

  if printf '%s\n' "$raw" \
      | sed -n '/#include <...> search starts here:/,/End of search list./p' \
      | grep -Eq '^[[:space:]]*/usr/include[[:space:]]*$'; then
    echo "[ERROR] wrapper GCC still reports server40 host /usr/include" >&2
    return 1
  fi

  log "[OK] compiler wrappers use target sysroot and migrated C++ runtime"
  return 0
}

refresh_and_validate_local_config_cc() {
  log "===== BAZEL 1.2.1 LOCAL_CONFIG_CC ====="

  export CC="$BAZEL_CC_WRAPPER"
  export CXX="$BAZEL_CXX_WRAPPER"
  export PATH="$BAZEL_CC_WRAPPER_ROOT/bin:$GCC_HOME/bin:$PATH"

  # Bazel 1.2.1 uses a persistent server. Restart it so cc_autoconf sees the
  # wrapper environment from a clean server process. This does not delete the
  # workspace, third_party, sysroot, compiler, or deployment artifacts.
  (cd "$PROJECT_DIR" && "$BAZEL_BIN" shutdown) >/dev/null 2>&1 || true

  local output_base local_cc builtin_file
  output_base="$(cd "$PROJECT_DIR" && "$BAZEL_BIN" info output_base 2>/dev/null)" || {
    echo "[ERROR] unable to obtain Bazel output_base" >&2
    return 1
  }

  (
    cd "$PROJECT_DIR"
    CC="$BAZEL_CC_WRAPPER" \
    CXX="$BAZEL_CXX_WRAPPER" \
    PATH="$PATH" \
      "$BAZEL_BIN" query '@local_config_cc//...' >/dev/null
  ) || {
    echo "[ERROR] failed to configure/query @local_config_cc" >&2
    return 1
  }

  local_cc="$output_base/external/local_config_cc"
  builtin_file="$local_cc/builtin_include_directory_paths"

  [[ -f "$builtin_file" ]] || {
    echo "[ERROR] missing Bazel builtin include file: $builtin_file" >&2
    return 1
  }

  log "LOCAL_CONFIG_CC=$local_cc"
  log "Builtin include directories:"
  sed 's/^/  /' "$builtin_file" | tee -a "$LOG_FILE"

  if ! grep -Fqx "$WTP184_SYSROOT/usr/include" "$builtin_file"; then
    cat >&2 <<EOF
[ERROR] @local_config_cc does not contain the target sysroot header directory.

Expected:
  $WTP184_SYSROOT/usr/include

Do not patch third_party BUILD files and do not add absolute -isystem flags.
Bazel cc_autoconf must run through:
  $BAZEL_CC_WRAPPER
EOF
    return 1
  fi

  if grep -Eq '^/usr/include/?$' "$builtin_file"; then
    cat >&2 <<EOF
[ERROR] @local_config_cc still contains server40 host /usr/include.
Build is blocked to prevent host/target header mixing.
EOF
    return 1
  fi

  if [[ -f "$local_cc/BUILD" ]]; then
    if grep -Fq "\"gcc\": \"$BAZEL_CC_WRAPPER\"" "$local_cc/BUILD"; then
      log "[OK] local_config_cc gcc tool path = wrapper"
    else
      log "[WARN] generated BUILD does not show exact wrapper gcc path"
      grep -n '"gcc":' "$local_cc/BUILD" | head -5 | tee -a "$LOG_FILE" || true
    fi
  fi

  log "[OK] Bazel builtin includes use target sysroot"
  return 0
}

prepare_gcc_env() {
  resolve_gcc || die "GCC 4.9.3 preflight failed"
  validate_migrated_gcc_runtime || die "migrated GCC runtime preflight failed"
  validate_sysroot || die "sysroot preflight failed"
  prepare_bazel_cc_wrappers || die "failed to prepare Bazel sysroot compiler wrappers"

  export CC="$BAZEL_CC_WRAPPER"
  export CXX="$BAZEL_CXX_WRAPPER"
  export PATH="$BAZEL_CC_WRAPPER_ROOT/bin:$GCC_HOME/bin:$PATH"

  log "Underlying GCC=$CC_PATH"
  log "Underlying G++=$CXX_PATH"
  log "Bazel CC=$CC"
  log "Bazel CXX=$CXX"
  log "gcc version=$("$CC" --version | head -1)"
  log "g++ version=$("$CXX" --version | head -1)"

  if [[ "$USE_SYSROOT" == "1" ]]; then
    log "Target sysroot=$WTP184_SYSROOT"
    log "Target GLIBC ceiling=$MAX_TARGET_GLIBC"
  fi
}

maybe_reset_bazel_toolchain_cache() {
  local marker="$PROJECT_DIR/.cu-dev-last-gcc"
  local sysroot_identity="none"

  if [[ "$USE_SYSROOT" == "1" && -f "$WTP184_SYSROOT/.wtp184/provenance.txt" ]]; then
    sysroot_identity="$(
      sed -n -e 's/^TOOLCHAIN_IDENTITY=//p' -e 's/^SYSROOT_IDENTITY=//p'         "$WTP184_SYSROOT/.wtp184/provenance.txt" | tail -n1
    )"
  fi

  local gcc_identity="unknown"
  if [[ -f "$GCC_HOME/.wtp184/provenance.txt" ]]; then
    gcc_identity="$(
      sed -n 's/^TOOLCHAIN_IDENTITY=//p' "$GCC_HOME/.wtp184/provenance.txt" | tail -n1
    )"
  fi

  local libstdcpp="$("$CXX_PATH" -print-file-name=libstdc++.so)"
  local libstdcpp_sha="unknown"
  if [[ -f "$(readlink -f "$libstdcpp")" ]]; then
    libstdcpp_sha="$(sha256_file "$(readlink -f "$libstdcpp")")"
  fi

  local wrapper_sha="unknown"
  if [[ -f "$BAZEL_CC_WRAPPER" ]]; then
    wrapper_sha="$(sha256_file "$BAZEL_CC_WRAPPER")"
  fi

  local current="$BAZEL_CC_WRAPPER|$("$CC_PATH" -dumpversion)|wrapper=$wrapper_sha|gccid=$gcc_identity|libstdcpp=$libstdcpp_sha|sysroot=$USE_SYSROOT:$sysroot_identity|max_glibc=$MAX_TARGET_GLIBC"

  if [[ "$CLEAN" -eq 1 ]]; then
    log "Explicit --clean requested -> bazel clean"
    (cd "$PROJECT_DIR" && "$BAZEL_BIN" clean) 2>&1 | tee -a "$LOG_FILE"
  elif [[ ! -f "$marker" ]] || [[ "$(cat "$marker" 2>/dev/null || true)" != "$current" ]]; then
    log "Compiler/sysroot marker changed -> bazel shutdown before cc_autoconf refresh"
    (cd "$PROJECT_DIR" && "$BAZEL_BIN" shutdown) 2>&1 | tee -a "$LOG_FILE" || true
  fi

  printf '%s\n' "$current" > "$marker"
}

third_party_revision() {
  if [[ -d "$THIRD_PARTY_DIR/.git" ]] && have git; then
    git -C "$THIRD_PARTY_DIR" rev-parse HEAD 2>/dev/null || true
  else
    printf '%s' "not-a-git-repo"
  fi
}

validate_third_party() {
  log "===== THIRD_PARTY PREFLIGHT ====="
  log "THIRD_PARTY_DIR=$THIRD_PARTY_DIR"

  [[ -d "$THIRD_PARTY_DIR" ]] || {
    echo "[ERROR] WTP184 third_party directory is missing:" >&2
    echo "  $THIRD_PARTY_DIR" >&2
    return 1
  }

  # local_repository normally needs a repository marker in older Bazel layouts.
  if [[ ! -f "$THIRD_PARTY_DIR/WORKSPACE" && \
        ! -f "$THIRD_PARTY_DIR/WORKSPACE.bazel" && \
        ! -f "$THIRD_PARTY_DIR/MODULE.bazel" ]]; then
    log "[WARN] third_party has no WORKSPACE/WORKSPACE.bazel/MODULE.bazel marker"
    log "       Bazel may still work with this historical repository layout,"
    log "       but check @third_party if the following build fails."
  fi

  # These are known important dependency families for //cu:server.
  # Do not make every optional library mandatory, but require the tree to have
  # meaningful content and surface important paths when present.
  local top_count
  top_count="$(find "$THIRD_PARTY_DIR" -mindepth 1 -maxdepth 1 -print 2>/dev/null | wc -l)"
  [[ "$top_count" -gt 0 ]] || {
    echo "[ERROR] third_party directory exists but is empty: $THIRD_PARTY_DIR" >&2
    return 1
  }

  local d
  for d in kafka onnxruntime re2 jsoncpp curl xgboost; do
    if [[ -e "$THIRD_PARTY_DIR/$d" ]]; then
      log "[OK] third_party/$d"
    else
      log "[INFO] third_party/$d not found at top level (may be nested or unused)"
    fi
  done

  # Verify the project still declares @third_party. We deliberately do not
  # rewrite WORKSPACE automatically.
  local workspace=""
  [[ -f "$PROJECT_DIR/WORKSPACE" ]] && workspace="$PROJECT_DIR/WORKSPACE"
  [[ -z "$workspace" && -f "$PROJECT_DIR/WORKSPACE.bazel" ]] && workspace="$PROJECT_DIR/WORKSPACE.bazel"

  if [[ -n "$workspace" ]]; then
    if grep -Eq 'name[[:space:]]*=[[:space:]]*"third_party"' "$workspace"; then
      log "[OK] Bazel workspace declares repository name=third_party"
    else
      log "[WARN] no explicit name=\"third_party\" declaration found in $workspace"
    fi
  fi

  log "THIRD_PARTY_REVISION=$(third_party_revision)"
  log "[OK] third_party build dependency tree is present"
  return 0
}

check_linux_bazel_config() {
  local os
  os="$(uname -s 2>/dev/null || true)"
  [[ "$os" == "Linux" ]] || die "this pipeline expects Linux; uname -s=$os"

  log "Linux Bazel profile: --cpu=$BAZEL_CPU --host_cpu=$BAZEL_HOST_CPU"

  local files=()
  [[ -f "$PROJECT_DIR/WORKSPACE" ]] && files+=("$PROJECT_DIR/WORKSPACE")
  [[ -f "$PROJECT_DIR/WORKSPACE.bazel" ]] && files+=("$PROJECT_DIR/WORKSPACE.bazel")
  [[ -f "$PROJECT_DIR/.bazelrc" ]] && files+=("$PROJECT_DIR/.bazelrc")

  local bad=""
  if (( ${#files[@]} > 0 )); then
    bad="$(
      grep -nEH '([A-Za-z]:[/\\]|C:/Users/|AppData/Local/Android)' "${files[@]}" 2>/dev/null         | grep -Ev '^[^:]+:[0-9]+:[[:space:]]*#'         || true
    )"
  fi

  if [[ -n "$bad" ]]; then
    log "===== WINDOWS PATH FOUND IN LINUX BAZEL CONFIG ====="
    printf '%s\n' "$bad" | tee -a "$LOG_FILE"
    cat >&2 <<EOF
[ERROR] Windows absolute path is present in the Linux checkout's Bazel config.

Your current failure shows @androidndk pointing to:
  C:/Users/TINNOVE/AppData/Local/Android/Sdk/ndk/20.1.5948944

Inspect the actual source configuration:
  cd $PROJECT_DIR
  grep -nA6 -B3 -E 'android_ndk_repository|androidndk|C:/Users|AppData/Local/Android' \
    WORKSPACE WORKSPACE.bazel .bazelrc 2>/dev/null

The pipeline will not rewrite WORKSPACE automatically.
Restore/fix the Linux checkout first, then rebuild.

Linux //cu:server is built with:
  --cpu=$BAZEL_CPU --host_cpu=$BAZEL_HOST_CPU
EOF
    return 1
  fi

  return 0
}

inspect_built_elf() {
  local elf="$1"

  [[ -x "$elf" ]] || die "built ELF missing/not executable: $elf"

  log "===== BUILT ELF CHECK ====="

  if have file; then
    file "$elf" | tee -a "$LOG_FILE"
  fi

  if have readelf; then
    log "Dynamic dependencies (NEEDED/RPATH/RUNPATH):"
    readelf -d "$elf" 2>/dev/null \
      | grep -E 'NEEDED|RPATH|RUNPATH' \
      | tee -a "$LOG_FILE" || true

    # Do not ship an ELF with an accidental absolute build-host runtime path.
    if readelf -d "$elf" 2>/dev/null \
        | grep -E 'RPATH|RUNPATH' \
        | grep -Eq '/home/daigd|/home/yydh|bazel-out|execroot'; then
      die "built ELF contains build-host absolute RPATH/RUNPATH"
    fi
  else
    log "[WARN] readelf missing; skipping dynamic-section inspection"
  fi
}

build_server() {
  case "$BAZEL_DEBUG_MODE" in
    0|1) ;;
    *) die "BAZEL_DEBUG_MODE must be 0 or 1" ;;
  esac
  case "$BAZEL_RELEASE_MODE" in
    0|1) ;;
    *) die "BAZEL_RELEASE_MODE must be 0 or 1" ;;
  esac
  case "$BAZEL_ASAN_MODE" in
    0|1) ;;
    *) die "BAZEL_ASAN_MODE must be 0 or 1" ;;
  esac
  (( BAZEL_DEBUG_MODE + BAZEL_RELEASE_MODE + BAZEL_ASAN_MODE <= 1 )) ||
    die "debug, release, and ASan build modes are mutually exclusive"

  local build_profile=default
  if [[ "$BAZEL_DEBUG_MODE" == "1" ]]; then
    build_profile=debug
  elif [[ "$BAZEL_RELEASE_MODE" == "1" ]]; then
    build_profile=release
  elif [[ "$BAZEL_ASAN_MODE" == "1" ]]; then
    build_profile=asan
  fi

  prepare_gcc_env
  prepare_package_profile_libraries

  [[ -d "$PROJECT_DIR" ]] || die "project directory missing: $PROJECT_DIR"
  [[ -f "$PROJECT_DIR/WORKSPACE" || -f "$PROJECT_DIR/WORKSPACE.bazel" ]] || \
    die "not a Bazel workspace: $PROJECT_DIR"

  have "$BAZEL_BIN" || die "bazel not found: $BAZEL_BIN"

  validate_third_party || die "third_party dependency preflight failed"
  check_linux_bazel_config || die "Linux Bazel configuration preflight failed"
  maybe_reset_bazel_toolchain_cache
  refresh_and_validate_local_config_cc || die "Bazel local_config_cc sysroot validation failed"

  local build_log="$BUILD_LOG_DIR/${BUILD_LOG_PREFIX}-$(date '+%Y%m%d-%H%M%S').log"
  log "Bazel log: $build_log"
  log "Building target: $BAZEL_TARGET"
  log "Build third_party: $THIRD_PARTY_DIR"
  log "Dependency policy: build uses local @third_party; deploy packaging is delegated to server21 auto_build.sh"
  log "Shared-library link policy ALLOW_SHLIB_UNDEFINED=$ALLOW_SHLIB_UNDEFINED"
  log "Build profile: $build_profile"

  set +e
  (
    cd "$PROJECT_DIR"
    local -a bazel_args=(
      build
      --verbose_failures
      --cpu="$BAZEL_CPU"
      --host_cpu="$BAZEL_HOST_CPU"
      --action_env="CC=$CC"
      --action_env="CXX=$CXX"
      --action_env="PATH=$PATH"
      --action_env="LD_LIBRARY_PATH="
      --action_env="WTP184_THIRD_PARTY_DIR=$THIRD_PARTY_DIR"
    )

    if is_v3_build; then
      bazel_args+=("--define=$DIALOGUE_PIPELINE_DEFINE")
      log "Dialogue pipeline: variant=$DIALOGUE_PIPELINE_VARIANT --define=$DIALOGUE_PIPELINE_DEFINE"
    fi

    if [[ "$PACKAGE_PROFILE_ACTIVE" == "1" ]]; then
      bazel_args+=(
        "--action_env=WTP184_PACKAGE_LINKER_PREFIX=$PACKAGE_LINKER_PREFIX"
        "--linkopt=-L$PACKAGE_LIBRARY_VIEW"
        "--linkopt=-Wl,-rpath-link,$PACKAGE_LIBRARY_VIEW"
        "--define=wtp184_package_manifest=$PACKAGE_MANIFEST_SHA256"
      )
      log "Package link policy: selected view + linker interposer; manifest=$PACKAGE_MANIFEST_SHA256"
      log "Package loader policy: no global LD_LIBRARY_PATH and no package/temp RPATH"
    fi

    if [[ "$USE_SYSROOT" == "1" ]]; then
      # Sysroot is injected by the stable compiler wrapper. Do not add absolute
      # rule-level -isystem paths: Bazel 1.2.1 rejects those outside execroot.
      log "Sysroot policy: compiler-wrapper/toolchain managed"
      log "  CC=$CC"
      log "  sysroot=$WTP184_SYSROOT"
      log "  GLIBC ceiling=$MAX_TARGET_GLIBC"

      bazel_args+=(
        "--linkopt=-Wl,-rpath-link,$WTP184_SYSROOT/usr/lib64"
        "--linkopt=-Wl,-rpath-link,$WTP184_SYSROOT/lib64"
      )
    else
      log "[WARN] Sysroot policy: DISABLED"
    fi

    if [[ "$ALLOW_SHLIB_UNDEFINED" == "1" ]]; then
      bazel_args+=(--linkopt=-Wl,--allow-shlib-undefined)
      log "Link policy: --allow-shlib-undefined enabled"
      log "Runtime ABI will be validated inside Docker on server 21 before startup"
    else
      log "Link policy: strict shared-library symbol resolution"
    fi

    if [[ "$BAZEL_DEBUG_MODE" == "1" ]]; then
      bazel_args+=(--compilation_mode=dbg --strip=never \
        --cxxopt=-fno-omit-frame-pointer --cxxopt=-O0 --cxxopt=-g)
      log "Bazel debug mode: --compilation_mode=dbg --strip=never --cxxopt=-fno-omit-frame-pointer --cxxopt=-O0 --cxxopt=-g"
    elif [[ "$BAZEL_RELEASE_MODE" == "1" ]]; then
      bazel_args+=(--compilation_mode=opt --strip=always)
      log "Bazel release mode: --compilation_mode=opt --strip=always"
    elif [[ "$BAZEL_ASAN_MODE" == "1" ]]; then
      bazel_args+=(--compilation_mode=dbg --strip=never --config=asan)
      log "Bazel ASan mode: --compilation_mode=dbg --strip=never --config=asan"
    fi

    bazel_args+=("$BAZEL_TARGET")
    "$BAZEL_BIN" "${bazel_args[@]}"
  ) 2>&1 | tee "$build_log" | tee -a "$LOG_FILE"
  local rc=${PIPESTATUS[0]}
  set -e

  [[ "$rc" -eq 0 ]] || die "bazel build failed rc=$rc"
  [[ -x "$BAZEL_OUTPUT" ]] || die "build succeeded but output missing/not executable: $BAZEL_OUTPUT"

  inspect_built_elf "$BAZEL_OUTPUT"
  validate_built_abi "$BAZEL_OUTPUT" || die "target ABI gate failed"
  validate_package_link_provenance "$build_log"
  validate_package_runtime_closure "$BAZEL_OUTPUT"

  local built_glibcxx built_cxxabi
  built_glibcxx="$(elf_max_version_requirement "$BAZEL_OUTPUT" GLIBCXX)"
  built_cxxabi="$(elf_max_version_requirement "$BAZEL_OUTPUT" CXXABI)"
  log "BUILT_ELF_GLIBCXX_MAX=${built_glibcxx:-UNKNOWN}"
  log "BUILT_ELF_CXXABI_MAX=${built_cxxabi:-UNKNOWN}"

  local git_sha git_short branch ts name dst tmp sha
  local release_stripped=0 strip_path=none
  git_sha="$(git -C "$PROJECT_DIR" rev-parse HEAD 2>/dev/null || echo unknown)"
  git_short="${git_sha:0:8}"
  branch="$(git -C "$PROJECT_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || echo unknown)"
  ts="$(date '+%Y%m%d-%H%M%S')"
  name="${ARTIFACT_PREFIX}.${ts}-${git_short}"
  dst="$LOCAL_ARTIFACT_DIR/$name"
  tmp="$dst.tmp.$$"

  trap 'rm -f -- "$tmp"; cleanup_package_profile_libraries' EXIT
  cp -f "$BAZEL_OUTPUT" "$tmp"

  if [[ "$build_profile" == "release" ]]; then
    chmod u+w "$tmp"
    have "$STRIP_BIN" || die "release strip tool not found: $STRIP_BIN"
    strip_path="$(command -v "$STRIP_BIN")"
    "$strip_path" --strip-all "$tmp" || die "failed to strip release artifact copy: $tmp"
    if file -b "$tmp" | grep -Fq 'not stripped'; then
      die "release artifact copy remains unstripped after $strip_path --strip-all"
    fi
    file -b "$tmp" | grep -Fq 'stripped' || die "unable to confirm stripped release artifact copy"
    release_stripped=1
    log "[OK] release artifact copy stripped with $strip_path --strip-all"
    inspect_built_elf "$tmp"
    validate_built_abi "$tmp" || die "stripped release artifact ABI gate failed"
    validate_package_runtime_closure "$tmp"
  fi

  chmod +x "$tmp"
  mv -f "$tmp" "$dst"

  sha="$(sha256_file "$dst")"

  cat > "$dst.meta" <<EOF
artifact=$name
built_at=$(date -Is)
build_server=$BUILD_SERVER_IP
project=$PROJECT_DIR
branch=$branch
git_commit=$git_sha
bazel_target=$BAZEL_TARGET
bazel_cpu=$BAZEL_CPU
bazel_host_cpu=$BAZEL_HOST_CPU
build_profile=$build_profile
release_stripped=$release_stripped
strip_tool=$strip_path
package_profile_active=$PACKAGE_PROFILE_ACTIVE
package_library_dir=$PACKAGE_LIBRARY_DIR
package_manifest_sha256=$PACKAGE_MANIFEST_SHA256
package_libstdcpp=$PACKAGE_LIBSTDCPP
package_libstdcpp_sha256=$PACKAGE_LIBSTDCPP_SHA256
package_libgcc=$PACKAGE_LIBGCC
package_libgcc_sha256=$PACKAGE_LIBGCC_SHA256
package_onnxruntime=$PACKAGE_ONNXRUNTIME
package_onnxruntime_sha256=$PACKAGE_ONNXRUNTIME_SHA256
package_rdkafka=$PACKAGE_RDKAFKA
package_rdkafka_sha256=$PACKAGE_RDKAFKA_SHA256
third_party_dir=$THIRD_PARTY_DIR
third_party_revision=$(third_party_revision)
bazel_cc_wrapper=$BAZEL_CC_WRAPPER
bazel_cxx_wrapper=$BAZEL_CXX_WRAPPER
allow_shlib_undefined=$ALLOW_SHLIB_UNDEFINED
use_sysroot=$USE_SYSROOT
sysroot=$WTP184_SYSROOT
toolchain_identity=$(sed -n 's/^TOOLCHAIN_IDENTITY=//p' "$GCC_HOME/.wtp184/provenance.txt" 2>/dev/null | tail -n1 || true)
sysroot_identity=$(sed -n -e 's/^TOOLCHAIN_IDENTITY=//p' -e 's/^SYSROOT_IDENTITY=//p' "$WTP184_SYSROOT/.wtp184/provenance.txt" 2>/dev/null | tail -n1 || true)
max_target_glibc=$MAX_TARGET_GLIBC
built_elf_glibc_max=$(elf_max_glibc_requirement "$dst")
built_elf_glibcxx_max=$(elf_max_version_requirement "$dst" GLIBCXX)
built_elf_cxxabi_max=$(elf_max_version_requirement "$dst" CXXABI)
gcc=$CC
gcc_version=$("$CC" -dumpversion)
gcc_target=$("$CC" -dumpmachine)
gcc_libstdcpp=$("$CXX" -print-file-name=libstdc++.so)
gcc_libstdcpp_sha256=$(sha256_file "$(readlink -f "$("$CXX" -print-file-name=libstdc++.so)")")
gcc_libstdcpp_glibc_max=$(elf_max_version_requirement "$(readlink -f "$("$CXX" -print-file-name=libstdc++.so)")" GLIBC)
gcc_libstdcpp_glibcxx_max=$(elf_max_version_provided "$(readlink -f "$("$CXX" -print-file-name=libstdc++.so)")" GLIBCXX)
sha256=$sha
size=$(stat -c '%s' "$dst")
EOF

  if is_v3_build; then
    cat >> "$dst.meta" <<EOF
dialogue_pipeline_variant=$DIALOGUE_PIPELINE_VARIANT
dialogue_pipeline_define=$DIALOGUE_PIPELINE_DEFINE
v3_compatibility_alias=$V3_COMPAT_ALIAS
latest_pointer=$LOCAL_ARTIFACT_DIR/LATEST
package_onnxruntime_selected=0
EOF
  fi

  printf '%s\n' "$name" > "$LOCAL_ARTIFACT_DIR/.LATEST.tmp"
  mv -f "$LOCAL_ARTIFACT_DIR/.LATEST.tmp" "$LOCAL_ARTIFACT_DIR/LATEST"

  {
    echo "##############################################"
    echo "artifact: $name"
    echo "time: $(date -Is)"
    echo "branch: $branch"
    echo "commit: $git_sha"
    echo "gcc: $("$CC" --version | head -1)"
    if [[ -n "$MESSAGE" ]]; then
      echo "message: $MESSAGE"
    else
      echo "message: $(git -C "$PROJECT_DIR" log -1 --pretty=%s 2>/dev/null || echo 'build')"
    fi
  } >> "$RELEASE_NOTE_FILE"

  log "===== BUILD SUCCESS ====="
  log "artifact=$dst"
  log "sha256=$sha"
  log "branch=$branch"
  log "commit=$git_sha"

  # Useful evidence. This does not replace Bazel toolchain verification, but it
  # makes ABI/toolchain diagnostics easier.
  if have file; then file "$dst" | tee -a "$LOG_FILE"; fi
  if have readelf; then
    log "ELF .comment compiler markers:"
    readelf -p .comment "$dst" 2>/dev/null | tail -n 20 | tee -a "$LOG_FILE" || true
  fi

  if [[ "$PACKAGE_PROFILE_ACTIVE" == "1" ]]; then
    cleanup_package_profile_libraries
  fi
  trap - EXIT
}

# ------------------------------------------------------------------------------
# 3. Artifact sync: 10.1.120.40 -> 21
# ------------------------------------------------------------------------------

check_batch_ssh() {
  ssh_batch_args
  ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" 'printf "SSH_OK\n"' 2>/dev/null | grep -q SSH_OK
}

setup_ssh() {
  have ssh-copy-id || die "ssh-copy-id not installed"
  ssh_base_args

  log "This step is intentionally interactive."
  log "If the target asks for a password/host-key confirmation, complete it now."
  log "Installing current user's SSH public key to $TARGET_SSH"

  local args=(-p "$TARGET_PORT")
  [[ -n "$SSH_IDENTITY" ]] && args+=(-i "$SSH_IDENTITY.pub")

  ssh-copy-id "${args[@]}" "$TARGET_SSH"

  check_batch_ssh || die "SSH key installation completed but BatchMode still fails"
  log "[OK] non-interactive SSH works: $TARGET_SSH"
}

sync_artifacts() {
  have rsync || die "rsync not installed locally"
  log "[SYNC] checking BatchMode SSH to $TARGET_SSH"
  if ! check_batch_ssh; then
    die "BatchMode SSH to $TARGET_SSH failed. Run: $SELF setup-ssh"
  fi
  log "[SYNC] BatchMode SSH OK"

  # --------------------------------------------------------------------------
  # Strict source validation.
  # Never report a successful sync when build/package did not produce LATEST.
  # --------------------------------------------------------------------------
  [[ -d "$LOCAL_ARTIFACT_DIR" ]] || \
    die "local artifact directory missing: $LOCAL_ARTIFACT_DIR"

  prepare_selected_deployment
  local latest_name
  latest_name="$(selected_deployment_name)"

  local latest_artifact="$LOCAL_ARTIFACT_DIR/$latest_name"
  [[ -f "$latest_artifact" ]] || \
    die "LATEST points to missing local artifact: $latest_artifact"
  [[ -x "$latest_artifact" ]] || \
    die "LATEST artifact is not executable: $latest_artifact"

  local local_sha local_size
  local_sha="$(sha256_file "$latest_artifact")"
  local_size="$(stat -c '%s' "$latest_artifact")"
  if [[ -n "${V3_DEPLOY_PINNED_NAME:-}" ]]; then
    [[ "$local_sha" == "$V3_DEPLOY_PINNED_SHA" ]] || \
      die "V3 debug artifact SHA changed after validation"
    [[ "$local_size" == "$V3_DEPLOY_PINNED_SIZE" ]] || \
      die "V3 debug artifact size changed after validation"
  fi

  log "===== SYNC SOURCE VERIFIED ====="
  log "LATEST=$latest_name"
  log "artifact=$latest_artifact"
  log "size=$local_size"
  log "sha256=$local_sha"

  ssh_batch_args
  log "[SYNC] SSH argument preparation OK"

  log "[SYNC] verifying/creating remote artifact directory: $REMOTE_ARTIFACT_DIR"
  local mkdir_rc
  set +e
  ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
    "set -e; mkdir -p $(printf '%q' "$REMOTE_ARTIFACT_DIR"); test -d $(printf '%q' "$REMOTE_ARTIFACT_DIR"); printf 'REMOTE_DIR_OK=%s\\n' $(printf '%q' "$REMOTE_ARTIFACT_DIR")" \
    2>&1 | tee -a "$LOG_FILE"
  mkdir_rc=${PIPESTATUS[0]}
  set -e
  log "[SYNC] remote directory prepare rc=$mkdir_rc"
  [[ "$mkdir_rc" -eq 0 ]] || die "failed to prepare remote artifact directory rc=$mkdir_rc"

  local ssh_cmd
  ssh_cmd="$(rsync_ssh_string)"

  log "Sync: $LOCAL_ARTIFACT_DIR/ -> $TARGET_SSH:$REMOTE_ARTIFACT_DIR/"
  log "Note: rsync intentionally does NOT use --delete."

  local -a sync_sources=("$LOCAL_ARTIFACT_DIR/")
  if [[ -n "$SERVER_VERSION" ]]; then
    sync_sources=("$latest_artifact" "$latest_artifact.meta")
  fi
  if ! run_logged "rsync artifacts" \
    rsync \
      -az \
      --partial \
      --delay-updates \
      --itemize-changes \
      -e "$ssh_cmd" \
      "${sync_sources[@]}" \
      "$TARGET_SSH:$REMOTE_ARTIFACT_DIR/"; then
    die "rsync artifact transfer failed"
  fi

  # --------------------------------------------------------------------------
  # Strict remote verification.
  # Confirm the exact LATEST name, file, size and checksum arrived on server 21.
  # --------------------------------------------------------------------------
  local verify_out verify_rc
  set +e
  verify_out="$(
    ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
      "EXPECT_V3=$(printf '%q' "${V3_DEPLOY_PINNED_NAME:-}") EXPECT_POINTER=$(printf '%q' "$LOCAL_ARTIFACT_DIR/LATEST") SELECTED_EXPLICIT=$(printf '%q' "$SERVER_VERSION") REMOTE_DIR=$(printf '%q' "$REMOTE_ARTIFACT_DIR") EXPECT_NAME=$(printf '%q' "$latest_name") EXPECT_SHA=$(printf '%q' "$local_sha") EXPECT_SIZE=$(printf '%q' "$local_size") bash -s" <<'EOS'
set -u

name="$EXPECT_NAME"
if [[ -z "$SELECTED_EXPLICIT" ]]; then
latest_file="$REMOTE_DIR/LATEST"
[[ -f "$latest_file" ]] || {
  echo "REMOTE_VERIFY_ERROR=LATEST_MISSING"
  exit 41
}

name="$(head -n 1 "$latest_file" | tr -d '\r\n')"
echo "REMOTE_LATEST=$name"

[[ "$name" == "$EXPECT_NAME" ]] || {
  echo "REMOTE_VERIFY_ERROR=LATEST_MISMATCH"
  exit 42
}
fi

artifact="$REMOTE_DIR/$name"
[[ -f "$artifact" ]] || {
  echo "REMOTE_VERIFY_ERROR=ARTIFACT_MISSING"
  exit 43
}

size="$(stat -c '%s' "$artifact")"
sha="$(sha256sum "$artifact" | awk '{print $1}')"

echo "REMOTE_ARTIFACT=$artifact"
echo "REMOTE_SIZE=$size"
echo "REMOTE_SHA256=$sha"

[[ "$size" == "$EXPECT_SIZE" ]] || {
  echo "REMOTE_VERIFY_ERROR=SIZE_MISMATCH"
  exit 44
}

[[ "$sha" == "$EXPECT_SHA" ]] || {
  echo "REMOTE_VERIFY_ERROR=SHA256_MISMATCH"
  exit 45
}

if [[ -n "$EXPECT_V3" ]]; then
  metadata="$artifact.meta"
  [[ -f "$metadata" ]] || { echo "REMOTE_VERIFY_ERROR=METADATA_MISSING"; exit 46; }
  records=("artifact=$EXPECT_NAME" "sha256=$EXPECT_SHA" "size=$EXPECT_SIZE"
    'bazel_target=//cu:server' 'build_profile=debug' 'release_stripped=0'
    'dialogue_pipeline_variant=v3' 'dialogue_pipeline_define=dialogue_pipeline_v3=true'
    "latest_pointer=$EXPECT_POINTER" 'package_onnxruntime_selected=0')
  for record in "${records[@]}"; do
    grep -Fqx "$record" "$metadata" || { echo "REMOTE_VERIFY_ERROR=METADATA_MISMATCH"; exit 46; }
  done
fi
echo "REMOTE_SYNC_OK=1"
EOS
  )"
  verify_rc=$?
  set -e

  printf '%s\n' "$verify_out" | tee -a "$LOG_FILE"

  [[ "$verify_rc" -eq 0 ]] || \
    die "remote artifact verification failed rc=$verify_rc"

  grep -q '^REMOTE_SYNC_OK=1$' <<<"$verify_out" || \
    die "remote artifact verification did not return REMOTE_SYNC_OK=1"

  log "[OK] artifact sync complete and checksum verified on server 21"
}

artifact_dir_fingerprint() {
  # Only successful packaged artifacts live here. Fingerprinting avoids running
  # rsync and emitting logs every 2 seconds when nothing changed.
  find "$LOCAL_ARTIFACT_DIR" -maxdepth 1 -type f \
    -printf '%f|%s|%T@\n' 2>/dev/null | sort | sha256sum | awk '{print $1}'
}

watch_sync() {
  log "Starting near-real-time sync watcher; interval=${SYNC_INTERVAL}s"
  log "Source: $LOCAL_ARTIFACT_DIR"
  log "Target: $TARGET_SSH:$REMOTE_ARTIFACT_DIR"
  log "This service SYNCs only. It does NOT auto-deploy 9530."

  local last="" current=""
  while true; do
    current="$(artifact_dir_fingerprint)"
    if [[ "$current" != "$last" ]]; then
      log "Artifact directory changed -> rsync"
      if sync_artifacts; then
        last="$current"
      else
        log "[WARN] sync failed; fingerprint not advanced, so it will retry"
      fi
    fi
    sleep "$SYNC_INTERVAL"
  done
}

# ------------------------------------------------------------------------------
# 4. LEGACY remote helper embedded in this single script
# NOTE: retained for reference only; current deploy/test/compare/status do not call it.
# ------------------------------------------------------------------------------

install_remote_helper() {
  check_batch_ssh || die "BatchMode SSH to $TARGET_SSH failed. Run: $SELF setup-ssh"
  ssh_batch_args

  log "Installing/updating remote deployment helper: $TARGET_SSH:$REMOTE_HELPER"

  ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
    "mkdir -p $(printf '%q' "$(dirname "$REMOTE_HELPER")")"

  ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
    "cat > $(printf '%q' "$REMOTE_HELPER") && chmod 0755 $(printf '%q' "$REMOTE_HELPER")" <<'__CU_REMOTE_HELPER__'
#!/usr/bin/env bash
set -Eeuo pipefail

# This file is installed automatically by cu-dev-pipeline.sh.
# It is intentionally self-contained.

CMD="${1:-status}"

BASELINE_PORT="${BASELINE_PORT:-9999}"
TEST_PORT="${TEST_PORT:-9530}"
CONTAINER_HTTP_PORT="${CONTAINER_HTTP_PORT:-8080}"
ARTIFACT_DIR="${ARTIFACT_DIR:-/home/daigd/cu-dev-artifacts/server}"
CURL_PATH="${CURL_PATH:-/zp/update}"
TEST_QUERY="${TEST_QUERY:-打开空调}"
CURL_MAX_TIME="${CURL_MAX_TIME:-30}"
SMOKE_RETRIES="${SMOKE_RETRIES:-15}"
SMOKE_INTERVAL="${SMOKE_INTERVAL:-1}"

STATE_ROOT="${STATE_ROOT:-/home/daigd/cu-dev-deploy}"
SLOT_DIR="$STATE_ROOT/$TEST_PORT"
LOG_DIR="$STATE_ROOT/logs"
HISTORY="$SLOT_DIR/history.tsv"

mkdir -p "$SLOT_DIR" "$LOG_DIR"
LOG_FILE="$LOG_DIR/remote-deploy-${TEST_PORT}-$(date '+%Y%m%d-%H%M%S').log"

exec > >(tee -a "$LOG_FILE") 2>&1

log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
die() { log "[ERROR] $*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

DOCKER=()

docker_init() {
  if docker info >/dev/null 2>&1; then
    DOCKER=(docker)
    return
  fi

  if have sudo; then
    # Manual deploy/test is expected to run with a TTY from the source script.
    # If sudo needs a password, the user can enter it here.
    if sudo docker info >/dev/null 2>&1; then
      DOCKER=(sudo docker)
      return
    fi
  fi

  die "cannot access Docker daemon"
}

history_init() {
  if [[ ! -f "$HISTORY" ]]; then
    printf 'time\tevent\tcontainer\timage\truntime_volume\tartifact\tsha256\tnote\n' > "$HISTORY"
  fi
}

history_add() {
  history_init
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$(date -Is)" "$1" "$2" "$3" "$4" "$5" "$6" "${7:-}" >> "$HISTORY"
}

sha256_file() {
  sha256sum "$1" | awk '{print $1}'
}

running_rows_by_port() {
  "${DOCKER[@]}" ps \
    --filter "publish=$1" \
    --format '{{.ID}}|{{.Names}}|{{.Image}}'
}

one_running_by_port() {
  local port="$1"
  mapfile -t rows < <(running_rows_by_port "$port")

  if (( ${#rows[@]} == 0 )); then
    return 1
  fi

  if (( ${#rows[@]} > 1 )); then
    printf '%s\n' "${rows[@]}" >&2
    die "multiple running containers publish port $port"
  fi

  printf '%s\n' "${rows[0]}"
}

baseline_info() {
  local row
  row="$(one_running_by_port "$BASELINE_PORT")" || \
    die "baseline container not found on host port $BASELINE_PORT"
  printf '%s\n' "$row"
}

latest_artifact() {
  local latest="$ARTIFACT_DIR/LATEST"
  [[ -f "$latest" ]] || die "LATEST file missing: $latest"

  local name
  name="$(head -1 "$latest" | tr -d '\r\n')"
  [[ -n "$name" ]] || die "LATEST is empty"

  local file="$ARTIFACT_DIR/$name"
  [[ -f "$file" ]] || die "latest artifact missing: $file"
  [[ -x "$file" ]] || chmod +x "$file"

  printf '%s\n' "$file"
}

make_request_json() {
  local outfile="$1"
  local session="$2"

  python3 - "$outfile" "$session" "$TEST_QUERY" <<'PY'
import json, sys
outfile, session, query = sys.argv[1], sys.argv[2], sys.argv[3]
payload = {
    "query": query,
    "session_id": session,
    "sessionId": session,
    "stream": False,
}
with open(outfile, "w", encoding="utf-8") as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)
    f.write("\n")
PY
}

curl_request() {
  local port="$1"
  local request_file="$2"
  local response_file="$3"
  local url="http://127.0.0.1:80${CURL_PATH}"

  local result rc code
  set +e
  code="$(curl -sS \
    --max-time "$CURL_MAX_TIME" \
    -o "$response_file" \
    -w '%{http_code}' \
    -X POST \
    -H 'Content-Type: application/json' \
    --data-binary "@$request_file" \
    "$url")"
  rc=$?
  set -e

  printf '%s|%s\n' "$rc" "$code"
}

smoke_test() {
  local port="$1"
  local label="$2"
  local session="cu-dev-${port}-$(date '+%Y%m%d%H%M%S')-$$"
  local req="$SLOT_DIR/${label}.request.json"
  local rsp="$SLOT_DIR/${label}.response.json"

  make_request_json "$req" "$session"

  local i result rc code
  for ((i=1; i<=SMOKE_RETRIES; i++)); do
    result="$(curl_request "$port" "$req" "$rsp")"
    IFS='|' read -r rc code <<< "$result"

    log "[SMOKE] attempt=$i port=$port curl_rc=$rc http=$code"

    if [[ "$rc" == "0" && "$code" == "200" && -s "$rsp" ]]; then
      log "[OK] HTTP smoke passed"
      echo "----- request -----"
      cat "$req"
      echo
      echo "----- response -----"
      cat "$rsp"
      echo
      return 0
    fi

    sleep "$SMOKE_INTERVAL"
  done

  log "[FAIL] HTTP smoke failed"
  [[ -f "$rsp" ]] && { echo "----- last response -----"; cat "$rsp"; echo; }
  return 1
}

compare_ab() {
  local ts
  ts="$(date '+%Y%m%d%H%M%S')"

  # Separate session IDs avoid both servers mutating the same Redis conversation
  # context while still using the same query and request shape.
  local base_req="$SLOT_DIR/ab-${ts}-baseline.request.json"
  local test_req="$SLOT_DIR/ab-${ts}-test.request.json"
  local base_rsp="$SLOT_DIR/ab-${ts}-baseline.response.json"
  local test_rsp="$SLOT_DIR/ab-${ts}-test.response.json"

  make_request_json "$base_req" "cu-ab-baseline-${ts}-$$"
  make_request_json "$test_req" "cu-ab-test-${ts}-$$"

  local a b arc acode brc bcode
  a="$(curl_request "$BASELINE_PORT" "$base_req" "$base_rsp")"
  b="$(curl_request "$TEST_PORT" "$test_req" "$test_rsp")"

  IFS='|' read -r arc acode <<< "$a"
  IFS='|' read -r brc bcode <<< "$b"

  echo "===== A/B HTTP ====="
  echo "baseline : port=$BASELINE_PORT curl_rc=$arc http=$acode"
  echo "new test : port=$TEST_PORT curl_rc=$brc http=$bcode"

  echo
  echo "===== BASELINE REQUEST ====="
  cat "$base_req"
  echo
  echo "===== BASELINE RESPONSE ====="
  cat "$base_rsp" 2>/dev/null || true

  echo
  echo "===== TEST REQUEST ====="
  cat "$test_req"
  echo
  echo "===== TEST RESPONSE ====="
  cat "$test_rsp" 2>/dev/null || true

  echo
  echo "===== RAW RESPONSE DIFF (informational) ====="
  diff -u "$base_rsp" "$test_rsp" || true
}

snapshot_runtime_to_volume() {
  local baseline_id="$1"
  local baseline_image="$2"
  local volume="$3"

  log "Creating independent runtime snapshot volume: $volume"
  "${DOCKER[@]}" volume create "$volume" >/dev/null

  local helper="cu-dev-runtime-copy-${TEST_PORT}-$(date '+%Y%m%d%H%M%S')-$$"
  local helper_id=""
  local tmp_root=""
  local ok=0

  # Docker does NOT support `docker cp containerA:path containerB:path`.
  # Use an explicit two-step copy through a temporary directory on server 21:
  #
  #   baseline container:/runtime -> host temp -> helper container:/runtime
  #
  # The helper container mounts the new independent volume at /runtime, so the
  # second copy populates the volume without sharing the baseline volume.
  tmp_root="$(mktemp -d "/tmp/cu-dev-runtime-${TEST_PORT}.XXXXXX")" || {
    "${DOCKER[@]}" volume rm "$volume" >/dev/null 2>&1 || true
    die "failed to create temporary runtime snapshot directory"
  }

  log "[RUNTIME SNAPSHOT] stage 1/3: baseline container -> host temp"
  log "source=$baseline_id:/runtime/."
  log "temp=$tmp_root/runtime"

  mkdir -p "$tmp_root/runtime"

  if ! "${DOCKER[@]}" cp "$baseline_id:/runtime/." "$tmp_root/runtime/"; then
    rm -rf "$tmp_root"
    "${DOCKER[@]}" volume rm "$volume" >/dev/null 2>&1 || true
    die "failed to copy baseline /runtime to host temp"
  fi

  # Basic sanity check before populating the new volume.
  if [[ -z "$(find "$tmp_root/runtime" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
    rm -rf "$tmp_root"
    "${DOCKER[@]}" volume rm "$volume" >/dev/null 2>&1 || true
    die "baseline /runtime snapshot is empty"
  fi

  local snapshot_size
  snapshot_size="$(du -sh "$tmp_root/runtime" 2>/dev/null | awk '{print $1}' || true)"
  log "[RUNTIME SNAPSHOT] host temp size=${snapshot_size:-unknown}"

  log "[RUNTIME SNAPSHOT] stage 2/3: host temp -> independent Docker volume"

  helper_id="$("${DOCKER[@]}" create \
    --name "$helper" \
    --entrypoint /bin/sh \
    -v "$volume:/runtime" \
    "$baseline_image" \
    -c 'true')" || {
      rm -rf "$tmp_root"
      "${DOCKER[@]}" volume rm "$volume" >/dev/null 2>&1 || true
      die "failed to create runtime-copy helper container"
    }

  if "${DOCKER[@]}" cp "$tmp_root/runtime/." "$helper_id:/runtime/"; then
    ok=1
  fi

  "${DOCKER[@]}" rm "$helper_id" >/dev/null 2>&1 || true
  helper_id=""
  rm -rf "$tmp_root"
  tmp_root=""

  if [[ "$ok" -ne 1 ]]; then
    "${DOCKER[@]}" volume rm "$volume" >/dev/null 2>&1 || true
    die "failed to populate independent runtime volume"
  fi

  log "[RUNTIME SNAPSHOT] stage 3/3: verify independent volume"

  local verify_output verify_rc
  set +e
  verify_output="$("${DOCKER[@]}" run --rm \
    --entrypoint /bin/sh \
    -v "$volume:/runtime:ro" \
    "$baseline_image" \
    -lc '
      count=$(find /runtime -mindepth 1 -maxdepth 1 -print 2>/dev/null | wc -l)
      echo "RUNTIME_TOPLEVEL_COUNT=$count"
      test "$count" -gt 0
    ' 2>&1)"
  verify_rc=$?
  set -e

  printf '%s\n' "$verify_output"
  if [[ "$verify_rc" -ne 0 ]]; then
    "${DOCKER[@]}" volume rm "$volume" >/dev/null 2>&1 || true
    die "runtime volume verification failed rc=$verify_rc"
  fi

  log "[OK] runtime copied from baseline container into independent volume"
}

write_env_file() {
  local baseline_id="$1"
  local outfile="$2"

  "${DOCKER[@]}" inspect \
    -f '{{range .Config.Env}}{{println .}}{{end}}' \
    "$baseline_id" > "$outfile"

  chmod 600 "$outfile"
}

build_derived_image() {
  local baseline_image="$1"
  local artifact="$2"
  local image="$3"
  local sha="$4"
  local builddir="$5"

  cp -f "$artifact" "$builddir/cu-server"
  chmod +x "$builddir/cu-server"

  cat > "$builddir/Dockerfile" <<EOF
ARG BASE_IMAGE
FROM \${BASE_IMAGE}

COPY cu-server /usr/bin/cu-server
RUN chmod +x /usr/bin/cu-server

LABEL cu.dev.slot="$TEST_PORT"
LABEL cu.dev.binary_sha="$sha"
LABEL cu.dev.artifact="$(basename "$artifact")"
EOF

  log "Building derived image: $image"
  "${DOCKER[@]}" build \
    --build-arg "BASE_IMAGE=$baseline_image" \
    -t "$image" \
    "$builddir"
}

ldd_preflight() {
  local image="$1"
  local runtime_volume="$2"
  local env_file="$3"

  log "===== LDD PREFLIGHT ====="
  local output rc
  set +e
  output="$("${DOCKER[@]}" run --rm \
    --entrypoint /bin/sh \
    --env-file "$env_file" \
    -v "$runtime_volume:/runtime:ro" \
    "$image" \
    -lc 'ldd /usr/bin/cu-server 2>&1' 2>&1)"
  rc=$?
  set -e

  echo "$output"

  [[ "$rc" -eq 0 ]] || return 1
  ! grep -q 'not found' <<< "$output"
}

current_test_container() {
  one_running_by_port "$TEST_PORT" 2>/dev/null || true
}

assert_test_slot_safe() {
  local row="$1"
  [[ -n "$row" ]] || return 0

  local id name image
  IFS='|' read -r id name image <<< "$row"

  local label
  label="$("${DOCKER[@]}" inspect \
    -f '{{index .Config.Labels "cu.dev.slot"}}' "$id" 2>/dev/null || true)"

  [[ "$label" == "$TEST_PORT" ]] || \
    die "TEST_PORT $TEST_PORT is occupied by non-dev container: $name ($image)"
}

deploy() {
  docker_init
  have curl || die "curl not installed"
  have python3 || die "python3 not installed"
  have sha256sum || die "sha256sum not installed"

  local brow baseline_id baseline_name baseline_image
  brow="$(baseline_info)"
  IFS='|' read -r baseline_id baseline_name baseline_image <<< "$brow"

  local artifact sha short ts image container runtime_volume log_volume
  artifact="$(latest_artifact)"
  sha="$(sha256_file "$artifact")"
  short="${sha:0:12}"
  ts="$(date '+%Y%m%d-%H%M%S')"

  image="cu-server:dev-${TEST_PORT}-${ts}-${short}"
  container="cu-server-dev-${TEST_PORT}-${ts}"
  runtime_volume="cu-dev-runtime-${TEST_PORT}-${ts}-${short}"
  log_volume="cu-dev-log-${TEST_PORT}-${ts}-${short}"

  local builddir envfile
  builddir="$(mktemp -d "$SLOT_DIR/build.XXXXXX")"
  envfile="$builddir/baseline.env"
  trap 'rm -rf "$builddir" 2>/dev/null || true' RETURN

  log "===== DEPLOY PLAN ====="
  log "baseline port      = $BASELINE_PORT"
  log "baseline container = $baseline_name"
  log "baseline image     = $baseline_image"
  log "test port          = $TEST_PORT"
  log "artifact           = $(basename "$artifact")"
  log "artifact sha256    = $sha"
  log "new container      = $container"
  log "new image          = $image"

  # 1) Build image with only the new binary.
  build_derived_image "$baseline_image" "$artifact" "$image" "$sha" "$builddir"

  # 2) Snapshot ACTUAL baseline /runtime into an independent volume.
  snapshot_runtime_to_volume "$baseline_id" "$baseline_image" "$runtime_volume"

  # 3) Capture baseline environment.
  write_env_file "$baseline_id" "$envfile"

  # 4) ABI/dynamic-library check BEFORE touching current 9530.
  if ! ldd_preflight "$image" "$runtime_volume" "$envfile"; then
    history_add "preflight-failed" "" "$image" "$runtime_volume" \
      "$(basename "$artifact")" "$sha" "ldd failed"
    die "new binary failed ldd preflight; current TEST_PORT was not touched"
  fi

  # 5) Create isolated /log volume.
  "${DOCKER[@]}" volume create "$log_volume" >/dev/null

  # 6) Stop current dev slot only after preflight passes.
  local old="" old_id="" old_name="" old_image=""
  old="$(current_test_container)"
  assert_test_slot_safe "$old"

  if [[ -n "$old" ]]; then
    IFS='|' read -r old_id old_name old_image <<< "$old"
    log "Stopping previous TEST_PORT container (kept for rollback): $old_name"
    "${DOCKER[@]}" stop "$old_id"
  fi

  # 7) Start new test container.
  log "Starting $container: host $TEST_PORT -> container $CONTAINER_HTTP_PORT"

  local new_id run_rc
  set +e
  new_id="$("${DOCKER[@]}" run -d \
    --name "$container" \
    --label "cu.dev.slot=$TEST_PORT" \
    --label "cu.dev.binary_sha=$sha" \
    --label "cu.dev.artifact=$(basename "$artifact")" \
    --label "cu.dev.runtime_volume=$runtime_volume" \
    --label "cu.dev.log_volume=$log_volume" \
    -p "$TEST_PORT:$CONTAINER_HTTP_PORT" \
    --env-file "$envfile" \
    -v "$runtime_volume:/runtime" \
    -v "$log_volume:/log" \
    "$image" 2>&1)"
  run_rc=$?
  set -e

  if [[ "$run_rc" -ne 0 ]]; then
    log "[FAIL] docker run failed: $new_id"
    history_add "run-failed" "$container" "$image" "$runtime_volume" \
      "$(basename "$artifact")" "$sha" "docker run rc=$run_rc"

    if [[ -n "$old_id" ]]; then
      log "Restoring previous test container: $old_name"
      "${DOCKER[@]}" start "$old_id"
    fi
    return "$run_rc"
  fi

  # 8) Real /zp/update POST smoke test.
  if smoke_test "$TEST_PORT" "deploy-${ts}"; then
    history_add "deploy-success" "$container" "$image" "$runtime_volume" \
      "$(basename "$artifact")" "$sha" "HTTP 200 + non-empty response"

    log "[SUCCESS] new cu-server is live:"
    log "  http://127.0.0.1:80${CURL_PATH}"

    if [[ -n "$old_name" ]]; then
      log "[ROLLBACK] previous container retained stopped: $old_name"
    fi

    echo
    compare_ab
    return 0
  fi

  # 9) Failed smoke -> automatic rollback.
  log "===== SMOKE FAILED: AUTO ROLLBACK ====="
  "${DOCKER[@]}" stop "$new_id" >/dev/null 2>&1 || true

  echo "----- failed container logs -----"
  "${DOCKER[@]}" logs --tail 200 "$new_id" 2>&1 || true

  history_add "smoke-failed" "$container" "$image" "$runtime_volume" \
    "$(basename "$artifact")" "$sha" "HTTP smoke failed"

  if [[ -n "$old_id" ]]; then
    log "Restarting previous test container: $old_name"
    "${DOCKER[@]}" start "$old_id"
    smoke_test "$TEST_PORT" "auto-rollback-${ts}" || true
    history_add "auto-rollback" "$old_name" "$old_image" "" "" "" \
      "restored after failed deployment"
  else
    log "No previous TEST_PORT container existed. TEST_PORT remains unused."
  fi

  return 1
}

latest_stopped_success() {
  history_init

  tac "$HISTORY" | awk -F'\t' '$2=="deploy-success"{print $3}' |
  while IFS= read -r name; do
    [[ -n "$name" ]] || continue
    if "${DOCKER[@]}" inspect "$name" >/dev/null 2>&1; then
      local running
      running="$("${DOCKER[@]}" inspect -f '{{.State.Running}}' "$name")"
      if [[ "$running" != "true" ]]; then
        echo "$name"
        break
      fi
    fi
  done
}

rollback() {
  docker_init

  local current="" current_id="" current_name="" current_image=""
  current="$(current_test_container)"
  assert_test_slot_safe "$current"

  if [[ -n "$current" ]]; then
    IFS='|' read -r current_id current_name current_image <<< "$current"
  fi

  local prev
  prev="$(latest_stopped_success)"
  [[ -n "$prev" ]] || die "no previous successful stopped test container found"

  log "Rollback target: $prev"

  if [[ -n "$current_id" ]]; then
    log "Stopping current test container: $current_name"
    "${DOCKER[@]}" stop "$current_id"
  fi

  if ! "${DOCKER[@]}" start "$prev"; then
    log "[FAIL] rollback target could not start"
    [[ -n "$current_id" ]] && "${DOCKER[@]}" start "$current_id" || true
    return 1
  fi

  if smoke_test "$TEST_PORT" "manual-rollback-$(date '+%Y%m%d-%H%M%S')"; then
    history_add "manual-rollback" "$prev" \
      "$("${DOCKER[@]}" inspect -f '{{.Config.Image}}' "$prev")" "" "" "" \
      "HTTP smoke passed"
    log "[SUCCESS] rollback completed"
    return 0
  fi

  log "[FAIL] rollback target started but HTTP smoke failed"
  return 1
}

diagnose() {
  docker_init
  have curl || die "curl missing"
  have python3 || die "python3 missing"
  have sha256sum || die "sha256sum missing"

  echo "===== REMOTE DEPLOY DIAGNOSE ====="
  echo "artifact dir : $ARTIFACT_DIR"
  echo "baseline port: $BASELINE_PORT"
  echo "test port    : $TEST_PORT"

  local row id name image
  row="$(baseline_info)"
  IFS='|' read -r id name image <<< "$row"

  echo "baseline     : $name"
  echo "image        : $image"

  # Environment diagnose must work BEFORE the first build/sync.
  # Artifact presence is mandatory for `deploy`, but optional for `diagnose`.
  if [[ ! -d "$ARTIFACT_DIR" ]]; then
    echo "[WARN] artifact directory does not exist yet."
    echo "       This is expected before the first successful sync."
    echo "       Expected after sync: $ARTIFACT_DIR"
  elif [[ ! -f "$ARTIFACT_DIR/LATEST" ]]; then
    echo "[WARN] LATEST is not present yet: $ARTIFACT_DIR/LATEST"
    echo "       Run build + sync (or `all`) on 10.1.120.40 before deploy."
  else
    local latest_name artifact
    latest_name="$(head -1 "$ARTIFACT_DIR/LATEST" | tr -d '\r\n')"
    if [[ -z "$latest_name" ]]; then
      echo "[WARN] LATEST exists but is empty: $ARTIFACT_DIR/LATEST"
    else
      artifact="$ARTIFACT_DIR/$latest_name"
      if [[ -f "$artifact" ]]; then
        echo "artifact     : $artifact"
        echo "sha256       : $(sha256_file "$artifact")"
      else
        echo "[WARN] LATEST points to a missing artifact:"
        echo "       $artifact"
        echo "       Run sync again before deploy."
      fi
    fi
  fi

  local current
  current="$(current_test_container)"
  if [[ -n "$current" ]]; then
    assert_test_slot_safe "$current"
    echo "test current : $current"
  else
    echo "test current : none"
  fi

  echo "[OK] remote environment preflight"
  echo "[INFO] artifact availability is checked strictly by the deploy command."
}

status() {
  echo "===== LOCAL BUILD/PACKAGE PATHS ====="
  echo "PROJECT_DIR=$PROJECT_DIR"
  echo "BAZEL_OUTPUT=$BAZEL_OUTPUT"
  echo "LOCAL_ARTIFACT_DIR=$LOCAL_ARTIFACT_DIR"
  echo "REMOTE_ARTIFACT_DIR=$REMOTE_ARTIFACT_DIR"
  echo "USE_SYSROOT=$USE_SYSROOT"
  echo "WTP184_SYSROOT=$WTP184_SYSROOT"
  echo "BAZEL_CC_WRAPPER=$BAZEL_CC_WRAPPER"
  echo "BAZEL_CXX_WRAPPER=$BAZEL_CXX_WRAPPER"
  echo "MAX_TARGET_GLIBC=$MAX_TARGET_GLIBC"
  echo "GCC_HOME=$GCC_HOME"
  if [[ -x "$GCC_HOME/bin/g++" ]]; then
    echo "GCC_VERSION=$("$GCC_HOME/bin/gcc" -dumpversion 2>/dev/null || true)"
    echo "GCC_TARGET=$("$GCC_HOME/bin/gcc" -dumpmachine 2>/dev/null || true)"
    echo "GCC_LIBSTDCPP=$("$GCC_HOME/bin/g++" -print-file-name=libstdc++.so 2>/dev/null || true)"
  fi
  if [[ -f "$GCC_HOME/.wtp184/provenance.txt" ]]; then
    echo "GCC_IDENTITY=$(sed -n 's/^TOOLCHAIN_IDENTITY=//p' "$GCC_HOME/.wtp184/provenance.txt" | tail -n1)"
  fi
  if [[ -f "$WTP184_SYSROOT/.wtp184/provenance.txt" ]]; then
    echo "SYSROOT_IDENTITY=$(sed -n -e 's/^TOOLCHAIN_IDENTITY=//p' -e 's/^SYSROOT_IDENTITY=//p' "$WTP184_SYSROOT/.wtp184/provenance.txt" | tail -n1)"
  fi
  echo

  echo "===== BAZEL OUTPUT ====="
  if [[ -f "$BAZEL_OUTPUT" ]]; then
    ls -lh "$BAZEL_OUTPUT"
    echo "BAZEL_SHA256=$(sha256_file "$BAZEL_OUTPUT")"
  else
    echo "BAZEL_OUTPUT_MISSING"
  fi
  echo

  docker_init

  echo "===== BASELINE :$BASELINE_PORT ====="
  running_rows_by_port "$BASELINE_PORT" || true

  echo
  echo "===== TEST :$TEST_PORT ====="
  running_rows_by_port "$TEST_PORT" || true

  echo
  echo "===== TEST SLOT HISTORY CONTAINERS ====="
  "${DOCKER[@]}" ps -a \
    --filter "label=cu.dev.slot=$TEST_PORT" \
    --format 'table {{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'

  echo
  echo "===== ARTIFACT ====="
  if [[ -f "$ARTIFACT_DIR/LATEST" ]]; then
    cat "$ARTIFACT_DIR/LATEST"
    local artifact
    artifact="$(latest_artifact)"
    echo "sha256=$(sha256_file "$artifact")"
  else
    echo "LATEST missing"
  fi

  echo
  echo "===== HISTORY (last 20) ====="
  [[ -f "$HISTORY" ]] && tail -n 20 "$HISTORY" || echo "no history yet"

  echo
  echo "log=$LOG_FILE"
}

case "$CMD" in
  diagnose) diagnose ;;
  deploy) deploy ;;
  test)
    docker_init
    smoke_test "$TEST_PORT" "manual-test-$(date '+%Y%m%d-%H%M%S')"
    ;;
  compare)
    docker_init
    compare_ab
    ;;
  rollback) rollback ;;
  status) status ;;
  *)
    echo "Usage: $0 {diagnose|deploy|test|compare|rollback|status}" >&2
    exit 2
    ;;
esac
__CU_REMOTE_HELPER__

  log "[OK] remote helper installed"
}

remote_helper_cmd() {
  local subcmd="$1"

  install_remote_helper

  # -tt intentionally allocates a TTY. If server 21 needs a sudo password for
  # Docker, the command waits for the user instead of failing invisibly.
  ssh_base_args

  local remote_cmd
  printf -v remote_cmd \
    'BASELINE_PORT=%q TEST_PORT=%q CONTAINER_HTTP_PORT=%q ARTIFACT_DIR=%q CURL_PATH=%q TEST_QUERY=%q CURL_MAX_TIME=%q SMOKE_RETRIES=%q SMOKE_INTERVAL=%q %q %q' \
    "$BASELINE_PORT" \
    "$TEST_PORT" \
    "$CONTAINER_HTTP_PORT" \
    "$REMOTE_ARTIFACT_DIR" \
    "$CURL_PATH" \
    "$TEST_QUERY" \
    "$CURL_MAX_TIME" \
    "$SMOKE_RETRIES" \
    "$SMOKE_INTERVAL" \
    "$REMOTE_HELPER" \
    "$subcmd"

  log "[REMOTE] command=$subcmd host=$TARGET_SSH helper=$REMOTE_HELPER"

  local rc
  set +e
  ssh -tt "${SSH_ARGS[@]}" "$TARGET_SSH" "$remote_cmd"
  rc=$?
  set -e

  log "[REMOTE] command=$subcmd rc=$rc"
  [[ "$rc" -eq 0 ]] || return "$rc"
}

# ------------------------------------------------------------------------------
# Server-21 auto_build.sh deployment path
# ------------------------------------------------------------------------------

remote_auto_build_deploy() {
  prepare_selected_deployment
  check_batch_ssh || die "BatchMode SSH to $TARGET_SSH failed. Run: $SELF setup-ssh"
  ssh_base_args

  if [[ "$TEST_PORT" == "$BASELINE_PORT" ]]; then
    die "refusing deploy: TEST_PORT=$TEST_PORT equals BASELINE_PORT=$BASELINE_PORT"
  fi
  [[ "$TEST_PORT" == "9530" ]] || \
    log "[WARN] TEST_PORT=$TEST_PORT; expected development slot is 9530"

  local latest_name latest_artifact local_sha local_size
  latest_name="$(selected_deployment_name)"
  latest_artifact="$LOCAL_ARTIFACT_DIR/$latest_name"
  [[ -x "$latest_artifact" ]] || die "latest artifact missing/not executable: $latest_artifact"
  local_sha="$(sha256_file "$latest_artifact")"
  local_size="$(stat -c '%s' "$latest_artifact")"
  if [[ -n "${V3_DEPLOY_PINNED_NAME:-}" ]]; then
    [[ "$local_sha" == "$V3_DEPLOY_PINNED_SHA" ]] || \
      die "V3 debug artifact SHA changed before managed deployment"
    [[ "$local_size" == "$V3_DEPLOY_PINNED_SIZE" ]] || \
      die "V3 debug artifact size changed before managed deployment"
  fi

  log "===== SERVER 21 AUTO_BUILD DEPLOY ====="
  log "remote_package_root=$REMOTE_PACKAGE_ROOT"
  log "remote_auto_build=$REMOTE_AUTO_BUILD"
  log "model=$REMOTE_MODEL_DIR"
  log "server=$latest_name"
  log "port=$TEST_PORT"
  log "expected_sha256=$local_sha"
  log "expected_size=$local_size"

  local remote_cmd
  printf -v remote_cmd \
    'set -Eeuo pipefail; cd %q; test -f %q; test -d %q; test -f %q/%q; printf "AUTO_BUILD_MODEL=%%s\nAUTO_BUILD_SERVER=%%s\nAUTO_BUILD_PORT=%%s\n" %q %q %q; PACKAGE_ROOT=%q bash %q %q %q %q' \
    "$REMOTE_PACKAGE_ROOT" \
    "$REMOTE_AUTO_BUILD" \
    "$REMOTE_MODEL_DIR" \
    "$REMOTE_ARTIFACT_DIR" \
    "$latest_name" \
    "$REMOTE_MODEL_DIR" \
    "$latest_name" \
    "$TEST_PORT" \
    "$REMOTE_PACKAGE_ROOT" \
    "$REMOTE_AUTO_BUILD" \
    "$REMOTE_MODEL_DIR" \
    "$latest_name" \
    "$TEST_PORT"

  local rc
  set +e
  ssh -tt "${SSH_ARGS[@]}" "$TARGET_SSH" "$remote_cmd" 2>&1 | tee -a "$LOG_FILE"
  rc=${PIPESTATUS[0]}
  set -e

  log "[REMOTE AUTO_BUILD] rc=$rc"
  [[ "$rc" -eq 0 ]] || return "$rc"
}

verify_remote_auto_build_deploy() {
  prepare_selected_deployment
  log "[VERIFY] server 21 auto_build deployment on :$TEST_PORT"
  check_batch_ssh || die "post-deploy SSH verification failed"
  ssh_batch_args

  local latest_name local_sha local_size output rc
  if [[ -n "${V3_DEPLOY_PINNED_NAME:-}" ]]; then
    latest_name="$V3_DEPLOY_PINNED_NAME"
    local_sha="$(sha256_file "$LOCAL_ARTIFACT_DIR/$latest_name")"
    local_size="$(stat -c '%s' "$LOCAL_ARTIFACT_DIR/$latest_name")"
    [[ "$local_sha" == "$V3_DEPLOY_PINNED_SHA" ]] || \
      die "V3 debug artifact SHA changed before verification"
    [[ "$local_size" == "$V3_DEPLOY_PINNED_SIZE" ]] || \
      die "V3 debug artifact size changed before verification"
  else
    latest_name="$(head -n1 "$LOCAL_ARTIFACT_DIR/LATEST" | tr -d '\r\n')"
    local_sha="$(sha256_file "$LOCAL_ARTIFACT_DIR/$latest_name")"
    local_size="$(stat -c '%s' "$LOCAL_ARTIFACT_DIR/$latest_name")"
  fi

  set +e
  output="$(
    ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
      "TEST_PORT=$(printf '%q' "$TEST_PORT") REMOTE_DIR=$(printf '%q' "$REMOTE_ARTIFACT_DIR") EXPECT_NAME=$(printf '%q' "$latest_name") EXPECT_SHA=$(printf '%q' "$local_sha") EXPECT_SIZE=$(printf '%q' "$local_size") bash -s" <<'EOS'
set -Eeuo pipefail

artifact="$REMOTE_DIR/$EXPECT_NAME"
[[ -f "$artifact" ]] || { echo "VERIFY_ERROR=REMOTE_ARTIFACT_MISSING"; exit 41; }
remote_size="$(stat -c '%s' "$artifact")"
remote_sha="$(sha256sum "$artifact" | awk '{print $1}')"
echo "REMOTE_ARTIFACT=$artifact"
echo "REMOTE_SIZE=$remote_size"
echo "REMOTE_SHA256=$remote_sha"
[[ "$remote_size" == "$EXPECT_SIZE" ]] || { echo "VERIFY_ERROR=REMOTE_SIZE_MISMATCH"; exit 42; }
[[ "$remote_sha" == "$EXPECT_SHA" ]] || { echo "VERIFY_ERROR=REMOTE_SHA_MISMATCH"; exit 43; }

if docker info >/dev/null 2>&1; then
  docker_cmd=(docker)
elif command -v sudo >/dev/null 2>&1 && sudo -n docker info >/dev/null 2>&1; then
  docker_cmd=(sudo -n docker)
else
  echo "VERIFY_ERROR=DOCKER_UNAVAILABLE"
  exit 44
fi

mapfile -t rows < <("${docker_cmd[@]}" ps --filter "publish=${TEST_PORT}" --format '{{.ID}}|{{.Names}}|{{.Image}}|{{.Ports}}')
echo "VERIFY_CONTAINER_COUNT=${#rows[@]}"
printf 'VERIFY_CONTAINER=%s\n' "${rows[@]}"
(( ${#rows[@]} == 1 )) || { echo "VERIFY_ERROR=CONTAINER_COUNT"; exit 45; }

IFS='|' read -r cid cname cimage cports <<< "${rows[0]}"
[[ "$cid" =~ ^[a-f0-9]{12}$ ]] || { echo "VERIFY_ERROR=INVALID_ID"; exit 45; }
bindings="$("${docker_cmd[@]}" inspect --format '{{range $p, $bs := .HostConfig.PortBindings}}{{range $bs}}{{printf "%s:%s\n" $p .HostPort}}{{end}}{{end}}' "$cid")"
found=0
while IFS= read -r binding; do
  [[ -n "$binding" ]] || continue
  [[ "$binding" == "8080/tcp:$TEST_PORT" ]] || { echo "VERIFY_ERROR=PORT_BINDING"; exit 45; }
  found=1
done <<< "$bindings"
(( found )) || { echo "VERIFY_ERROR=PORT_BINDING_MISSING"; exit 45; }
container_sha="$("${docker_cmd[@]}" exec "$cid" sha256sum /usr/bin/cu-server | awk '{print $1}')"
version="$("${docker_cmd[@]}" exec "$cid" sh -c 'cat /runtime/version.txt 2>/dev/null || true' | tr -d '\r\n')"
core_pattern="$("${docker_cmd[@]}" exec "$cid" cat /proc/sys/kernel/core_pattern 2>/dev/null || true)"
core_limits="$("${docker_cmd[@]}" exec "$cid" sh -c 'printf "soft=%s hard=%s" "$(ulimit -Sc)" "$(ulimit -Hc)"' 2>/dev/null || true)"

echo "CONTAINER_ID=$cid"
echo "CONTAINER_NAME=$cname"
echo "CONTAINER_IMAGE=$cimage"
echo "CONTAINER_SHA256=$container_sha"
echo "CONTAINER_VERSION=$version"
echo "CORE_PATTERN=$core_pattern"
echo "CORE_LIMITS=$core_limits"

[[ "$container_sha" == "$EXPECT_SHA" ]] || { echo "VERIFY_ERROR=CONTAINER_BINARY_SHA_MISMATCH"; exit 46; }
[[ "$version" == "$EXPECT_NAME" ]] || { echo "VERIFY_ERROR=VERSION_TXT_MISMATCH"; exit 47; }

echo "VERIFY_OK=1"
EOS
  )"
  rc=$?
  set -e

  printf '%s\n' "$output" | tee -a "$LOG_FILE"
  [[ "$rc" -eq 0 ]] || die "post-deploy verification failed rc=$rc"
  grep -q '^VERIFY_OK=1$' <<<"$output" || die "post-deploy verification did not return VERIFY_OK=1"
  DEPLOY_VERIFIED_ID="$(sed -n 's/^CONTAINER_ID=//p' <<< "$output")"
  [[ "$DEPLOY_VERIFIED_ID" =~ ^[a-f0-9]{12}$ ]] || die "verification returned invalid container ID"
  log "[OK] deployed container binary exactly matches selected artifact"
}

remote_http_smoke() {
  local port="${1:-80}"
  local label="${2:-smoke}"
  check_batch_ssh || die "BatchMode SSH to $TARGET_SSH failed"
  ssh_batch_args

  log "[SMOKE] $label http://127.0.0.1:${port}${CURL_PATH} query=$TEST_QUERY"
  local output rc
  set +e
  output="$(
    ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
      "PORT=$(printf '%q' "$port") PATH_=$(printf '%q' "$CURL_PATH") QUERY=$(printf '%q' "$TEST_QUERY") MAX_TIME=$(printf '%q' "$CURL_MAX_TIME") RETRIES=$(printf '%q' "$SMOKE_RETRIES") INTERVAL=$(printf '%q' "$SMOKE_INTERVAL") python3 -" <<'PY'
import json, os, subprocess, sys, time
port=os.environ['PORT']; path=os.environ['PATH_']; query=os.environ['QUERY']
max_time=os.environ['MAX_TIME']; retries=int(os.environ['RETRIES']); interval=float(os.environ['INTERVAL'])
body=json.dumps({'query': query}, ensure_ascii=False, separators=(',', ':'))
url=f'http://127.0.0.1:{port}{path}'
for attempt in range(1, retries+1):
    p=subprocess.run(['curl','-sS','--max-time',max_time,
                      '-H','Content-Type: application/json',
                      '--data-binary',body,
                      '-w','\n__HTTP__=%{http_code}',
                      '-X','POST',url],
                     text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    raw=p.stdout
    marker='\n__HTTP__='
    if marker in raw:
        payload, code=raw.rsplit(marker,1)
    else:
        payload, code=raw, ''
    print(f'ATTEMPT={attempt} CURL_RC={p.returncode} HTTP={code}')
    if p.returncode==0 and code=='200':
        try:
            obj=json.loads(payload)
            header_code=obj.get('Header',{}).get('Code')
            semantic_present='Semantic' in obj.get('Payload',{})
            print(f'HEADER_CODE={header_code}')
            print(f'SEMANTIC_EXISTS={semantic_present}')
            if header_code==0 and semantic_present:
                print('SMOKE_OK=1')
                sys.exit(0)
        except Exception as e:
            print('JSON_ERROR='+repr(e))
    if p.stderr:
        print('CURL_STDERR='+p.stderr.strip())
    time.sleep(interval)
print('SMOKE_OK=0')
sys.exit(51)
PY
  )"
  rc=$?
  set -e
  printf '%s\n' "$output" | tee -a "$LOG_FILE"
  [[ "$rc" -eq 0 ]] || return "$rc"
  grep -q '^SMOKE_OK=1$' <<<"$output"
}

remote_compare_ab() {
  log "===== A/B SMOKE: baseline :$BASELINE_PORT vs test :$TEST_PORT ====="
  remote_http_smoke "$BASELINE_PORT" "baseline"
  remote_http_smoke "$TEST_PORT" "test"
  log "[OK] both baseline and test passed smoke assertions"
}

remote_server_status() {
  check_batch_ssh || die "BatchMode SSH to $TARGET_SSH failed"
  ssh_batch_args
  ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
    "BASELINE_PORT=$(printf '%q' "$BASELINE_PORT") TEST_PORT=$(printf '%q' "$TEST_PORT") REMOTE_DIR=$(printf '%q' "$REMOTE_ARTIFACT_DIR") AUTO_BUILD=$(printf '%q' "$REMOTE_AUTO_BUILD") MODEL_DIR=$(printf '%q' "$REMOTE_MODEL_DIR") bash -s" <<'EOS'
set -u
echo "REMOTE_ARTIFACT_DIR=$REMOTE_DIR"
echo "REMOTE_AUTO_BUILD=$AUTO_BUILD"
echo "REMOTE_MODEL_DIR=$MODEL_DIR"
echo "AUTO_BUILD_EXISTS=$([[ -x "$AUTO_BUILD" ]] && echo YES || echo NO)"
echo "MODEL_EXISTS=$([[ -d "$MODEL_DIR" ]] && echo YES || echo NO)"
if [[ -f "$REMOTE_DIR/LATEST" ]]; then
  echo "REMOTE_LATEST=$(head -n1 "$REMOTE_DIR/LATEST" | tr -d '\r\n')"
else
  echo "REMOTE_LATEST=MISSING"
fi
if docker info >/dev/null 2>&1; then
  docker ps --format 'DOCKER={{.ID}}|{{.Names}}|{{.Image}}|{{.Ports}}' | grep -E ":(${BASELINE_PORT}|${TEST_PORT})->" || true
elif command -v sudo >/dev/null 2>&1 && sudo -n docker info >/dev/null 2>&1; then
  sudo -n docker ps --format 'DOCKER={{.ID}}|{{.Names}}|{{.Image}}|{{.Ports}}' | grep -E ":(${BASELINE_PORT}|${TEST_PORT})->" || true
else
  echo "DOCKER=UNAVAILABLE"
fi
EOS
}

deploy_pipeline() {
  prepare_selected_deployment
  log "===== DEPLOY PIPELINE START ====="
  log "script=$SELF"
  log "source_host=$(hostname 2>/dev/null || true)"
  log "artifact_source=$LOCAL_ARTIFACT_DIR"
  log "target=$TARGET_SSH"
  log "remote_package_root=$REMOTE_PACKAGE_ROOT"
  log "remote_artifact_dir=$REMOTE_ARTIFACT_DIR"
  log "remote_model=$REMOTE_MODEL_DIR"
  log "test_port=$TEST_PORT"

  log "[PHASE 1/4] sync artifacts -> server21 $REMOTE_ARTIFACT_DIR"
  sync_artifacts
  log "[OK] phase 1 sync"

  log "[PHASE 2/4] invoke server21 auto_build.sh"
  remote_auto_build_deploy || die "server21 auto_build.sh deploy failed"
  log "[OK] phase 2 auto_build"

  log "[PHASE 3/4] verify container/binary/version"
  verify_remote_auto_build_deploy
  log "[OK] phase 3 verification"
  publish_verified_deployment || return "$?"

  log "[PHASE 4/4] HTTP smoke test"
  remote_http_smoke "$TEST_PORT" "post-deploy" || die "post-deploy HTTP smoke failed"
  log "[OK] phase 4 smoke test"

  log "===== DEPLOY PIPELINE SUCCESS ====="
}

# ------------------------------------------------------------------------------
# 5. Diagnostics and status
# ------------------------------------------------------------------------------

diagnose() {
  local failed=0

  echo "===== LOCAL BUILD SERVER DIAGNOSE ====="
  echo "expected build server IP : $BUILD_SERVER_IP"
  echo "project                  : $PROJECT_DIR"
  echo "package dir              : $LOCAL_ARTIFACT_DIR"
  echo "third_party              : $THIRD_PARTY_DIR"
  echo "GCC_HOME                 : $GCC_HOME"
  echo "Use sysroot              : $USE_SYSROOT"
  echo "WTP184_SYSROOT           : $WTP184_SYSROOT"
  echo "Bazel CC wrapper         : $BAZEL_CC_WRAPPER"
  echo "Bazel CXX wrapper        : $BAZEL_CXX_WRAPPER"
  echo "Max target GLIBC         : $MAX_TARGET_GLIBC"
  echo "Bazel target/host CPU    : $BAZEL_CPU / $BAZEL_HOST_CPU"
  echo "Allow shlib undefined    : $ALLOW_SHLIB_UNDEFINED"
  echo "target                    : $TARGET_SSH"
  echo "remote package root       : $REMOTE_PACKAGE_ROOT"
  echo "remote artifact dir       : $REMOTE_ARTIFACT_DIR"
  echo "remote auto_build         : $REMOTE_AUTO_BUILD"
  echo "remote model dir          : $REMOTE_MODEL_DIR"
  echo "baseline/test ports       : $BASELINE_PORT / $TEST_PORT"
  echo

  if hostname -I 2>/dev/null | tr ' ' '\n' | grep -qx "$BUILD_SERVER_IP"; then
    echo "[OK] current host has IP $BUILD_SERVER_IP"
  else
    echo "[WARN] current host does not visibly report $BUILD_SERVER_IP"
  fi

  for cmd in "$BAZEL_BIN" git rsync ssh; do
    if have "$cmd"; then
      echo "[OK] $cmd -> $(command -v "$cmd")"
    else
      echo "[FAIL] missing command: $cmd"
      failed=1
    fi
  done

  if resolve_gcc; then
    echo "[OK] CC=$CC_PATH"
    echo "[OK] CXX=$CXX_PATH"
    echo "[OK] $("$CC_PATH" --version | head -1)"

    if validate_migrated_gcc_runtime; then
      echo "[OK] migrated GCC runtime validated"
    else
      echo "[FAIL] migrated GCC runtime validation failed"
      failed=1
    fi
  else
    failed=1
  fi

  if [[ "$USE_SYSROOT" == "1" ]]; then
    if validate_sysroot; then
      echo "[OK] sysroot validated: $WTP184_SYSROOT"

      if prepare_bazel_cc_wrappers; then
        echo "[OK] Bazel sysroot compiler wrappers validated"
        export CC="$BAZEL_CC_WRAPPER"
        export CXX="$BAZEL_CXX_WRAPPER"
        export PATH="$BAZEL_CC_WRAPPER_ROOT/bin:$GCC_HOME/bin:$PATH"

        if refresh_and_validate_local_config_cc; then
          echo "[OK] Bazel local_config_cc builtin sysroot validated"
        else
          echo "[FAIL] Bazel local_config_cc sysroot validation failed"
          failed=1
        fi
      else
        echo "[FAIL] Bazel compiler wrapper validation failed"
        failed=1
      fi
    else
      echo "[FAIL] sysroot validation failed"
      failed=1
    fi
  else
    echo "[WARN] sysroot disabled"
  fi

  if [[ -d "$PROJECT_DIR" ]]; then
    echo "[OK] project dir exists"

    if validate_third_party; then
      echo "[OK] third_party validated: $THIRD_PARTY_DIR"
    else
      echo "[FAIL] third_party validation failed"
      failed=1
    fi

    if ! check_linux_bazel_config; then
      failed=1
    fi
  else
    echo "[FAIL] project dir missing: $PROJECT_DIR"
    failed=1
  fi

  if [[ -f "$LOCAL_ARTIFACT_DIR/LATEST" ]]; then
    latest_local_name="$(head -1 "$LOCAL_ARTIFACT_DIR/LATEST" | tr -d '\r\n')"
    if [[ -n "$latest_local_name" && -f "$LOCAL_ARTIFACT_DIR/$latest_local_name" ]]; then
      echo "[OK] local latest artifact: $LOCAL_ARTIFACT_DIR/$latest_local_name"
    else
      echo "[WARN] local LATEST exists but target artifact is missing/invalid"
      echo "       A fresh build will regenerate it."
    fi
  else
    echo "[INFO] no pipeline LATEST artifact yet; this is valid before the first build"
  fi

  if check_batch_ssh; then
    echo "[OK] BatchMode SSH -> $TARGET_SSH"
  else
    echo "[FAIL] BatchMode SSH -> $TARGET_SSH"
    echo "       Run: $SELF setup-ssh"
    failed=1
  fi

  if [[ "$failed" -eq 0 ]]; then
    echo
    echo "===== SERVER 21 AUTO_BUILD DIAGNOSE ====="
    if ! remote_server_status; then
      failed=1
    fi

    ssh_batch_args
    if ! ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" \
      "test -f $(printf '%q' "$REMOTE_AUTO_BUILD") && test -d $(printf '%q' "$REMOTE_MODEL_DIR") && mkdir -p $(printf '%q' "$REMOTE_ARTIFACT_DIR")"; then
      echo "[FAIL] server21 auto_build/model/artifact-dir preflight failed"
      failed=1
    else
      echo "[OK] server21 auto_build/model/artifact-dir preflight passed"
    fi
  fi

  return "$failed"
}

status() {
  echo "===== BUILD INPUTS ====="
  echo "PROJECT_DIR=$PROJECT_DIR"
  echo "THIRD_PARTY_DIR=$THIRD_PARTY_DIR"
  echo "GCC_HOME=$GCC_HOME"
  echo "WTP184_SYSROOT=$WTP184_SYSROOT"
  echo "MAX_TARGET_GLIBC=$MAX_TARGET_GLIBC"
  echo "ALLOW_SHLIB_UNDEFINED=$ALLOW_SHLIB_UNDEFINED"
  echo

  echo "===== LOCAL ARTIFACT ====="
  if [[ -f "$LOCAL_ARTIFACT_DIR/LATEST" ]]; then
    local name
    name="$(cat "$LOCAL_ARTIFACT_DIR/LATEST")"
    echo "LATEST=$name"
    if [[ -f "$LOCAL_ARTIFACT_DIR/$name" ]]; then
      echo "sha256=$(sha256_file "$LOCAL_ARTIFACT_DIR/$name")"
      [[ -f "$LOCAL_ARTIFACT_DIR/$name.meta" ]] && cat "$LOCAL_ARTIFACT_DIR/$name.meta"
    fi
  else
    echo "No LATEST artifact yet"
  fi

  echo
  echo "===== SYNC SERVICE ====="
  if have systemctl; then
    systemctl --no-pager --full status "$SYNC_SERVICE_NAME" 2>/dev/null || true
  fi

  echo
  echo "===== SERVER 21 ====="
  remote_server_status
}

# ------------------------------------------------------------------------------
# 6. systemd sync service on 10.1.120.40
# ------------------------------------------------------------------------------

install_sync_service() {
  have systemctl || die "systemctl not found"
  have sudo || die "sudo not found"

  local user group unit tmp
  user="$(id -un)"
  group="$(id -gn)"
  unit="/etc/systemd/system/$SYNC_SERVICE_NAME"
  tmp="$(mktemp)"

  cat > "$tmp" <<EOF
[Unit]
Description=CU development artifact rsync to server 21
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$user
Group=$group
Environment=HOME=$HOME
Environment=GCC_HOME=$GCC_HOME
Environment=WTP184_SYSROOT=$WTP184_SYSROOT
Environment=BAZEL_CC_WRAPPER_ROOT=$BAZEL_CC_WRAPPER_ROOT
Environment=THIRD_PARTY_DIR=$THIRD_PARTY_DIR
Environment=ALLOW_SHLIB_UNDEFINED=$ALLOW_SHLIB_UNDEFINED
Environment=TARGET_USER=$TARGET_USER
Environment=TARGET_HOST=$TARGET_HOST
Environment=TARGET_PORT=$TARGET_PORT
Environment=SSH_IDENTITY=$SSH_IDENTITY
Environment=LOCAL_ARTIFACT_DIR=$LOCAL_ARTIFACT_DIR
Environment=REMOTE_PACKAGE_ROOT=$REMOTE_PACKAGE_ROOT
Environment=REMOTE_ARTIFACT_DIR=$REMOTE_ARTIFACT_DIR
Environment=REMOTE_AUTO_BUILD=$REMOTE_AUTO_BUILD
Environment=REMOTE_MODEL_DIR=$REMOTE_MODEL_DIR
Environment=SYNC_INTERVAL=$SYNC_INTERVAL
ExecStart=$SELF watch-sync
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

  log "Installing systemd service: $unit"
  log "sudo may ask for your password."

  sudo install -m 0644 "$tmp" "$unit"
  rm -f "$tmp"

  sudo systemctl daemon-reload
  sudo systemctl enable --now "$SYNC_SERVICE_NAME"

  sudo systemctl --no-pager --full status "$SYNC_SERVICE_NAME" || true

  log "[OK] sync service installed"
  log "Logs: journalctl -u $SYNC_SERVICE_NAME -f"
}

uninstall_sync_service() {
  have sudo || die "sudo not found"
  log "Removing sync service: $SYNC_SERVICE_NAME"

  sudo systemctl disable --now "$SYNC_SERVICE_NAME" 2>/dev/null || true
  sudo rm -f "/etc/systemd/system/$SYNC_SERVICE_NAME"
  sudo systemctl daemon-reload

  log "[OK] sync service removed"
}

# ------------------------------------------------------------------------------
# 7. Quick build/deploy/test commands
# ------------------------------------------------------------------------------

print_dry_run_argv() {
  printf 'DRY_RUN argv='
  printf ' %q' "$@"
  printf '\n'
}

resolve_v3_build_action() {
  local action="$1"
  V3_COMPAT_ALIAS=0
  case "$action" in
    v3_debug_build)
      V3_BUILD_PROFILE=debug
      ;;
    v3_build)
      V3_BUILD_PROFILE=release
      V3_COMPAT_ALIAS=1
      ;;
    v3_release_build)
      V3_BUILD_PROFILE=release
      ;;
    *)
      die "unsupported V3 build action: $action"
      ;;
  esac

  DIALOGUE_PIPELINE_VARIANT=v3
  DIALOGUE_PIPELINE_DEFINE=dialogue_pipeline_v3=true
  PROJECT_DIR="$V3_PROJECT_DIR"
  THIRD_PARTY_DIR="$V3_THIRD_PARTY_DIR"
  BAZEL_OUTPUT="$PROJECT_DIR/bazel-bin/cu/server"
  LOCAL_ARTIFACT_DIR="$V3_ARTIFACT_ROOT/$V3_BUILD_PROFILE"
  RELEASE_NOTE_FILE="$V3_RELEASE_NOTE_FILE"
  ARTIFACT_PREFIX="server-v3-$V3_BUILD_PROFILE"
  BUILD_LOG_PREFIX="bazel-cu-server-v3-$V3_BUILD_PROFILE"
  LOG_FILE="$BUILD_LOG_DIR/cu-dev-pipeline-v3-${V3_BUILD_PROFILE}-$(date '+%Y%m%d-%H%M%S').log"
}

resolve_v3_debug_deploy_action() {
  DIALOGUE_PIPELINE_VARIANT=v3
  DIALOGUE_PIPELINE_DEFINE=dialogue_pipeline_v3=true
  V3_BUILD_PROFILE=debug
  LOCAL_ARTIFACT_DIR="$V3_ARTIFACT_ROOT/$V3_BUILD_PROFILE"
  REMOTE_ARTIFACT_DIR="$REMOTE_PACKAGE_ROOT/server"
  LOG_FILE="$BUILD_LOG_DIR/cu-dev-pipeline-v3-debug-deploy-$(date '+%Y%m%d-%H%M%S').log"
}

validate_v3_debug_deploy_artifact() {
  local latest_file="$LOCAL_ARTIFACT_DIR/LATEST"
  [[ -n "$SERVER_VERSION" || -f "$latest_file" ]] ||     die "V3 debug LATEST missing: $latest_file. Run '$SELF v3_debug_build' first."

  local latest_name
  if [[ -n "$SERVER_VERSION" ]]; then
    latest_name="$SERVER_VERSION"
  else
    latest_name="$(head -n1 "$latest_file" | tr -d '\r\n')"
  fi
  [[ "$latest_name" =~ ^server-v3-debug[.][A-Za-z0-9._-]+$ ]] || die "selected artifact must be an exact V3 debug executable"
  [[ "$latest_name" != */* && "$latest_name" != "." &&
     "$latest_name" != ".." ]] ||     die "invalid V3 debug LATEST artifact name: $latest_name"

  local artifact="$LOCAL_ARTIFACT_DIR/$latest_name"
  local metadata="$artifact.meta"
  [[ -f "$artifact" && -x "$artifact" ]] ||     die "V3 debug artifact missing/not executable: $artifact"
  [[ -f "$metadata" ]] || die "V3 debug metadata missing: $metadata"

  local artifact_sha artifact_size
  artifact_sha="$(sha256_file "$artifact")"
  artifact_size="$(stat -c '%s' "$artifact")"
  grep -Fqx "artifact=$latest_name" "$metadata" ||     die "V3 debug metadata artifact mismatch"
  grep -Fqx "bazel_target=//cu:server" "$metadata" ||     die "V3 debug metadata target mismatch"
  grep -Fqx "build_profile=debug" "$metadata" ||     die "V3 debug metadata profile mismatch"
  grep -Fqx "release_stripped=0" "$metadata" ||     die "V3 debug metadata strip mismatch"
  grep -Fqx "dialogue_pipeline_variant=v3" "$metadata" ||     die "V3 debug metadata variant mismatch"
  grep -Fqx "dialogue_pipeline_define=dialogue_pipeline_v3=true"     "$metadata" || die "V3 debug metadata define mismatch"
  grep -Fqx "latest_pointer=$LOCAL_ARTIFACT_DIR/LATEST" "$metadata" ||     die "V3 debug metadata pointer mismatch"
  grep -Fqx "sha256=$artifact_sha" "$metadata" ||     die "V3 debug metadata sha256 mismatch"
  grep -Fqx "size=$artifact_size" "$metadata" ||     die "V3 debug metadata size mismatch"
  grep -Fqx "package_onnxruntime_selected=0" "$metadata" ||     die "V3 debug metadata package selection mismatch"

  V3_DEPLOY_PINNED_NAME="$latest_name"
  V3_DEPLOY_PINNED_SHA="$artifact_sha"
  V3_DEPLOY_PINNED_SIZE="$artifact_size"

  log "V3_DEPLOY_ARTIFACT=$latest_name"
  log "V3_DEPLOY_SHA256=$artifact_sha"
  log "V3_DEPLOY_SIZE=$artifact_size"
  log "V3_DEPLOY_LOCAL_DIR=$LOCAL_ARTIFACT_DIR"
  log "V3_DEPLOY_REMOTE_DIR=$REMOTE_ARTIFACT_DIR"
}

# One validated tuple throughout sync/deploy/verification; explicit selection
# never consults or rewrites LATEST. Default selection still detects drift.
prepare_selected_deployment() {
  if [[ -n "$SERVER_VERSION${V3_DEPLOY_PINNED_NAME:-}" || "$DEPLOY_METADATA" == 1 ]]; then
    resolve_v3_debug_deploy_action
    local old_name="${V3_DEPLOY_PINNED_NAME:-}" old_sha="${V3_DEPLOY_PINNED_SHA:-}" old_size="${V3_DEPLOY_PINNED_SIZE:-}"
    validate_v3_debug_deploy_artifact
    if [[ -n "$old_name" ]]; then
      [[ "$V3_DEPLOY_PINNED_NAME" == "$old_name" && "$V3_DEPLOY_PINNED_SHA" == "$old_sha" && "$V3_DEPLOY_PINNED_SIZE" == "$old_size" ]] || die "selected V3 artifact tuple changed after validation"
    fi
  fi
}

selected_deployment_name() {
  local name
  if [[ -n "$SERVER_VERSION" ]]; then
    [[ "$SERVER_VERSION" == "${V3_DEPLOY_PINNED_NAME:-}" ]] || die "selected artifact not validated"
    name="$SERVER_VERSION"
  else
    name="$(head -n1 "$LOCAL_ARTIFACT_DIR/LATEST" | tr -d '\r\n')"
    [[ -n "$name" ]] || die "local LATEST is empty"
    [[ -z "${V3_DEPLOY_PINNED_NAME:-}" || "$name" == "$V3_DEPLOY_PINNED_NAME" ]] || die "V3 debug LATEST changed after validation"
  fi
  printf '%s\n' "$name"
}

publish_verified_deployment() {
  (( DEPLOY_METADATA )) || return 0
  [[ "$DEPLOY_VERIFIED_ID" =~ ^[a-f0-9]{12}$ && -n "${V3_DEPLOY_PINNED_NAME:-}" ]] || die "metadata requires verified V3 deployment"
  local project="$DEPLOY_PROJECT_NAME" remote_cmd rc
  if (( ! DEPLOY_PROJECT_EXPLICIT )); then project="$(basename -- "$REMOTE_MODEL_DIR")"; fi
  ssh_batch_args
  printf -v remote_cmd 'PACKAGE_ROOT=%q bash %q %q %q %q --publish-only --project-name %q --description %q --verified-id %q --expected-sha %q --expected-size %q' \
    "$REMOTE_PACKAGE_ROOT" "$REMOTE_AUTO_BUILD" "$REMOTE_MODEL_DIR" \
    "$V3_DEPLOY_PINNED_NAME" "$TEST_PORT" "$project" "$DEPLOY_DESCRIPTION" \
    "$DEPLOY_VERIFIED_ID" "$V3_DEPLOY_PINNED_SHA" "$V3_DEPLOY_PINNED_SIZE"
  set +e
  ssh "${SSH_BATCH_ARGS[@]}" "$TARGET_SSH" "$remote_cmd" 2>&1 | tee -a "$LOG_FILE"
  rc=${PIPESTATUS[0]}
  set -e
  if (( rc )); then
    log "DEPLOY_STATUS=VERIFIED METADATA_STATUS=FAILED runtime_rollback=none rc=$rc"
    return 50
  fi
}

run_v3_debug_deploy() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf 'DRY_RUN command=%s\n' "$CMD"
    printf 'DRY_RUN dialogue_pipeline_variant=%s\n' "$DIALOGUE_PIPELINE_VARIANT"
    printf 'DRY_RUN dialogue_pipeline_define=%s\n' "$DIALOGUE_PIPELINE_DEFINE"
    printf 'DRY_RUN build_profile=%s\n' "$V3_BUILD_PROFILE"
    printf 'DRY_RUN artifact_dir=%s\n' "$LOCAL_ARTIFACT_DIR"
    printf 'DRY_RUN latest_pointer=%s/LATEST\n' "$LOCAL_ARTIFACT_DIR"
    printf 'DRY_RUN remote_artifact_dir=%s\n' "$REMOTE_ARTIFACT_DIR"
    printf 'DRY_RUN model_dir=%s\nDRY_RUN service_port=%s\n' "$REMOTE_MODEL_DIR" "$TEST_PORT"
    printf 'DRY_RUN server_version=%s\nDRY_RUN metadata=%s\n' "${SERVER_VERSION:-LATEST}" "$DEPLOY_METADATA"
    local project="$DEPLOY_PROJECT_NAME"
    if (( ! DEPLOY_PROJECT_EXPLICIT )); then project="$(basename -- "$REMOTE_MODEL_DIR")"; fi
    printf 'DRY_RUN project_name=%s\nDRY_RUN description=%s\n' "$project" "$DEPLOY_DESCRIPTION"
    printf 'DRY_RUN build=never\n'
    printf 'DRY_RUN deployment=sync+managed_deploy+verify+smoke\n'
    printf 'DRY_RUN steps=validate_v3_debug_artifact,deploy_pipeline\n'
    return 0
  fi

  validate_v3_debug_deploy_artifact
  deploy_pipeline
}

run_v3_profile_build() {
  local profile="$1"
  [[ "$profile" == "$V3_BUILD_PROFILE" ]] || die "V3 profile resolution mismatch"
  select_build_profile "$profile"
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf 'DRY_RUN command=%s\n' "$CMD"
    printf 'DRY_RUN dialogue_pipeline_variant=%s\n' "$DIALOGUE_PIPELINE_VARIANT"
    printf 'DRY_RUN dialogue_pipeline_define=%s\n' "$DIALOGUE_PIPELINE_DEFINE"
    printf 'DRY_RUN v3_compatibility_alias=%s\n' "$V3_COMPAT_ALIAS"
    printf 'DRY_RUN build_profile=%s\n' "$profile"
    printf 'DRY_RUN project_dir=%s\n' "$PROJECT_DIR"
    printf 'DRY_RUN third_party_dir=%s\n' "$THIRD_PARTY_DIR"
    printf 'DRY_RUN bazel_target=%s\n' "$BAZEL_TARGET"
    printf 'DRY_RUN bazel_output=%s\n' "$BAZEL_OUTPUT"
    printf 'DRY_RUN artifact_dir=%s\n' "$LOCAL_ARTIFACT_DIR"
    printf 'DRY_RUN artifact_prefix=%s\n' "$ARTIFACT_PREFIX"
    printf 'DRY_RUN latest_pointer=%s/LATEST\n' "$LOCAL_ARTIFACT_DIR"
    printf 'DRY_RUN package_library_policy=selected-v3-no-onnxruntime\n'
    printf 'DRY_RUN package_sonames=libstdc++.so.6,libgcc_s.so.1,librdkafka.so.1,libsasl2.so.3,libssl.so.10\n'
    if [[ "$profile" == "debug" ]]; then
      printf 'DRY_RUN bazel_flags=--define=%s --compilation_mode=dbg --strip=never --cxxopt=-fno-omit-frame-pointer --cxxopt=-O0 --cxxopt=-g\n' "$DIALOGUE_PIPELINE_DEFINE"
    else
      printf 'DRY_RUN bazel_flags=--define=%s --compilation_mode=opt --strip=always\n' "$DIALOGUE_PIPELINE_DEFINE"
      printf 'DRY_RUN release_packaging_strip=%s --strip-all\n' "$STRIP_BIN"
    fi
    printf 'DRY_RUN deployment=never\n'
    printf 'DRY_RUN steps=build_server_package_only\n'
    return 0
  fi
  mkdir -p "$LOCAL_ARTIFACT_DIR" "$(dirname "$RELEASE_NOTE_FILE")"
  build_server
}

select_build_profile() {
  local profile="$1"
  case "$profile" in
    debug)
      BAZEL_DEBUG_MODE=1
      BAZEL_RELEASE_MODE=0
      BAZEL_ASAN_MODE=0
      ;;
    release)
      BAZEL_DEBUG_MODE=0
      BAZEL_RELEASE_MODE=1
      BAZEL_ASAN_MODE=0
      ;;
    asan)
      BAZEL_DEBUG_MODE=0
      BAZEL_RELEASE_MODE=0
      BAZEL_ASAN_MODE=1
      ;;
    *)
      die "unsupported build profile: $profile"
      ;;
  esac
}

run_profile_build() {
  local profile="$1"
  select_build_profile "$profile"
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf 'DRY_RUN command=%s\n' "$CMD"
    printf 'DRY_RUN build_profile=%s\n' "$profile"
    if [[ "$profile" == "debug" || "$profile" == "release" ]]; then
      printf 'DRY_RUN package_library_policy=selected-debug-release-only\n'
      printf 'DRY_RUN package_library_dir=%s\n' "$PACKAGE_LIBRARY_DIR"
      printf 'DRY_RUN package_sonames=libstdc++.so.6,libgcc_s.so.1,libonnxruntime.so.1.14.0,librdkafka.so.1,libsasl2.so.3,libssl.so.10\n'
      printf 'DRY_RUN loader_environment=LD_LIBRARY_PATH-unset;selected-view-plus-centos7-sysroot\n'
    fi
    if [[ "$profile" == "debug" ]]; then
      printf 'DRY_RUN bazel_flags=--compilation_mode=dbg --strip=never --cxxopt=-fno-omit-frame-pointer --cxxopt=-O0 --cxxopt=-g\n'
    elif [[ "$profile" == "release" ]]; then
      printf 'DRY_RUN bazel_flags=--compilation_mode=opt --strip=always\n'
      printf 'DRY_RUN release_packaging_strip=%s --strip-all\n' "$STRIP_BIN"
    else
      printf 'DRY_RUN bazel_flags=--compilation_mode=dbg --strip=never --config=asan\n'
    fi
    printf 'DRY_RUN steps=build_server\n'
    return 0
  fi
  build_server
}

run_profile_all() {
  local profile="$1"
  select_build_profile "$profile"
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf 'DRY_RUN command=%s\n' "$CMD"
    printf 'DRY_RUN build_profile=%s\n' "$profile"
    printf 'DRY_RUN package_library_policy=selected-debug-release-only\n'
    printf 'DRY_RUN package_library_dir=%s\n' "$PACKAGE_LIBRARY_DIR"
    printf 'DRY_RUN package_sonames=libstdc++.so.6,libgcc_s.so.1,libonnxruntime.so.1.14.0,librdkafka.so.1,libsasl2.so.3,libssl.so.10\n'
    printf 'DRY_RUN loader_environment=LD_LIBRARY_PATH-unset;selected-view-plus-centos7-sysroot\n'
    if [[ "$profile" == "debug" ]]; then
      printf 'DRY_RUN bazel_flags=--compilation_mode=dbg --strip=never --cxxopt=-fno-omit-frame-pointer --cxxopt=-O0 --cxxopt=-g\n'
    else
      printf 'DRY_RUN bazel_flags=--compilation_mode=opt --strip=always\n'
      printf 'DRY_RUN release_packaging_strip=%s --strip-all\n' "$STRIP_BIN"
    fi
    printf 'DRY_RUN steps=build_server,deploy_pipeline(sync+deploy+verify)\n'
    return 0
  fi
  build_server
  deploy_pipeline
}

validate_quick_test_common() {
  [[ -x "$STRESS_RUNNER" ]] || die "stress runner missing/not executable: $STRESS_RUNNER"
  [[ -r "$STRESS_CSV" ]] || die "stress CSV missing/not readable: $STRESS_CSV"
  [[ "$WTP184_CONCURRENCY" =~ ^[0-9]{1,2}$ ]] || die "WTP184_CONCURRENCY must be one or two decimal digits"
  local concurrency_decimal=$((10#$WTP184_CONCURRENCY))
  (( concurrency_decimal >= 1 && concurrency_decimal <= 64 )) || die "WTP184_CONCURRENCY must be between 1 and 64"
  WTP184_CONCURRENCY="$concurrency_decimal"
  [[ "$WTP184_MONITOR_SSH" =~ ^[A-Za-z_][A-Za-z0-9_.-]*@[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || \
    die "WTP184_MONITOR_SSH must be USER@HOST"
}

run_2w_test() {
  local stream_mode="$1"
  local label="$2"
  local session_prefix="wtp184_${label}_$(date '+%Y%m%d_%H%M%S')_$$"
  validate_quick_test_common
  local -a args=(
    "$STRESS_RUNNER"
    --mode stress
    --exact-once
    --stream "$stream_mode"
    --session-prefix "$session_prefix"
    -f "$STRESS_CSV"
    -c "$WTP184_CONCURRENCY"
    -R 1
    -r 30
    -C 3
    -T 10
    --max-response-bytes 1048576
    -E 20
    -B 200
    -m "$WTP184_MONITOR_SSH"
    -P "$TEST_PORT"
  )
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf 'DRY_RUN command=%s\n' "$CMD"
    printf 'DRY_RUN test_kind=2w_exact_once\n'
    printf 'DRY_RUN stream=%s\n' "$stream_mode"
    printf 'DRY_RUN automatic_request_retry=disabled\n'
    print_dry_run_argv "${args[@]}"
    return 0
  fi
  (cd "$STRESS_ROOT" && "${args[@]}")
}

run_multi_round_test() {
  [[ -x "$STRESS_RUNNER" ]] || die "stress runner missing/not executable: $STRESS_RUNNER"
  [[ -r "$STRESS_CASES" ]] || die "history cases missing/not readable: $STRESS_CASES"
  [[ "$WTP184_HISTORY_CASE_ID" =~ ^[A-Za-z0-9_.-]{1,128}$ ]] || \
    die "WTP184_HISTORY_CASE_ID contains unsupported characters"
  local -a args=(
    "$STRESS_RUNNER"
    --mode histories
    --case-id "$WTP184_HISTORY_CASE_ID"
    --cases "$STRESS_CASES"
    --url-9999 "http://${TARGET_HOST}:${BASELINE_PORT}${CURL_PATH}"
    --url-9530 "http://${TARGET_HOST}:${TEST_PORT}${CURL_PATH}"
    --force-stream-false
  )
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf 'DRY_RUN command=%s\n' "$CMD"
    printf 'DRY_RUN test_kind=multi_round_single_case\n'
    print_dry_run_argv "${args[@]}"
    return 0
  fi
  (cd "$STRESS_ROOT" && "${args[@]}")
}

# ------------------------------------------------------------------------------
# 8. CLI
# ------------------------------------------------------------------------------

CMD="${1:-}"
[[ -n "$CMD" ]] || { usage; exit 2; }
shift || true

while [[ $# -gt 0 ]]; do
  case "$1" in
    --model-dir|--project-name|--description|--service-port|--server-version)
      [[ "$DEPLOY_FIELD_OPTIONS" != *"|$1|"* ]] || die "duplicate option: $1"
      [[ $# -ge 2 ]] || die "$1 requires a value"
      DEPLOY_FIELD_OPTIONS+="$1|"
      case "$1" in
        --model-dir) REMOTE_MODEL_DIR="$2" ;;
        --project-name) DEPLOY_PROJECT_NAME="$2"; DEPLOY_PROJECT_EXPLICIT=1; DEPLOY_METADATA=1 ;;
        --description) DEPLOY_DESCRIPTION="$2"; DEPLOY_METADATA=1 ;;
        --service-port) TEST_PORT="$2" ;;
        --server-version) SERVER_VERSION="$2" ;;
      esac
      shift 2
      ;;
    --clean)
      CLEAN=1
      shift
      ;;
    --message)
      [[ $# -ge 2 ]] || die "--message requires a value"
      MESSAGE="$2"
      shift 2
      ;;
    --debug)
      DEBUG=1
      shift
      ;;
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "unknown option: $1"
      ;;
  esac
done

[[ -n "$REMOTE_MODEL_DIR" ]] || die "model directory must not be empty"
[[ "$TEST_PORT" =~ ^[1-9][0-9]{0,4}$ ]] && (( TEST_PORT <= 65535 )) || die "service port must be 1..65535 without leading zeros"
if (( DEPLOY_PROJECT_EXPLICIT )); then [[ -n "$DEPLOY_PROJECT_NAME" ]] || die "project name must not be empty"; fi
if [[ -n "$SERVER_VERSION" ]]; then
  [[ "$SERVER_VERSION" =~ ^server-v3-debug[.][A-Za-z0-9._-]+$ ]] || die "server version must be an exact V3 debug artifact basename"
fi
if [[ "$DEPLOY_FIELD_OPTIONS" == *'|--server-version|'* && -z "$SERVER_VERSION" ]]; then die "server version must not be empty"; fi

if [[ "$DRY_RUN" -eq 1 ]]; then
  case "$CMD" in
    build|debug_build|release_build|v3_build|v3_debug_build|v3_debug_deploy|v3_release_build|asan_build|debug_all|release_all|test_2w_non_stream|test_multi_round|test_2w_stream) ;;
    *) die "--dry-run is supported only by the new quick commands" ;;
  esac
fi

case "$CMD" in
  v3_build|v3_debug_build|v3_release_build)
    resolve_v3_build_action "$CMD"
    ;;
  v3_debug_deploy)
    resolve_v3_debug_deploy_action
    ;;
esac

log "===== COMMAND START ====="
log "script=$SELF"
log "command=$CMD"
log "local_log=$LOG_FILE"

case "$CMD" in
  diagnose)
    diagnose
    ;;
  setup-ssh)
    setup_ssh
    ;;
  build)
    run_profile_build release
    ;;
  debug_build)
    run_profile_build debug
    ;;
  release_build)
    run_profile_build release
    ;;
  v3_build|v3_debug_build|v3_release_build)
    run_v3_profile_build "$V3_BUILD_PROFILE"
    ;;
  v3_debug_deploy)
    run_v3_debug_deploy
    ;;
  asan_build)
    run_profile_build asan
    ;;
  sync)
    sync_artifacts
    ;;
  deploy)
    deploy_pipeline
    ;;
  debug_all)
    run_profile_all debug
    ;;
  release_all)
    run_profile_all release
    ;;
  test_2w_non_stream)
    run_2w_test false 2w_non_stream
    ;;
  test_multi_round)
    run_multi_round_test
    ;;
  test_2w_stream)
    run_2w_test true 2w_stream
    ;;
  test)
    remote_http_smoke "$TEST_PORT" "manual-test"
    ;;
  compare)
    remote_compare_ab
    ;;
  rollback)
    die "rollback is not supported in auto_build mode: auto_build.sh uses dsm.sh --rmi --port $TEST_PORT and removes the previous test slot"
    ;;
  all)
    build_server
    deploy_pipeline
    ;;
  watch-sync)
    watch_sync
    ;;
  install-sync-service)
    check_batch_ssh || die "SSH key not ready. Run: $SELF setup-ssh"
    install_sync_service
    ;;
  uninstall-sync-service)
    uninstall_sync_service
    ;;
  status)
    status
    ;;
  -h|--help|help)
    usage
    ;;
  *)
    usage >&2
    die "unknown command: $CMD"
    ;;
esac

log "===== COMMAND SUCCESS: $CMD ====="
