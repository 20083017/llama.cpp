#!/usr/bin/env bash
set -euo pipefail

fail() { printf 'ERROR=%s\n' "$*" >&2; exit 1; }
usage() {
  cat <<'HELP'
Usage: auto_build_offline_v3.sh MODEL_DIR SERVER PORT
       auto_build_offline_v3.sh --model-dir DIR --server-version NAME --service-port PORT
       auto_build_offline_v3.sh MODEL_DIR SERVER PORT --publish-only \
         [--project-name NAME] [--description TEXT] \
         --verified-id ID --expected-sha SHA256 --expected-size BYTES
Legacy deploy builds/runs only; metadata options require --publish-only after controller verification.
Model resources and display project are independent; display defaults to basename(MODEL_DIR).
Host PORT (1..65535, no leading zeros) maps to internal 8080. Only exact cu.dev.slot-owned ports may be replaced.
Publication rechecks staged/runtime binary SHA, version, unique running ID and actual binding.
Metadata failure exits 50; it never removes the verified runtime. No Docker build/deploy in publish-only.
Environment: PACKAGE_ROOT (default ~/packages), app_name (cu-server), METADATA_PYTHON (python3),
 METADATA_REDIS_HOST (10.1.122.21), METADATA_REDIS_PORT (6379), METADATA_REDIS_TIMEOUT (3 seconds, max 30),
 METADATA_REDIS_USERNAME / METADATA_REDIS_PASSWORD (optional, environment only). Redis DB5, hint TTL250,
 persistent container_list. Legacy no-metadata deployment does not need Python or redis.
The unchanged web reader can overwrite this cache update; arbitrary-description push quoting is not fixed.
HELP
}
model='' server='' port='' project='' description=''
metadata=0 publish_only=0 verified_id='' expected_sha='' expected_size='' seen='|'
positional=()
while (( $# )); do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --publish-only)
      [[ "$seen" != *'|--publish-only|'* ]] || fail "duplicate option: $1"
      seen+="$1|"; publish_only=1; shift ;;
    --model-dir|--server-version|--service-port|--project-name|--description|--verified-id|--expected-sha|--expected-size)
      [[ "$seen" != *"|$1|"* ]] || fail "duplicate option: $1"
      (( $# >= 2 )) || fail "$1 requires a value"
      seen+="$1|"
      case "$1" in
        --model-dir) model="$2" ;;
        --server-version) server="$2" ;;
        --service-port) port="$2" ;;
        --project-name) project="$2"; metadata=1 ;;
        --description) description="$2"; metadata=1 ;;
        --verified-id) verified_id="$2" ;;
        --expected-sha) expected_sha="$2" ;;
        --expected-size) expected_size="$2" ;;
      esac
      shift 2 ;;
    -*) fail "unknown option: $1" ;;
    *) positional+=("$1"); shift ;;
  esac
done
if (( ${#positional[@]} )); then
  (( ${#positional[@]} == 3 )) || fail 'required 3 paramters'
  [[ "$seen" != *'|--model-dir|'* && "$seen" != *'|--server-version|'* && "$seen" != *'|--service-port|'* ]] || fail 'do not mix positional MODEL SERVER PORT with their named options'
  model="${positional[0]}"; server="${positional[1]}"; port="${positional[2]}"
fi
[[ -n "$model" && -n "$server" && -n "$port" ]] || fail 'required 3 paramters'
[[ "$server" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || fail 'server must be an exact artifact basename'
[[ "$port" =~ ^[1-9][0-9]{0,4}$ ]] && (( port <= 65535 )) || fail 'service port must be 1..65535 without leading zeros'
if [[ "$seen" == *'|--project-name|'* ]]; then
  [[ -n "$project" ]] || fail 'project name must not be empty'
else
  project="$(basename -- "$model")"
fi
if (( metadata && ! publish_only )); then
  fail 'metadata requires --publish-only after verified deployment'
fi
if (( ! publish_only )); then
  [[ -z "$verified_id$expected_sha$expected_size" ]] || fail 'verification proof requires --publish-only'
fi
cd -- "${PACKAGE_ROOT:-$HOME/packages}"
[[ -f "server/$server" && -x "server/$server" ]] || fail 'server artifact missing/not executable'

# Enumerate actual bindings, not dsm.sh's unanchored port/name grep. A removable
# candidate must own ONLY this port -> 8080/tcp, including IPv4/IPv6 bindings.
owned_port_id=''
inspect_owned_port() {
  local ids cid row binding label pipeline target other
  local -a fields
  owned_port_id=''
  ids="$(docker ps -aq)" || fail 'cannot enumerate containers'
  for cid in $ids; do
    [[ "$cid" =~ ^[a-f0-9]{12,64}$ ]] || fail 'invalid Docker container ID'
    row="$(docker inspect --format '{{.Id}}|{{.State.Running}}|{{index .Config.Labels "cu.dev.slot"}}|{{index .Config.Labels "cu.dev.pipeline"}}{{range $p, $bindings := .HostConfig.PortBindings}}{{range $bindings}}{{printf "|%s:%s:%s" $p .HostIp .HostPort}}{{end}}{{end}}' "$cid")" || fail 'cannot inspect port ownership'
    IFS='|' read -r -a fields <<< "$row"
    [[ "${fields[0]:-}" =~ ^[a-f0-9]{64}$ && "${fields[1]:-}" =~ ^(true|false)$ ]] || fail 'invalid Docker inspection'
    label="${fields[2]:-}"; pipeline="${fields[3]:-}"; target=0; other=0
    for binding in "${fields[@]:4}"; do
      if [[ "${binding##*:}" == "$port" && "${binding%%:*}" == '8080/tcp' ]]; then
        target=1
      else
        other=1
        [[ "${binding##*:}" != "$port" ]] || fail 'service port occupied by wrong internal binding'
      fi
    done
    if (( target )); then
      [[ "$label" == "$port" && "$pipeline" == v3 && "$other" == 0 ]] || fail 'service port occupied by unrelated/unlabelled/multi-port container'
      [[ -z "$owned_port_id" ]] || fail 'ambiguous service port occupants'
      owned_port_id="${fields[0]}"
      owned_port_running="${fields[1]}"
    fi
  done
}

verify_publication_target() {
  [[ "$server" == server-v3-debug.* ]] || fail 'metadata publication requires a V3 artifact'
  [[ "$verified_id" =~ ^([a-f0-9]{12}|[a-f0-9]{64})$ ]] || fail 'publication requires verified exact container ID'
  [[ "$expected_sha" =~ ^[a-f0-9]{64}$ && "$expected_size" =~ ^[1-9][0-9]*$ ]] || fail 'publication requires SHA256 and size proof'
  [[ "$(sha256sum "server/$server" | awk '{print $1}')" == "$expected_sha" ]] || fail 'staged artifact SHA mismatch'
  [[ "$(stat -c '%s' "server/$server")" == "$expected_size" ]] || fail 'staged artifact size mismatch'
  inspect_owned_port
  [[ -n "$owned_port_id" && "$owned_port_running" == true ]] || fail 'no running owned publication target'
  [[ "$verified_id" == "$owned_port_id" || "$verified_id" == "${owned_port_id:0:12}" ]] || fail 'verified ID does not match actual port'
  [[ "$(docker exec "$owned_port_id" sha256sum /usr/bin/cu-server | awk '{print $1}')" == "$expected_sha" ]] || fail 'runtime binary SHA mismatch'
  [[ "$(docker exec "$owned_port_id" cat /runtime/version.txt)" == "$server" ]] || fail 'runtime version mismatch'
}

publish_metadata() {
  local python="${METADATA_PYTHON:-python3}"
  command -v "$python" >/dev/null 2>&1 || return 50
  # No credentials in argv or logs. Isolated Python loads only stdlib and the
  # already-installed redis client. One WATCH transaction, no fallback/retries.
  METADATA_ID="${owned_port_id:0:12}" METADATA_PROJECT="$project" \
  METADATA_DESCRIPTION="$description" METADATA_SERVER="$server" METADATA_PORT="$port" \
    "$python" -I - <<'METADATA_PY'
import json
import os
import re
import sys

try:
    import redis
    timeout = float(os.environ.get("METADATA_REDIS_TIMEOUT", "3"))
    redis_port = int(os.environ.get("METADATA_REDIS_PORT", "6379"))
    if not 0 < timeout <= 30 or not 1 <= redis_port <= 65535:
        raise ValueError("invalid client settings")
    client = redis.Redis(
        host=os.environ.get("METADATA_REDIS_HOST", "10.1.122.21"),
        port=redis_port, db=5, decode_responses=True,
        username=os.environ.get("METADATA_REDIS_USERNAME") or None,
        password=os.environ.get("METADATA_REDIS_PASSWORD") or None,
        socket_timeout=timeout, socket_connect_timeout=timeout,
        retry_on_timeout=False,
    )
    cid = os.environ["METADATA_ID"]
    port = os.environ["METADATA_PORT"]
    hint_key = "container:" + port
    fields = dict(project=os.environ["METADATA_PROJECT"], port=port,
                  server=os.environ["METADATA_SERVER"], desc=os.environ["METADATA_DESCRIPTION"])

    def invalid_constant(value):
        raise ValueError("invalid JSON constant")

    def unique_object(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError("duplicate JSON field")
            obj[key] = value
        return obj

    def decode(raw, kind):
        if raw is None:
            return [] if kind is list else {}
        if not isinstance(raw, str) or len(raw.encode("utf-8")) > 4 * 1024 * 1024:
            raise ValueError("invalid cache size/type")
        value = json.loads(raw, parse_constant=invalid_constant, object_pairs_hook=unique_object)
        if not isinstance(value, kind):
            raise ValueError("invalid cache type")
        return value

    with client.pipeline() as tx:
        tx.watch("container_list", hint_key)
        rows = decode(tx.get("container_list"), list)
        if tx.ttl("container_list") not in (-1, -2):
            raise ValueError("container_list must be persistent")
        raw_hint = tx.get(hint_key)
        hint = decode(raw_hint, dict)
        ids = set()
        for row in rows:
            if not isinstance(row, dict) or not isinstance(row.get("id"), str) or not re.fullmatch(r"[a-f0-9]{12}", row["id"]) or row["id"] in ids:
                raise ValueError("invalid cached row identity")
            ids.add(row["id"])
            if any(not isinstance(row.get(k), str) for k in ("path", "desc", "server")) or type(row.get("port")) not in (str, int):
                raise ValueError("invalid cached row fields")
        if raw_hint is not None and (any(not isinstance(hint.get(k), str) for k in ("project", "server", "desc")) or type(hint.get("port")) not in (str, int)):
            raise ValueError("invalid hint fields")
        own = next((row for row in rows if row["id"] == cid), None)
        if own is None:
            own = {"id": cid}
            rows.append(own)
        own.update(path=fields["project"], desc=fields["desc"], server=fields["server"], port=port)
        hint.update(fields)
        tx.multi()
        tx.set("container_list", json.dumps(rows, ensure_ascii=False))
        tx.set(hint_key, json.dumps(hint, ensure_ascii=False), ex=250)
        tx.execute()
    print("METADATA_STATUS=PUBLISHED")
except Exception as exc:
    # Exception text may contain connection/credential data; report category only.
    print("METADATA_STATUS=FAILED reason=" + type(exc).__name__, file=sys.stderr)
    sys.exit(50)
METADATA_PY
}

if (( publish_only )); then
  verify_publication_target
  if publish_metadata; then
    exit 0
  else
    printf 'DEPLOY_STATUS=VERIFIED METADATA_STATUS=FAILED runtime_rollback=none\n' >&2
    exit 50
  fi
fi

[[ -d "$model" ]] || fail 'model directory missing'
[[ "${app_name:-cu-server}" =~ ^[A-Za-z0-9_.-]+$ ]] || fail 'invalid app_name'
inspect_owned_port
temp_file="$(pwd)/.service.building"
if [ -z ${app_name+x} ]; then
  app_name=cu-server
fi

release_folder=release_dialogue
log_base_dir=~/packages/logs
name=cu-server
tag=$(date +"%y%m%d.%H%M%S")

# Dockerfile requires release/. Refuse existing output, never delete shared data.
root=release
[[ ! -e "$root" ]] || fail 'release directory already exists; inspect previous output before retry'
mkdir -- "$root"
cleanup_release() { rm -rf -- "$root"; }
trap cleanup_release EXIT

# bazel clean
# bazel build -c opt contact:contact-server --distdir=~/bazel-1.2.1-dist/derived/distdir
# cp -f bazel-bin/contact/contact-server ${root}/contact-server
cp -f -- "server/${server}" "${root}/cu-server"
sed 's/${APP_NAME}/'"${app_name}"'/g' ${release_folder}/startup.sh > "${root}/start.sh"
cp -f ${release_folder}/stop.sh "${root}/stop.sh"
cp -f ${release_folder}/del_logs.sh "${root}/del_logs.sh"
cp -f ${release_folder}/cron_task "${root}/cron_task"
chmod +x "${root}/start.sh"
chmod +x "${root}/stop.sh"
chmod +x "${root}/del_logs.sh"
printf '%s\n' "$server" > "${root}/version.txt"
cp -rf lib "${root}/"
# cp -rf /lib64/libgomp.so.1.0.0 ${root}/libgomp.so.1
# cp -rf /usr/lib/x86_64-linux-gnu/libgomp.so.1 ${root}

mkdir -p "${root}/data"
cp -rf -- "${model}"/* "${root}/data/"

cp -rf ${release_folder}/nlu.data.Dockerfile ./Dockerfile
cp -rf ${release_folder}/.dockerignore ./.dockerignore
# # BUILD docker image
# sed 's/${APP_NAME}/'${app_name}'/g' ${release_folder}/osu.cloud.dockerfile > ./Dockerfile
docker build -t "$name:$tag" .

printf 'done!\n'

# clean
rm -f Dockerfile
cleanup_release
trap - EXIT

restartFile=".$port-restart.log"
rm -f -- "$restartFile"

# Recheck immediately before touching the exact owned ID; never remove an image
# or use dsm.sh/prune. Refuse legacy unlabelled occupants instead of adopting them.
inspect_owned_port
if [[ -n "$owned_port_id" ]]; then
  docker rm -f -- "$owned_port_id"
fi
docker run --label "cu.dev.slot=$port" --label "cu.dev.pipeline=v3" --name "cu-server-$(date +%Y%m%d_%H%M%S)" --ulimit core=-1:-1  -d -p "$port:8080" -e REJECTION_LLM_URL=http://82.157.133.222:8000/v1/chat/completions -e LLM_URL_V2=http://10.1.122.21:7000/v1/nlu/inference -e LLM_URL=https://llm-v2.auto-pai.cn/v1/chat/completions  -e ACTIVE_CONTEXT=local -e REDIS_HOST=10.1.122.21 -e REDIS_PORT=6379 -e REDIS_DB=0 "$name:$tag"

rm -f -- "$temp_file"
