#!/usr/bin/env python3
# Task-only fixtures: all service and build boundaries are mocked.
import contextlib, copy, hashlib, io, json, os, shutil, subprocess, sys, tempfile, types, unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
HELPER=BASE/'staged-editable/auto_build_offline_v3.sh'
CONTROLLER=BASE/'staged-editable/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh'
HS=HELPER.read_text(encoding='utf-8'); CS=CONTROLLER.read_text(encoding='utf-8')
CODE=HS.split("<<'METADATA_PY'\n",1)[1].split('\nMETADATA_PY',1)[0]
NAME='server-v3-debug.20261013-113035-fixture'; ID='123456abcdef'+'0'*52; OTHER='fedcba654321'
TEXT='平台化1.0 quote\' " ; $(touch SENTINEL) & | < > \\ TAB\t新行\n'
def posix(p):
 s=str(p).replace('\\','/'); return '/'+s[0].lower()+s[2:] if len(s)>2 and s[1]==':' else s
def quote(s): return "'"+s.replace("'","'\\''")+"'"
class WatchError(Exception): pass
class FakeTx:
 def __init__(self,state,mode): self.state=state; self.mode=mode; self.pending=[]; self.started=False
 def __enter__(self): return self
 def __exit__(self,*args): return False
 def watch(self,*keys):
  assert keys==('container_list','container:9529')
  if self.mode=='clientfail': raise ConnectionError('synthetic sensitive detail')
 def get(self,k): return self.state['data'].get(k)
 def ttl(self,k): return self.state['ttl'].get(k,-1 if k in self.state['data'] else -2)
 def multi(self): self.started=True
 def set(self,k,v,ex=None):
  assert self.started; self.pending.append((k,v,ex))
 def execute(self):
  assert len(self.pending)==2
  if self.mode=='conflict':
   self.state['concurrent_commit_preserved']=True; raise WatchError('synthetic conflict')
  new=copy.deepcopy(self.state)
  for k,v,ex in self.pending: new['data'][k]=v; new['ttl'][k]=ex if ex is not None else -1
  self.state.clear(); self.state.update(new); return [True,True]
def metadata(code,state,mode=''):
 module=types.ModuleType('redis')
 def constructor(**kw):
  assert kw['db']==5 and kw['decode_responses'] and not kw['retry_on_timeout']
  if mode=='constructorfail': raise ConnectionError('synthetic sensitive detail')
  return types.SimpleNamespace(pipeline=lambda:FakeTx(state,mode))
 module.Redis=constructor; old=sys.modules.get('redis'); sys.modules['redis']=module; out=io.StringIO()
 try:
  with contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):
   try: exec(compile(code,'<embedded-publisher>','exec'),{}); rc=0
   except SystemExit as e: rc=e.code
 finally:
  if old is None: del sys.modules['redis']
  else: sys.modules['redis']=old
 return rc,out.getvalue()
MOCK=r'''
docker() {
 printf 'docker:%s\n' "$1" >> "$MOCK_TRACE"
 local cmd="$1"; shift
 case "$cmd" in
 info) return 0 ;;
 ps)
  if [[ "$*" == *'-aq'* ]]; then cut -d '|' -f1 "$MOCK_ROWS"
  else
   while IFS='|' read -r cid running slot pipeline rest; do
    [[ -n "$cid" && "$running" == true ]] || continue
    printf '%s|cu-server-fixture|fixture:tag|0.0.0.0:%s->8080/tcp\n' "${cid:0:12}" "$MOCK_PORT"
   done < "$MOCK_ROWS"
  fi ;;
 inspect)
  local row cid="${@: -1}"
  row="$(awk -F'|' -v id="$cid" 'index($1,id)==1 {print}' "$MOCK_ROWS")"
  [[ -n "$row" ]] || return 1
  if [[ "$*" == *'.Id'* ]]; then printf '%s\n' "$row"
  else printf '%s\n' "${MOCK_BINDING:-8080/tcp:$MOCK_PORT}"; fi ;;
 exec)
  shift
  case "$*" in
   *sha256sum*) printf '%s  /usr/bin/cu-server\n' "${MOCK_RUNTIME_SHA:-$MOCK_SHA}" ;;
   *version.txt*) printf '%s\n' "${MOCK_RUNTIME_VERSION:-$MOCK_SERVER}" ;;
   *core_pattern*) printf 'core\n' ;;
   *) printf 'soft=unlimited hard=unlimited\n' ;;
  esac ;;
 build) [[ "${MOCK_BUILD_FAIL:-0}" == 0 ]] ;;
 rm) printf 'removed:%s\n' "${@: -1}" >> "$MOCK_TRACE" ;;
 run)
  printf '%s|true|%s|v3|8080/tcp:0.0.0.0:%s|8080/tcp::::%s\n' "$MOCK_ID" "$MOCK_PORT" "$MOCK_PORT" "$MOCK_PORT" > "$MOCK_ROWS"
  printf '%s\n' "$MOCK_ID" ;;
 *) return 97 ;;
 esac
}
mockpython() {
 [[ "$*" == '-I -' ]] || return 96
 printf 'metadata:python\n' >> "$MOCK_TRACE"
 "$MOCK_PYTHON" -I -X utf8 "$MOCK_TEST_FILE" --bootstrap
}
ssh() {
 local cmd="${@: -1}"
 case "$cmd" in
 *'python3 -') printf 'http:mock\n' >> "$MOCK_TRACE"; cat >/dev/null; printf 'SMOKE_OK=1\n' ;;
 *'--publish-only'*) printf 'ssh:publish\n' >> "$MOCK_TRACE"; bash -c "$cmd" ;;
 *'TEST_PORT='*'bash -s') printf 'ssh:verify\n' >> "$MOCK_TRACE"; bash -c "$cmd" ;;
 *) bash -c "$cmd" ;;
 esac
}
rsync() {
 printf 'sync:mock\n' >> "$MOCK_TRACE"
 local last="${@: -1}" source
 local -a argv=("$@")
 for source in "${argv[@]:0:${#argv[@]}-1}"; do
  if [[ -f "$source" ]]; then cp -- "$source" "${last#*:}"
  elif [[ -d "$source" ]]; then cp -r -- "$source/." "${last#*:}"; fi
 done
 if [[ "${MOCK_REMOTE_META_FAIL:-0}" == 1 ]]; then printf bad > "$REMOTE_ARTIFACT_DIR/$MOCK_SERVER.meta"; fi
}
curl() { return 97; }
bazel() { return 97; }
sudo() { return 97; }
'''
class Cases(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='isolated-',dir=BASE/'tests'); self.root=Path(self.tmp.name)
  self.pkg=self.root/'packages'; self.art=self.root/'artifacts/debug'; self.remote=self.pkg/'server'; self.model=self.pkg/'model resources 模型'
  for p in (self.pkg,self.art,self.remote,self.model,self.pkg/'lib',self.pkg/'release_dialogue'): p.mkdir(parents=True,exist_ok=True)
  (self.model/'data.txt').write_text('synthetic model',encoding='utf-8'); (self.model/'.hidden').write_text('hidden',encoding='utf-8')
  self.blob=b'#!/usr/bin/env bash\n# synthetic fixture never executed\nexit 0\n'; self.sha=hashlib.sha256(self.blob).hexdigest()
  for parent in (self.remote,self.art): (parent/NAME).write_bytes(self.blob); (parent/NAME).chmod(0o755)
  self.meta='\n'.join(['artifact='+NAME,'bazel_target=//cu:server','build_profile=debug','release_stripped=0','dialogue_pipeline_variant=v3','dialogue_pipeline_define=dialogue_pipeline_v3=true','latest_pointer='+posix(self.art/'LATEST'),'sha256='+self.sha,'size='+str(len(self.blob)),'package_onnxruntime_selected=0',''])
  (self.art/(NAME+'.meta')).write_text(self.meta,encoding='utf-8'); (self.art/'LATEST').write_text('server-v3-debug.different-latest\n',encoding='utf-8'); (self.remote/'LATEST').write_text('untouched-remote-pointer\n',encoding='utf-8')
  for n in ('startup.sh','stop.sh','del_logs.sh','cron_task','nlu.data.Dockerfile','.dockerignore'): (self.pkg/'release_dialogue'/n).write_text('${APP_NAME}\n',encoding='utf-8')
  self.rows=self.root/'docker-rows.txt'; self.rows.write_text(self.row(),encoding='utf-8')
  self.trace=self.root/'trace.txt'; self.trace.write_text('',encoding='utf-8')
  self.mock=self.root/'mock-shell.txt'; self.mock.write_text(MOCK,encoding='utf-8')
  self.prefix=self.root/'controller-functions.txt'; self.prefix.write_text(CS.split('# 8. CLI',1)[0],encoding='utf-8')
  self.statepath=self.root/'redis-state.json'; self.statepath.write_text(json.dumps({'data':{},'ttl':{}}),encoding='utf-8')
  self.env={k:v for k,v in os.environ.items() if k.upper() in ('PATH','SYSTEMROOT','WINDIR','TEMP','TMP','COMSPEC','PATHEXT')}
  self.env.update(HOME=posix(self.root),PACKAGE_ROOT=posix(self.pkg),BUILD_LOG_DIR=posix(self.root/'logs'),LOCAL_ARTIFACT_DIR=posix(self.art),V3_ARTIFACT_ROOT=posix(self.art.parent),REMOTE_PACKAGE_ROOT=posix(self.pkg),REMOTE_ARTIFACT_DIR=posix(self.remote),REMOTE_AUTO_BUILD=posix(HELPER),REMOTE_MODEL_DIR=posix(self.model),TARGET_HOST='mock.invalid',TARGET_USER='fixture',BASH_ENV=posix(self.mock),METADATA_PYTHON='mockpython',MOCK_PYTHON=posix(Path(sys.executable)),MOCK_TEST_FILE=str(Path(__file__).resolve()),MOCK_STATE_PATH=str(self.statepath),MOCK_TRACE=posix(self.trace),MOCK_ROWS=posix(self.rows),MOCK_ID=ID,MOCK_SHA=self.sha,MOCK_SERVER=NAME,MOCK_PORT='9529',TEST_PORT='9529',LC_ALL='C.UTF-8',PYTHONUTF8='1',MSYS_NO_PATHCONV='1')
 def tearDown(self): self.tmp.cleanup()
 def row(self,id=ID,running='true',label='9529',pipeline='v3',bindings='|8080/tcp:0.0.0.0:9529|8080/tcp::::9529'): return f'{id}|{running}|{label}|{pipeline}{bindings}\n'
 def bash(self,args,rc=0,env=None):
  actual=dict(self.env); actual.update(env or {})
  p=subprocess.run([shutil.which('bash'),*args],cwd=self.root,env=actual,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
  self.assertEqual(p.returncode,rc,p.stdout[-2000:]); self.assertFalse((self.root/'SENTINEL').exists()); return p.stdout
 def helper(self,args=(),rc=0,env=None,port='9529',server=NAME): return self.bash([posix(HELPER),posix(self.model),server,port,*args],rc,env)
 def publish(self,rc=0,env=None): return self.helper(['--publish-only','--project-name',TEXT,'--description',TEXT,'--verified-id',ID[:12],'--expected-sha',self.sha,'--expected-size',str(len(self.blob))],rc,env)
 def controller(self,body,rc=0,env=None):
  p=self.root/'controller-case.txt'; p.write_text('source "'+posix(self.prefix)+'"\n'+body+'\n',encoding='utf-8'); return self.bash([posix(p)],rc,env)
 def lines(self): return self.trace.read_text(encoding='utf-8').splitlines()
 def state(self): return json.loads(self.statepath.read_text(encoding='utf-8'))
 def test_01_cli_defaults_quotes_utf8_env(self):
  out=self.bash([posix(CONTROLLER),'v3_debug_deploy','--dry-run','--model-dir',posix(self.model),'--project-name',TEXT,'--description',TEXT,'--service-port','65535','--server-version',NAME])
  for s in ('service_port=65535','project_name='+TEXT,'description='+TEXT,'server_version='+NAME,'metadata=1'): self.assertIn('DRY_RUN '+s,out)
  self.assertEqual(self.lines(),[])
  env=dict(self.env); env.pop('REMOTE_MODEL_DIR'); env.pop('TEST_PORT')
  p=subprocess.run([shutil.which('bash'),posix(CONTROLLER),'v3_debug_deploy','--dry-run'],cwd=self.root,env=env,text=True,encoding='utf-8',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
  self.assertEqual(p.returncode,0,p.stdout)
  for s in ('model_dir=/home/shared/models/car_v3.0','service_port=9530','project_name=car_v3.0','server_version=LATEST','metadata=0'): self.assertIn(s,p.stdout)
  out=self.bash([posix(CONTROLLER),'v3_debug_deploy','--dry-run'],env={'DEPLOY_PROJECT_NAME':TEXT,'DEPLOY_DESCRIPTION':TEXT,'SERVER_VERSION':NAME})
  self.assertIn('project_name='+TEXT,out); self.assertIn('metadata=1',out)
 def test_02_negative_inputs(self):
  for port in ('0','65536','100000','09529','-1','9;touch SENTINEL','９５２９','9529x'):
   with self.subTest(port=port):
    self.helper(rc=1,port=port); self.bash([posix(CONTROLLER),'v3_debug_deploy','--dry-run','--service-port',port],1)
  for args in (['--wat'],['--model-dir'],['--model-dir','','--server-version',NAME,'--service-port','9529'],[posix(self.model),NAME,'9529','--model-dir',''],[posix(self.model),NAME,'9529','--project-name',''],[posix(self.model),NAME,'9529','--description','metadata'],[posix(self.model),'../artifact','9529'],[posix(self.model),NAME,'9529','--service-port','9529'],[posix(self.model),NAME,'9529','--publish-only','--publish-only']):
   with self.subTest(args=args): self.bash([posix(HELPER),*args],1)
  for args in (['--wat'],['--description'],['--project-name',''],['--server-version',''],['--server-version','server-v2.label'],['--server-version','server-v3-release.label'],['--server-version','../'+NAME],['--service-port','9529','--service-port','9530']):
   with self.subTest(args=args): self.bash([posix(CONTROLLER),'v3_debug_deploy','--dry-run',*args],1)
  self.assertNotIn('metadata:python',self.lines())
 def test_03_publish_only_repeat_schema(self):
  other=dict(id=OTHER,path='V2',desc='keep',server='v2',port=9999,extra={'keep':[1,2]})
  seed={'data':{'container_list':json.dumps([other]),'container:9529':json.dumps(dict(project='old',port=9529,server='old',desc='old',extra=42))},'ttl':{'container_list':-1,'container:9529':1}}
  self.statepath.write_text(json.dumps(seed),encoding='utf-8')
  for _ in range(2):
   self.assertIn('METADATA_STATUS=PUBLISHED',self.publish()); state=self.state(); rows=json.loads(state['data']['container_list'])
   self.assertEqual(rows,[other,dict(id=ID[:12],path=TEXT,desc=TEXT,server=NAME,port='9529')])
   self.assertEqual(json.loads(state['data']['container:9529']),dict(project=TEXT,port='9529',server=NAME,desc=TEXT,extra=42))
   self.assertEqual(state['ttl'],{'container_list':-1,'container:9529':250})
  self.assertEqual(self.lines().count('metadata:python'),2)
  self.assertFalse(any(x in self.lines() for x in ('docker:build','docker:run','docker:rm')))
 def test_04_display_default_full_id_and_own_extra(self):
  own=dict(id=ID[:12],path='',desc='',server='',port=9529,extra=['retain'])
  self.statepath.write_text(json.dumps({'data':{'container_list':json.dumps([own])},'ttl':{}}),encoding='utf-8')
  self.helper(['--publish-only','--description',TEXT,'--verified-id',ID,'--expected-sha',self.sha,'--expected-size',str(len(self.blob))])
  rows=json.loads(self.state()['data']['container_list']); self.assertEqual(len(rows),1)
  self.assertEqual(rows[0]['path'],self.model.name); self.assertEqual(rows[0]['desc'],TEXT); self.assertEqual(rows[0]['extra'],['retain']); self.assertEqual(rows[0]['id'],ID[:12])
 def test_05_runtime_proof_failure_no_redis(self):
  for env in ({'MOCK_RUNTIME_SHA':'f'*64},{'MOCK_RUNTIME_VERSION':'server-v2.fixture'}):
   with self.subTest(env=env): self.publish(rc=1,env=env)
  for flag,val in (('--verified-id','000000000000'),('--expected-sha','f'*64),('--expected-size','999')):
   args=['--publish-only','--verified-id',ID[:12],'--expected-sha',self.sha,'--expected-size',str(len(self.blob))]; args[args.index(flag)+1]=val
   with self.subTest(flag=flag): self.helper(args,rc=1)
  self.rows.write_text('',encoding='utf-8'); self.publish(rc=1)
  self.assertNotIn('metadata:python',self.lines()); self.assertEqual(self.state()['data'],{})
 def test_06_ownership_refusals(self):
  rows=[self.row(label='<no value>'),self.row(pipeline='v2'),self.row(bindings='|9090/tcp:0.0.0.0:9529'),self.row(bindings='|8080/tcp:0.0.0.0:9529|8080/tcp:0.0.0.0:9530'),self.row()+self.row(id='2'*64),'not-an-id|true|9529|v3\n']
  for row in rows:
   self.rows.write_text(row,encoding='utf-8')
   with self.subTest(row=row): self.helper(rc=1); self.publish(rc=1)
  self.assertFalse(any(x in self.lines() for x in ('docker:build','docker:run','docker:rm','metadata:python')))
  self.rows.write_text(self.row(id='2'*64,label='19529',bindings='|8080/tcp:0.0.0.0:19529'),encoding='utf-8')
  self.helper(env={'METADATA_PYTHON':'missing-client'}); self.assertNotIn('docker:rm',self.lines())
 def test_07_legacy_client_free_repeat_build_failure(self):
  self.rows.write_text('',encoding='utf-8')
  for _ in range(2): self.helper(env={'METADATA_PYTHON':'missing-client'}); self.assertFalse((self.pkg/'release').exists())
  self.assertEqual(self.lines().count('docker:build'),2); self.assertEqual(self.lines().count('docker:run'),2); self.assertEqual(self.lines().count('docker:rm'),1); self.assertNotIn('metadata:python',self.lines())
  self.trace.write_text('',encoding='utf-8'); self.helper(rc=1,env={'MOCK_BUILD_FAIL':'1'})
  self.assertFalse((self.pkg/'release').exists()); self.assertNotIn('docker:run',self.lines()); self.assertNotIn('docker:rm',self.lines())
  (self.remote/'server-v2.fixture').write_bytes(self.blob); (self.remote/'server-v2.fixture').chmod(0o755)
  self.helper(server='server-v2.fixture',env={'METADATA_PYTHON':'missing-client'})
 def test_08_client_failure_no_rollback(self):
  for env in ({'MOCK_REDIS_MODE':'clientfail'},{'MOCK_REDIS_MODE':'constructorfail'},{'METADATA_PYTHON':'missing-client'},{'METADATA_REDIS_TIMEOUT':'31'},{'METADATA_REDIS_PORT':'65536'}):
   before=self.statepath.read_bytes(); out=self.publish(rc=50,env=env)
   self.assertIn('DEPLOY_STATUS=VERIFIED METADATA_STATUS=FAILED runtime_rollback=none',out); self.assertNotIn('synthetic sensitive',out); self.assertEqual(self.statepath.read_bytes(),before)
  self.assertFalse(any(x in self.lines() for x in ('docker:rm','docker:run','docker:build')))
 def test_09_malformed_cache_no_reset(self):
  row=dict(id=OTHER,path='v2',desc='old',server='v2',port='9999')
  bad=('{bad','{}','null','[null]','[{"id":"fedcba654321","id":"123456abcdef"}]','[NaN]',json.dumps([{'id':OTHER}]),json.dumps([dict(row,id='x')]),json.dumps([row,row]),json.dumps([dict(row,path=None)]),json.dumps([dict(row,port=True)]))
  states=[{'data':{'container_list':raw},'ttl':{'container_list':-1}} for raw in bad]
  states += [{'data':{'container_list':'[]'},'ttl':{'container_list':200}},{'data':{'container:9529':'[]'},'ttl':{}},{'data':{'container:9529':'{}'},'ttl':{}},{'data':{'container:9529':'{"project":"bad"}'},'ttl':{}}]
  for state in states:
   self.statepath.write_text(json.dumps(state),encoding='utf-8')
   with self.subTest(state=state): self.publish(rc=50); self.assertEqual(self.state(),state)
 def test_10_atomic_helper_conflict(self):
  before=self.state(); self.publish(rc=50,env={'MOCK_REDIS_MODE':'conflict'}); after=self.state()
  self.assertTrue(after.pop('concurrent_commit_preserved')); self.assertEqual(after,before)
 def test_11_nonlatest_sync_tuple_preserves_pointers(self):
  out=self.controller('SERVER_VERSION="$MOCK_SERVER"\nprepare_selected_deployment\nsync_artifacts\nremote_auto_build_deploy\nverify_remote_auto_build_deploy')
  self.assertIn('REMOTE_SYNC_OK=1',out); self.assertIn('VERIFY_OK=1',out)
  self.assertEqual((self.art/'LATEST').read_text(),'server-v3-debug.different-latest\n'); self.assertEqual((self.remote/'LATEST').read_text(),'untouched-remote-pointer\n')
  self.assertEqual((self.remote/NAME).read_bytes(),self.blob); self.assertEqual((self.remote/(NAME+'.meta')).read_text(encoding='utf-8'),self.meta)
 def test_12_artifact_negative_and_drift(self):
  for field,value in (('build_profile=debug','build_profile=release'),('dialogue_pipeline_variant=v3','dialogue_pipeline_variant=v2'),('sha256='+self.sha,'sha256='+'f'*64),('size='+str(len(self.blob)),'size=1000'),('release_stripped=0','release_stripped=1')):
   (self.art/(NAME+'.meta')).write_text(self.meta.replace(field,value),encoding='utf-8')
   with self.subTest(field=field): self.controller('SERVER_VERSION="$MOCK_SERVER"\nprepare_selected_deployment',1)
  (self.art/(NAME+'.meta')).write_text(self.meta,encoding='utf-8')
  self.controller('SERVER_VERSION=server-v3-debug.missing\nprepare_selected_deployment',1)
  self.controller('SERVER_VERSION="$MOCK_SERVER"\nprepare_selected_deployment\nprintf x >> "$LOCAL_ARTIFACT_DIR/$SERVER_VERSION"\nsync_artifacts',1)
  (self.art/NAME).write_bytes(self.blob)
  self.controller('SERVER_VERSION="$MOCK_SERVER"\nprepare_selected_deployment\nsed -i s/build_profile=debug/build_profile=release/ "$LOCAL_ARTIFACT_DIR/$SERVER_VERSION.meta"\nsync_artifacts',1)
  (self.art/(NAME+'.meta')).write_text(self.meta,encoding='utf-8'); (self.art/'LATEST').write_text(NAME+'\n',encoding='utf-8')
  self.controller('resolve_v3_debug_deploy_action\nvalidate_v3_debug_deploy_artifact\nprintf server-v3-debug.changed > "$LOCAL_ARTIFACT_DIR/LATEST"\nsync_artifacts',1)
  self.assertNotIn('sync:mock',self.lines())
 def test_13_remote_profile_drift(self):
  out=self.controller('SERVER_VERSION="$MOCK_SERVER"\nsync_artifacts',1,env={'MOCK_REMOTE_META_FAIL':'1'})
  self.assertIn('REMOTE_VERIFY_ERROR=METADATA_MISMATCH',out); self.assertNotIn('docker:build',self.lines())
 def test_14_controller_verify_first_no_redis_on_failure(self):
  body='SERVER_VERSION="$MOCK_SERVER"\nDEPLOY_METADATA=1\nDEPLOY_PROJECT_EXPLICIT=1\nDEPLOY_PROJECT_NAME='+quote(TEXT)+'\nDEPLOY_DESCRIPTION='+quote(TEXT)+'\ndeploy_pipeline'
  out=self.controller(body); self.assertIn('METADATA_STATUS=PUBLISHED',out); lines=self.lines()
  self.assertLess(lines.index('ssh:verify'),lines.index('ssh:publish')); self.assertLess(lines.index('ssh:publish'),lines.index('metadata:python')); self.assertLess(lines.index('metadata:python'),lines.index('http:mock'))
  rows=json.loads(self.state()['data']['container_list']); self.assertEqual(rows[0]['path'],TEXT); self.assertEqual(rows[0]['desc'],TEXT)
  self.trace.write_text('',encoding='utf-8'); self.controller(body,1,env={'MOCK_RUNTIME_SHA':'f'*64}); self.assertNotIn('ssh:publish',self.lines()); self.assertNotIn('metadata:python',self.lines())
  self.trace.write_text('',encoding='utf-8'); self.controller(body,50,env={'MOCK_REDIS_MODE':'clientfail'}); lines=self.lines()
  self.assertNotIn('docker:rm',lines[lines.index('metadata:python'):]); self.assertNotIn('http:mock',lines)
 def test_15_controller_exact_bindings(self):
  for binding in ('8080/tcp:19529','9090/tcp:9529','8080/tcp:9529\n8080/tcp:9530'):
   with self.subTest(binding=binding): self.controller('SERVER_VERSION="$MOCK_SERVER"\nverify_remote_auto_build_deploy',1,env={'MOCK_BINDING':binding})
  self.assertNotIn('metadata:python',self.lines())
 def test_16_named_legacy_and_valid_ports(self):
  self.bash([posix(HELPER),'--model-dir',posix(self.model),'--server-version',NAME,'--service-port','9529'],env={'METADATA_PYTHON':'missing-client'})
  self.assertNotIn('metadata:python',self.lines())
  for port in ('9529','10000','65535','1'):
   self.rows.write_text('',encoding='utf-8')
   with self.subTest(port=port):
    self.helper(port=port,env={'MOCK_PORT':port,'METADATA_PYTHON':'missing-client'})
    self.assertIn('service_port='+port,self.bash([posix(CONTROLLER),'v3_debug_deploy','--dry-run','--service-port',port]))
def reader(cached,hints,live):
 # Acquired auto_build.py:304-353: four-char Docker textual port and cached ID lookup.
 data=[]
 for cid,actual_port in live:
  port=str(actual_port)[:4] if actual_port else ''; path=desc=server=''
  for row in cached:
   if row['id']==cid:
    if port and not row['path']:
     hint=hints.get('container:'+port)
     if hint: path=hint['project']; server=hint['server']; desc=hint['desc']; port=hint['port']
    else: path=row['path']; server=row['server']; desc=row['desc']; port=row['port']
  data.append(dict(id=cid,path=path,desc=desc,server=server,port=port))
 return data
class Embedded(unittest.TestCase):
 def setUp(self):
  self.saved=os.environ.copy(); os.environ.update(METADATA_ID=ID[:12],METADATA_PROJECT=TEXT,METADATA_DESCRIPTION=TEXT,METADATA_SERVER=NAME,METADATA_PORT='9529',METADATA_REDIS_HOST='mock.invalid')
  for k in ('METADATA_REDIS_TIMEOUT','METADATA_REDIS_PORT','METADATA_REDIS_USERNAME','METADATA_REDIS_PASSWORD'): os.environ.pop(k,None)
 def tearDown(self): os.environ.clear(); os.environ.update(self.saved)
 def test_17_embedded_compile(self):
  compile(CODE,'<embedded-metadata>','exec')
  self.assertNotIn('{{printf "%s:%s'+chr(10)+'"',CS)
  self.assertIn('{{printf "%s:%s'+chr(92)+'n"',CS)
 def test_18_sequential_new_stale_and_external_web_race(self):
  stale=dict(id=OTHER,path='old',desc='keep',server='v2',port='9529',extra='preserved')
  state={'data':{'container_list':json.dumps([stale])},'ttl':{}}; snapshot=json.loads(state['data']['container_list'])
  rc,out=metadata(CODE,state); self.assertEqual(rc,0,out); rows=json.loads(state['data']['container_list']); hints={'container:9529':json.loads(state['data']['container:9529'])}
  result=reader(rows,hints,[(ID[:12],'9529')]); self.assertEqual(result[0]['path'],TEXT); self.assertEqual(result[0]['desc'],TEXT); self.assertEqual(len(rows),2)
  # Stale blind GET overwrite loses the seeded row. Hint recovery needs a later GET.
  overwritten=reader(snapshot,hints,[(ID[:12],'9529')]); self.assertEqual(overwritten[0]['path'],'')
  self.assertEqual(reader(overwritten,hints,[(ID[:12],'9529')])[0]['path'],TEXT)
  self.assertEqual(reader(overwritten,{},[(ID[:12],'9529')])[0]['path'],'')
  seeded=dict(rows[-1],port='65535'); self.assertEqual(reader([seeded],{},[(ID[:12],'65535')])[0]['port'],'65535')
 def test_19_missing_client_and_size_bound(self):
  old=sys.modules.get('redis'); sys.modules['redis']=None
  try:
   out=io.StringIO()
   with contextlib.redirect_stderr(out):
    with self.assertRaises(SystemExit) as ctx: exec(compile(CODE,'<embedded-metadata>','exec'),{})
   self.assertEqual(ctx.exception.code,50); self.assertIn('ModuleNotFoundError',out.getvalue())
  finally:
   if old is None: sys.modules.pop('redis',None)
   else: sys.modules['redis']=old
  state={'data':{'container_list':' '*(4*1024*1024+1)},'ttl':{}}; before=copy.deepcopy(state)
  rc,_=metadata(CODE,state); self.assertEqual(rc,50); self.assertEqual(state,before)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='--bootstrap':
  assert sys.flags.isolated
  p=Path(os.environ['MOCK_STATE_PATH']); state=json.loads(p.read_text(encoding='utf-8')); before=copy.deepcopy(state)
  rc,out=metadata(sys.stdin.read(),state,os.environ.get('MOCK_REDIS_MODE',''))
  if state!=before: p.write_text(json.dumps(state,ensure_ascii=False),encoding='utf-8')
  print(out,end=''); sys.exit(rc)
 unittest.main(verbosity=2)
