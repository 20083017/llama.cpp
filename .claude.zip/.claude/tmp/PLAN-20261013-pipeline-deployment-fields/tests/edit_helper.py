from pathlib import Path
import sys
base=Path(sys.argv[1]); original=(base/'centos-auto_build_offline_v3.original-read-only.sh').read_text()
header=(base/'tests/helper-header.txt').read_text()
body=original[original.index('temp_file='):]
start=body.index('if [[ $# -ne 3 ]]'); end=body.index('release_folder=release_dialogue')
body=body[:start]+body[end:]
body=body.replace('model=$1\nport=$3\n','')
body=body.replace('$(pwd)/.service.building','"$(pwd)/.service.building"')
body=body.replace('cp -f server/${server} ${root}/cu-server','cp -f -- "server/${server}" "${root}/cu-server"')
body=body.replace("sed 's/${APP_NAME}/'${app_name}'/g'", "sed 's/${APP_NAME}/'\"${app_name}\"'/g'")
body=body.replace('echo ${server} > ${root}/version.txt','printf \'%s\n\' "$server" > "${root}/version.txt"')
body=body.replace('cp -rf ${model}/* ${root}/data/','cp -rf -- "${model}/." "${root}/data/"')
body=body.replace('docker build -t $name:$tag .', 'docker build -t "$name:$tag" .')
a=body.index('if [ $? -ne 0 ]'); b=body.index('# clean',a)
body=body[:a]+"printf 'done!\n'\n\n"+body[b:]
a=body.index('restartFile=')
run_start=body.index('\nbash dsm.sh --rmi --port $port && docker run', a)+1
run_end=body.index('\n',run_start)
run=body[run_start:run_end].replace('bash dsm.sh --rmi --port $port && ', '')
run=run.replace('docker run  --name cu-server-$(date +%Y%m%d_%H%M%S)', 'docker run --label "cu.dev.slot=$port" --name "cu-server-$(date +%Y%m%d_%H%M%S)"')
run=run.replace('-p $port:8080','-p "$port:8080"').replace('$name:$tag','"$name:$tag"')
body=body[:a]+'''restartFile=".$port-restart.log"
rm -f -- "$restartFile"

# Recheck immediately before touching the exact owned ID; never remove an image
# or use dsm.sh/prune. Refuse legacy unlabelled occupants instead of adopting them.
inspect_owned_port
if [[ -n "$owned_port_id" ]]; then
  docker rm -f -- "$owned_port_id"
fi
'''+run+'\n\nrm -f -- "$temp_file"\n'
(base/'staged-editable/auto_build_offline_v3.sh').write_text(header+body, encoding='utf-8')
