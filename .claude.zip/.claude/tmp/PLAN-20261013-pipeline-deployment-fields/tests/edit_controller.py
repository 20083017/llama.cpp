from pathlib import Path
import sys
b=Path(sys.argv[1]); p=b/'staged-editable/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh'; s=p.read_text()
def change(old,new):
 global s
 if s.count(old)!=1: raise ValueError((s.count(old),old[:120]))
 s=s.replace(old,new)
change('REMOTE_MODEL_DIR="${REMOTE_MODEL_DIR:-/home/shared/models/car_v3.0}"', '''REMOTE_MODEL_DIR="${REMOTE_MODEL_DIR:-/home/shared/models/car_v3.0}"
# Optional display metadata is independent of model resources.
DEPLOY_METADATA=0
[[ -z "${DEPLOY_PROJECT_NAME+x}${DEPLOY_DESCRIPTION+x}" ]] || DEPLOY_METADATA=1
DEPLOY_PROJECT_EXPLICIT=0
[[ -z "${DEPLOY_PROJECT_NAME+x}" ]] || DEPLOY_PROJECT_EXPLICIT=1
DEPLOY_PROJECT_NAME="${DEPLOY_PROJECT_NAME-}"
DEPLOY_DESCRIPTION="${DEPLOY_DESCRIPTION-}"
SERVER_VERSION="${SERVER_VERSION:-}"
DEPLOY_VERIFIED_ID=''
DEPLOY_FIELD_OPTIONS='|' ''')
a=s.index('  local latest_file=',s.index('sync_artifacts()'))
z=s.index('  local latest_artifact=',a)
s=s[:a]+'''  prepare_selected_deployment
  local latest_name
  latest_name="$(selected_deployment_name)"

'''+s[z:]
change('  if ! run_logged "rsync artifacts"', '''  local -a sync_sources=("$LOCAL_ARTIFACT_DIR/")
  if [[ -n "$SERVER_VERSION" ]]; then
    sync_sources=("$latest_artifact" "$latest_artifact.meta")
  fi
  if ! run_logged "rsync artifacts"''')
change('      "$LOCAL_ARTIFACT_DIR/"', '      "${sync_sources[@]}"')
change('"REMOTE_DIR=$(printf \'%q\' "$REMOTE_ARTIFACT_DIR") EXPECT_NAME=', '"SELECTED_EXPLICIT=$(printf \'%q\' "$SERVER_VERSION") REMOTE_DIR=$(printf \'%q\' "$REMOTE_ARTIFACT_DIR") EXPECT_NAME=')
change('latest_file="$REMOTE_DIR/LATEST"\n[[ -f "$latest_file" ]]', 'name="$EXPECT_NAME"\nif [[ -z "$SELECTED_EXPLICIT" ]]; then\nlatest_file="$REMOTE_DIR/LATEST"\n[[ -f "$latest_file" ]]')
change('  exit 42\n}\n\nartifact="$REMOTE_DIR/$name"', '  exit 42\n}\nfi\n\nartifact="$REMOTE_DIR/$name"')
a=s.index('  latest_name="$(head -n1',s.index('remote_auto_build_deploy()'))
z=s.index('  latest_artifact=',a)
s=s[:a]+'''  latest_name="$(selected_deployment_name)"
'''+s[z:]
change("; bash %q %q %q %q", "; PACKAGE_ROOT=%q bash %q %q %q %q")
change('    "$TEST_PORT" ' + chr(92) + chr(10) + '    "$REMOTE_AUTO_BUILD"', '    "$TEST_PORT" ' + chr(92) + chr(10) + '    "$REMOTE_PACKAGE_ROOT" ' + chr(92) + chr(10) + '    "$REMOTE_AUTO_BUILD"')
change('IFS=\'|\' read -r cid cname cimage cports <<< "${rows[0]}"', '''IFS='|' read -r cid cname cimage cports <<< "${rows[0]}"
[[ "$cid" =~ ^[a-f0-9]{12}$ ]] || { echo "VERIFY_ERROR=INVALID_ID"; exit 45; }
bindings="$("${docker_cmd[@]}" inspect --format '{{range $p, $bs := .HostConfig.PortBindings}}{{range $bs}}{{printf "%s:%s\n" $p .HostPort}}{{end}}{{end}}' "$cid")"
found=0
while IFS= read -r binding; do
  [[ -n "$binding" ]] || continue
  [[ "$binding" == "8080/tcp:$TEST_PORT" ]] || { echo "VERIFY_ERROR=PORT_BINDING"; exit 45; }
  found=1
done <<< "$bindings"
(( found )) || { echo "VERIFY_ERROR=PORT_BINDING_MISSING"; exit 45; }''')
change('  log "[OK] deployed container binary exactly matches synced LATEST artifact"', '''  DEPLOY_VERIFIED_ID="$(sed -n 's/^CONTAINER_ID=//p' <<< "$output")"
  [[ "$DEPLOY_VERIFIED_ID" =~ ^[a-f0-9]{12}$ ]] || die "verification returned invalid container ID"
  log "[OK] deployed container binary exactly matches selected artifact"''')
change('  log "===== DEPLOY PIPELINE START ====="', '  prepare_selected_deployment\n  log "===== DEPLOY PIPELINE START ====="')
change('  log "[OK] phase 3 verification"', '  log "[OK] phase 3 verification"\n  publish_verified_deployment || return "$?"')
change('  latest_name="$(head -n1 "$latest_file" | tr -d \'\\r\\n\')"\n  [[ -n "$latest_name" ]] || die "V3 debug LATEST is empty: $latest_file"', '''  if [[ -n "$SERVER_VERSION" ]]; then
    latest_name="$SERVER_VERSION"
  else
    latest_name="$(head -n1 "$latest_file" | tr -d '\\r\\n')"
  fi
  [[ "$latest_name" =~ ^server-v3-debug[.][A-Za-z0-9._-]+$ ]] || die "selected artifact must be an exact V3 debug executable"''')
change('  [[ -f "$latest_file" ]] ||     die "V3 debug LATEST missing: $latest_file. Run \'$SELF v3_debug_build\' first."', '  [[ -n "$SERVER_VERSION" || -f "$latest_file" ]] ||     die "V3 debug LATEST missing: $latest_file. Run \'$SELF v3_debug_build\' first."')
# Remaining additions supplied separately, keeping this editor bounded.
p.write_text(s,encoding='utf-8')
