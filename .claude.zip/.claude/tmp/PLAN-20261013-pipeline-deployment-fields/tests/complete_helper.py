from pathlib import Path
import sys
b=Path(sys.argv[1]); p=b/'staged-editable/auto_build_offline_v3.sh'; s=p.read_text()
s=s.replace('(( $# >= 2 )) && [[ "$2" != --* ]]', '(( $# >= 2 ))')
s=s.replace('local ids cid row binding label target other', 'local ids cid row binding label pipeline target other')
s=s.replace('{{index .Config.Labels "cu.dev.slot"}}{{range', '{{index .Config.Labels "cu.dev.slot"}}|{{index .Config.Labels "cu.dev.pipeline"}}{{range')
s=s.replace('label="${fields[2]:-}"; target=0; other=0', 'label="${fields[2]:-}"; pipeline="${fields[3]:-}"; target=0; other=0')
s=s.replace('"${fields[@]:3}"','"${fields[@]:4}"')
s=s.replace('"$label" == "$port" && "$other" == 0', '"$label" == "$port" && "$pipeline" == v3 && "$other" == 0')
s=s.replace('[[ "$server" == server-v3-* ]]', '[[ "$server" == server-v3-debug.* ]]')
s=s.replace('import os\nimport sys', 'import os\nimport re\nimport sys')
s=s.replace('or not row["id"] or row["id"] in ids', 'or not re.fullmatch(r"[a-f0-9]{12}", row["id"]) or row["id"] in ids')
s=s.replace('root=release\nmkdir -p ${root}', '''# Dockerfile requires release/. Refuse existing output, never delete shared data.
root=release
[[ ! -e "$root" ]] || fail 'release directory already exists; inspect previous output before retry'
mkdir -- "$root"
cleanup_release() { rm -rf -- "$root"; }
trap cleanup_release EXIT''')
s=s.replace('rm -rf ${root}', 'cleanup_release\ntrap - EXIT')
s=s.replace('docker run --label "cu.dev.slot=$port"', 'docker run --label "cu.dev.slot=$port" --label "cu.dev.pipeline=v3"')
for suffix in ('start.sh','stop.sh','del_logs.sh','cron_task','data'):
 s=s.replace('${root}/'+suffix, '"${root}/'+suffix+'"')
s=s.replace('cp -rf lib ${root}/','cp -rf lib "${root}/"')
p.write_text(s,encoding='utf-8')
