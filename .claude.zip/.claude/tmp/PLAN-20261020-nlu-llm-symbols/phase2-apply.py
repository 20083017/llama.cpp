# Task-owned bounded stdin input; never installed on the source host.
import os, re, sys, stat, json, subprocess, difflib, collections, traceback
from pathlib import Path
ROOT = Path('/home/daigd/dialogue')
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_PAGER='cat', PAGER='cat', GIT_EXTERNAL_DIFF='', GIT_CONFIG_NOSYSTEM='1')
def need(ok, message):
    if not ok: raise RuntimeError(message)
def safe(p):
    p = Path(p).resolve()
    need(p == ROOT or ROOT in p.parents, 'resolved-path escape ' + str(p))
    return p
def read(p):
    p = safe(p)
    need(p.is_file() and p.stat().st_size <= 4000000, 'file/size bound ' + str(p))
    return p.read_bytes()
def txt(b): return b.decode('utf-8', 'replace')
def git(repo, *args):
    cmd = ['git', '-c', 'core.fsmonitor=false', '-c', 'core.untrackedCache=false', '-c', 'core.pager=cat', '-c', 'diff.external=', '-C', str(repo)] + list(args)
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV, timeout=35)
    need(r.returncode == 0, 'read-only Git failed ' + repr(args) + ' ' + txt(r.stderr))
    need(len(r.stdout) < 4000000, 'Git output bound')
    return r.stdout
BSL = re.escape(bytes([92])); HI = bytes([128])+b'-'+bytes([255]); FIRST=b'[A-Za-z_'+HI+b']'; REST=b'[A-Za-z_0-9'+HI+b']'; UCN=b'(?:'+BSL+b'u[0-9A-Fa-f]{4}|'+BSL+b'U[0-9A-Fa-f]{8})'; ID = re.compile(b'(?:'+FIRST+b'|'+UCN+b')(?:'+REST+b'|'+UCN+b')*')
RAW = re.compile(rb'(?:u8|u|U|L)?R"')
QUOTE = re.compile(b'(?:u8|u|U|L)?'+bytes([91,34,39,93]))
SPLICE = re.compile(BSL + bytes([13]) + b'?' + bytes([10]))
def scan(b, path):
    ids, protected = [], []
    i, n = 0, len(b)
    while i < n:
        s = i
        if b.startswith(b'//', i):
            i += 2
            while i < n:
                m = SPLICE.match(b, i)
                if m: i = m.end()
                elif b[i] in (10, 13): break
                else: i += 1
            protected.append(('comment', b[s:i])); continue
        if b.startswith(b'/*', i):
            end = b.find(b'*/', i+2)
            need(end >= 0, 'unterminated comment ' + path)
            i = end+2; protected.append(('comment', b[s:i])); continue
        if b[i:i+1] == b'#' and not b[b.rfind(b'\n', 0, i)+1:i].strip():
            m = re.match(b'#[ '+bytes([9])+b']*(?:include|include_next)[ '+bytes([9])+b']*<[^>'+bytes([13,10])+b']*>', b[i:])
            if m:
                i += m.end(); protected.append(('header', b[s:i])); continue
        m = RAW.match(b, i)
        if m:
            opening = b.find(b'(', m.end(), m.end()+17)
            need(opening >= 0, 'ambiguous raw delimiter ' + path)
            delim = b[m.end():opening]
            need(all(c > 32 and c not in (40,41,92,127) for c in delim), 'invalid raw delimiter ' + path)
            end = b.find(b')'+delim+b'"', opening+1)
            need(end >= 0, 'unterminated raw literal ' + path)
            i = end+len(delim)+2
            suffix = ID.match(b, i)
            if suffix: i = suffix.end()
            protected.append(('literal', b[s:i])); continue
        m = QUOTE.match(b, i)
        if m:
            quote = b[m.end()-1]; i = m.end()
            while i < n:
                if b[i] == 92:
                    need(i+1 < n, 'unterminated escape ' + path)
                    i += 3 if b[i+1:i+3] == b'\r\n' else 2
                elif b[i] == quote:
                    i += 1; break
                else:
                    need(b[i] not in (10, 13), 'unescaped literal newline ' + path)
                    i += 1
            else: raise RuntimeError('unterminated literal ' + path)
            suffix = ID.match(b, i)
            if suffix: i = suffix.end()
            protected.append(('literal', b[s:i])); continue
        if 48 <= b[i] <= 57 or (b[i:i+1] == b'.' and i+1 < n and 48 <= b[i+1] <= 57):
            i += 1
            while i < n:
                m = ID.match(b, i)
                if m: i = m.end()
                elif b[i:i+1] in (b'.', b"'") or 48 <= b[i] <= 57: i += 1
                elif b[i:i+1] in (b'+', b'-') and b[i-1:i] in (b'e', b'E', b'p', b'P'): i += 1
                else: break
            continue
        m = ID.match(b, i)
        if m:
            i = m.end(); splice = SPLICE.match(b, i)
            need(not (splice and ID.match(b, splice.end())), 'line-spliced identifier ' + path)
            ids.append((s, i, b[s:i])); continue
        splice = SPLICE.match(b, i)
        if splice:
            need(not (b[i-1:i] in (b'/', b'*') and b[splice.end():splice.end()+1] in (b'/', b'*')), 'spliced comment delimiter ' + path)
            i = splice.end(); continue
        i += 1
    return ids, protected
def main():
    need(ROOT.resolve() == ROOT, 'root mismatch')
    paths = [safe(p) for p in SPEC['files']]
    need(len(paths) == len(set(paths)) == 24, 'scope mismatch')
    mapping = {k.encode(): v.encode() for k, v in SPEC['identifier_map'].items()}
    need(len(mapping) == 20 and all(len(k) == len(v) for k,v in mapping.items()), 'map mismatch')
    nested = safe(ROOT/'third_party')
    head = git(ROOT, 'rev-parse', 'HEAD'); branch = git(ROOT, 'rev-parse', '--abbrev-ref', 'HEAD')
    status = git(ROOT, 'status', '--porcelain=v1', '--untracked-files=all')
    nh = git(nested, 'rev-parse', 'HEAD'); nb = git(nested, 'rev-parse', '--abbrev-ref', 'HEAD')
    ns = git(nested, 'status', '--porcelain=v1', '--untracked-files=all')
    lh = git(ROOT, 'ls-tree', 'HEAD', '--', 'third_party')
    li = git(ROOT, 'ls-files', '--stage', '--', 'third_party')
    print('BASELINE parent='+txt(head).strip()+' branch='+txt(branch).strip())
    print('BASELINE parent status (complete)\n'+txt(status), end='')
    print('BASELINE nested='+txt(nh).strip()+' branch='+txt(nb).strip()+' status='+repr(txt(ns)))
    print('BASELINE HEAD gitlink='+txt(lh).strip()+' INDEX gitlink='+txt(li).strip())
    need(txt(head).strip() == SPEC['authority']['last_observed_revision'] and branch.strip() == b'feat/v3-nlu-linux', 'parent revision/branch drift')
    need(nh.strip() == b'dbc5e096b29e3c160b240f6536346d6c61ae2817' and not ns, 'nested state drift')
    need(nh.strip() in lh and nh.strip() in li, 'gitlink mismatch')
    scoped = git(ROOT, 'status', '--porcelain=v1', '--untracked-files=all', '--', *[str(p.relative_to(ROOT)) for p in paths])
    need(not scoped, 'planned paths have edits; preserve '+txt(scoped))
    indexes = []
    for repo in (ROOT, nested):
        ip = Path(txt(git(repo, 'rev-parse', '--git-path', 'index')).strip())
        ip = safe(ip if ip.is_absolute() else repo/ip)
        need(ip.is_file() and ip.stat().st_size <= 64000000, 'index comparison size bound')
        indexes.append((ip, ip.read_bytes()))
        print('BASELINE index byte comparison size='+str(len(indexes[-1][1])))
    listed = git(ROOT, 'ls-files', '-z', '--cached', '--others', '--exclude-standard').split(b'\0')
    need(len(listed) < 20000, 'inventory bound')
    cpp, builds = [], {}
    for raw in listed:
        if not raw: continue
        rel = os.fsdecode(raw)
        if rel == 'third_party' or rel.startswith('third_party/'): continue
        if rel.endswith(('.cc','.h','.cpp','.hpp','.cxx','.c','.hh','.hxx')): cpp.append(safe(ROOT/rel))
        if Path(rel).name in ('BUILD','BUILD.bazel'): builds[safe(ROOT/rel)] = read(ROOT/rel)
    cpp = sorted(set(cpp)); need(set(paths).issubset(cpp), 'scope absent in inventory')
    baseline, modes, parsed = {}, {}, {}
    size = 0; counts = collections.Counter(); initializer = b'InitializeWithNlu06BInference'
    for p in cpp:
        b = read(p); size += len(b); need(size <= 80000000, 'audit bytes bound')
        if p not in paths and b'Nlu06B' not in b and not any(v in b for v in mapping.values()): continue
        ids, protected = scan(b, str(p))
        for s,e,name in ids:
            need(name not in mapping.values(), 'preexisting neutral collision '+str(p)+' '+txt(name))
            if b'Nlu06B' in name:
                need(name in mapping or name == initializer, 'unlisted legacy token '+str(p)+' '+txt(name))
                need(p in paths, 'legacy code needs unapproved path '+str(p))
                counts[name] += 1
        if p in paths: baseline[p], modes[p], parsed[p] = b, stat.S_IMODE(p.stat().st_mode), (ids,protected)
    print('AUDIT tracked+untracked C++ inventory='+str(len(cpp))+' bytes='+str(size)+' relevant='+str(len(parsed))+' BUILD protected='+str(len(builds)))
    print('BASELINE actual code-token counts='+json.dumps({txt(k):v for k,v in sorted(counts.items())}, sort_keys=True))
    print('BASELINE migratable='+str(sum(counts[k] for k in mapping))+' initializer='+str(counts[initializer]))
    need(counts[initializer] == 16, 'initializer count drift')
    ap = Path(SPEC['alias_insertion']['path']); insertion = SPEC['alias_insertion']['text'].encode()
    cb = SPEC['alias_insertion']['context_before_rename'].encode()
    ca = SPEC['alias_insertion']['context_after_token_rename'].encode()
    need(baseline[ap].count(cb) == 1, 'provider captured context drift')
    after, spans = {}, {}; offset = None
    for p in paths:
        b = baseline[p]; changes = [(s,e,name,mapping[name]) for s,e,name in parsed[p][0] if name in mapping]
        need(bool(changes), 'no changes '+str(p)); out = bytearray(b)
        for s,e,old,new in changes:
            need(bytes(out[s:e]) == old, 'overlap/mismatch'); out[s:e] = new
        out = bytes(out)
        if p == ap:
            need(out.count(ca) == 1, 'renamed provider context mismatch')
            offset = out.index(ca)+ca.index(SPEC['alias_insertion']['insert_before_within_context'].encode())
            out = out[:offset]+insertion+out[offset:]
            for decl in SPEC['alias_insertion']['primary_declarations_after_rename']:
                need(out.count(decl.encode()) == 1, 'primary typedef mismatch')
        after[p], spans[p] = out, changes
    def validate(p, actual):
        normalized = actual
        if p == ap:
            need(actual[offset:offset+len(insertion)] == insertion and actual.count(insertion) == 1, 'known insertion mismatch')
            normalized = actual[:offset]+actual[offset+len(insertion):]
        ids, protected = scan(normalized, str(p))
        need(protected == parsed[p][1], 'protected bytes changed '+str(p))
        inverse = bytearray(normalized)
        for s,e,old,new in reversed(spans[p]):
            need(bytes(inverse[s:e]) == new, 'inverse new-span mismatch '+str(p)); inverse[s:e] = old
        need(bytes(inverse) == baseline[p], 'inverse not byte equal '+str(p))
        need([(s,e) for s,e,n in ids if n == initializer] == [(s,e) for s,e,n in parsed[p][0] if n == initializer], 'initializer changed')
        need(not any(n in mapping or (b'Nlu06B' in n and n != initializer) for s,e,n in ids), 'legacy residual')
        need(stat.S_IMODE(p.stat().st_mode) == modes[p], 'mode changed')
        if p == ap:
            all_ids, _ = scan(actual, str(p))
            for old in (b'Nlu06BOutputCallback',b'Nlu06BInferenceHook'):
                need(sum(n == old for s,e,n in all_ids) == 1, 'duplicate/missing alias')
            for decl in SPEC['old_code_token_allowlist'][1:]:
                need(actual.count(decl['exact_declaration'].encode()) == 1, 'alias mismatch')
            need(actual.count(b'extern "C" {') == baseline[p].count(b'extern "C" {') == 1, 'provider C linkage mismatch')
            need(actual.index(insertion) < actual.index(b'}  // extern "C"'), 'aliases outside linkage')
        return collections.Counter(k for k,b in protected)
    for p in paths: validate(p, after[p])
    print('PREVALIDATION PASS all 24 transforms/inverse/literals/comments/headers/modes; no neutral collisions; unique aliases; no product writes yet')
    print('INSERTION '+str(ap)+' original_byte_offset='+str(offset)+' bytes='+repr(insertion))
    for p in paths:
        print('SPANS '+str(p)+' zero-based half-open')
        for s,e,old,new in spans[p]: print('  ['+str(s)+','+str(e)+') '+txt(old)+' -> '+txt(new))
        print('PAIRED_UNIFIED_DIFF '+str(p))
        for line in difflib.unified_diff(txt(baseline[p]).splitlines(True), txt(after[p]).splitlines(True), fromfile=str(p)+' (CURRENT before)', tofile=str(p)+' (after)', n=3):
            print(line, end='')
    sys.stdout.flush()
    for p in paths:
        need(read(p) == baseline[p], 'current bytes drift before write '+str(p))
        with p.open('r+b') as f: f.write(after[p]); f.truncate()
        print('WROTE '+str(p), flush=True)
    for p in paths:
        actual = read(p); need(actual == after[p], 'actual write mismatch')
        pc = validate(p, actual)
        print('FILE_PASS '+str(p)+' spans='+str(len(spans[p]))+' literal_tokens='+str(pc['literal'])+' comments='+str(pc['comment'])+' headers='+str(pc['header'])+' inverse=byte_equal protected=exact mode='+oct(modes[p]))
    for p,b in builds.items(): need(read(p) == b, 'BUILD bytes changed '+str(p))
    for p,b in indexes: need(safe(p).read_bytes() == b, 'Git index bytes changed')
    need(git(ROOT,'rev-parse','HEAD') == head and git(ROOT,'rev-parse','--abbrev-ref','HEAD') == branch, 'parent ref changed')
    need(git(nested,'rev-parse','HEAD') == nh and git(nested,'rev-parse','--abbrev-ref','HEAD') == nb and git(nested,'status','--porcelain=v1','--untracked-files=all') == ns, 'nested state changed')
    need(git(ROOT,'ls-tree','HEAD','--','third_party') == lh and git(ROOT,'ls-files','--stage','--','third_party') == li, 'gitlinks changed')
    final = git(ROOT,'status','--porcelain=v1','--untracked-files=all')
    expected = set(status.splitlines()) | {b' M '+os.fsencode(str(p.relative_to(ROOT))) for p in paths}
    need(set(final.splitlines()) == expected, 'unexpected status delta; preserve and return')
    print('PRESERVATION_PASS all BUILD bytes; parent+nested index bytes; parent+nested revision/branch; HEAD/index gitlinks; nested clean; unrelated status; committed filenames preserved')
    print('API_STATIC_PASS initializer tokens=16 unchanged; callback/initializer structural signatures, linkage, punctuation/order/layout/control flow preserved by exact inverse; 2 canonical callbacks + exactly 2 legacy callback aliases; no wrappers/class/binding aliases')
    print('OLD_CODE_TOKEN_ALLOWLIST InitializeWithNlu06BInference=16; provider-only alias declarations Nlu06BOutputCallback=1 and Nlu06BInferenceHook=1; prior callback/test uses migrated')
    print('FINAL parent status (complete)\n'+txt(final), end='')
    print('ACCEPTANCE PASS files=24 mapped_identifiers=20 replaced_tokens='+str(sum(len(v) for v in spans.values()))+' insertion=2 typedefs+1 comment')
    print('NO_PIPELINE_EFFECT no helper/pipeline inspection/execution; no build/compiler/test/model/HTTP/runtime/service/container/deploy/Git mutation/third_party edits')
    print('UNVERIFIED compilation/project tests/binary ABI/external consumers/runtime/deployment; static proof only')
try:
    main()
except Exception:
    print('EXECUTION FAIL; preserve existing/partial edits; no rollback', flush=True)
    traceback.print_exc()
    sys.exit(1)
