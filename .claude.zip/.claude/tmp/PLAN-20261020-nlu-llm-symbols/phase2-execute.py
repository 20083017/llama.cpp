import os, sys, json, subprocess, re, shlex, pathlib, time, traceback
TASK = pathlib.Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261020-nlu-llm-symbols')
SSH = sys.argv[1]; KEYGEN = sys.argv[2]; ALIAS = 'new2_wtp184-server'
def need(ok, msg):
    if not ok: raise RuntimeError(msg)
def effective():
    r = subprocess.run([SSH,'-G',ALIAS], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    need(r.returncode == 0, 'ssh -G failed; no fallback')
    fields = {}
    wanted = {'hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','proxyjump','proxycommand','stricthostkeychecking','hostkeyalias','canonicalizehostname','knownhostscommand'}
    for line in r.stdout.decode('utf-8','replace').splitlines():
        key, sep, val = line.partition(' ')
        if key in wanted: fields.setdefault(key,[]).append(val.strip())
    return fields
def localpath(s):
    s = os.path.expanduser(s.strip(chr(34)).replace(chr(92),'/'))
    if re.match(r'^/[A-Za-z]/',s): s = s[1]+':'+s[2:]
    return pathlib.Path(s)
def main(log):
    def record(s): print(s, file=log, flush=True)
    record('PLAN-20261020-nlu-llm-symbols v2 Phase2 authoritative source-only rename')
    record('IN_PHASE_CORRECTION: append-only command evidence; prior preparation stopped at source-sized bound for nested Git index; use dedicated bounded 64MB index byte comparison; source remains 4MB per file; no source writes from failed commands')
    record('START '+time.strftime('%Y-%m-%dT%H:%M:%S%z'))
    record('LOCAL preparation: long Bash heredoc parse failed before execution; corrected with short chunks; no remote action occurred')
    need(not any(os.environ.get(k) for k in ('WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS')), 'unexpected explicit SSH overrides')
    f = effective()
    for k,v in [('hostname','10.1.120.40'),('user','daigd'),('port','22'),('identitiesonly','yes')]:
        need(f.get(k) == [v], 'effective field mismatch '+k)
    for k in ('proxyjump','proxycommand','knownhostscommand','hostkeyalias'):
        need(f.get(k,['none']) == ['none'], 'unexpected routing/trust customization '+k)
    need(f.get('canonicalizehostname',['false']) in (['false'],['no']), 'hostname canonicalization not permitted')
    need(f.get('stricthostkeychecking') in (['ask'],['true'],['yes']), 'configured verification weakened')
    need(bool(f.get('identityfile')), 'no configured identity')
    for ident in f['identityfile']:
        ip = localpath(ident)
        need(ip.is_file() and os.access(str(ip),os.R_OK), 'configured identity unavailable; path suppressed; no fallback')
    kh = []
    for k in ('userknownhostsfile','globalknownhostsfile'):
        for line in f.get(k,[]):
            for token in shlex.split(line,posix=False):
                kp = localpath(token)
                if kp.is_file(): kh.append(kp)
    need(bool(kh), 'no existing known-hosts file')
    trusted = False
    for kp in kh:
        r = subprocess.run([KEYGEN,'-F','10.1.120.40','-f',str(kp)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        if r.returncode == 0 and any(x and not x.startswith(b'#') for x in r.stdout.splitlines()): trusted = True
    need(trusted, 'no existing trusted host entry; no trust changes')
    record('SSH_CONTRACT PASS role=Ubuntu-authoritative-source mode=alias alias='+ALIAS+' user=daigd hostname=10.1.120.40 port=22 identitiesonly=yes identities=readable existing trusted host entry=yes proxy=none; private paths suppressed')
    spec = json.loads((TASK/'edit-spec-v2.json').read_text(encoding='utf-8'))
    script = (TASK/'phase2-apply.py').read_bytes()
    compile(script, 'phase2-apply.py','exec')
    scope = {}; exec(compile(script.split(b'def main():')[0],'scanner-input','exec'),scope)
    sample = b'Nlu06BBackend Nlu06BBackendSuffix 123Nlu06BBackend u8"Nlu06BBackend" L\'x\' R"tag(Nlu06BBackend /* */ \\\n)tag" // Nlu06BBackend\\\n Nlu06BBackend\n/* Nlu06BBackend */ Nlu06BBackend'
    ids, protected = scope['scan'](sample,'inline acceptance')
    need(sum(n == b'Nlu06BBackend' for s,e,n in ids) == 2 and len(protected) == 5, 'scanner protection probe failed')
    sample = b'Nlu06BBackend\\u1234 Nlu06BBackend\xc3\xa9'
    need(not any(n == b'Nlu06BBackend' for s,e,n in scope['scan'](sample,'identifier-continuation')[0]), 'identifier continuation probe failed')
    record('LOCAL_STATIC PASS compile(input) and literal/raw/multiline/escaped-comment/pp-number/UCN/non-ASCII scanner probes; no project tests')
    payload = ('import json\nSPEC = json.loads('+repr(json.dumps(spec))+')\n').encode()+script
    need(effective() == f, 'effective SSH contract drift; stop')
    opts = ['-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','IdentitiesOnly=yes','-o','PasswordAuthentication=no','-o','KbdInteractiveAuthentication=no','-o','PreferredAuthentications=publickey','-o','ForwardAgent=no','-o','ForwardX11=no','-o','ClearAllForwardings=yes','-o','RequestTTY=no','-o','ControlMaster=no','-o','ControlPath=none','-o','ControlPersist=no','-o','ConnectTimeout=12','-o','ConnectionAttempts=1','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=2','-o','UpdateHostKeys=no']
    cmd = [SSH]+opts+[ALIAS,'timeout 150s python3 -I -u -']
    record('ACTUAL_COMMAND ssh '+shlex.join(opts+[ALIAS,'timeout 150s python3 -I -u -'])+' < task-owned stdin (exact spec + CURRENT-byte scanner/application)')
    r = subprocess.run(cmd,input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=175)
    need(len(r.stdout)+len(r.stderr) <= 2000000, 'remote evidence output bound exceeded')
    record(r.stdout.decode('utf-8','replace'))
    if r.stderr: record('STDERR\n'+r.stderr.decode('utf-8','replace'))
    record('REMOTE_EXIT_STATUS='+str(r.returncode))
    record('END '+time.strftime('%Y-%m-%dT%H:%M:%S%z'))
    print('remote_exit_status='+str(r.returncode)+' evidence='+str(TASK/'rename-static-v2.log'))
    return r.returncode
import io
log = io.StringIO()
try: code = main(log)
except Exception:
    log.write('LOCAL_EXECUTION_FAIL; no alternate SSH contract or rollback'+chr(10)+traceback.format_exc())
    print('execution failed: '+str(sys.exc_info()[1]))
    code = 1
log.write('LOCAL_EXIT_STATUS='+str(code)+chr(10))
if code == 0 or 'ACTUAL_COMMAND' in log.getvalue():
    with (TASK/'rename-static-v2.log').open('a',encoding='utf-8',newline=chr(10)) as output:
        output.write(log.getvalue())
else:
    print('No remote execution and no authoritative evidence log finalized')
sys.exit(code)
