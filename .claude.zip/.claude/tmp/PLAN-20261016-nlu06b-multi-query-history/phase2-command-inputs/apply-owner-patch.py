import os, sys, pathlib, subprocess, shlex, json, base64, datetime, hashlib
root=pathlib.Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261016-nlu06b-multi-query-history')
packet=root/('v2-phase2-'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S'))
packet.mkdir(exist_ok=False)
log=(packet/'operation.log').open('w',encoding='utf-8')
def emit(s):
 print(s,flush=True);log.write(s+'\n');log.flush()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def run(args,**kw):return subprocess.run(args,capture_output=True,timeout=kw.pop('timeout',15),**kw)
ssh=os.environ['PHASE2_SSH_EXE'];keygen=os.environ['PHASE2_KEYGEN_EXE'];cygpath=os.environ['PHASE2_CYGPATH_EXE']
alias='new2_wtp184-server'
files=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/v3_linux_offline_test.cc']
try:
 need(not any(os.environ.get(k) for k in ['WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS']),'Explicit override present; no alias fallback')
 r=run([ssh,'-G',alias]);emit('ssh -G new2_wtp184-server EXIT '+str(r.returncode));need(r.returncode==0,'Alias resolution failed')
 wanted=['hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','hostkeyalias','proxyjump','proxycommand','canonicalizehostname']
 cfg={}
 for line in r.stdout.decode().splitlines():
  k,_,v=line.partition(' ')
  if k in wanted:cfg.setdefault(k,[]).append(v)
 for k,v in [('hostname','10.1.120.40'),('user','daigd'),('port','22'),('identitiesonly','yes')]:need(cfg.get(k)==[v],'Alias mismatch: '+k)
 for k in ['proxyjump','proxycommand','hostkeyalias']:need(cfg.get(k,['none'])==['none'],'Unexpected '+k)
 need(cfg.get('canonicalizehostname',['false'])[0] in ['false','no'],'Hostname canonicalization enabled')
 def paths(v):
  lexer=shlex.shlex(v,posix=True);lexer.whitespace_split=True;lexer.commenters='';lexer.escape=''
  return list(lexer)
 identities=[]
 for v in cfg.get('identityfile',[]):
  # Each IdentityFile line is one path; preserve embedded spaces.
  if len(v)>=2 and v[0]==v[-1] and v[0] in ['"', "'"]:v=v[1:-1]
  identities.append(v)
 known=[(kind,i,p) for kind in ['userknownhostsfile','globalknownhostsfile'] for i,p in enumerate([p for v in cfg.get(kind,[]) for p in paths(v)],1) if p!='none']
 need(identities and known,'Missing configured identity/trust mechanisms')
 def native(p,category):
  if p=='~' or p.startswith('~/'):
   home=os.environ.get('HOME');need(bool(home),category+' tilde expansion: HOME absent')
   p=home.rstrip('/')+p[1:]
  need(not p.startswith('~') and '%' not in p,category+' unresolved path expansion')
  r=run([cygpath,'-w',p]);need(r.returncode==0,category+' cygpath conversion failed exit='+str(r.returncode))
  n=r.stdout.decode().strip();need(bool(n),category+' empty converted path')
  return n
 for i,p in enumerate(identities,1):
  category='identity['+str(i)+']';n=native(p,category)
  exists=pathlib.Path(n).is_file();readable=exists and os.access(n,os.R_OK)
  emit(category+' native_file='+str(exists)+' readable='+str(readable)+' conversion=cygpath-w')
  need(readable,category+' required configured identity absent/nonregular/unreadable')
 count=0;readable_known=0
 for kind,i,p in known:
  category=kind+'['+str(i)+']';n=native(p,category)
  exists=pathlib.Path(n).exists();regular=pathlib.Path(n).is_file();readable=regular and os.access(n,os.R_OK)
  emit(category+' basename='+pathlib.Path(n).name+' native_exists='+str(exists)+' readable='+str(readable)+' conversion=cygpath-w')
  if not exists:
   emit(category+' OPTIONAL_ABSENT skipped; no trust/config mutation');continue
  need(readable,category+' existing configured trust file nonregular/unreadable')
  readable_known+=1
  r=run([keygen,'-F','10.1.120.40','-f',n]);need(r.returncode in [0,1],category+' known-host lookup failed exit='+str(r.returncode))
  lines=[x for x in r.stdout.decode().splitlines() if x and not x.startswith('#')]
  need(not any(x.startswith('@revoked') for x in lines),category+' revoked destination key')
  matches=[x for x in lines if not x.startswith('@')]
  count+=len(matches);emit(category+' bare_HostName_trusted_matches='+str(len(matches)))
 need(readable_known>0 and count==2,'Pinned trust mismatch: expected two existing bare-HostName matches; found='+str(count))
 emit('CONTRACT PASS Ubuntu new2_wtp184-server -> daigd@10.1.120.40:22; configured readable identities; existing trust matches=2; no HostKeyAlias/proxy; no trust/config mutation')
 opts=['-T']
 for option in ['BatchMode=yes','StrictHostKeyChecking=yes','UpdateHostKeys=no','IdentitiesOnly=yes','IdentityAgent=none','PasswordAuthentication=no','KbdInteractiveAuthentication=no','PreferredAuthentications=publickey','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=10','ConnectionAttempts=1','ServerAliveInterval=10','ServerAliveCountMax=2','ProxyJump=none','ProxyCommand=none','CanonicalizeHostname=no']:opts+=['-o',option]
 def remote(label,code,payload=b'',bound=60):
  compile(code,'<'+label+'>','exec')
  (packet/(label+'-command.py')).write_text(code,encoding='utf-8')
  cmd='timeout --kill-after=5s '+str(bound)+'s python3 -I -c '+shlex.quote(code)
  r=run([ssh]+opts+[alias,cmd],input=payload,timeout=bound+25)
  (packet/(label+'-stdout.bin')).write_bytes(r.stdout);(packet/(label+'-stderr.log')).write_bytes(r.stderr)
  emit(label+' SSH/REMOTE EXIT '+str(r.returncode))
  if r.stderr:emit(r.stderr.decode(errors='replace')[:3000])
  if r.returncode:emit(r.stdout.decode(errors='replace')[-3000:])
  need(r.returncode==0,label+' failed; see retained packet');return r.stdout
 common=r"""import os,sys,json,base64,pathlib,subprocess,stat,shutil,hashlib
P=pathlib.Path('/home/daigd/dialogue')
F=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/v3_linux_offline_test.cc']
H='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert P.resolve(strict=True)==P, 'Project path mismatch'
for f in F:
 p=P/f
 assert not p.is_symlink() and p.resolve(strict=True)==p and p.is_file(), 'Product path escape/nonregular'
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_EXTERNAL_DIFF='')
G=['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-C',str(P)]
def git(args):
 r=subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==0, r.stderr.decode(errors='replace')
 return r.stdout
assert git(['rev-parse','HEAD']).decode().strip()==H, 'HEAD drift'
assert git(['symbolic-ref','--short','HEAD']).decode().strip()=='feat/v3-nlu-linux', 'Branch drift'
"""
 precode=common+r"""S=git(['status','--porcelain=v1','--untracked-files=all','--']+F)
assert not S, 'Scoped preimage drift: '+S.decode()
assert not git(['diff','--no-ext-diff','--no-textconv','--']+F)
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F)
D={}
for f in F:
 b=(P/f).read_bytes();assert b==git(['show','HEAD:'+f]), 'Working preimage differs from HEAD'
 D[f]=base64.b64encode(b).decode()
print(json.dumps({'head':H,'branch':'feat/v3-nlu-linux','preimages':D}))
"""
 pre=json.loads(remote('01-preimage',precode))
 for f in files:
  b=base64.b64decode(pre['preimages'][f]);need(b==(root/'source'/f).read_bytes(),'Original preimage mismatch: '+f)
  dest=packet/'preimages'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  emit('PREIMAGE BYTE EQUALITY PASS '+f)
 patch=(root/'v2-work/v2.patch').read_bytes()
 need(len(patch)==50230 and len(patch.splitlines())==1067,'Owner patch size drift')
 need([x[4:].decode() for x in patch.splitlines() if x.startswith(b'--- ')]==['a/'+f for f in files],'Old patch pathscope mismatch')
 need([x[4:].decode() for x in patch.splitlines() if x.startswith(b'+++ ')]==['b/'+f for f in files],'New patch pathscope mismatch')
 tx='/home/daigd/.wtp184-transactions/PLAN-20261016-nlu06b-multi-query-history-v2-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 emit('TRANSACTION '+tx)
 (packet/'transaction-path.txt').write_text(tx+'\n',encoding='utf-8')
 applycode=common+'T=pathlib.Path('+repr(tx)+')\n'+r"""assert T.parent==pathlib.Path('/home/daigd/.wtp184-transactions')
assert T.name.startswith('PLAN-20261016-nlu06b-multi-query-history-v2-') and len(T.name)==len('PLAN-20261016-nlu06b-multi-query-history-v2-20261016T000000Z')
T.parent.mkdir(mode=0o700,exist_ok=True)
assert T.parent.resolve(strict=True)==T.parent and not T.exists(), 'Transaction escape/collision'
T.mkdir(mode=0o700);assert T.resolve(strict=True)==T
os.umask(0o077)
b=sys.stdin.buffer.read(50231);assert len(b)==50230 and len(b.splitlines())==1067
assert hashlib.sha256(b).hexdigest()==PATCH_SHA, 'Patch transfer mismatch'
print('PATCH TRANSFER SHA256 MATCH '+PATCH_SHA)
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'--- ')]==['a/'+f for f in F]
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'+++ ')]==['b/'+f for f in F]
patch=T/'v2.patch';patch.write_bytes(b)
assert not git(['status','--porcelain=v1','--untracked-files=all','--']+F), 'Scoped drift before apply'
meta={}
for f in F:
 p=P/f;original=p.read_bytes();assert original==git(['show','HEAD:'+f]), 'Preimage changed before apply'
 s=p.stat();meta[f]=(s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode))
 q=T/'preimages'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(p),str(q));assert q.read_bytes()==original
(T/'preimage-metadata.json').write_text(json.dumps(meta))
def patchrun(dry):
 args=['patch','--batch','--forward','--fuzz=0','--no-backup-if-mismatch','--reject-file='+str(T/'patch-rejects.txt'),'-p1','-i',str(patch)]
 if dry:args.insert(1,'--dry-run')
 r=subprocess.run(args,cwd=str(P),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 text=r.stdout.decode(errors='replace');name='dry-run' if dry else 'apply'
 (T/(name+'.log')).write_text(text);print(name+' EXIT '+str(r.returncode));print(text,end='')
 assert r.returncode==0, name+' failed'
 assert 'offset' not in text.lower() and 'fuzz' not in text.lower(), 'Patch did not match exact locations'
patchrun(True)
for f in F:assert (P/f).read_bytes()==(T/'preimages'/f).read_bytes(), 'Preimage drift after dry-run'
patchrun(False)
for f in F:
 s=(P/f).stat();assert (s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode))==meta[f], 'Product metadata changed'
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F), 'Unexpected staged changes'
assert git(['diff','--no-ext-diff','--no-textconv','--name-only','--']+F).decode().splitlines()==F, 'Scoped changed-name mismatch'
ws=subprocess.run(G+['diff','--no-ext-diff','--no-textconv','--check','--']+F,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
(T/'whitespace.log').write_bytes(ws.stdout);print('WHITESPACE EXIT '+str(ws.returncode));print(ws.stdout.decode(errors='replace'),end='');assert ws.returncode==0, 'Whitespace audit failed; owner correction required'
for label,args in [('scoped-status',['status','--porcelain=v1','--untracked-files=all','--']+F),('scoped-stat',['diff','--no-ext-diff','--no-textconv','--stat','--']+F),('scoped-numstat',['diff','--no-ext-diff','--no-textconv','--numstat','--']+F),('scoped-diff',['diff','--no-ext-diff','--no-textconv','--']+F)]:
 data=git(args);(T/(label+'.txt')).write_bytes(data)
 if label!='scoped-diff':print(label+' EXIT 0\n'+data.decode(),end='')
print('TRANSACTION '+str(T));print('METADATA PRESERVED; STAGED DIFF EMPTY; HEAD/BRANCH UNCHANGED')
"""
 applycode='PATCH_SHA='+repr(hashlib.sha256(patch).hexdigest())+chr(10)+applycode
 emit(remote('02-apply',applycode,patch,90).decode(errors='replace'))
 postcode=common+r"""assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F)
S=git(['status','--porcelain=v1','--untracked-files=all','--']+F).decode()
assert S==''.join(' M '+f+'\n' for f in F), 'Unexpected scoped status'
print(json.dumps({'head':H,'branch':'feat/v3-nlu-linux','postimages':{f:base64.b64encode((P/f).read_bytes()).decode() for f in F},'status':S,'numstat':git(['diff','--no-ext-diff','--no-textconv','--numstat','--']+F).decode()}))
"""
 post=json.loads(remote('03-postimage',postcode))
 for f in files:
  b=base64.b64decode(post['postimages'][f]);dest=packet/'postimages'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  need(b==(root/'v2-work'/f).read_bytes(),'Postimage differs from sole content owner: '+f)
  emit('POSTIMAGE BYTE EQUALITY PASS '+f)
 emit('PASS Phase2 exact owner patch applied; no build/test/Git mutation/runtime/config/deployment action')
except Exception as e:
 emit('FAIL '+str(e));sys.exit(1)
finally:
 emit('LOCAL EVIDENCE PACKET '+str(packet));log.close()
