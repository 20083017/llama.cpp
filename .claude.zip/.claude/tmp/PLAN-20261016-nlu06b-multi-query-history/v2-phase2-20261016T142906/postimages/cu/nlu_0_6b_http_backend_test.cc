// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_0_6b_http_backend.h"

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

#include "base/json_helper.h"
#include "base/logging.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace {

class FakeTransport : public Nlu06BHttpTransport {
 public:
  FakeTransport(int result_code, long status_code, const std::string& body)
      : result_code_(result_code),
        status_code_(status_code),
        body_(body),
        post_count_(0) {}

  int Post(const Nlu06BHttpRequest& request,
           Nlu06BHttpResponse* response) const override {
    ++post_count_;
    request_ = request;
    if (result_code_ < 0 || response == nullptr) {
      return -1;
    }
    response->status_code = status_code_;
    response->body = body_;
    return 0;
  }

  int post_count() const { return post_count_; }
  void SetResponseBody(const std::string& body) { body_ = body; }

  mutable Nlu06BHttpRequest request_;

 private:
  int result_code_;
  long status_code_;
  std::string body_;
  mutable int post_count_;
};

class ScopedLogCapture : public google::LogSink {
 public:
  ScopedLogCapture() { google::AddLogSink(this); }
  ~ScopedLogCapture() override { google::RemoveLogSink(this); }

  void send(google::LogSeverity severity, const char* full_filename,
            const char* base_filename, int line,
            const google::LogMessageTime& log_message_time,
            const char* message, size_t message_len) override {
    (void)severity;
    (void)full_filename;
    (void)base_filename;
    (void)line;
    (void)log_message_time;
    std::lock_guard<std::mutex> lock(mutex_);
    messages_.append(message, message_len);
    messages_.push_back('\n');
  }

  std::string messages() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return messages_;
  }

 private:
  mutable std::mutex mutex_;
  std::string messages_;
};

Json::Value MakeConfig() {
  Json::Value config(Json::objectValue);
  config["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  config["model"] = "qwen3";
  config["system_prompt"] = "parse vehicle semantics";
  return config;
}

class ConstantTransport : public Nlu06BHttpTransport {
 public:
  ConstantTransport(long status_code, const std::string& body)
      : status_code_(status_code), body_(body) {}

  int Post(const Nlu06BHttpRequest& request,
           Nlu06BHttpResponse* response) const override {
    (void)request;
    if (response == nullptr) {
      return -1;
    }
    response->status_code = status_code_;
    response->body = body_;
    return 0;
  }

 private:
  long status_code_;
  std::string body_;
};

class ScopedCaptureDirectory {
 public:
  ScopedCaptureDirectory() {
    char path[] = "/tmp/wtp184_nlu06b_capture_XXXXXX";
    char* created = mkdtemp(path);
    if (created != nullptr) {
      path_ = created;
    }
  }

  ~ScopedCaptureDirectory() {
    for (size_t i = 0; i < files_.size(); ++i) {
      std::remove(files_[i].c_str());
    }
    if (!path_.empty()) {
      rmdir(path_.c_str());
    }
  }

  bool valid() const { return !path_.empty(); }

  std::string NewFile(const std::string& name) {
    const std::string path = path_ + "/" + name;
    files_.push_back(path);
    return path;
  }

 private:
  std::string path_;
  std::vector<std::string> files_;
};

Json::Value MakeCaptureConfig(const std::string& path,
                              const std::string& prefix,
                              int max_entries, int max_content_bytes) {
  Json::Value config = MakeConfig();
  config["diagnostic_capture_enabled"] = true;
  config["diagnostic_capture_output_path"] = path;
  config["diagnostic_capture_request_id_prefix"] = prefix;
  config["diagnostic_capture_max_entries"] = max_entries;
  config["diagnostic_capture_max_content_bytes"] = max_content_bytes;
  return config;
}

std::vector<Json::Value> ReadCaptureRecords(const std::string& path) {
  std::vector<Json::Value> records;
  std::ifstream input(path.c_str());
  std::string line;
  while (std::getline(input, line)) {
    records.push_back(JsonHelper::ParseJsonFromString(line));
  }
  return records;
}

std::string MakeEnvelope(const std::string& content) {
  Json::Value envelope(Json::objectValue);
  envelope["choices"] = Json::Value(Json::arrayValue);
  Json::Value choice(Json::objectValue);
  choice["message"]["role"] = "assistant";
  choice["message"]["content"] = content;
  envelope["choices"].append(choice);
  return JsonHelper::ToString(envelope);
}

void ExpectDecodedContentFailure(const Json::Value& result,
                                 const std::string& content) {
  ASSERT_TRUE(result.isObject());
  ASSERT_EQ(1u, result.size());
  ASSERT_TRUE(result["nlu_result"].isString());
  EXPECT_EQ(content, result["nlu_result"].asString());
  EXPECT_FALSE(result.isMember("frames"));
  EXPECT_FALSE(result.isMember("is_rejected"));
  EXPECT_FALSE(result.isMember("is_multi_intent"));
  EXPECT_FALSE(result.isMember("stale"));
}

std::unique_ptr<Nlu06BBackend> MakeBackend(
    const Json::Value& config, int result_code, long status_code,
    const std::string& body, FakeTransport** fake) {
  std::unique_ptr<FakeTransport> transport(
      new FakeTransport(result_code, status_code, body));
  *fake = transport.get();
  return CreateNlu06BHttpBackend(
      config, std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
}

Nlu06BRequest MakeRequest() {
  Nlu06BRequest request;
  request.request_id = "request-id-not-sent";
  request.query = "副驾驶座椅加热降到1档";
  request.histories = Json::Value(Json::arrayValue);
  request.histories.append("prior query");
  request.model_last_context = Json::Value(Json::objectValue);
  request.model_last_context["last_domain"] = "vehicle";
  return request;
}

Json::Value MakeProjectedHistory(const std::string& query,
                                 const std::string& domain,
                                 const std::string& intent,
                                 const Json::Value& slots) {
  Json::Value semantic(Json::objectValue);
  semantic["query"] = query;
  semantic["domain"] = domain;
  semantic["intent"] = intent;
  semantic["slots"] = slots;
  Json::Value history(Json::objectValue);
  history["v3_nlu_semantics"] = Json::Value(Json::arrayValue);
  history["v3_nlu_semantics"].append(semantic);
  return history;
}

Json::Value ReadPayload(const FakeTransport* fake) {
  if (fake == nullptr) {
    return Json::Value();
  }
  return JsonHelper::ParseJsonFromString(fake->request_.body);
}

TEST(Nlu06BHttpBackendTest, MapsExactPipeResultAndBuildsBoundedRequest) {
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeConfig(), 0, 200,
      MakeEnvelope(
          "domain=intelligent_car_control|intent=seat_heating_control|"
          "slot=area：座椅；gear_number：1；gear_unit：档；position：副驾"),
      &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
  EXPECT_STREQ("nlu06b", backend->result_source());
  ASSERT_EQ(1u, result["frames"].size());
  EXPECT_EQ("intelligent_car_control", result["frames"][0u]["domain"].asString());
  EXPECT_EQ("seat_heating_control",
            result["frames"][0u]["intents"][0u].asString());
  EXPECT_EQ("1", result["frames"][0u]["slots"]["gear_number"].asString());
  EXPECT_EQ("副驾", result["frames"][0u]["slots"]["position"].asString());
  EXPECT_FALSE(result["is_rejected"].asBool());
  EXPECT_FALSE(result["is_multi_intent"].asBool());

  ASSERT_NE(nullptr, fake);
  EXPECT_EQ(5000, fake->request_.connect_timeout_ms);
  EXPECT_EQ(30000, fake->request_.total_timeout_ms);
  EXPECT_EQ(1024u * 1024u, fake->request_.max_response_bytes);
  ASSERT_EQ(1u, fake->request_.headers.size());
  EXPECT_EQ("Content-Type: application/json", fake->request_.headers[0]);
  Json::Value payload = JsonHelper::ParseJsonFromString(fake->request_.body);
  ASSERT_TRUE(payload.isObject());
  EXPECT_EQ("qwen3", payload["model"].asString());
  ASSERT_TRUE(payload.isMember("stream"));
  EXPECT_FALSE(payload["stream"].asBool());
  EXPECT_FALSE(payload["enable_thinking"].asBool());
  ASSERT_TRUE(payload.isMember("chat_template_kwargs"));
  EXPECT_FALSE(payload["chat_template_kwargs"]["enable_thinking"].asBool());
  ASSERT_EQ(2u, payload["messages"].size());
  const std::string user_content =
      payload["messages"][1u]["content"].asString();
  EXPECT_EQ("{\"histories\":[\"prior query\"],"
            "\"model_last_context\":{\"last_domain\":\"vehicle\"},"
            "\"query\":\"副驾驶座椅加热降到1档\"}",
            user_content);
  Json::Value model_input =
      JsonHelper::ParseJsonFromString(user_content);
  EXPECT_EQ("副驾驶座椅加热降到1档", model_input["query"].asString());
  EXPECT_EQ("prior query", model_input["histories"][0u].asString());
  EXPECT_EQ("vehicle",
            model_input["model_last_context"]["last_domain"].asString());
  EXPECT_FALSE(fake->request_.body.find("request-id-not-sent") !=
               std::string::npos);
}

TEST(Nlu06BHttpBackendTest, AcceptsEmptySlotsAndAsciiWhitespace) {
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeConfig(), 0, 200,
      MakeEnvelope("  domain=vehicle | intent=open_window | slot=  \n"),
      &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
  EXPECT_TRUE(result["frames"][0u]["slots"].empty());
}

TEST(Nlu06BHttpBackendTest, AcceptsExplicitPipeV1Forms) {
  struct AcceptedCase {
    const char* content;
    size_t slot_count;
  };
  const AcceptedCase cases[] = {
      {"domain=vehicle|intent=open_window", 0u},
      {"domain：vehicle|intent：open_window|"
       "slot：area：driver；position：front",
       2u},
      {"domain：vehicle|intent：open_window|slot：", 0u},
      {"domain：vehicle|intent=open_window|slot：", 0u}};
  Json::Value config = MakeConfig();
  config["response_protocol"] = "pipe_v1";
  for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, 0, 200, MakeEnvelope(cases[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result)) << i;
    ASSERT_EQ(1u, result["frames"].size()) << i;
    EXPECT_EQ("vehicle", result["frames"][0u]["domain"].asString()) << i;
    EXPECT_EQ("open_window",
              result["frames"][0u]["intents"][0u].asString())
        << i;
    EXPECT_EQ(cases[i].slot_count,
              result["frames"][0u]["slots"].size())
        << i;
    if (cases[i].slot_count == 2u) {
      EXPECT_EQ("driver",
                result["frames"][0u]["slots"]["area"].asString())
          << i;
      EXPECT_EQ("front",
                result["frames"][0u]["slots"]["position"].asString())
          << i;
    }
    EXPECT_FALSE(result["is_multi_intent"].asBool()) << i;
  }
}

TEST(Nlu06BHttpBackendTest, AcceptsTsvV1Forms) {
  struct AcceptedCase {
    const char* content;
    size_t slot_count;
  };
  const AcceptedCase cases[] = {
      {"vehicle\topen_window\tarea=driver;position=front", 2u},
      {"vehicle\topen_window\tarea:driver;position:front", 2u},
      {"vehicle\topen_window\t", 0u}};
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, 0, 200, MakeEnvelope(cases[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result)) << i;
    ASSERT_EQ(1u, result["frames"].size()) << i;
    EXPECT_EQ("vehicle", result["frames"][0u]["domain"].asString()) << i;
    EXPECT_EQ("open_window",
              result["frames"][0u]["intents"][0u].asString())
        << i;
    EXPECT_EQ(cases[i].slot_count,
              result["frames"][0u]["slots"].size())
        << i;
    if (cases[i].slot_count == 2u) {
      EXPECT_EQ("driver",
                result["frames"][0u]["slots"]["area"].asString())
          << i;
      EXPECT_EQ("front",
                result["frames"][0u]["slots"]["position"].asString())
          << i;
    }
    EXPECT_FALSE(result["is_multi_intent"].asBool()) << i;
  }
}

TEST(Nlu06BHttpBackendTest, RejectsTsvV1ResponseWithOnlyOneTab) {
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle\topen_window"), &fake);
  ASSERT_TRUE(backend);

  ScopedLogCapture capture;
  Json::Value result(Json::objectValue);
  result["stale"] = true;
  EXPECT_LT(backend->Process(MakeRequest(), &result), 0);
  ExpectDecodedContentFailure(result, "vehicle	open_window");
  EXPECT_NE(std::string::npos,
            capture.messages().find("schema_detail=missing_tab"));
}

TEST(Nlu06BHttpBackendTest,
     BuildsExactTsvV1RequestWithoutHistoryAndOmitsTemplateKwargs) {
  Json::Value config = MakeConfig();
  config["model"] = "opaque-pipe-sounding-model";
  config["response_protocol"] = "tsv_v1";
  config["enable_thinking"] = true;
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle\topen_window\t"), &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));

  const Json::Value payload = ReadPayload(fake);
  ASSERT_TRUE(payload.isObject());
  EXPECT_EQ("opaque-pipe-sounding-model", payload["model"].asString());
  EXPECT_FALSE(payload.isMember("stream"));
  EXPECT_FALSE(payload.isMember("enable_thinking"));
  EXPECT_FALSE(payload.isMember("chat_template_kwargs"));
  EXPECT_DOUBLE_EQ(0.01, payload["temperature"].asDouble());
  EXPECT_DOUBLE_EQ(0.95, payload["top_p"].asDouble());
  EXPECT_EQ(20, payload["top_k"].asInt());
  EXPECT_EQ(1024, payload["max_tokens"].asInt());
  ASSERT_EQ(2u, payload["messages"].size());
  EXPECT_EQ("system", payload["messages"][0u]["role"].asString());
  EXPECT_EQ("parse vehicle semantics",
            payload["messages"][0u]["content"].asString());
  const std::string user_content =
      payload["messages"][1u]["content"].asString();
  EXPECT_EQ("history:\t\t\t\t\t\tcurrent query", user_content);
  EXPECT_EQ(6u, static_cast<size_t>(
                    std::count(user_content.begin(), user_content.end(),
                               '\t')));
}

TEST(Nlu06BHttpBackendTest,
     PreservesFullwidthPunctuationBytesInTsvV1CurrentQuery) {
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle\topen_window\t"), &fake);
  ASSERT_TRUE(backend);

  Nlu06BRequest request = MakeRequest();
  request.query =
      "current"
      "\xEF\xBC\x9A"
      "query"
      "\xEF\xBC\x9B"
      "payload";
  request.histories = Json::Value(Json::arrayValue);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));

  const Json::Value payload = ReadPayload(fake);
  const std::string user_content =
      payload["messages"][1u]["content"].asString();
  EXPECT_EQ("history:\t\t\t\t\t\tcurrent"
            "\xEF\xBC\x9A"
            "query"
            "\xEF\xBC\x9B"
            "payload",
            user_content);
}

TEST(Nlu06BHttpBackendTest,
     BuildsExactTsvV1RequestFromNewestHistoryInSortedSlotOrder) {
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle\topen_window\t"), &fake);
  ASSERT_TRUE(backend);

  Json::Value older_slots(Json::objectValue);
  older_slots["ignored"] = "old";
  Json::Value newest_slots(Json::objectValue);
  newest_slots["zeta"] = "last";
  newest_slots["alpha"] = "first";
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  request.histories.append(MakeProjectedHistory(
      "older query", "older_domain", "older_intent", older_slots));
  request.histories.append(MakeProjectedHistory(
      "newest query", "vehicle", "open_window", newest_slots));
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));

  const Json::Value payload = ReadPayload(fake);
  const std::string user_content =
      payload["messages"][1u]["content"].asString();
  EXPECT_EQ("history:\tnewest query\tvehicle\topen_window\t"
            "alpha=first;zeta=last\t\tcurrent query",
            user_content);
  EXPECT_EQ(6u, static_cast<size_t>(
                    std::count(user_content.begin(), user_content.end(),
                               '\t')));
  EXPECT_EQ(std::string::npos, user_content.find("older query"));
}

TEST(Nlu06BHttpBackendTest,
     PreservesFullwidthPunctuationBytesInProjectedHistoryQuery) {
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle\topen_window\t"), &fake);
  ASSERT_TRUE(backend);

  const std::string history_query =
      "history"
      "\xEF\xBC\x9A"
      "query"
      "\xEF\xBC\x9B"
      "payload";
  Json::Value slots(Json::objectValue);
  slots["area"] = "driver";
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  request.histories.append(MakeProjectedHistory(
      history_query, "vehicle", "open_window", slots));
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));

  const Json::Value payload = ReadPayload(fake);
  const std::string user_content =
      payload["messages"][1u]["content"].asString();
  EXPECT_EQ("history:\thistory"
            "\xEF\xBC\x9A"
            "query"
            "\xEF\xBC\x9B"
            "payload\tvehicle\topen_window\tarea=driver\t\tcurrent query",
            user_content);
  EXPECT_NE(std::string::npos, user_content.find(history_query));
}

TEST(Nlu06BHttpBackendTest,
     OmitsMalformedOrUnrepresentableNewestTsvV1History) {
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle\topen_window\t"), &fake);
  ASSERT_TRUE(backend);

  Json::Value valid_slots(Json::objectValue);
  valid_slots["slot"] = "value";
  const Json::Value valid = MakeProjectedHistory(
      "history query", "vehicle", "open_window", valid_slots);
  std::vector<Json::Value> invalid;
  invalid.push_back(Json::Value("not-an-object"));
  invalid.push_back(Json::Value(Json::objectValue));

  Json::Value multi = valid;
  multi["v3_nlu_semantics"].append(multi["v3_nlu_semantics"][0u]);
  invalid.push_back(multi);
  Json::Value empty_query = valid;
  empty_query["v3_nlu_semantics"][0u]["query"] = "";
  invalid.push_back(empty_query);
  Json::Value non_string_domain = valid;
  non_string_domain["v3_nlu_semantics"][0u]["domain"] = 1;
  invalid.push_back(non_string_domain);
  Json::Value missing_intent = valid;
  missing_intent["v3_nlu_semantics"][0u].removeMember("intent");
  invalid.push_back(missing_intent);
  Json::Value non_object_slots = valid;
  non_object_slots["v3_nlu_semantics"][0u]["slots"] =
      Json::Value(Json::arrayValue);
  invalid.push_back(non_object_slots);
  Json::Value non_string_slot = valid;
  non_string_slot["v3_nlu_semantics"][0u]["slots"]["slot"] = 1;
  invalid.push_back(non_string_slot);

  const char* field_controls[] = {"bad\tfield", "bad\rfield",
                                  "bad\nfield"};
  for (size_t i = 0; i < sizeof(field_controls) / sizeof(field_controls[0]);
       ++i) {
    Json::Value bad_query = valid;
    bad_query["v3_nlu_semantics"][0u]["query"] = field_controls[i];
    invalid.push_back(bad_query);
    Json::Value bad_domain = valid;
    bad_domain["v3_nlu_semantics"][0u]["domain"] = field_controls[i];
    invalid.push_back(bad_domain);
    Json::Value bad_intent = valid;
    bad_intent["v3_nlu_semantics"][0u]["intent"] = field_controls[i];
    invalid.push_back(bad_intent);
  }

  const char* slot_delimiters[] = {"bad\tpart", "bad\rpart",
                                   "bad\npart", "bad;part", "bad:part",
                                   "bad=part",
                                   "bad" "\xEF\xBC\x9A" "part",
                                   "bad" "\xEF\xBC\x9B" "part"};
  for (size_t i = 0;
       i < sizeof(slot_delimiters) / sizeof(slot_delimiters[0]); ++i) {
    Json::Value bad_name = valid;
    bad_name["v3_nlu_semantics"][0u]["slots"].removeMember("slot");
    bad_name["v3_nlu_semantics"][0u]["slots"][slot_delimiters[i]] =
        "value";
    invalid.push_back(bad_name);
    Json::Value bad_value = valid;
    bad_value["v3_nlu_semantics"][0u]["slots"]["slot"] =
        slot_delimiters[i];
    invalid.push_back(bad_value);
  }

  for (size_t i = 0; i < invalid.size(); ++i) {
    Nlu06BRequest request = MakeRequest();
    request.query = "current query";
    request.histories = Json::Value(Json::arrayValue);
    request.histories.append(valid);
    request.histories.append(invalid[i]);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result)) << i;
    const Json::Value payload = ReadPayload(fake);
    EXPECT_EQ("history:\t\t\t\t\t\tcurrent query",
              payload["messages"][1u]["content"].asString())
        << i;
    EXPECT_EQ(static_cast<int>(i + 1u), fake->post_count()) << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     RejectsTsvV1CurrentQueryControlsBeforeTransport) {
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle\topen_window\t"), &fake);
  ASSERT_TRUE(backend);
  const char* invalid_queries[] = {"current\tquery", "current\rquery",
                                   "current\nquery"};
  for (size_t i = 0;
       i < sizeof(invalid_queries) / sizeof(invalid_queries[0]); ++i) {
    Nlu06BRequest request = MakeRequest();
    request.query = invalid_queries[i];
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(request, &result), 0) << i;
    EXPECT_TRUE(result["stale"].asBool()) << i;
    EXPECT_EQ(0, fake->post_count()) << i;
    EXPECT_TRUE(fake->request_.body.empty()) << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     ExplicitPipeV1WithOpaqueModelPreservesStructuredJsonRequest) {
  Json::Value config = MakeConfig();
  config["model"] = "opaque-tsv-sounding-model";
  config["response_protocol"] = "pipe_v1";
  config["enable_thinking"] = true;
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200,
      MakeEnvelope("domain=vehicle|intent=open_window|slot="), &fake);
  ASSERT_TRUE(backend);
  const Nlu06BRequest request = MakeRequest();
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));

  const Json::Value payload = ReadPayload(fake);
  EXPECT_EQ("opaque-tsv-sounding-model", payload["model"].asString());
  ASSERT_TRUE(payload.isMember("stream"));
  EXPECT_FALSE(payload["stream"].asBool());
  EXPECT_TRUE(payload["enable_thinking"].asBool());
  ASSERT_TRUE(payload.isMember("chat_template_kwargs"));
  EXPECT_TRUE(payload["chat_template_kwargs"]["enable_thinking"].asBool());
  const Json::Value model_input = JsonHelper::ParseJsonFromString(
      payload["messages"][1u]["content"].asString());
  EXPECT_EQ(request.query, model_input["query"].asString());
  EXPECT_EQ(request.histories, model_input["histories"]);
  EXPECT_EQ(request.model_last_context,
            model_input["model_last_context"]);
}

TEST(Nlu06BHttpBackendTest, LogsBoundedContentSchemaDetails) {
  struct FailureCase {
    const char* content;
    const char* detail;
  };
  const FailureCase failures[] = {
      {"domain=vehicle", "missing_pipe"},
      {"intent=open_window|domain=vehicle|slot=", "invalid_domain_field"},
      {"domain=vehicle：extra|intent=open_window",
       "invalid_domain_field"},
      {"domain：vehicle：extra|intent=open_window",
       "invalid_domain_field"},
      {"domain=vehicle|intent=open_window：extra",
       "invalid_intent_field"},
      {"domain=vehicle|intent：open_window：extra",
       "invalid_intent_field"},
      {"domain=vehicle|intent=open_window|slots=",
       "invalid_slot_field"},
      {"domain=vehicle|intent=open_window|slot=name:window",
       "invalid_slot_pair"},
      {"domain=vehicle|intent=open_window|slot=name：window；name：roof",
       "duplicate_slot"},
      {"domain=|intent=open_window|slot=", "empty_domain"},
      {"domain=vehicle|intent=|slot=", "empty_intent"},
      {"domain=vehicle|intent=open_window|slot=name：", "empty_slot_value"},
      {"domain=vehicle|intent=open_window|slot=：window", "empty_slot_name"},
      {"domain=vehicle|intent=open_window|slot=name：window；",
       "trailing_slot_separator"},
      {"domain=vehicle|intent=open_window|slot=name：window|extra=value",
       "extra_pipe"},
      {"```domain=vehicle|intent=open_window|slot=```",
       "invalid_domain_field"},
      {"is_rejected=true|reason=unsafe|slot=", "invalid_domain_field"},
      {"domain=vehicle|intent=open|intent=close|slot=",
       "extra_pipe"}};
  for (size_t i = 0; i < sizeof(failures) / sizeof(failures[0]); ++i) {
    ScopedLogCapture capture;
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        MakeConfig(), 0, 200, MakeEnvelope(failures[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    ExpectDecodedContentFailure(result, failures[i].content);

    const std::string messages = capture.messages();
    EXPECT_NE(std::string::npos,
              messages.find("event=nlu06b_http_failure stage=content"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find("request_id=request-id-not-sent"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find("backend=openai_http reason=content_schema"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find(std::string("schema_detail=") +
                            failures[i].detail))
        << i;
    EXPECT_NE(std::string::npos, messages.find("http_status=200")) << i;
    EXPECT_NE(std::string::npos, messages.find("response_bytes=")) << i;
    EXPECT_NE(std::string::npos, messages.find("content_bytes=")) << i;
    EXPECT_EQ(std::string::npos, messages.find(failures[i].content)) << i;
    EXPECT_EQ(std::string::npos,
              messages.find("副驾驶座椅加热降到1档"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find("http://127.0.0.1:1/v1/chat/completions"))
        << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     LogsOnlySanitizedBackendIdentityOnContentSchemaFailure) {
  Json::Value config = MakeConfig();
  const std::string unsafe_endpoint =
      std::string("https://route-user:route-password@example.com:8443/v1/chat") +
      static_cast<char>(10) +
      "/completions?access_token=query-secret#private-fragment";
  const std::string unsafe_model =
      std::string("qwen3") + static_cast<char>(9) + "vehicle" +
      static_cast<char>(10) + "model-" +
      std::string(160u, static_cast<char>(120)) + "model-tail-secret";
  config["endpoint"] = unsafe_endpoint;
  config["model"] = unsafe_model;
  config["response_protocol"] = "tsv_v1";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      config, 0, 200, MakeEnvelope("vehicle"), &fake);
  ASSERT_TRUE(backend);

  ScopedLogCapture capture;
  Json::Value result;
  EXPECT_LT(backend->Process(MakeRequest(), &result), 0);
  const std::string messages = capture.messages();
  EXPECT_NE(std::string::npos,
            messages.find(
                "endpoint_url=https://example.com:8443/v1/"
                "chat_/completions"));
  EXPECT_NE(std::string::npos,
            messages.find("model=qwen3_vehicle_model-"));
  EXPECT_NE(std::string::npos,
            messages.find("response_protocol=tsv_v1"));
  EXPECT_EQ(std::string::npos, messages.find("route-user"));
  EXPECT_EQ(std::string::npos, messages.find("route-password"));
  EXPECT_EQ(std::string::npos, messages.find("access_token"));
  EXPECT_EQ(std::string::npos, messages.find("query-secret"));
  EXPECT_EQ(std::string::npos, messages.find("private-fragment"));
  EXPECT_EQ(std::string::npos, messages.find("model-tail-secret"));
  EXPECT_EQ(std::string::npos,
            messages.find(std::string("qwen3") + static_cast<char>(9) +
                          "vehicle"));
}

TEST(Nlu06BHttpBackendTest, RejectsMalformedTsvV1Content) {
  struct FailureCase {
    const char* content;
    const char* detail;
  };
  const FailureCase failures[] = {
      {"vehicle", "missing_tab"},
      {"\topen_window\t", "empty_domain"},
      {"vehicle\t\t", "empty_intent"},
      {"vehicle\topen_window\tname", "invalid_slot_pair"},
      {"vehicle\topen_window\tname=", "empty_slot_value"},
      {"vehicle\topen_window\t=value", "empty_slot_name"},
      {"vehicle\topen_window\tname=value;name=other", "duplicate_slot"},
      {"vehicle\topen_window\tname:value;name:other", "duplicate_slot"},
      {"vehicle\topen_window\tname=value;",
       "trailing_slot_separator"},
      {"vehicle\topen_window\tname:value;",
       "trailing_slot_separator"},
      {"vehicle\topen_window\tfirst=1;second:2", "invalid_slot_pair"},
      {"vehicle\topen_window\tfirst:1;second=2", "invalid_slot_pair"},
      {"vehicle\topen_window\tname=value:other", "invalid_slot_pair"},
      {"vehicle\topen_window\tname:value=other", "invalid_slot_pair"},
      {"vehicle\topen_window\tname=a=b", "invalid_slot_pair"},
      {"vehicle\topen_window\tname:a:b", "invalid_slot_pair"},
      {"vehicle\topen_window\tname==value", "invalid_slot_pair"},
      {"vehicle\topen_window\tname::value", "invalid_slot_pair"},
      {"vehicle\topen_window\tname=value\textra", "extra_tab"},
      {"vehicle\topen\nwindow", "invalid_wrapper"},
      {"vehicle\topen\rwindow", "invalid_wrapper"},
      {"```vehicle\topen_window```", "invalid_wrapper"},
      {"\"vehicle\topen_window\"", "invalid_wrapper"},
      {"vehicle\topen_window\tname" "\xEF\xBC\x9A" "value",
       "forbidden_punctuation"},
      {"vehicle\topen_window\tname=value"
       "\xEF\xBC\x9B"
       "other=second",
       "forbidden_punctuation"},
      {"vehicle\topen_window\tname=value"
       "\xEF\xBC\x9A"
       "suffix",
       "forbidden_punctuation"},
      {"vehicle\topen_window\tname=value" "\xEF\xBC\x9B",
       "forbidden_punctuation"}};
  Json::Value config = MakeConfig();
  config["response_protocol"] = "tsv_v1";
  for (size_t i = 0; i < sizeof(failures) / sizeof(failures[0]); ++i) {
    ScopedLogCapture capture;
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, 0, 200, MakeEnvelope(failures[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    ExpectDecodedContentFailure(result, failures[i].content);

    const std::string messages = capture.messages();
    EXPECT_NE(std::string::npos,
              messages.find("event=nlu06b_http_failure stage=content"))
        << i;
    EXPECT_NE(std::string::npos,
              messages.find(std::string("schema_detail=") +
                            failures[i].detail))
        << i;
    EXPECT_EQ(std::string::npos, messages.find(failures[i].content)) << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     SelectedProtocolMismatchFailsClosedWithoutFallback) {
  struct FailureCase {
    const char* protocol;
    const char* content;
    const char* detail;
  };
  const FailureCase failures[] = {
      {"pipe_v1", "vehicle\topen_window\tarea=driver", "missing_pipe"},
      {"tsv_v1", "domain=vehicle|intent=open_window|slot=",
       "missing_tab"}};
  for (size_t i = 0; i < sizeof(failures) / sizeof(failures[0]); ++i) {
    Json::Value config = MakeConfig();
    config["response_protocol"] = failures[i].protocol;
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, 0, 200, MakeEnvelope(failures[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    EXPECT_STREQ("nlu06b", backend->result_source()) << i;
    ScopedLogCapture capture;
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    ExpectDecodedContentFailure(result, failures[i].content);
    EXPECT_NE(std::string::npos,
              capture.messages().find(std::string("schema_detail=") +
                                      failures[i].detail))
        << i;
  }
}

TEST(Nlu06BHttpBackendTest, TransportEnvelopeStatusAndSizeFailuresClearResult) {
  struct FailureCase {
    int transport_code;
    long status_code;
    std::string body;
  };
  Json::Value small_config = MakeConfig();
  small_config["max_response_bytes"] = 16;
  std::vector<FailureCase> failures;
  failures.push_back(FailureCase{-1, 0, ""});
  failures.push_back(FailureCase{0, 500, MakeEnvelope("domain=d|intent=i|slot=")});
  failures.push_back(FailureCase{0, 200, "not-json"});
  failures.push_back(FailureCase{0, 200, "{}"});
  failures.push_back(
      FailureCase{0, 200, MakeEnvelope("domain=d|intent=i|slot=")});
  for (size_t i = 0; i < failures.size(); ++i) {
    FakeTransport* fake = nullptr;
    const Json::Value& config = i + 1 == failures.size() ? small_config
                                                         : MakeConfig();
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, failures[i].transport_code, failures[i].status_code,
        failures[i].body, &fake);
    ASSERT_TRUE(backend);
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    EXPECT_TRUE(result.isNull()) << i;
  }
}

TEST(Nlu06BHttpBackendTest, DiagnosticCaptureDefaultsOff) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("default_off.jsonl");
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeConfig(), 0, 200,
      MakeEnvelope("domain=vehicle|intent=open_window|slot="), &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  EXPECT_EQ(0, backend->Process(MakeRequest(), &result));
  EXPECT_NE(0, access(path.c_str(), F_OK));
}

TEST(Nlu06BHttpBackendTest, CapturesExactSuccessAndFailureJsonl) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());

  const std::string success_path = directory.NewFile("success.jsonl");
  const std::string success_content =
      "domain=vehicle|intent=open_window|slot=note：say \\\"hi\\\"\\nnow";
  FakeTransport* success_fake = nullptr;
  std::unique_ptr<Nlu06BBackend> success_backend = MakeBackend(
      MakeCaptureConfig(success_path, "capture-", 2, 4096), 0, 200,
      MakeEnvelope(success_content), &success_fake);
  ASSERT_TRUE(success_backend);
  Nlu06BRequest success_request = MakeRequest();
  success_request.request_id = "capture-success";
  Json::Value success_result;
  ASSERT_EQ(0, success_backend->Process(success_request, &success_result));
  std::vector<Json::Value> success_records = ReadCaptureRecords(success_path);
  ASSERT_EQ(1u, success_records.size());
  EXPECT_EQ("capture-success", success_records[0u]["request_id"].asString());
  EXPECT_EQ(success_request.query, success_records[0u]["query"].asString());
  EXPECT_EQ(success_content, success_records[0u]["content"].asString());
  EXPECT_EQ("success", success_records[0u]["schema_detail"].asString());
  EXPECT_EQ(success_content, success_result["nlu_result"].asString());
  EXPECT_FALSE(success_records[0u]["parsed_result"].isMember("nlu_result"));
  Json::Value business_result = success_result;
  business_result.removeMember("nlu_result");
  EXPECT_EQ(business_result, success_records[0u]["parsed_result"]);
  EXPECT_FALSE(success_records[0u]["truncated"].asBool());

  const std::string failure_path = directory.NewFile("failure.jsonl");
  const std::string failure_content = "prefix\\nwithout pipes";
  FakeTransport* failure_fake = nullptr;
  std::unique_ptr<Nlu06BBackend> failure_backend = MakeBackend(
      MakeCaptureConfig(failure_path, "capture-", 2, 4096), 0, 200,
      MakeEnvelope(failure_content), &failure_fake);
  ASSERT_TRUE(failure_backend);
  Nlu06BRequest failure_request = MakeRequest();
  failure_request.request_id = "capture-failure";
  Json::Value failure_result;
  ASSERT_LT(failure_backend->Process(failure_request, &failure_result), 0);
  std::vector<Json::Value> failure_records = ReadCaptureRecords(failure_path);
  ASSERT_EQ(1u, failure_records.size());
  EXPECT_EQ(failure_content, failure_records[0u]["content"].asString());
  EXPECT_EQ("missing_pipe", failure_records[0u]["schema_detail"].asString());
  EXPECT_TRUE(failure_records[0u]["parsed_result"].isNull());
  ExpectDecodedContentFailure(failure_result, failure_content);
}

TEST(Nlu06BHttpBackendTest, EnforcesCaptureEntryAndContentBounds) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("bounded.jsonl");
  const std::string content =
      "domain=vehicle|intent=open_window|slot=position：front";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeCaptureConfig(path, "bounded-", 1, 8), 0, 200,
      MakeEnvelope(content), &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest first = MakeRequest();
  first.request_id = "bounded-first";
  Nlu06BRequest second = MakeRequest();
  second.request_id = "bounded-second";
  Json::Value result;
  ScopedLogCapture logs;
  EXPECT_EQ(0, backend->Process(first, &result));
  EXPECT_EQ(0, backend->Process(second, &result));
  EXPECT_EQ(std::string::npos,
            logs.messages().find("nlu06b_diagnostic_capture_failure"));
  std::vector<Json::Value> records = ReadCaptureRecords(path);
  ASSERT_EQ(1u, records.size());
  EXPECT_TRUE(records[0u]["truncated"].asBool());
  EXPECT_EQ(8u, records[0u]["captured_content_bytes"].asUInt());
  EXPECT_EQ(content.size(), records[0u]["content_bytes"].asUInt());
  EXPECT_EQ(content.substr(0, 8), records[0u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, TruncatesCaptureAtUtf8Boundaries) {
  struct Utf8Case {
    const char* name;
    std::string content;
    int limit;
    std::string expected;
  };
  const Utf8Case cases[] = {
      {"three-byte-1", "车辆", 1, ""},
      {"three-byte-2", "车辆", 2, ""},
      {"three-byte-boundary", "车辆", 3, "车"},
      {"four-byte-1", "😀ok", 1, ""},
      {"four-byte-2", "😀ok", 2, ""},
      {"four-byte-3", "😀ok", 3, ""},
      {"four-byte-boundary", "😀ok", 4, "😀"}};
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    const std::string path = directory.NewFile(
        std::string("utf8-") + cases[i].name + ".jsonl");
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        MakeCaptureConfig(path, "utf8-", 1, cases[i].limit), 0, 200,
        MakeEnvelope(cases[i].content), &fake);
    ASSERT_TRUE(backend) << cases[i].name;
    Nlu06BRequest request = MakeRequest();
    request.request_id = std::string("utf8-") + cases[i].name;
    Json::Value result;
    EXPECT_LT(backend->Process(request, &result), 0) << cases[i].name;
    std::vector<Json::Value> records = ReadCaptureRecords(path);
    ASSERT_EQ(1u, records.size()) << cases[i].name;
    ASSERT_TRUE(records[0u].isObject()) << cases[i].name;
    EXPECT_EQ(cases[i].expected, records[0u]["content"].asString())
        << cases[i].name;
    EXPECT_EQ(cases[i].expected.size(),
              records[0u]["captured_content_bytes"].asUInt())
        << cases[i].name;
    EXPECT_TRUE(records[0u]["truncated"].asBool()) << cases[i].name;
  }
}

TEST(Nlu06BHttpBackendTest, WritesConcurrentCaptureRecordsWithoutInterleaving) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("concurrent.jsonl");
  const std::string content = "domain=vehicle|intent=open_window|slot=";
  std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
      MakeCaptureConfig(path, "parallel-", 8, 4096),
      std::unique_ptr<Nlu06BHttpTransport>(
          new ConstantTransport(200, MakeEnvelope(content))));
  ASSERT_TRUE(backend);
  std::vector<std::thread> threads;
  for (int i = 0; i < 8; ++i) {
    threads.push_back(std::thread([&backend, i]() {
      Nlu06BRequest request = MakeRequest();
      request.request_id = "parallel-" + std::to_string(i);
      Json::Value result;
      EXPECT_EQ(0, backend->Process(request, &result));
    }));
  }
  for (size_t i = 0; i < threads.size(); ++i) {
    threads[i].join();
  }
  std::vector<Json::Value> records = ReadCaptureRecords(path);
  ASSERT_EQ(8u, records.size());
  std::set<std::string> request_ids;
  for (size_t i = 0; i < records.size(); ++i) {
    ASSERT_TRUE(records[i].isObject());
    request_ids.insert(records[i]["request_id"].asString());
  }
  EXPECT_EQ(8u, request_ids.size());
  struct stat status;
  ASSERT_EQ(0, stat(path.c_str(), &status));
  EXPECT_EQ(0600, status.st_mode & 0777);
}

TEST(Nlu06BHttpBackendTest, DecodedDiagnosticsPreserveExactBytesAndReset) {
  struct Case {
    const char* protocol;
    std::string content;
    int code;
  };
  const Case cases[] = {
      {"pipe_v1", "  domain=vehicle | intent=open_window | slot=  \n", 0},
      {"tsv_v1", "vehicle\topen_window\tname=车窗;position=副驾", 0},
      {"tsv_v1", "vehicle\topen_window\tname：车窗；position：副驾\n", -1},
      {"tsv_v1", "vehicle\topen_window\tfirst=1;second:2", -1},
      {"pipe_v1", "", -1},
      {"pipe_v1", "未解析\t原文\n：；=|", -1}};
  EXPECT_EQ(std::string(u8"："), std::string("\xEF\xBC\x9A"));
  EXPECT_EQ(std::string(u8"；"), std::string("\xEF\xBC\x9B"));
  EXPECT_EQ(0x09, static_cast<unsigned char>('\t'));
  EXPECT_EQ(0x0a, static_cast<unsigned char>('\n'));
  for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    Json::Value config = MakeConfig();
    config["response_protocol"] = cases[i].protocol;
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
        config, 0, 200, MakeEnvelope(cases[i].content), &fake);
    ASSERT_TRUE(backend) << i;
    Json::Value result;
    ASSERT_EQ(cases[i].code, backend->Process(MakeRequest(), &result)) << i;
    ASSERT_TRUE(result["nlu_result"].isString()) << i;
    EXPECT_EQ(cases[i].content, result["nlu_result"].asString()) << i;
    const Json::Value round_trip = JsonHelper::ParseJsonFromString(
        JsonHelper::ToString(result));
    EXPECT_EQ(cases[i].content, round_trip["nlu_result"].asString()) << i;
    if (cases[i].code < 0) {
      ExpectDecodedContentFailure(result, cases[i].content);
    }
    // Reuse the same carrier and backend. Envelope failure has no decoded text.
    fake->SetResponseBody("{}");
    ASSERT_LT(backend->Process(MakeRequest(), &result), 0);
    EXPECT_TRUE(result.isNull());
    EXPECT_EQ(2, fake->post_count());
  }
}

TEST(Nlu06BHttpBackendTest, ResponseDiagnosticsDoNotUseCaptureTruncation) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string path = directory.NewFile("exact-response.jsonl");
  const std::string content = "unparseable\t" + std::string(65536u, 'x') + "\n尾";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeCaptureConfig(path, "capture-", 1, 16), 0, 200,
      MakeEnvelope(content), &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeRequest();
  request.request_id = "capture-exact-response";
  Json::Value result;
  ASSERT_LT(backend->Process(request, &result), 0);
  ExpectDecodedContentFailure(result, content);
  const std::vector<Json::Value> records = ReadCaptureRecords(path);
  ASSERT_EQ(1u, records.size());
  EXPECT_TRUE(records[0u]["truncated"].asBool());
  EXPECT_LE(records[0u]["content"].asString().size(), 16u);
  EXPECT_TRUE(records[0u]["parsed_result"].isNull());
}

TEST(Nlu06BHttpBackendTest, EnvelopeSchemaErrorsHaveNoDecodedDiagnosticText) {
  FakeTransport* fake = nullptr;
  const std::string valid = MakeEnvelope("domain=vehicle|intent=open_window|slot=");
  std::unique_ptr<Nlu06BBackend> backend = MakeBackend(
      MakeConfig(), 0, 200, valid, &fake);
  ASSERT_TRUE(backend);
  const char* invalid[] = {
      "{\"choices\":[]}",
      "{\"choices\":[{\"message\":{\"content\":null}}]}",
      "{\"choices\":[{\"message\":{\"content\":false}}]}",
      "{\"choices\":[{\"message\":{\"content\":\"one\"}},"
      "{\"message\":{\"content\":\"two\"}}]}"};
  Json::Value result;
  for (const char* body : invalid) {
    fake->SetResponseBody(valid);
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
    ASSERT_TRUE(result["nlu_result"].isString());
    fake->SetResponseBody(body);
    ASSERT_LT(backend->Process(MakeRequest(), &result), 0);
    EXPECT_TRUE(result.isNull());
  }
}

TEST(Nlu06BHttpBackendTest, InvalidConfigurationFailsBeforeTransportUse) {
  std::vector<Json::Value> invalid;
  Json::Value missing_endpoint = MakeConfig();
  missing_endpoint.removeMember("endpoint");
  invalid.push_back(missing_endpoint);
  Json::Value bad_scheme = MakeConfig();
  bad_scheme["endpoint"] = "file:///tmp/model";
  invalid.push_back(bad_scheme);
  Json::Value bad_timeout = MakeConfig();
  bad_timeout["connect_timeout_ms"] = 100;
  bad_timeout["total_timeout_ms"] = 50;
  invalid.push_back(bad_timeout);
  Json::Value bad_top_p = MakeConfig();
  bad_top_p["top_p"] = 0.0;
  invalid.push_back(bad_top_p);
  Json::Value unknown_response_protocol = MakeConfig();
  unknown_response_protocol["response_protocol"] = "future_v2";
  invalid.push_back(unknown_response_protocol);
  Json::Value non_string_response_protocol = MakeConfig();
  non_string_response_protocol["response_protocol"] = 1;
  invalid.push_back(non_string_response_protocol);
  Json::Value missing_endpoint_env = MakeConfig();
  missing_endpoint_env["endpoint"] =
      "${WTP184_NLU06B_TEST_DEFINITELY_MISSING_ENDPOINT}";
  invalid.push_back(missing_endpoint_env);
  Json::Value missing_key_env = MakeConfig();
  missing_key_env["api_key_env"] =
      "WTP184_NLU06B_TEST_DEFINITELY_MISSING_KEY";
  invalid.push_back(missing_key_env);
  Json::Value capture_missing_path = MakeConfig();
  capture_missing_path["diagnostic_capture_enabled"] = true;
  capture_missing_path["diagnostic_capture_request_id_prefix"] = "capture-";
  capture_missing_path["diagnostic_capture_max_entries"] = 1;
  capture_missing_path["diagnostic_capture_max_content_bytes"] = 16;
  invalid.push_back(capture_missing_path);
  Json::Value capture_relative_path = capture_missing_path;
  capture_relative_path["diagnostic_capture_output_path"] = "relative.jsonl";
  invalid.push_back(capture_relative_path);
  Json::Value capture_bad_prefix = capture_missing_path;
  capture_bad_prefix["diagnostic_capture_output_path"] = "/tmp/capture.jsonl";
  capture_bad_prefix["diagnostic_capture_request_id_prefix"] = "bad.prefix";
  invalid.push_back(capture_bad_prefix);
  Json::Value capture_zero_entries = capture_missing_path;
  capture_zero_entries["diagnostic_capture_output_path"] =
      "/tmp/capture-zero.jsonl";
  capture_zero_entries["diagnostic_capture_max_entries"] = 0;
  invalid.push_back(capture_zero_entries);
  for (size_t i = 0; i < invalid.size(); ++i) {
    FakeTransport* fake = nullptr;
    EXPECT_FALSE(MakeBackend(invalid[i], 0, 200, "{}", &fake)) << i;
  }
}

}  // namespace

const char kV10SystemPromptForTest[] =
    u8"你是智能座舱的语义算法专家，你接受用户的Query，进行深度分析，给出语义标签理解结果。对于符合：不完整，不通顺，无意义，结构混乱的无效句式，输出标签:unknown；多意图句式，输出标签：multi";

Json::Value MakeProfileSelector(const std::string& profile) {
  Json::Value selector(Json::objectValue);
  selector["profile"] = profile;
  selector["profile_catalog_path"] = "catalog.json";
  return selector;
}

Json::Value MakeProfileProtocol(const std::string& protocol_version,
                                const Json::Value& response_slot_assignment) {
  const bool v3 = protocol_version == "nlu_06b_v3";
  Json::Value protocol(Json::objectValue);
  protocol["version"] = protocol_version;
  protocol["request_field_prefixes"] = Json::Value(Json::arrayValue);
  if (protocol_version == "nlu_06b_v10") {
    protocol["request_field_prefixes"].append("history:");
    protocol["request_field_prefixes"].append("query: ");
  } else if (v3) {
    const char* prefixes[] = {"history:", "", "", "", "", "", ""};
    for (size_t i = 0u; i < 7u; ++i)
      protocol["request_field_prefixes"].append(prefixes[i]);
  } else {
    const char* prefixes[] = {"history_query: ", "history_domain: ",
        "history_intent: ", "history_slot: ", "history_tts: ", "query: "};
    for (size_t i = 0u; i < 6u; ++i)
      protocol["request_field_prefixes"].append(prefixes[i]);
  }
  protocol["field_delimiter"] = "\t";
  protocol["request_slot_assignment"] = v3 ? ":" : "=";
  protocol["request_slot_separator"] = v3 ? ";" : ",";
  protocol["response_slot_assignment"] = response_slot_assignment;
  protocol["response_slot_separator"] = v3 ? ";" : ",";
  if (protocol_version == "nlu_06b_v10") {
    protocol["response_frame_separator"] = ";";
    protocol["response_unknown_marker"] = "unknown";
    protocol["response_multi_marker"] = "multi:";
  } else {
    protocol["response_frame_separator"] = "|";
    protocol["response_flag_prefix"] = "flag:";
  }
  return protocol;
}

void WriteProfileProtocol(const std::string& root, const Json::Value& protocol) {
  std::ofstream output((root + "/protocol.json").c_str());
  output << JsonHelper::ToString(protocol);
}

std::unique_ptr<Nlu06BBackend> MakeProfileBackend(
    const std::string& root, const std::string& profile,
    const std::string& content, FakeTransport** fake) {
  std::unique_ptr<FakeTransport> transport(
      new FakeTransport(0, 200, MakeEnvelope(content)));
  *fake = transport.get();
  return CreateNlu06BHttpBackend(
      MakeProfileSelector(profile), root,
      std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
}

Nlu06BRequest MakeProfileHistoryRequest() {
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  Json::Value slots(Json::objectValue);
  slots["zeta"] = "last";
  slots["alpha"] = "first";
  Json::Value history = MakeProjectedHistory(
      "history query", "vehicle", "open_window", slots);
  history["v3_nlu_semantics"][0u]["tts"] = "spoken";
  request.histories.append(history);
  return request;
}

void WriteProfileFiles(const std::string& root, const std::string& profile,
                       const std::string& protocol_version,
                       bool allow_multi,
                       const Json::Value& response_slot_assignment) {
  const bool v3 = protocol_version == "nlu_06b_v3";
  Json::Value selected(Json::objectValue);
  selected["endpoint"] = "http://127.0.0.1:1/v1/chat/completions";
  const bool v10 = protocol_version == "nlu_06b_v10";
  selected["model"] = v10 ? "qwen3_nlu" : (v3 ? "v3-model" : "v4-model");
  selected["system_prompt"] = v10 ? kV10SystemPromptForTest
                                  : (v3 ? "v3 prompt" : "v4 prompt");
  selected["protocol_path"] = "protocol.json";
  selected["stream"] = false;
  selected["connect_timeout_ms"] = 1200;
  selected["total_timeout_ms"] = 3400;
  selected["temperature"] = 0.2;
  selected["top_p"] = 0.8;
  selected["top_k"] = 12;
  selected["max_tokens"] = 256;
  selected["enable_thinking"] = !v10;
  selected["allow_multi_intent_output"] = allow_multi;
  Json::Value catalog(Json::objectValue);
  catalog["profiles"][profile] = selected;
  std::ofstream catalog_file((root + "/catalog.json").c_str());
  catalog_file << JsonHelper::ToString(catalog);
  catalog_file.close();

  WriteProfileProtocol(root, MakeProfileProtocol(
      protocol_version, response_slot_assignment));
}

void WriteProfileFiles(const std::string& root, const std::string& profile,
                       const std::string& protocol_version,
                       bool allow_multi) {
  const bool v3 = protocol_version == "nlu_06b_v3";
  WriteProfileFiles(root, profile, protocol_version, allow_multi,
                    Json::Value(v3 ? ":" : "="));
}

TEST(Nlu06BHttpBackendTest, ProfileV3GoldenRequestAndSingleResponse) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", true);
  FakeTransport* fake = nullptr;
  std::unique_ptr<FakeTransport> transport(new FakeTransport(
      0, 200, MakeEnvelope("vehicle\topen_window\tarea:driver;name:window")));
  fake = transport.get();
  std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
      MakeProfileSelector("nlu_06b_v3"), root,
      std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
  ASSERT_TRUE(backend);
  Json::Value slots(Json::objectValue);
  slots["zeta"] = "last";
  slots["alpha"] = "first";
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  Json::Value history = MakeProjectedHistory(
      "history query", "vehicle", "open_window", slots);
  history["v3_nlu_semantics"][0u]["tts"] = "spoken";
  request.histories.append(history);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));
  const Json::Value payload = ReadPayload(fake);
  EXPECT_EQ("history:\thistory query\tvehicle\topen_window\t"
            "alpha:first;zeta:last\tspoken\tcurrent query",
            payload["messages"][1u]["content"].asString());
  const std::string user_content =
      payload["messages"][1u]["content"].asString();
  EXPECT_EQ(6u, static_cast<size_t>(std::count(
      user_content.begin(), user_content.end(), '	')));
  EXPECT_FALSE(payload.isMember("chat_template_kwargs"));
  EXPECT_FALSE(payload["stream"].asBool());
  EXPECT_EQ("driver", result["frames"][0u]["slots"]["area"].asString());
}

TEST(Nlu06BHttpBackendTest,
     ProfileV3AcceptsConfiguredResponseAssignments) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  struct ResponseCase {
    const char* configured_assignment;
    const char* content;
  };
  const ResponseCase cases[] = {
      {"=", "vehicle\topen_window\tarea=driver;name=window"},
      {":=", "vehicle\topen_window\tarea:driver;name:window"},
      {":=", "vehicle\topen_window\tarea=driver;name=window"},
  };
  for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", true,
                      Json::Value(cases[i].configured_assignment));
    std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
        MakeProfileSelector("nlu_06b_v3"), root,
        std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
            200, MakeEnvelope(cases[i].content))));
    ASSERT_TRUE(backend) << i;
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result)) << i;
    ASSERT_EQ(1u, result["frames"].size()) << i;
    EXPECT_EQ("driver", result["frames"][0u]["slots"]["area"].asString())
        << i;
    EXPECT_EQ("window", result["frames"][0u]["slots"]["name"].asString())
        << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     ProfileV3CanonicalAssignmentRejectsMixedBothAndRepeatedBytes) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", true,
                    Json::Value(":="));
  const char* invalid_content[] = {
      "vehicle\topen_window\tfirst:1;second=2",
      "vehicle\topen_window\tfirst=1;second:2",
      "vehicle\topen_window\tname:value=other",
      "vehicle\topen_window\tname=value:other",
      "vehicle\topen_window\tname::value",
      "vehicle\topen_window\tname==value",
  };
  for (size_t i = 0u;
       i < sizeof(invalid_content) / sizeof(invalid_content[0]); ++i) {
    ScopedLogCapture capture;
    std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
        MakeProfileSelector("nlu_06b_v3"), root,
        std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
            200, MakeEnvelope(invalid_content[i]))));
    ASSERT_TRUE(backend) << i;
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    ExpectDecodedContentFailure(result, invalid_content[i]);
    EXPECT_NE(std::string::npos,
              capture.messages().find("schema_detail=invalid_slot_pair"))
        << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     ProfileV3CanonicalAssignmentIsUniformAcrossAllFrames) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", true,
                    Json::Value(":="));
  struct SuccessCase {
    const char* content;
    Json::ArrayIndex frame_count;
    int empty_frame;
  };
  const SuccessCase cases[] = {
      {"flag:multi|vehicle\topen_window\tarea:driver;name:window|"
       "media\tplay_music\tartist:guest;song:title", 2u, -1},
      {"flag:multi|vehicle\topen_window\tarea=driver;name=window|"
       "media\tplay_music\tartist=guest;song=title", 2u, -1},
      {"flag:multi|vehicle\topen_window\t|"
       "media\tplay_music\tartist=guest", 2u, 0},
      {"flag:multi|vehicle\topen_window\tarea:driver|"
       "media\tplay_music\t|navigation\tgo_home\tdestination:home",
       3u, 1},
  };
  for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
        MakeProfileSelector("nlu_06b_v3"), root,
        std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
            200, MakeEnvelope(cases[i].content))));
    ASSERT_TRUE(backend) << i;
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result)) << i;
    EXPECT_FALSE(result["is_rejected"].asBool()) << i;
    EXPECT_TRUE(result["is_multi_intent"].asBool()) << i;
    ASSERT_EQ(cases[i].frame_count, result["frames"].size()) << i;
    if (cases[i].empty_frame >= 0) {
      EXPECT_TRUE(result["frames"][static_cast<Json::ArrayIndex>(
          cases[i].empty_frame)]["slots"].empty()) << i;
    }
  }
}

TEST(Nlu06BHttpBackendTest,
     ProfileV3CanonicalAssignmentRejectsCrossFrameStyleChanges) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", true,
                    Json::Value(":="));
  const char* invalid_content[] = {
      "flag:multi|vehicle\topen_window\tarea:driver|"
      "media\tplay_music\tartist=guest",
      "flag:multi|vehicle\topen_window\tarea:driver|"
      "media\tplay_music\t|navigation\tgo_home\tdestination=home",
  };
  for (size_t i = 0u;
       i < sizeof(invalid_content) / sizeof(invalid_content[0]); ++i) {
    ScopedLogCapture capture;
    std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
        MakeProfileSelector("nlu_06b_v3"), root,
        std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
            200, MakeEnvelope(invalid_content[i]))));
    ASSERT_TRUE(backend) << i;
    Json::Value result;
    EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i;
    ExpectDecodedContentFailure(result, invalid_content[i]);
    EXPECT_NE(std::string::npos,
              capture.messages().find("schema_detail=invalid_slot_pair"))
        << i;
  }
}

TEST(Nlu06BHttpBackendTest,
     ProfileParsesMalformedFrameBeforeMultiDisabledPolicy) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", false,
                    Json::Value(":="));
  ScopedLogCapture capture;
  std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
      MakeProfileSelector("nlu_06b_v3"), root,
      std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
          200, MakeEnvelope("flag:multi|vehicle\topen_window\t|"
                            "media\tplay_music\tmalformed"))));
  ASSERT_TRUE(backend);
  Json::Value result;
  EXPECT_LT(backend->Process(MakeRequest(), &result), 0);
  ExpectDecodedContentFailure(result, "flag:multi|vehicle	open_window	|"
                              "media	play_music	malformed");
  EXPECT_NE(std::string::npos,
            capture.messages().find("schema_detail=invalid_slot_pair"));
}

TEST(Nlu06BHttpBackendTest,
     ProfilesRejectInvalidResponseAssignmentConfiguration) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  std::vector<Json::Value> invalid;
  const std::string invalid_strings[] = {
      "", "::", "==", ":=:", "@@", " ", "\t", "\r", "\n",
      std::string(1u, '\0'), std::string(1u, '\x1f'),
      std::string(1u, '\x7f'), "\xC2\xA2", "\xEF\xBC\x9A",
      "\xEF\xBC\x9B", "\xEF\xBC\x9D", ";", ",", "|"};
  for (size_t i = 0u; i < sizeof(invalid_strings) / sizeof(invalid_strings[0]);
       ++i) invalid.push_back(Json::Value(invalid_strings[i]));
  invalid.push_back(Json::Value());
  invalid.push_back(Json::Value(1));
  invalid.push_back(Json::Value(true));
  invalid.push_back(Json::Value(Json::objectValue));
  invalid.push_back(Json::Value(Json::arrayValue));
  const Json::Value invalid_entries[] = {
      Json::Value(""), Json::Value(":="), Json::Value(1), Json::Value(),
      Json::Value("\t"), Json::Value(std::string(1u, '\0')),
      Json::Value("\xEF\xBC\x9A")};
  for (size_t i = 0u; i < sizeof(invalid_entries) / sizeof(invalid_entries[0]);
       ++i) {
    Json::Value candidates(Json::arrayValue);
    candidates.append("@");
    candidates.append(invalid_entries[i]);
    invalid.push_back(candidates);
  }
  Json::Value duplicate(Json::arrayValue);
  duplicate.append("@");
  duplicate.append("@");
  invalid.push_back(duplicate);
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    for (size_t i = 0u; i < invalid.size(); ++i) {
      // Semicolon/comma collide only in their respective canonical layouts.
      if ((p == 0u && invalid[i] == Json::Value(",")) ||
          (p == 1u && invalid[i] == Json::Value(";"))) continue;
      WriteProfileFiles(root, profiles[p], profiles[p], true, invalid[i]);
      FakeTransport* fake = nullptr;
      EXPECT_FALSE(MakeProfileBackend(root, profiles[p], "vehicle\topen\t",
                                     &fake)) << p << ":" << i;
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV4CanonicalAssignmentRejectsUnconfiguredColon) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_06b_v4", "nlu_06b_v4", true,
                    Json::Value("="));
  std::unique_ptr<Nlu06BBackend> valid = CreateNlu06BHttpBackend(
      MakeProfileSelector("nlu_06b_v4"), root,
      std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
          200, MakeEnvelope("vehicle\topen_window\tarea=driver,name=window"))));
  ASSERT_TRUE(valid);
  Json::Value result;
  EXPECT_EQ(0, valid->Process(MakeRequest(), &result));

  ScopedLogCapture capture;
  std::unique_ptr<Nlu06BBackend> colon_response = CreateNlu06BHttpBackend(
      MakeProfileSelector("nlu_06b_v4"), root,
      std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
          200, MakeEnvelope("vehicle\topen_window\tarea:driver"))));
  ASSERT_TRUE(colon_response);
  EXPECT_LT(colon_response->Process(MakeRequest(), &result), 0);
  EXPECT_NE(std::string::npos,
            capture.messages().find("schema_detail=invalid_slot_pair"));

}

TEST(Nlu06BHttpBackendTest, ProfileV4GoldenRequestAndMultiPolicy) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  Json::Value slots(Json::objectValue);
  slots["zeta"] = "last";
  slots["alpha"] = "first";
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  request.histories.append(MakeProjectedHistory(
      "history query", "vehicle", "open_window", slots));
  const std::string response =
      "flag:multi|vehicle\topen_window\tarea=driver,name=window|"
      "media\tplay_music\t";
  for (int enabled = 0; enabled < 2; ++enabled) {
    WriteProfileFiles(root, "nlu_06b_v4", "nlu_06b_v4", enabled != 0);
    FakeTransport* fake = nullptr;
    std::unique_ptr<FakeTransport> transport(
        new FakeTransport(0, 200, MakeEnvelope(response)));
    fake = transport.get();
    std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
        MakeProfileSelector("nlu_06b_v4"), root,
        std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
    ASSERT_TRUE(backend);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result));
    const std::string expected =
        "history_query: history query\thistory_domain: vehicle\t"
        "history_intent: open_window\thistory_slot: alpha=first,zeta=last\t"
        "history_tts: \tquery: current query";
    const std::string user_content =
        ReadPayload(fake)["messages"][1u]["content"].asString();
    EXPECT_EQ(expected, user_content);
    EXPECT_EQ(5u, static_cast<size_t>(std::count(
        user_content.begin(), user_content.end(), '	')));
    if (enabled == 0) {
      EXPECT_TRUE(result["is_rejected"].asBool());
      EXPECT_EQ("multi_intent_disabled", result["reject_reason"].asString());
      EXPECT_FALSE(result["is_multi_intent"].asBool());
      EXPECT_TRUE(result["frames"].empty());
    } else {
      EXPECT_FALSE(result["is_rejected"].asBool());
      EXPECT_TRUE(result["is_multi_intent"].asBool());
      ASSERT_EQ(2u, result["frames"].size());
    }
  }
}

TEST(Nlu06BHttpBackendTest,
     ProfileV3AndV4OmitHistoryWithUnrepresentableSlots) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));

  Json::Value slots(Json::objectValue);
  slots["slot"] = "safe value";
  const Json::Value valid = MakeProjectedHistory(
      "history leak marker", "vehicle", "open_window", slots);
  std::vector<Json::Value> invalid;
  Json::Value empty_name = valid;
  empty_name["v3_nlu_semantics"][0u]["slots"].removeMember("slot");
  empty_name["v3_nlu_semantics"][0u]["slots"][""] = "value";
  invalid.push_back(empty_name);
  Json::Value non_string_value = valid;
  non_string_value["v3_nlu_semantics"][0u]["slots"]["slot"] = 1;
  invalid.push_back(non_string_value);
  const char* record_delimiters[] = {"bad\tpart", "bad\rpart",
                                     "bad\npart"};
  for (size_t i = 0u;
       i < sizeof(record_delimiters) / sizeof(record_delimiters[0]); ++i) {
    Json::Value bad_name = valid;
    bad_name["v3_nlu_semantics"][0u]["slots"].removeMember("slot");
    bad_name["v3_nlu_semantics"][0u]["slots"][record_delimiters[i]] =
        "value";
    invalid.push_back(bad_name);
    Json::Value bad_value = valid;
    bad_value["v3_nlu_semantics"][0u]["slots"]["slot"] =
        record_delimiters[i];
    invalid.push_back(bad_value);
  }

  struct ProfileCase {
    const char* profile;
    const char* expected_content;
    size_t tab_count;
  };
  const ProfileCase profiles[] = {
      {"nlu_06b_v3", "history:\t\t\t\t\t\tcurrent query", 6u},
      {"nlu_06b_v4",
       "history_query: \thistory_domain: \thistory_intent: \t"
       "history_slot: \thistory_tts: \tquery: current query",
       5u},
  };
  for (size_t i = 0u; i < sizeof(profiles) / sizeof(profiles[0]); ++i) {
    WriteProfileFiles(root, profiles[i].profile, profiles[i].profile, false);
    FakeTransport* fake = nullptr;
    std::unique_ptr<FakeTransport> transport(new FakeTransport(
        0, 200, MakeEnvelope("vehicle\topen_window\t")));
    fake = transport.get();
    std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
        MakeProfileSelector(profiles[i].profile), root,
        std::unique_ptr<Nlu06BHttpTransport>(transport.release()));
    ASSERT_TRUE(backend) << i;
    for (size_t j = 0u; j < invalid.size(); ++j) {
      Nlu06BRequest request = MakeRequest();
      request.query = "current query";
      request.histories = Json::Value(Json::arrayValue);
      request.histories.append(invalid[j]);
      Json::Value result;
      ASSERT_EQ(0, backend->Process(request, &result)) << i << ":" << j;
      const std::string user_content =
          ReadPayload(fake)["messages"][1u]["content"].asString();
      EXPECT_EQ(profiles[i].expected_content, user_content) << i << ":" << j;
      EXPECT_EQ(profiles[i].tab_count, static_cast<size_t>(std::count(
          user_content.begin(), user_content.end(), '\t'))) << i << ":" << j;
      EXPECT_EQ(std::string::npos, user_content.find("history leak marker"))
          << i << ":" << j;
      EXPECT_EQ(static_cast<int>(j + 1u), fake->post_count())
          << i << ":" << j;
    }
  }
}

TEST(Nlu06BHttpBackendTest, Profile4BV4UsesSharedV4Protocol) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_4b_v4", "nlu_06b_v4", false);
  std::unique_ptr<Nlu06BBackend> backend = CreateNlu06BHttpBackend(
      MakeProfileSelector("nlu_4b_v4"), root,
      std::unique_ptr<Nlu06BHttpTransport>(
          new ConstantTransport(200, MakeEnvelope("vehicle	open	"))));
  EXPECT_TRUE(backend);
}

TEST(Nlu06BHttpBackendTest, ProfileRejectsUnknownAndEscapingConfiguration) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", true);
  Json::Value unknown = MakeProfileSelector("unknown");
  EXPECT_FALSE(CreateNlu06BHttpBackend(
      unknown, root, std::unique_ptr<Nlu06BHttpTransport>(
          new ConstantTransport(200, MakeEnvelope("vehicle\topen\t")))));
  std::vector<Json::Value> invalid_selectors;
  Json::Value missing_catalog = MakeProfileSelector("nlu_06b_v3");
  missing_catalog.removeMember("profile_catalog_path");
  invalid_selectors.push_back(missing_catalog);
  Json::Value missing_profile = MakeProfileSelector("nlu_06b_v3");
  missing_profile.removeMember("profile");
  invalid_selectors.push_back(missing_profile);
  Json::Value bad_profile = MakeProfileSelector("nlu_06b_v3");
  bad_profile["profile"] = 1;
  invalid_selectors.push_back(bad_profile);
  bad_profile["profile"] = "";
  invalid_selectors.push_back(bad_profile);
  for (size_t i = 0u; i < invalid_selectors.size(); ++i) {
    EXPECT_FALSE(CreateNlu06BHttpBackend(invalid_selectors[i], root,
        std::unique_ptr<Nlu06BHttpTransport>(new ConstantTransport(
            200, MakeEnvelope("vehicle	open	")))));
  }
  Json::Value escaping = MakeProfileSelector("nlu_06b_v3");
  escaping["profile_catalog_path"] = "../catalog.json";
  EXPECT_FALSE(CreateNlu06BHttpBackend(
      escaping, root, std::unique_ptr<Nlu06BHttpTransport>(
          new ConstantTransport(200, MakeEnvelope("vehicle\topen\t")))));
}


TEST(Nlu06BHttpBackendTest, ProfilesConsumeEachChangedNotationRole) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  struct RoleCase {
    const char* role;
    const char* value;
    const char* request_v3;
    const char* request_v4;
    const char* response_v3;
    const char* response_v4;
  };
  const RoleCase cases[] = {
      {"request_field_prefixes", "",
       "头：\t问：history query\t域：vehicle\t意：open_window\t"
       "槽：alpha:first;zeta:last\t说：spoken\t现：current query",
       "问：history query\t域：vehicle\t意：open_window\t"
       "槽：alpha=first,zeta=last\t说：spoken\t现：current query",
       "flag:multi|vehicle\topen_window\tarea:driver;name:window|media\tplay\t",
       "flag:multi|vehicle\topen_window\tarea=driver,name=window|media\tplay\t"},
      {"field_delimiter", "#",
       "history:#history query#vehicle#open_window#alpha:first;zeta:last#"
       "spoken#current query",
       "history_query: history query#history_domain: vehicle#"
       "history_intent: open_window#history_slot: alpha=first,zeta=last#"
       "history_tts: spoken#query: current query",
       "flag:multi|vehicle#open_window#area:driver;name:window|media#play#",
       "flag:multi|vehicle#open_window#area=driver,name=window|media#play#"},
      {"request_slot_assignment", "@",
       "history:\thistory query\tvehicle\topen_window\talpha@first;zeta@last\t"
       "spoken\tcurrent query",
       "history_query: history query\thistory_domain: vehicle\t"
       "history_intent: open_window\thistory_slot: alpha@first,zeta@last\t"
       "history_tts: spoken\tquery: current query",
       "flag:multi|vehicle\topen_window\tarea:driver;name:window|media\tplay\t",
       "flag:multi|vehicle\topen_window\tarea=driver,name=window|media\tplay\t"},
      {"request_slot_separator", "^",
       "history:\thistory query\tvehicle\topen_window\talpha:first^zeta:last\t"
       "spoken\tcurrent query",
       "history_query: history query\thistory_domain: vehicle\t"
       "history_intent: open_window\thistory_slot: alpha=first^zeta=last\t"
       "history_tts: spoken\tquery: current query",
       "flag:multi|vehicle\topen_window\tarea:driver;name:window|media\tplay\t",
       "flag:multi|vehicle\topen_window\tarea=driver,name=window|media\tplay\t"},
      {"response_slot_separator", "^",
       "history:\thistory query\tvehicle\topen_window\talpha:first;zeta:last\t"
       "spoken\tcurrent query",
       "history_query: history query\thistory_domain: vehicle\t"
       "history_intent: open_window\thistory_slot: alpha=first,zeta=last\t"
       "history_tts: spoken\tquery: current query",
       "flag:multi|vehicle\topen_window\tarea:driver^name:window|media\tplay\t",
       "flag:multi|vehicle\topen_window\tarea=driver^name=window|media\tplay\t"},
      {"response_frame_separator", "~",
       "history:\thistory query\tvehicle\topen_window\talpha:first;zeta:last\t"
       "spoken\tcurrent query",
       "history_query: history query\thistory_domain: vehicle\t"
       "history_intent: open_window\thistory_slot: alpha=first,zeta=last\t"
       "history_tts: spoken\tquery: current query",
       "flag:multi~vehicle\topen_window\tarea:driver;name:window~media\tplay\t",
       "flag:multi~vehicle\topen_window\tarea=driver,name=window~media\tplay\t"},
  };
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    WriteProfileFiles(root, profiles[p], profiles[p], true);
    for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0]); ++i) {
      SCOPED_TRACE(std::string(profiles[p]) + ":" + cases[i].role);
      Json::Value protocol = MakeProfileProtocol(
          profiles[p], Json::Value(p == 0u ? ":" : "="));
      if (i == 0u) {
        protocol["request_field_prefixes"] = Json::Value(Json::arrayValue);
        if (p == 0u) protocol["request_field_prefixes"].append("头：");
        const char* prefixes[] = {"问：", "域：", "意：", "槽：", "说：", "现："};
        for (size_t j = 0u; j < 6u; ++j)
          protocol["request_field_prefixes"].append(prefixes[j]);
      } else {
        protocol[cases[i].role] = cases[i].value;
      }
      WriteProfileProtocol(root, protocol);
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
          root, profiles[p], p == 0u ? cases[i].response_v3 : cases[i].response_v4,
          &fake);
      ASSERT_TRUE(backend);
      Json::Value result;
      ASSERT_EQ(0, backend->Process(MakeProfileHistoryRequest(), &result));
      const std::string request = ReadPayload(fake)["messages"][1u]["content"].asString();
      EXPECT_EQ(p == 0u ? cases[i].request_v3 : cases[i].request_v4, request);
      const char delimiter = protocol["field_delimiter"].asString()[0];
      EXPECT_EQ(p == 0u ? 6u : 5u, static_cast<size_t>(
          std::count(request.begin(), request.end(), delimiter)));
      ASSERT_EQ(2u, result["frames"].size());
      EXPECT_TRUE(result["is_multi_intent"].asBool());
      EXPECT_EQ("driver", result["frames"][0u]["slots"]["area"].asString());
      EXPECT_EQ("window", result["frames"][0u]["slots"]["name"].asString());
      EXPECT_TRUE(result["frames"][1u]["slots"].empty());
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesConsumeCoherentCombinedNotation) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    WriteProfileFiles(root, profiles[p], profiles[p], true);
    Json::Value protocol = MakeProfileProtocol(profiles[p], Json::Value("@^"));
    protocol["field_delimiter"] = "?";
    protocol["request_slot_assignment"] = "@";  // Cross-direction reuse is valid.
    protocol["request_slot_separator"] = "%";
    protocol["response_slot_separator"] = "/";
    protocol["response_frame_separator"] = "~";
    protocol.removeMember("response_flag_prefix");
    protocol["response_unknown_marker"] = "不支持";
    protocol["response_multi_marker"] = "M";
    protocol["request_field_prefixes"] = Json::Value(Json::arrayValue);
    if (p == 0u) protocol["request_field_prefixes"].append("头：");
    const char* prefixes[] = {"问：", "域：", "意：", "槽：", "说：", "现："};
    for (size_t i = 0u; i < 6u; ++i)
      protocol["request_field_prefixes"].append(prefixes[i]);
    WriteProfileProtocol(root, protocol);
    Nlu06BRequest request = MakeProfileHistoryRequest();
    request.query = "current: =,;|text";
    Json::Value& semantic = request.histories[0u]["v3_nlu_semantics"][0u];
    semantic["slots"]["alpha"] = "first: =,;|text";
    semantic["tts"] = "spoken: =,;|text";
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, profiles[p], "M~vehicle?open_window?area@driver/name@window~media?play?",
        &fake);
    ASSERT_TRUE(backend) << p;
    // The initialized backend owns one immutable snapshot, not a runtime file read.
    Json::Value changed = protocol;
    changed["field_delimiter"] = "#";
    WriteProfileProtocol(root, changed);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result)) << p;
    const std::string expected = p == 0u
        ? "头：?问：history query?域：vehicle?意：open_window?"
          "槽：alpha@first: =,;|text%zeta@last?说：spoken: =,;|text?现：current: =,;|text"
        : "问：history query?域：vehicle?意：open_window?"
          "槽：alpha@first: =,;|text%zeta@last?说：spoken: =,;|text?现：current: =,;|text";
    EXPECT_EQ(expected, ReadPayload(fake)["messages"][1u]["content"].asString());
    ASSERT_EQ(2u, result["frames"].size());
    EXPECT_EQ("driver", result["frames"][0u]["slots"]["area"].asString());
    EXPECT_EQ("window", result["frames"][0u]["slots"]["name"].asString());
    EXPECT_FALSE(ReadPayload(fake).isMember("chat_template_kwargs"));
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesAcceptGenericAssignmentScalarsAndArrays) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  std::vector<Json::Value> configurations;
  configurations.push_back(Json::Value(":"));
  configurations.push_back(Json::Value("="));
  configurations.push_back(Json::Value(":="));
  configurations.push_back(Json::Value("=:"));
  configurations.push_back(Json::Value("@"));
  configurations.push_back(Json::Value("@^"));
  configurations.push_back(Json::Value("^@"));
  const char* arrays[] = {":=", "=:", "@^", "^@", "@"};
  for (size_t i = 0u; i < sizeof(arrays) / sizeof(arrays[0]); ++i) {
    Json::Value configured(Json::arrayValue);
    const std::string candidates(arrays[i]);
    for (size_t j = 0u; j < candidates.size(); ++j)
      configured.append(std::string(1u, candidates[j]));
    configurations.push_back(configured);
  }
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    for (size_t i = 0u; i < configurations.size(); ++i) {
      WriteProfileFiles(root, profiles[p], profiles[p], true, configurations[i]);
      const Json::Value& configured = configurations[i];
      const size_t count = configured.isArray() ? configured.size()
                                                : configured.asString().size();
      for (size_t j = 0u; j < count; ++j) {
        const char assignment = configured.isArray()
            ? configured[static_cast<Json::ArrayIndex>(j)].asString()[0]
            : configured.asString()[j];
        const char pair = p == 0u ? ';' : ',';
        const std::string content = std::string("vehicle\topen\tarea") +
            assignment + "driver" + pair + "name" + assignment + "window";
        FakeTransport* fake = nullptr;
        std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
            root, profiles[p], content, &fake);
        ASSERT_TRUE(backend) << p << ":" << i << ":" << j;
        Json::Value result;
        ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
        EXPECT_EQ("driver", result["frames"][0u]["slots"]["area"].asString());
        EXPECT_EQ("window", result["frames"][0u]["slots"]["name"].asString());
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesKeepGenericAssignmentStyleResponseWide) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    for (int enabled = 0; enabled < 2; ++enabled) {
      WriteProfileFiles(root, profiles[p], profiles[p], enabled != 0,
                        Json::Value("@^"));
      const char pair = p == 0u ? ';' : ',';
      const std::string valid[] = {
          "vehicle\topen\t", "vehicle\topen\ta@1", "vehicle\topen\ta^1",
          "flag:multi|vehicle\topen\t|media\tplay\ta@1",
          "flag:multi|vehicle\topen\ta^1|media\tplay\t|nav\tgo\tb^2"};
      for (size_t i = 0u; i < sizeof(valid) / sizeof(valid[0]); ++i) {
        FakeTransport* fake = nullptr;
        std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
            root, profiles[p], valid[i], &fake);
        ASSERT_TRUE(backend);
        Json::Value result;
        ASSERT_EQ(0, backend->Process(MakeRequest(), &result)) << p << ":" << i;
        if (enabled == 0 && i >= 3u) {
          EXPECT_TRUE(result["is_rejected"].asBool());
          EXPECT_EQ("multi_intent_disabled", result["reject_reason"].asString());
          EXPECT_TRUE(result["frames"].empty());
        } else {
          EXPECT_FALSE(result["is_rejected"].asBool());
          if (i == 3u) EXPECT_TRUE(result["frames"][0u]["slots"].empty());
          if (i == 4u) EXPECT_TRUE(result["frames"][1u]["slots"].empty());
        }
        // A different style on a second response proves call-local state.
        fake->SetResponseBody(MakeEnvelope(
            valid[i].find('@') != std::string::npos
                ? "vehicle	open	a^1" : "vehicle	open	a@1"));
        ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
        ASSERT_EQ(1u, result["frames"].size());
        EXPECT_FALSE(result["is_rejected"].asBool());
      }
      const std::string invalid[] = {
          "vehicle\topen\ta", "vehicle\topen\ta@@1", "vehicle\topen\ta^^1",
          "vehicle\topen\ta@1^2", "vehicle\topen\tna^me@1",
          std::string("vehicle\topen\ta@1") + pair + "b^2",
          std::string("vehicle\topen\ta^1") + pair + "b@2",
          "flag:multi|vehicle\topen\ta@1|media\tplay\tb^2",
          "flag:multi|vehicle\topen\ta^1|media\tplay\t|nav\tgo\tb@2",
          "flag:multi|vehicle\topen\t|media\tplay\tmalformed"};
      for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
        ScopedLogCapture capture;
        FakeTransport* fake = nullptr;
        std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
            root, profiles[p], invalid[i], &fake);
        ASSERT_TRUE(backend);
        Json::Value result(Json::objectValue);
        result["stale"] = true;
        EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << p << ":" << i;
        ExpectDecodedContentFailure(result, invalid[i]);
        EXPECT_NE(std::string::npos,
                  capture.messages().find("schema_detail=invalid_slot_pair"));
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesUseExactCompleteAndLegacyDerivedMarkers) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  struct MarkerCase {
    std::string unknown;
    std::string multi;
    std::string legacy_prefix;
  };
  const MarkerCase cases[] = {
      {"flag:unknown", "flag:multi", ""},
      {"flag:unknown", "flag:multi", "flag:"},
      {"U", "a.long.complete.multiple.marker", ""},
      {"未知：未识别", "多路回应：确认", ""},
      {std::string(128u, 'u'), std::string(128u, 'm'), ""},
      {"status/unknown", "status/multi", "status/"},
      {std::string(121u, 'p') + "unknown", std::string(121u, 'p') + "multi",
       std::string(121u, 'p')},
  };
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    WriteProfileFiles(root, profiles[p], profiles[p], true);
    for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0]); ++i) {
      Json::Value protocol = MakeProfileProtocol(profiles[p], Json::Value("@^"));
      protocol["response_frame_separator"] = "~";
      if (cases[i].legacy_prefix.empty()) {
        protocol.removeMember("response_flag_prefix");
        protocol["response_unknown_marker"] = cases[i].unknown;
        protocol["response_multi_marker"] = cases[i].multi;
      } else {
        protocol["response_flag_prefix"] = cases[i].legacy_prefix;
      }
      WriteProfileProtocol(root, protocol);
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> unknown = MakeProfileBackend(
          root, profiles[p], cases[i].unknown, &fake);
      ASSERT_TRUE(unknown) << p << ":" << i;
      Json::Value result;
      ASSERT_EQ(0, unknown->Process(MakeRequest(), &result));
      EXPECT_TRUE(result["is_rejected"].asBool());
      EXPECT_EQ("unknown", result["reject_reason"].asString());
      EXPECT_EQ(cases[i].unknown, result["nlu_result"].asString());
      EXPECT_FALSE(result["is_multi_intent"].asBool());
      EXPECT_TRUE(result["frames"].empty());
      std::unique_ptr<Nlu06BBackend> multi = MakeProfileBackend(
          root, profiles[p], cases[i].multi + "~vehicle\topen\ta@1~media\tplay\t",
          &fake);
      ASSERT_TRUE(multi);
      ASSERT_EQ(0, multi->Process(MakeRequest(), &result));
      ASSERT_EQ(2u, result["frames"].size());
      EXPECT_TRUE(result["is_multi_intent"].asBool());
      EXPECT_EQ("1", result["frames"][0u]["slots"]["a"].asString());
      EXPECT_EQ(cases[i].multi + "~vehicle	open	a@1~media	play	",
                result["nlu_result"].asString());
      const std::string invalid[] = {
          cases[i].unknown + "x", cases[i].multi,
          cases[i].multi + "~vehicle\topen\t",
          cases[i].multi + "~vehicle\topen\t~",
          cases[i].multi + "|vehicle\topen\t|media\tplay\t"};
      for (size_t j = 0u; j < sizeof(invalid) / sizeof(invalid[0]); ++j) {
        std::unique_ptr<Nlu06BBackend> bad = MakeProfileBackend(
            root, profiles[p], invalid[j], &fake);
        ASSERT_TRUE(bad);
        result["stale"] = true;
        EXPECT_LT(bad->Process(MakeRequest(), &result), 0) << p << ":" << i << ":" << j;
        ExpectDecodedContentFailure(result, invalid[j]);
      }
      if (cases[i].unknown != "flag:unknown") {
        const char* old[] = {"flag:unknown",
            "flag:multi~vehicle\topen\t~media\tplay\t",
            "flag:multi|vehicle\topen\t|media\tplay\t"};
        for (size_t j = 0u; j < sizeof(old) / sizeof(old[0]); ++j) {
          std::unique_ptr<Nlu06BBackend> bad = MakeProfileBackend(
              root, profiles[p], old[j], &fake);
          ASSERT_TRUE(bad);
          EXPECT_LT(bad->Process(MakeRequest(), &result), 0);
          ExpectDecodedContentFailure(result, old[j]);
        }
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesRejectInvalidAndConflictingMarkerForms) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    WriteProfileFiles(root, profiles[p], profiles[p], true);
    Json::Value canonical = MakeProfileProtocol(profiles[p], Json::Value("@^"));
    canonical["field_delimiter"] = "#";
    canonical["response_frame_separator"] = "~";
    Json::Value explicit_markers = canonical;
    explicit_markers.removeMember("response_flag_prefix");
    explicit_markers["response_unknown_marker"] = "U";
    explicit_markers["response_multi_marker"] = "MULTIPLE";
    std::vector<Json::Value> invalid;
    Json::Value missing = explicit_markers;
    missing.removeMember("response_unknown_marker");
    invalid.push_back(missing);
    missing = explicit_markers;
    missing.removeMember("response_multi_marker");
    invalid.push_back(missing);
    missing.removeMember("response_unknown_marker");
    invalid.push_back(missing);
    Json::Value equal = explicit_markers;
    equal["response_multi_marker"] = "U";
    invalid.push_back(equal);
    const char* new_fields[] = {"response_unknown_marker", "response_multi_marker"};
    for (size_t i = 0u; i < 2u; ++i) {
      Json::Value coexist = canonical;
      coexist[new_fields[i]] = "new";
      invalid.push_back(coexist);
    }
    Json::Value coexist = explicit_markers;
    coexist["response_flag_prefix"] = "flag:";
    invalid.push_back(coexist);
    const Json::Value bad_values[] = {
        Json::Value(""), Json::Value(std::string(129u, 'x')),
        Json::Value(std::string("bad\0tail", 8u)), Json::Value("bad\ttail"),
        Json::Value("bad\rtail"), Json::Value("bad\ntail"),
        Json::Value("bad#tail"), Json::Value("bad~tail"), Json::Value(),
        Json::Value(1), Json::Value(true), Json::Value(Json::arrayValue),
        Json::Value(Json::objectValue)};
    for (size_t f = 0u; f < 2u; ++f) {
      for (size_t i = 0u; i < sizeof(bad_values) / sizeof(bad_values[0]); ++i) {
        Json::Value bad = explicit_markers;
        bad[new_fields[f]] = bad_values[i];
        invalid.push_back(bad);
      }
    }
    for (size_t i = 0u; i < sizeof(bad_values) / sizeof(bad_values[0]); ++i) {
      Json::Value bad = canonical;
      bad["response_flag_prefix"] = bad_values[i];
      invalid.push_back(bad);
    }
    Json::Value overlong_derived = canonical;
    overlong_derived["response_flag_prefix"] = std::string(122u, 'p');
    invalid.push_back(overlong_derived);
    for (size_t i = 0u; i < invalid.size(); ++i) {
      WriteProfileProtocol(root, invalid[i]);
      FakeTransport* fake = nullptr;
      EXPECT_FALSE(MakeProfileBackend(root, profiles[p], "U", &fake))
          << p << ":" << i;
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesRejectInvalidStructuralRolesAndPrefixes) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const char* roles[] = {"field_delimiter", "request_slot_assignment",
      "request_slot_separator", "response_slot_separator", "response_frame_separator"};
  const Json::Value bad_values[] = {
      Json::Value(""), Json::Value("ab"), Json::Value(" "), Json::Value("\t"),
      Json::Value("\r"), Json::Value("\n"), Json::Value(std::string(1u, '\0')),
      Json::Value(std::string(1u, '\x1f')), Json::Value(std::string(1u, '\x7f')),
      Json::Value("\xEF\xBC\x9A"), Json::Value("\xEF\xBC\x9B"),
      Json::Value("\xEF\xBC\x9D"), Json::Value("\xC2\xA2"),
      Json::Value(), Json::Value(1), Json::Value(true),
      Json::Value(Json::arrayValue), Json::Value(Json::objectValue)};
  for (size_t p = 0u; p < 2u; ++p) {
    WriteProfileFiles(root, profiles[p], profiles[p], true);
    const Json::Value canonical = MakeProfileProtocol(profiles[p], Json::Value("@^"));
    std::vector<Json::Value> invalid;
    for (size_t f = 0u; f < sizeof(roles) / sizeof(roles[0]); ++f) {
      Json::Value missing = canonical;
      missing.removeMember(roles[f]);
      invalid.push_back(missing);
      for (size_t i = 0u; i < sizeof(bad_values) / sizeof(bad_values[0]); ++i) {
        if (f == 0u && bad_values[i] == Json::Value("\t")) continue;
        Json::Value bad = canonical;
        bad[roles[f]] = bad_values[i];
        invalid.push_back(bad);
      }
    }
    const Json::Value bad_prefixes[] = {Json::Value(), Json::Value("text"),
        Json::Value(1), Json::Value(Json::objectValue), Json::Value(Json::arrayValue)};
    for (size_t i = 0u; i < sizeof(bad_prefixes) / sizeof(bad_prefixes[0]); ++i) {
      Json::Value bad = canonical;
      bad["request_field_prefixes"] = bad_prefixes[i];
      invalid.push_back(bad);
    }
    Json::Value missing_prefixes = canonical;
    missing_prefixes.removeMember("request_field_prefixes");
    invalid.push_back(missing_prefixes);
    Json::Value too_many = canonical;
    too_many["request_field_prefixes"].append("");
    invalid.push_back(too_many);
    Json::Value too_few = canonical;
    too_few["request_field_prefixes"].resize(p == 0u ? 6u : 5u);
    invalid.push_back(too_few);
    const Json::Value bad_prefix_entries[] = {
        Json::Value(std::string(129u, 'p')), Json::Value("bad\ttail"),
        Json::Value("bad\rtail"), Json::Value("bad\ntail"),
        Json::Value(std::string("bad\0tail", 8u)), Json::Value(1), Json::Value()};
    for (size_t i = 0u;
         i < sizeof(bad_prefix_entries) / sizeof(bad_prefix_entries[0]); ++i) {
      Json::Value bad = canonical;
      bad["request_field_prefixes"][0u] = bad_prefix_entries[i];
      invalid.push_back(bad);
    }
    Json::Value field_prefix_collision = canonical;
    field_prefix_collision["field_delimiter"] = "#";
    field_prefix_collision["request_field_prefixes"][0u] = "bad#tail";
    invalid.push_back(field_prefix_collision);
    const char* field_colliders[] = {"request_slot_assignment", "request_slot_separator",
        "response_slot_separator", "response_frame_separator", "response_slot_assignment"};
    for (size_t i = 0u; i < sizeof(field_colliders) / sizeof(field_colliders[0]); ++i) {
      Json::Value bad = canonical;
      bad["field_delimiter"] = "#";
      bad[field_colliders[i]] = "#";
      invalid.push_back(bad);
    }
    Json::Value request_collision = canonical;
    request_collision["request_slot_assignment"] =
        request_collision["request_slot_separator"];
    invalid.push_back(request_collision);
    Json::Value response_collision = canonical;
    response_collision["response_slot_separator"] = "|";
    invalid.push_back(response_collision);
    Json::Value pair_candidate_collision = canonical;
    pair_candidate_collision["response_slot_assignment"] =
        pair_candidate_collision["response_slot_separator"];
    invalid.push_back(pair_candidate_collision);
    Json::Value frame_candidate_collision = canonical;
    frame_candidate_collision["response_slot_assignment"] = "|";
    invalid.push_back(frame_candidate_collision);
    Json::Value missing_assignment = canonical;
    missing_assignment.removeMember("response_slot_assignment");
    invalid.push_back(missing_assignment);
    Json::Value bad_version = canonical;
    bad_version["version"] = "future";
    invalid.push_back(bad_version);
    bad_version["version"] = 1;
    invalid.push_back(bad_version);
    for (size_t i = 0u; i < invalid.size(); ++i) {
      WriteProfileProtocol(root, invalid[i]);
      FakeTransport* fake = nullptr;
      EXPECT_FALSE(MakeProfileBackend(root, profiles[p], "vehicle\topen\t", &fake))
          << p << ":" << i;
    }
    // Exact byte bound is inclusive; empty/textual Unicode prefixes stay literal.
    Json::Value boundary = canonical;
    boundary["request_field_prefixes"][0u] = std::string(128u, 'p');
    boundary["request_field_prefixes"][1u] = "文字：；＝";
    WriteProfileProtocol(root, boundary);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, profiles[p], "vehicle\topen\t", &fake);
    ASSERT_TRUE(backend);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
    const std::string content = ReadPayload(fake)["messages"][1u]["content"].asString();
    EXPECT_EQ(0u, content.find(std::string(128u, 'p')));
    EXPECT_NE(std::string::npos, content.find("文字：；＝"));
    std::string utf8_prefix;
    for (size_t i = 0u; i < 42u; ++i) utf8_prefix.append(u8"文");
    utf8_prefix.append("pp");
    ASSERT_EQ(128u, utf8_prefix.size());
    boundary["request_field_prefixes"][0u] = utf8_prefix;
    WriteProfileProtocol(root, boundary);
    backend = MakeProfileBackend(root, profiles[p], "vehicle\topen\t", &fake);
    ASSERT_TRUE(backend);
    ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
    EXPECT_EQ(0u, ReadPayload(fake)["messages"][1u]["content"].asString().find(utf8_prefix));
    boundary["request_field_prefixes"][0u] = utf8_prefix + "p";
    WriteProfileProtocol(root, boundary);
    EXPECT_FALSE(MakeProfileBackend(root, profiles[p], "vehicle\topen\t", &fake));
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesAllowEveryNoncollidingPrintableRoleByte) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const char* roles[] = {"field_delimiter", "request_slot_assignment",
      "request_slot_separator", "response_slot_separator", "response_frame_separator",
      "response_slot_assignment"};
  for (size_t p = 0u; p < 2u; ++p) {
    WriteProfileFiles(root, profiles[p], profiles[p], true);
    for (size_t role = 0u; role < 6u; ++role) {
      for (int byte = 0x21; byte <= 0x7e; ++byte) {
        SCOPED_TRACE(std::string(profiles[p]) + ":" + roles[role] + ":" +
                     std::to_string(byte));
        Json::Value protocol = MakeProfileProtocol(profiles[p], Json::Value("="));
        protocol["request_field_prefixes"] = Json::Value(Json::arrayValue);
        for (size_t i = 0u; i < (p == 0u ? 7u : 6u); ++i)
          protocol["request_field_prefixes"].append("");
        protocol.removeMember("response_flag_prefix");
        protocol["response_unknown_marker"] = "未知";
        protocol["response_multi_marker"] = "多项";
        int next = 0x21;
        for (size_t i = 0u; i < 6u; ++i) {
          if (i == role) {
            protocol[roles[i]] = std::string(1u, static_cast<char>(byte));
          } else {
            if (next == byte) ++next;
            protocol[roles[i]] = std::string(1u, static_cast<char>(next++));
          }
        }
        const char field = protocol["field_delimiter"].asString()[0];
        const char request_assignment = protocol["request_slot_assignment"].asString()[0];
        const char request_pair = protocol["request_slot_separator"].asString()[0];
        const char response_assignment = protocol["response_slot_assignment"].asString()[0];
        const char response_pair = protocol["response_slot_separator"].asString()[0];
        const char frame = protocol["response_frame_separator"].asString()[0];
        WriteProfileProtocol(root, protocol);
        const std::string response = std::string("多项") + frame + "车" + field +
            "开" + field + "甲" + response_assignment + "首" + response_pair +
            "乙" + response_assignment + "尾" + frame + "音" + field + "播" + field;
        FakeTransport* fake = nullptr;
        std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
            root, profiles[p], response, &fake);
        ASSERT_TRUE(backend);
        Nlu06BRequest request = MakeRequest();
        request.query = "现在";
        request.histories = Json::Value(Json::arrayValue);
        Json::Value slots(Json::objectValue);
        slots["甲"] = "首";
        slots["乙"] = "尾";
        request.histories.append(MakeProjectedHistory("过去", "车", "开", slots));
        Json::Value result;
        ASSERT_EQ(0, backend->Process(request, &result));
        ASSERT_EQ(2u, result["frames"].size());
        EXPECT_EQ("首", result["frames"][0u]["slots"]["甲"].asString());
        EXPECT_EQ("尾", result["frames"][0u]["slots"]["乙"].asString());
        const std::string content = ReadPayload(fake)["messages"][1u]["content"].asString();
        EXPECT_EQ(p == 0u ? 6u : 5u, static_cast<size_t>(
            std::count(content.begin(), content.end(), field)));
        // UTF-8 byte order sorts 乙 before 甲.
        EXPECT_NE(std::string::npos, content.find(std::string("乙") +
            request_assignment + "尾" + request_pair + "甲" + request_assignment + "首"));
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfilesUseActualRolesForHistoryAndCurrentInput) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  for (size_t p = 0u; p < 2u; ++p) {
    WriteProfileFiles(root, profiles[p], profiles[p], true);
    Json::Value protocol = MakeProfileProtocol(profiles[p], Json::Value("!%"));
    protocol["field_delimiter"] = "#";
    protocol["request_slot_assignment"] = "@";
    protocol["request_slot_separator"] = "^";
    protocol["response_slot_separator"] = "/";
    protocol["response_frame_separator"] = "~";
    WriteProfileProtocol(root, protocol);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, profiles[p], "vehicle#open#", &fake);
    ASSERT_TRUE(backend);
    Nlu06BRequest request = MakeProfileHistoryRequest();
    request.query = "current: =,;|!%/@^";
    Json::Value& semantic = request.histories[0u]["v3_nlu_semantics"][0u];
    semantic["query"] = "history: =,;|!%/@^";
    semantic["slots"]["alpha"] = "first: =,;|!%/";
    semantic["tts"] = "spoken: =,;|!%/@^";
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result));
    const std::string expected = p == 0u
        ? "history:#history: =,;|!%/@^#vehicle#open_window#"
          "alpha@first: =,;|!%/^zeta@last#spoken: =,;|!%/@^#current: =,;|!%/@^"
        : "history_query: history: =,;|!%/@^#history_domain: vehicle#"
          "history_intent: open_window#history_slot: alpha@first: =,;|!%/^zeta@last#"
          "history_tts: spoken: =,;|!%/@^#query: current: =,;|!%/@^";
    EXPECT_EQ(expected, ReadPayload(fake)["messages"][1u]["content"].asString());
    // The newest coherent item alone is selected; no merging with an older turn.
    const Json::Value valid = request.histories[0u];
    request.histories = Json::Value(Json::arrayValue);
    request.histories.append(MakeProjectedHistory(
        "older leak", "old_domain", "old_intent", Json::Value(Json::objectValue)));
    request.histories.append(valid);
    ASSERT_EQ(0, backend->Process(request, &result));
    EXPECT_EQ(expected, ReadPayload(fake)["messages"][1u]["content"].asString());
    std::vector<Json::Value> invalid;
    const char* fields[] = {"query", "domain", "intent", "tts"};
    const std::string forbidden[] = {"bad#tail", "bad\ttail", "bad\rtail",
                                    "bad\ntail", std::string("bad\0tail", 8u)};
    for (size_t f = 0u; f < 4u; ++f) {
      for (size_t i = 0u; i < sizeof(forbidden) / sizeof(forbidden[0]); ++i) {
        Json::Value bad = valid;
        bad["v3_nlu_semantics"][0u][fields[f]] = forbidden[i];
        invalid.push_back(bad);
      }
    }
    std::vector<std::string> bad_slot_text(forbidden,
        forbidden + sizeof(forbidden) / sizeof(forbidden[0]));
    bad_slot_text.push_back("bad@tail");
    bad_slot_text.push_back("bad^tail");
    for (size_t i = 0u; i < bad_slot_text.size(); ++i) {
      Json::Value bad = valid;
      bad["v3_nlu_semantics"][0u]["slots"]["alpha"] = bad_slot_text[i];
      invalid.push_back(bad);
      bad = valid;
      bad["v3_nlu_semantics"][0u]["slots"][bad_slot_text[i]] = "value";
      invalid.push_back(bad);
    }
    Json::Value bad_tts_type = valid;
    bad_tts_type["v3_nlu_semantics"][0u]["tts"] = 1;
    invalid.push_back(bad_tts_type);
    Json::Value multi_history = valid;
    multi_history["v3_nlu_semantics"].append(valid["v3_nlu_semantics"][0u]);
    invalid.push_back(multi_history);
    invalid.push_back(Json::Value("not projected"));
    const std::string omitted = p == 0u
        ? "history:######current: =,;|!%/@^"
        : "history_query: #history_domain: #history_intent: #history_slot: #"
          "history_tts: #query: current: =,;|!%/@^";
    for (size_t i = 0u; i < invalid.size(); ++i) {
      request.histories = Json::Value(Json::arrayValue);
      request.histories.append(valid);
      request.histories.append(invalid[i]);
      ASSERT_EQ(0, backend->Process(request, &result)) << p << ":" << i;
      EXPECT_EQ(omitted, ReadPayload(fake)["messages"][1u]["content"].asString())
          << p << ":" << i;
    }
    for (size_t i = 0u; i < sizeof(forbidden) / sizeof(forbidden[0]); ++i) {
      ScopedLogCapture capture;
      request.query = forbidden[i];
      const int before = fake->post_count();
      result["stale"] = true;
      EXPECT_LT(backend->Process(request, &result), 0) << p << ":" << i;
      EXPECT_EQ(before, fake->post_count());
      EXPECT_TRUE(result.isNull());
      EXPECT_NE(std::string::npos, capture.messages().find("reason=invalid_input"));
      EXPECT_EQ(std::string::npos, capture.messages().find("bad"));
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV3RejectsFullwidthSlotPunctuationWithoutNormalization) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  struct PunctuationCase {
    const char* codepoint;
    const char* utf8;
    char ascii;
    unsigned int byte;
  };
  const PunctuationCase cases[] = {
      {u8"：", "\xEF\xBC\x9A", ':', 0x3au},
      {u8"；", "\xEF\xBC\x9B", ';', 0x3bu},
      {u8"＝", "\xEF\xBC\x9D", '=', 0x3du}};
  WriteProfileFiles(root, "nlu_06b_v3", "nlu_06b_v3", true, Json::Value(":="));
  for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0]); ++i) {
    const std::string fullwidth(cases[i].utf8);
    EXPECT_EQ(std::string(cases[i].codepoint), fullwidth);
    ASSERT_EQ(3u, fullwidth.size());
    EXPECT_EQ(0xefu, static_cast<unsigned char>(fullwidth[0]));
    EXPECT_EQ(0xbcu, static_cast<unsigned char>(fullwidth[1]));
    EXPECT_EQ(cases[i].byte, static_cast<unsigned char>(cases[i].ascii));
    EXPECT_NE(std::string(1u, cases[i].ascii), fullwidth);
    const std::string invalid[] = {
        "vehicle\topen\tname:value" + fullwidth + "tail",
        "vehicle\topen\tna" + fullwidth + "me:value",
        "vehicle\topen\tname=value" + fullwidth + "tail",
        "vehicle\topen\tna" + fullwidth + "me=value",
        "vehicle\topen\tname" + fullwidth + "value",
        "flag:multi|vehicle\topen\tname:value|media\tplay\ta=1" + fullwidth + "tail"};
    for (size_t j = 0u; j < sizeof(invalid) / sizeof(invalid[0]); ++j) {
      ScopedLogCapture capture;
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
          root, "nlu_06b_v3", invalid[j], &fake);
      ASSERT_TRUE(backend);
      Json::Value result(Json::objectValue);
      result["stale"] = true;
      EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << i << ":" << j;
      ExpectDecodedContentFailure(result, invalid[j]);
      EXPECT_NE(std::string::npos,
                capture.messages().find("schema_detail=forbidden_punctuation"));
      EXPECT_EQ(std::string::npos, capture.messages().find(fullwidth));
    }
  }
  // The restriction belongs to named V3 response slots, not all UTF-8 payload.
  WriteProfileFiles(root, "nlu_06b_v4", "nlu_06b_v4", true);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> v4 = MakeProfileBackend(
      root, "nlu_06b_v4", "vehicle\topen\tna：me=文字：；＝", &fake);
  ASSERT_TRUE(v4);
  Json::Value result;
  ASSERT_EQ(0, v4->Process(MakeRequest(), &result));
  EXPECT_EQ("文字：；＝", result["frames"][0u]["slots"]["na：me"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfilesRejectWrappersWrongFieldCountsAndNonAtomicFrames) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string catalog_path = directory.NewFile("catalog.json");
  directory.NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  const char* profiles[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const std::string invalid[] = {
      "vehicle#open", "vehicle#open##extra", "#open#", "vehicle##",
      "\"vehicle#open#\"", "`vehicle#open#`", "vehicle#open#\n",
      "vehicle#open#bad\tvalue", std::string("vehicle#open#bad\0value", 23u),
      "ALL~vehicle#open#a@1~media#play#a@@2",
      "ALL~vehicle#open#a@1~media#play#a@2/a@3",
      "ALL~vehicle#open#a@1~media#play#a@2/",
      "ALL~vehicle#open#a@1~media#play#@2",
      "ALL~vehicle#open#a@1~media#play#a@",
      "ALL~vehicle#open#a@1~media#play#"};
  for (size_t p = 0u; p < 2u; ++p) {
    for (int enabled = 0; enabled < 2; ++enabled) {
      WriteProfileFiles(root, profiles[p], profiles[p], enabled != 0);
      Json::Value protocol = MakeProfileProtocol(profiles[p], Json::Value("@^"));
      protocol["field_delimiter"] = "#";
      protocol["response_slot_separator"] = "/";
      protocol["response_frame_separator"] = "~";
      protocol.removeMember("response_flag_prefix");
      protocol["response_unknown_marker"] = "UNKNOWN";
      protocol["response_multi_marker"] = "ALL";
      WriteProfileProtocol(root, protocol);
      for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
        // The last record is valid and follows the normal multi-output policy.
        FakeTransport* fake = nullptr;
        std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
            root, profiles[p], invalid[i], &fake);
        ASSERT_TRUE(backend);
        Json::Value result(Json::objectValue);
        result["stale"] = true;
        if (i + 1u == sizeof(invalid) / sizeof(invalid[0])) {
          ASSERT_EQ(0, backend->Process(MakeRequest(), &result));
          EXPECT_EQ(enabled == 0, result["is_rejected"].asBool());
          if (enabled == 0) EXPECT_TRUE(result["frames"].empty());
          else ASSERT_EQ(2u, result["frames"].size());
        } else {
          EXPECT_LT(backend->Process(MakeRequest(), &result), 0) << p << ":" << i;
          ExpectDecodedContentFailure(result, invalid[i]);
        }
      }
    }
  }
}

namespace {

Json::Value MakeEmptyHistoryOptionForTest(
    const std::string& history_field, const std::string& query_prefix) {
  Json::Value option(Json::objectValue);
  option["history_field"] = history_field;
  option["query_prefix"] = query_prefix;
  return option;
}

Json::Value MakeEmptyHistoryProtocolForTest(
    const std::string& version, const std::string& history_field,
    const std::string& query_prefix, char delimiter = '\t') {
  Json::Value protocol = MakeProfileProtocol(
      version, Json::Value(version == "nlu_06b_v3" ? ":" : "="));
  protocol["field_delimiter"] = std::string(1u, delimiter);
  protocol["empty_history_request"] =
      MakeEmptyHistoryOptionForTest(history_field, query_prefix);
  return protocol;
}

std::unique_ptr<Nlu06BBackend> MakeEmptyHistoryBackendForTest(
    const std::string& root, const std::string& version,
    const Json::Value& protocol, FakeTransport** fake,
    char response_delimiter = '\t') {
  WriteProfileFiles(root, version, version, true);
  WriteProfileProtocol(root, protocol);
  const std::string delimiter(1u, response_delimiter);
  const std::string response =
      "vehicle" + delimiter + "open_window" + delimiter +
      (version == "nlu_06b_v3" ? "name:window" : "name=window");
  return MakeProfileBackend(root, version, response, fake);
}

Json::Value MakeEmptyHistorySingletonForTest(const Json::Value& value) {
  Json::Value array(Json::arrayValue);
  array.append(value);
  return array;
}

Json::Value MakeEmptyHistoryEntryForTest(const Json::Value& projection) {
  Json::Value history(Json::objectValue);
  history["v3_nlu_semantics"] = projection;
  return history;
}

Json::Value MakeEmptyHistoryFieldForTest(
    const Json::Value& history, const char* field,
    const Json::Value& value) {
  Json::Value changed = history;
  changed["v3_nlu_semantics"][0u][field] = value;
  return changed;
}

std::string EmptyHistoryFallbackForTest(
    const std::string& version, const std::string& query,
    char delimiter = '\t') {
  if (version == "nlu_06b_v3")
    return "history:" + std::string(6u, delimiter) + query;
  const std::string separator(1u, delimiter);
  return "history_query: " + separator +
      "history_domain: " + separator +
      "history_intent: " + separator +
      "history_slot: " + separator +
      "history_tts: " + separator + "query: " + query;
}

std::string EmptyHistoryPopulatedGoldenForTest(
    const std::string& version, const std::string& history_query,
    const std::string& tts, const std::string& current_query) {
  if (version == "nlu_06b_v3") {
    return "history:\t" + history_query +
        "\tvehicle\topen_window\talpha:first;zeta:last\t" +
        tts + "\t" + current_query;
  }
  return "history_query: " + history_query +
      "\thistory_domain: vehicle\thistory_intent: open_window"
      "\thistory_slot: alpha=first,zeta=last\thistory_tts: " +
      tts + "\tquery: " + current_query;
}

}  // namespace

TEST(Nlu06BHttpBackendTest, EmptyHistoryOptionGoldenBothProfiles) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const std::string query(
      u8"开启空调播放音乐");
  const std::string query_bytes(
      "\xE5\xBC\x80\xE5\x90\xAF\xE7\xA9\xBA\xE8\xB0\x83"
      "\xE6\x92\xAD\xE6\x94\xBE\xE9\x9F\xB3\xE4\xB9\x90");
  ASSERT_EQ(query_bytes, query);
  ASSERT_EQ(24u, query.size());

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string catalog_path = directory.NewFile("catalog.json");
    directory.NewFile("protocol.json");
    const std::string root =
        catalog_path.substr(0u, catalog_path.find_last_of('/'));
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend =
        MakeEmptyHistoryBackendForTest(
            root, versions[p],
            MakeEmptyHistoryProtocolForTest(
                versions[p], "history:None", "query: "),
            &fake);
    ASSERT_TRUE(backend);

    Nlu06BRequest request = MakeRequest();
    request.query = query;
    request.histories = Json::Value();
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result));
    const Json::Value payload = ReadPayload(fake);
    const std::string content =
        payload["messages"][1u]["content"].asString();

    ASSERT_EQ("history:None\tquery: " + query_bytes, content);
    ASSERT_EQ(20u + query_bytes.size(), content.size());
    EXPECT_EQ("None", content.substr(8u, 4u));
    EXPECT_EQ(query_bytes, content.substr(20u));
    EXPECT_EQ(1u, static_cast<size_t>(
        std::count(content.begin(), content.end(), '\t')));
    // Structural TAB is U+0009/09; ':' is U+003A/3A;
    // the configured prefix's space is U+0020/20.
    EXPECT_EQ(0x09u, static_cast<unsigned char>(content[12u]));
    EXPECT_EQ(0x3Au, static_cast<unsigned char>(content[7u]));
    EXPECT_EQ(0x3Au, static_cast<unsigned char>(content[18u]));
    EXPECT_EQ(0x20u, static_cast<unsigned char>(content[19u]));
    EXPECT_NE(std::string::npos,
              fake->request_.body.find("history:None\\tquery: "));
    EXPECT_FALSE(payload.isMember("chat_template_kwargs"));
    EXPECT_FALSE(payload["stream"].asBool());
    ASSERT_TRUE(result["frames"].isArray());
    ASSERT_EQ(1u, result["frames"].size());
    EXPECT_EQ("window", result["frames"][0u]["slots"]["name"].asString());
  }
}

TEST(Nlu06BHttpBackendTest,
     EmptyHistoryOptionOmittedAndPresentHistoryGoldens) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  Json::Value slots(Json::objectValue);
  slots["zeta"] = "last";
  slots["alpha"] = "first";
  const Json::Value valid_history = MakeProjectedHistory(
      "history query", "vehicle", "open_window", slots);

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string catalog_path = directory.NewFile("catalog.json");
    directory.NewFile("protocol.json");
    const std::string root =
        catalog_path.substr(0u, catalog_path.find_last_of('/'));
    FakeTransport* plain_fake = nullptr;
    std::unique_ptr<Nlu06BBackend> plain =
        MakeEmptyHistoryBackendForTest(
            root, versions[p],
            MakeProfileProtocol(
                versions[p],
                Json::Value(p == 0u ? ":" : "=")),
            &plain_fake);
    ASSERT_TRUE(plain);

    const Json::Value fallback_histories[] = {
        Json::Value(),
        Json::Value(Json::arrayValue),
        Json::Value("malformed histories"),
        MakeEmptyHistorySingletonForTest(
            MakeEmptyHistoryFieldForTest(
                valid_history, "slots", Json::Value(Json::arrayValue)))
    };
    Nlu06BRequest request = MakeRequest();
    request.query = "current query";
    for (size_t i = 0u;
         i < sizeof(fallback_histories) / sizeof(fallback_histories[0u]);
         ++i) {
      SCOPED_TRACE(i);
      request.histories = fallback_histories[i];
      Json::Value result;
      ASSERT_EQ(0, plain->Process(request, &result));
      const std::string content =
          ReadPayload(plain_fake)["messages"][1u]["content"].asString();
      EXPECT_EQ(EmptyHistoryFallbackForTest(versions[p], request.query),
                content);
      EXPECT_EQ(p == 0u ? 6u : 5u, static_cast<size_t>(
          std::count(content.begin(), content.end(), '\t')));
    }

    FakeTransport* configured_fake = nullptr;
    std::unique_ptr<Nlu06BBackend> configured =
        MakeEmptyHistoryBackendForTest(
            root, versions[p],
            MakeEmptyHistoryProtocolForTest(
                versions[p], "history:None", "query: "),
            &configured_fake);
    ASSERT_TRUE(configured);

    for (size_t i = 0u; i < 3u; ++i) {
      SCOPED_TRACE(i);
      const std::string history_query =
          i == 2u ? "None" : "history query";
      const std::string tts = i == 0u ? "spoken" : "";
      Json::Value history = MakeProjectedHistory(
          history_query, "vehicle", "open_window", slots);
      if (i == 0u)
        history["v3_nlu_semantics"][0u]["tts"] = tts;
      request.histories = MakeEmptyHistorySingletonForTest(history);
      Json::Value plain_result;
      Json::Value configured_result;
      ASSERT_EQ(0, plain->Process(request, &plain_result));
      ASSERT_EQ(0, configured->Process(request, &configured_result));
      const std::string expected = EmptyHistoryPopulatedGoldenForTest(
          versions[p], history_query, tts, request.query);
      EXPECT_EQ(expected,
                ReadPayload(plain_fake)["messages"][1u]["content"].asString());
      const std::string configured_content =
          ReadPayload(configured_fake)["messages"][1u]["content"].asString();
      EXPECT_EQ(expected, configured_content);
      EXPECT_EQ(p == 0u ? 6u : 5u, static_cast<size_t>(
          std::count(configured_content.begin(),
                     configured_content.end(), '\t')));
      EXPECT_TRUE(plain_result == configured_result);
      EXPECT_EQ("window",
                configured_result["frames"][0u]["slots"]["name"].asString());
    }
  }
}

TEST(Nlu06BHttpBackendTest,
     EmptyHistoryOptionIndependentProfilesAndCustomDelimiter) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const std::string history_fields[] = {
      std::string("history") + "\xEF\xBC\x9A" + " Unset",
      std::string("history_query") + "\xEF\xBC\x9B" + " Missing"
  };
  const std::string query_prefixes[] = {
      std::string("current") + "\xEF\xBC\x9A" + " ",
      std::string("request") + "\xEF\xBC\x9A" + " "
  };
  const std::string query =
      std::string("query") + "\xEF\xBC\x9A\xEF\xBC\x9B";

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string catalog_path = directory.NewFile("catalog.json");
    directory.NewFile("protocol.json");
    const std::string root =
        catalog_path.substr(0u, catalog_path.find_last_of('/'));
    FakeTransport* configured_fake = nullptr;
    std::unique_ptr<Nlu06BBackend> configured =
        MakeEmptyHistoryBackendForTest(
            root, versions[p],
            MakeEmptyHistoryProtocolForTest(
                versions[p], history_fields[p], query_prefixes[p], '~'),
            &configured_fake, '~');
    ASSERT_TRUE(configured);

    const size_t other = 1u - p;
    FakeTransport* plain_fake = nullptr;
    std::unique_ptr<Nlu06BBackend> plain =
        MakeEmptyHistoryBackendForTest(
            root, versions[other],
            MakeProfileProtocol(
                versions[other],
                Json::Value(other == 0u ? ":" : "=")),
            &plain_fake);
    ASSERT_TRUE(plain);

    // Rewriting the fixture for the other profile must not alter the
    // already-normalized configured backend or enable the plain backend.
    Nlu06BRequest request = MakeRequest();
    request.query = query;
    request.histories = Json::Value();
    Json::Value configured_result;
    Json::Value plain_result;
    ASSERT_EQ(0, configured->Process(request, &configured_result));
    ASSERT_EQ(0, plain->Process(request, &plain_result));
    const std::string content =
        ReadPayload(configured_fake)["messages"][1u]["content"].asString();
    EXPECT_EQ(history_fields[p] + "~" + query_prefixes[p] + query, content);
    EXPECT_EQ(history_fields[p], content.substr(0u, history_fields[p].size()));
    ASSERT_GT(content.size(), history_fields[p].size());
    EXPECT_EQ(0x7Eu, static_cast<unsigned char>(
        content[history_fields[p].size()]));
    EXPECT_EQ(1u, static_cast<size_t>(
        std::count(content.begin(), content.end(), '~')));
    EXPECT_EQ(0u, static_cast<size_t>(
        std::count(content.begin(), content.end(), '\t')));
    EXPECT_EQ(EmptyHistoryFallbackForTest(versions[other], query),
              ReadPayload(plain_fake)["messages"][1u]["content"].asString());
    const std::string expected_configured_raw =
        std::string("vehicle~open_window~") +
        (p == 0u ? "name:window" : "name=window");
    const std::string expected_plain_raw =
        std::string("vehicle\topen_window\t") +
        (other == 0u ? "name:window" : "name=window");
    ASSERT_TRUE(configured_result["nlu_result"].isString());
    ASSERT_TRUE(plain_result["nlu_result"].isString());
    EXPECT_EQ(expected_configured_raw,
              configured_result["nlu_result"].asString());
    EXPECT_EQ(expected_plain_raw, plain_result["nlu_result"].asString());

    // The profiles have different raw responses but identical decoded results.
    Json::Value configured_comparison = configured_result;
    Json::Value plain_comparison = plain_result;
    configured_comparison.removeMember("nlu_result");
    plain_comparison.removeMember("nlu_result");
    EXPECT_TRUE(configured_comparison == plain_comparison);
    EXPECT_EQ("window",
              configured_result["frames"][0u]["slots"]["name"].asString());
  }
}

TEST(Nlu06BHttpBackendTest,
     EmptyHistoryOptionAbsenceVersusMalformedHistory) {
  Json::Value slots(Json::objectValue);
  slots["name"] = "window";
  const Json::Value valid_history = MakeProjectedHistory(
      "history query", "vehicle", "open_window", slots);
  Json::Value missing_query = valid_history["v3_nlu_semantics"][0u];
  missing_query.removeMember("query");
  Json::Value empty_query = missing_query;
  empty_query["query"] = "";
  Json::Value empty_query_bad_fields = empty_query;
  empty_query_bad_fields["domain"] = Json::Value(Json::objectValue);
  empty_query_bad_fields["intent"] = Json::Value(Json::arrayValue);
  empty_query_bad_fields["slots"] = Json::Value();
  empty_query_bad_fields["tts"] = Json::Value(Json::objectValue);
  Json::Value missing_domain = valid_history;
  missing_domain["v3_nlu_semantics"][0u].removeMember("domain");
  Json::Value missing_intent = valid_history;
  missing_intent["v3_nlu_semantics"][0u].removeMember("intent");
  Json::Value missing_slots = valid_history;
  missing_slots["v3_nlu_semantics"][0u].removeMember("slots");
  Json::Value duplicate_projection =
      valid_history["v3_nlu_semantics"];
  duplicate_projection.append(valid_history["v3_nlu_semantics"][0u]);
  const Json::Value none_history = MakeProjectedHistory(
      "None", "vehicle", "open_window", slots);

  struct HistoryCase {
    const char* name;
    Json::Value histories;
    bool compact;
  };
  const HistoryCase cases[] = {
      {"null_histories", Json::Value(), true},
      {"empty_histories", Json::Value(Json::arrayValue), true},
      {"missing_projection",
       MakeEmptyHistorySingletonForTest(Json::Value(Json::objectValue)), true},
      {"empty_projection",
       MakeEmptyHistorySingletonForTest(
           MakeEmptyHistoryEntryForTest(Json::Value(Json::arrayValue))), true},
      {"missing_query",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(missing_query))), true},
      {"empty_query",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(empty_query))), true},
      {"missing_query_and_other_fields",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(
               Json::Value(Json::objectValue)))), true},
      {"empty_query_with_bad_other_fields",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(empty_query_bad_fields))), true},
      {"object_histories", Json::Value(Json::objectValue), false},
      {"string_histories", Json::Value("invalid"), false},
      {"number_histories", Json::Value(7), false},
      {"bool_histories", Json::Value(true), false},
      {"null_newest", MakeEmptyHistorySingletonForTest(Json::Value()), false},
      {"array_newest",
       MakeEmptyHistorySingletonForTest(Json::Value(Json::arrayValue)), false},
      {"string_newest",
       MakeEmptyHistorySingletonForTest(Json::Value("invalid")), false},
      {"number_newest",
       MakeEmptyHistorySingletonForTest(Json::Value(7)), false},
      {"bool_newest",
       MakeEmptyHistorySingletonForTest(Json::Value(true)), false},
      {"null_projection",
       MakeEmptyHistorySingletonForTest(
           MakeEmptyHistoryEntryForTest(Json::Value())), false},
      {"object_projection",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           Json::Value(Json::objectValue))), false},
      {"string_projection",
       MakeEmptyHistorySingletonForTest(
           MakeEmptyHistoryEntryForTest(Json::Value("invalid"))), false},
      {"number_projection",
       MakeEmptyHistorySingletonForTest(
           MakeEmptyHistoryEntryForTest(Json::Value(7))), false},
      {"bool_projection",
       MakeEmptyHistorySingletonForTest(
           MakeEmptyHistoryEntryForTest(Json::Value(true))), false},
      {"multiple_semantics",
       MakeEmptyHistorySingletonForTest(
           MakeEmptyHistoryEntryForTest(duplicate_projection)), false},
      {"null_semantic",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(Json::Value()))), false},
      {"array_semantic",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(
               Json::Value(Json::arrayValue)))), false},
      {"string_semantic",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(Json::Value("invalid")))), false},
      {"number_semantic",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(Json::Value(7)))), false},
      {"bool_semantic",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryEntryForTest(
           MakeEmptyHistorySingletonForTest(Json::Value(true)))), false},
      {"null_query",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "query", Json::Value())), false},
      {"number_query",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "query", Json::Value(7))), false},
      {"bool_query",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "query", Json::Value(true))), false},
      {"object_query",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "query", Json::Value(Json::objectValue))), false},
      {"array_query",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "query", Json::Value(Json::arrayValue))), false},
      {"missing_domain",
       MakeEmptyHistorySingletonForTest(missing_domain), false},
      {"missing_intent",
       MakeEmptyHistorySingletonForTest(missing_intent), false},
      {"missing_slots",
       MakeEmptyHistorySingletonForTest(missing_slots), false},
      {"object_domain",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "domain", Json::Value(Json::objectValue))), false},
      {"array_intent",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "intent", Json::Value(Json::arrayValue))), false},
      {"array_slots",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "slots", Json::Value(Json::arrayValue))), false},
      {"null_slots",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "slots", Json::Value())), false},
      {"string_slots",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "slots", Json::Value("invalid"))), false},
      {"object_tts",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           valid_history, "tts", Json::Value(Json::objectValue))), false},
      {"none_query_with_invalid_slots",
       MakeEmptyHistorySingletonForTest(MakeEmptyHistoryFieldForTest(
           none_history, "slots", Json::Value(Json::arrayValue))), false}
  };
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const Json::Value older_history = MakeProjectedHistory(
      "older query", "vehicle", "open_window", slots);

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string catalog_path = directory.NewFile("catalog.json");
    directory.NewFile("protocol.json");
    const std::string root =
        catalog_path.substr(0u, catalog_path.find_last_of('/'));
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend =
        MakeEmptyHistoryBackendForTest(
            root, versions[p],
            MakeEmptyHistoryProtocolForTest(
                versions[p], "history:None", "query: "),
            &fake);
    ASSERT_TRUE(backend);

    for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0u]); ++i) {
      SCOPED_TRACE(cases[i].name);
      Nlu06BRequest request = MakeRequest();
      request.query = "current query";
      request.histories = cases[i].histories;
      const std::string expected = cases[i].compact
          ? "history:None\tquery: current query"
          : EmptyHistoryFallbackForTest(versions[p], request.query);
      Json::Value result;
      ASSERT_EQ(0, backend->Process(request, &result));
      const std::string content =
          ReadPayload(fake)["messages"][1u]["content"].asString();
      EXPECT_EQ(expected, content);
      EXPECT_EQ(cases[i].compact ? 1u : (p == 0u ? 6u : 5u),
                static_cast<size_t>(
                    std::count(content.begin(), content.end(), '\t')));

      if (cases[i].histories.isArray() &&
          !cases[i].histories.empty()) {
        Json::Value with_older(Json::arrayValue);
        with_older.append(older_history);
        for (Json::ArrayIndex j = 0u;
             j < cases[i].histories.size(); ++j)
          with_older.append(cases[i].histories[j]);
        request.histories = with_older;
        Json::Value newest_only_result;
        ASSERT_EQ(0, backend->Process(request, &newest_only_result));
        EXPECT_EQ(expected,
                  ReadPayload(fake)["messages"][1u]["content"].asString());
        EXPECT_TRUE(result == newest_only_result);
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest,
     EmptyHistoryOptionPresentHistoryReservedBytesKeepFullFallback) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const char delimiters[] = {'\t', '~'};
  const char invalid_bytes[] = {'\0', '\t', '\r', '\n', '~'};
  Json::Value slots(Json::objectValue);
  slots["name"] = "window";
  Json::Value valid_history = MakeProjectedHistory(
      "history query", "vehicle", "open_window", slots);
  valid_history["v3_nlu_semantics"][0u]["tts"] = "spoken";

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    for (size_t d = 0u; d < 2u; ++d) {
      SCOPED_TRACE(d);
      ScopedCaptureDirectory directory;
      ASSERT_TRUE(directory.valid());
      const std::string catalog_path = directory.NewFile("catalog.json");
      directory.NewFile("protocol.json");
      const std::string root =
          catalog_path.substr(0u, catalog_path.find_last_of('/'));
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend =
          MakeEmptyHistoryBackendForTest(
              root, versions[p],
              MakeEmptyHistoryProtocolForTest(
                  versions[p], "history:None", "query: ", delimiters[d]),
              &fake, delimiters[d]);
      ASSERT_TRUE(backend);

      for (size_t b = 0u; b < sizeof(invalid_bytes); ++b) {
        if (invalid_bytes[b] == '~' && delimiters[d] != '~')
          continue;
        SCOPED_TRACE(b);
        std::string bad("bad");
        bad.push_back(invalid_bytes[b]);
        bad += "history";
        for (size_t f = 0u; f < 6u; ++f) {
          SCOPED_TRACE(f);
          Json::Value history = valid_history;
          Json::Value& semantic = history["v3_nlu_semantics"][0u];
          if (f == 0u) {
            semantic["query"] = bad;
          } else if (f == 1u) {
            semantic["domain"] = bad;
          } else if (f == 2u) {
            semantic["intent"] = bad;
          } else if (f == 3u) {
            semantic["slots"] = Json::Value(Json::objectValue);
            semantic["slots"][bad] = "window";
          } else if (f == 4u) {
            semantic["slots"]["name"] = bad;
          } else {
            semantic["tts"] = bad;
          }
          Nlu06BRequest request = MakeRequest();
          request.query = "current query";
          request.histories = MakeEmptyHistorySingletonForTest(history);
          Json::Value result;
          ASSERT_EQ(0, backend->Process(request, &result));
          const std::string content =
              ReadPayload(fake)["messages"][1u]["content"].asString();
          EXPECT_EQ(EmptyHistoryFallbackForTest(
                        versions[p], request.query, delimiters[d]),
                    content);
          EXPECT_EQ(p == 0u ? 6u : 5u, static_cast<size_t>(
              std::count(content.begin(), content.end(), delimiters[d])));
        }
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, EmptyHistoryOptionValidationBothProfiles) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const Json::Value wrong_types[] = {
      Json::Value(),
      Json::Value(true),
      Json::Value(7),
      Json::Value(1.5),
      Json::Value(Json::arrayValue),
      Json::Value(Json::objectValue)
  };
  Json::Value missing_history =
      MakeEmptyHistoryOptionForTest("history:None", "query: ");
  missing_history.removeMember("history_field");
  Json::Value missing_prefix =
      MakeEmptyHistoryOptionForTest("history:None", "query: ");
  missing_prefix.removeMember("query_prefix");
  Json::Value unknown_member =
      MakeEmptyHistoryOptionForTest("history:None", "query: ");
  unknown_member["unexpected_member"] = true;
  const Json::Value bad_options[] = {
      Json::Value(),
      Json::Value(true),
      Json::Value(7),
      Json::Value(1.5),
      Json::Value("invalid"),
      Json::Value(Json::arrayValue),
      Json::Value(Json::objectValue),
      missing_history,
      missing_prefix,
      unknown_member,
      MakeEmptyHistoryOptionForTest("", "query: "),
      MakeEmptyHistoryOptionForTest(std::string(129u, 'h'), "query: "),
      MakeEmptyHistoryOptionForTest("history:None", std::string(129u, 'q')),
      MakeEmptyHistoryOptionForTest(
          std::string(126u, 'h') + "\xEF\xBC\x9A", "query: "),
      MakeEmptyHistoryOptionForTest(
          "history:None", std::string(126u, 'q') + "\xEF\xBC\x9B")
  };
  const char* fields[] = {"history_field", "query_prefix"};
  const char invalid_bytes[] = {'\0', '\t', '\r', '\n', '~'};
  // U+FF1B, U+FF1A and U+FF5E are multi-byte payload characters,
  // not substitutes for an ASCII field delimiter.
  const char* fullwidth_delimiters[] = {
      "\xEF\xBC\x9B", "\xEF\xBC\x9A", "\xEF\xBD\x9E"
  };

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string catalog_path = directory.NewFile("catalog.json");
    directory.NewFile("protocol.json");
    const std::string root =
        catalog_path.substr(0u, catalog_path.find_last_of('/'));

    for (size_t i = 0u;
         i < sizeof(bad_options) / sizeof(bad_options[0u]); ++i) {
      SCOPED_TRACE(i);
      Json::Value protocol = MakeEmptyHistoryProtocolForTest(
          versions[p], "history:None", "query: ");
      protocol["empty_history_request"] = bad_options[i];
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend =
          MakeEmptyHistoryBackendForTest(root, versions[p], protocol, &fake);
      EXPECT_FALSE(backend);
    }

    for (size_t f = 0u; f < 2u; ++f) {
      SCOPED_TRACE(fields[f]);
      for (size_t i = 0u;
           i < sizeof(wrong_types) / sizeof(wrong_types[0u]); ++i) {
        SCOPED_TRACE(i);
        Json::Value protocol = MakeEmptyHistoryProtocolForTest(
            versions[p], "history:None", "query: ");
        protocol["empty_history_request"][fields[f]] = wrong_types[i];
        FakeTransport* fake = nullptr;
        std::unique_ptr<Nlu06BBackend> backend =
            MakeEmptyHistoryBackendForTest(root, versions[p], protocol, &fake);
        EXPECT_FALSE(backend);
      }
      for (size_t b = 0u; b < sizeof(invalid_bytes); ++b) {
        SCOPED_TRACE(b);
        std::string bad("bad");
        bad.push_back(invalid_bytes[b]);
        bad += "prefix";
        Json::Value protocol = MakeEmptyHistoryProtocolForTest(
            versions[p], "history:None", "query: ", '~');
        protocol["empty_history_request"][fields[f]] = bad;
        FakeTransport* fake = nullptr;
        std::unique_ptr<Nlu06BBackend> backend =
            MakeEmptyHistoryBackendForTest(
                root, versions[p], protocol, &fake, '~');
        EXPECT_FALSE(backend);
      }
    }

    for (size_t i = 0u; i < 3u; ++i) {
      SCOPED_TRACE(i);
      Json::Value protocol = MakeEmptyHistoryProtocolForTest(
          versions[p], "history:None", "query: ");
      protocol["field_delimiter"] = fullwidth_delimiters[i];
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend =
          MakeEmptyHistoryBackendForTest(root, versions[p], protocol, &fake);
      EXPECT_FALSE(backend);
    }
  }
}

TEST(Nlu06BHttpBackendTest,
     EmptyHistoryOptionAcceptsLimitsAndEmptyQueryPrefix) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  struct ValidOption {
    const char* name;
    std::string history_field;
    std::string query_prefix;
  };
  const ValidOption cases[] = {
      {"ascii_128_bytes", std::string(128u, 'h'), std::string(128u, 'q')},
      {"empty_query_prefix", "history:None", ""},
      {"utf8_128_bytes",
       std::string(125u, 'h') + "\xEF\xBC\x9A",
       std::string(125u, 'q') + "\xEF\xBC\x9B"}
  };

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string catalog_path = directory.NewFile("catalog.json");
    directory.NewFile("protocol.json");
    const std::string root =
        catalog_path.substr(0u, catalog_path.find_last_of('/'));

    for (size_t i = 0u; i < sizeof(cases) / sizeof(cases[0u]); ++i) {
      SCOPED_TRACE(cases[i].name);
      Json::Value protocol = MakeEmptyHistoryProtocolForTest(
          versions[p], cases[i].history_field, cases[i].query_prefix);
      // Strict member validation belongs only to the new option object.
      protocol["test_only_unrelated_member"] = true;
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend =
          MakeEmptyHistoryBackendForTest(root, versions[p], protocol, &fake);
      ASSERT_TRUE(backend);
      Nlu06BRequest request = MakeRequest();
      request.query = "current query";
      request.histories = Json::Value(Json::arrayValue);
      Json::Value result;
      ASSERT_EQ(0, backend->Process(request, &result));
      const std::string content =
          ReadPayload(fake)["messages"][1u]["content"].asString();
      EXPECT_EQ(cases[i].history_field + "\t" +
                    cases[i].query_prefix + request.query,
                content);
      EXPECT_EQ(1u, static_cast<size_t>(
          std::count(content.begin(), content.end(), '\t')));
      if (i != 1u) {
        EXPECT_EQ(128u, cases[i].history_field.size());
        EXPECT_EQ(128u, cases[i].query_prefix.size());
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest,
     EmptyHistoryOptionPreservesCurrentQueryRejection) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const char delimiters[] = {'\t', '~'};
  const char invalid_bytes[] = {'\0', '\t', '\r', '\n', '~'};
  Json::Value slots(Json::objectValue);
  slots["name"] = "window";
  const Json::Value populated_histories =
      MakeEmptyHistorySingletonForTest(MakeProjectedHistory(
          "history query", "vehicle", "open_window", slots));

  for (size_t p = 0u; p < 2u; ++p) {
    SCOPED_TRACE(versions[p]);
    for (size_t d = 0u; d < 2u; ++d) {
      SCOPED_TRACE(d);
      ScopedCaptureDirectory directory;
      ASSERT_TRUE(directory.valid());
      const std::string catalog_path = directory.NewFile("catalog.json");
      directory.NewFile("protocol.json");
      const std::string root =
          catalog_path.substr(0u, catalog_path.find_last_of('/'));
      FakeTransport* fake = nullptr;
      std::unique_ptr<Nlu06BBackend> backend =
          MakeEmptyHistoryBackendForTest(
              root, versions[p],
              MakeEmptyHistoryProtocolForTest(
                  versions[p], "history:None", "query: ", delimiters[d]),
              &fake, delimiters[d]);
      ASSERT_TRUE(backend);

      for (size_t h = 0u; h < 2u; ++h) {
        SCOPED_TRACE(h);
        Nlu06BRequest request = MakeRequest();
        request.histories =
            h == 0u ? Json::Value() : populated_histories;
        request.query = "";
        Json::Value empty_result;
        EXPECT_NE(0, backend->Process(request, &empty_result));
        for (size_t b = 0u; b < sizeof(invalid_bytes); ++b) {
          if (invalid_bytes[b] == '~' && delimiters[d] != '~')
            continue;
          SCOPED_TRACE(b);
          std::string query("current");
          query.push_back(invalid_bytes[b]);
          query += "query";
          request.query = query;
          Json::Value result;
          EXPECT_NE(0, backend->Process(request, &result));
        }
      }
    }
  }
}

namespace {

std::string WriteV10FilesForTest(ScopedCaptureDirectory* directory,
                                bool allow_multi = true) {
  const std::string catalog_path = directory->NewFile("catalog.json");
  directory->NewFile("protocol.json");
  const std::string root = catalog_path.substr(0u, catalog_path.find_last_of('/'));
  WriteProfileFiles(root, "v10", "nlu_06b_v10", allow_multi);
  return root;
}

Nlu06BRequest MakeV10RequestForTest() {
  Nlu06BRequest request = MakeRequest();
  request.query = "current query";
  request.histories = Json::Value(Json::arrayValue);
  return request;
}

}  // namespace

TEST(Nlu06BHttpBackendTest, ProfileV10FixedNoneAndConfiguredPromptBytes) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "intelligent_car_control\tcancel_hud_set\tname=hud,mode=歌词",
      &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = u8"hud不显示歌词";
  const std::string query_bytes("hud\xE4\xB8\x8D\xE6\x98\xBE\xE7\xA4\xBA"
                                "\xE6\xAD\x8C\xE8\xAF\x8D");
  ASSERT_EQ(query_bytes, request.query);
  for (size_t i = 0u; i < 2u; ++i) {
    SCOPED_TRACE(i);
    request.histories = i == 0u ? Json::Value() : Json::Value(Json::arrayValue);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(request, &result));
    const Json::Value payload = ReadPayload(fake);
    const std::string wire = payload["messages"][1u]["content"].asString();
    EXPECT_EQ("history:None;query: " + query_bytes, wire);
    EXPECT_EQ(0x3bu, static_cast<unsigned char>(wire[12u]));
    EXPECT_EQ(0x3au, static_cast<unsigned char>(wire[7u]));
    EXPECT_EQ(std::string::npos, wire.find('\t'));
    EXPECT_EQ("qwen3_nlu", payload["model"].asString());
    const std::string system = payload["messages"][0u]["content"].asString();
    EXPECT_EQ(kV10SystemPromptForTest, system);
    EXPECT_NE(std::string::npos, system.find("unknown\xEF\xBC\x9B"));
    EXPECT_NE(std::string::npos, system.find(u8"标签" +
                                            std::string("\xEF\xBC\x9A") + "multi"));
    EXPECT_EQ(std::string::npos, system.find("unknown;"));
    EXPECT_FALSE(payload["stream"].asBool());
    EXPECT_FALSE(payload["enable_thinking"].asBool());
    EXPECT_FALSE(payload.isMember("chat_template_kwargs"));
    EXPECT_EQ(1200, fake->request_.connect_timeout_ms);
    EXPECT_EQ(3400, fake->request_.total_timeout_ms);
    EXPECT_EQ("歌词", result["frames"][0u]["slots"]["mode"].asString());
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10UsesChangedProfileValuesNotConstants) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  Json::Value catalog = JsonHelper::ParseJsonFromFile(root + "/catalog.json");
  catalog["profiles"]["v10"]["model"] = "other-configured-model";
  catalog["profiles"]["v10"]["system_prompt"] = "other configured prompt";
  catalog["profiles"]["v10"]["temperature"] = 0.6;
  catalog["profiles"]["v10"]["max_tokens"] = 123;
  catalog["profiles"]["v10"]["enable_thinking"] = true;
  {
    std::ofstream output((root + "/catalog.json").c_str());
    output << JsonHelper::ToString(catalog);
  }
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  const Json::Value payload = ReadPayload(fake);
  EXPECT_EQ("other-configured-model", payload["model"].asString());
  EXPECT_EQ("other configured prompt",
            payload["messages"][0u]["content"].asString());
  EXPECT_DOUBLE_EQ(0.6, payload["temperature"].asDouble());
  EXPECT_EQ(123, payload["max_tokens"].asInt());
  EXPECT_TRUE(payload["enable_thinking"].asBool());
}

TEST(Nlu06BHttpBackendTest, ProfileV10DocumentHistoryRowsAndAllProjectedOrder) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = u8"太阳晒的坐凳好热给我打开座椅通风";
  const std::string q1 = u8"现在的环境有点暗，能帮我把氛围灯调亮一点吗？";
  const std::string q2 = u8"列表中的歌曲，能不能设置成循环播放呢";
  Json::Value slots(Json::objectValue);
  slots["gear_direction"] = "调亮";
  Json::Value first = MakeProjectedHistory(q1, "intelligent_car_control",
                                          "atlights_control", slots);
  // V10 never serializes TTS, even when the legacy optional field is present.
  first["v3_nlu_semantics"][0u]["tts"] = "not sent";
  request.histories.append(first);
  const std::string first_row = q1 +
      "\tintelligent_car_control\tatlights_control\tgear_direction=调亮";
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:" + first_row + ";query: " + request.query,
            ReadPayload(fake)["messages"][1u]["content"].asString());

  request.histories.append(MakeProjectedHistory(
      q2, "music", "ctrl_list_cycle", Json::Value(Json::objectValue)));
  const std::string two_rows = first_row + ";" + q2 + "\tmusic\tctrl_list_cycle\t";
  ASSERT_EQ(0, backend->Process(request, &result));
  const std::string wire = ReadPayload(fake)["messages"][1u]["content"].asString();
  EXPECT_EQ("history:" + two_rows + ";query: " + request.query, wire);
  EXPECT_NE(std::string::npos, wire.find("ctrl_list_cycle\t;query: "));
  EXPECT_EQ(6, std::count(wire.begin(), wire.end(), '\t'));
  EXPECT_EQ(2, std::count(wire.begin(), wire.end(), ';'));
  EXPECT_EQ(std::string::npos, wire.find("not sent"));
  EXPECT_EQ(std::string::npos, wire.find("Query1"));

  // The backend does not add a second cap of one or two after projection.
  request.histories.append(MakeProjectedHistory(
      "third", "fm", "stop", Json::Value(Json::objectValue)));
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:" + two_rows + ";third\tfm\tstop\t;query: " + request.query,
            ReadPayload(fake)["messages"][1u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10CleansOnlyQueryControlBytesCallLocally) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = "current\t\r\n  query;keep：；＝";
  Json::Value slots(Json::objectValue);
  slots["zeta"] = "a=b|c";
  slots["alpha"] = "原样：；，＝";
  request.histories.append(MakeProjectedHistory(
      "past\t\r\n  query；", "music", "play", slots));
  const std::string saved_query = request.query;
  const std::string saved_histories = JsonHelper::ToString(request.histories);
  Json::Value result;
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:past     query；\tmusic\tplay\t"
            "alpha=原样：；，＝,zeta=a=b|c;query: current     query;keep：；＝",
            ReadPayload(fake)["messages"][1u]["content"].asString());
  EXPECT_EQ(saved_query, request.query);
  EXPECT_EQ(saved_histories, JsonHelper::ToString(request.histories));

  // Successful normalization is repeatable, never written back into a request.
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ(saved_query, request.query);
  EXPECT_EQ(saved_histories, JsonHelper::ToString(request.histories));
  request.query = "current\f\v query";
  request.histories = Json::Value();
  ASSERT_EQ(0, backend->Process(request, &result));
  EXPECT_EQ("history:None;query: current\f\v query",
            ReadPayload(fake)["messages"][1u]["content"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10RejectsMalformedHistoriesBeforeTransport) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  const Json::Value valid = MakeProjectedHistory(
      "past", "music", "play", Json::Value(Json::objectValue));
  std::vector<Json::Value> bad;
  bad.push_back(Json::Value());
  bad.push_back(Json::Value("row"));
  bad.push_back(Json::Value(Json::objectValue));
  Json::Value entry = valid;
  entry["v3_nlu_semantics"] = Json::Value(Json::arrayValue);
  bad.push_back(entry);
  entry["v3_nlu_semantics"] = "bad";
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"].append(valid["v3_nlu_semantics"][0u]);
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u] = "bad";
  bad.push_back(entry);
  const char* fields[] = {"query", "domain", "intent", "slots"};
  for (size_t i = 0u; i < 4u; ++i) {
    entry = valid;
    entry["v3_nlu_semantics"][0u].removeMember(fields[i]);
    bad.push_back(entry);
    entry = valid;
    entry["v3_nlu_semantics"][0u][fields[i]] = 7;
    bad.push_back(entry);
    entry = valid;
    entry["v3_nlu_semantics"][0u][fields[i]] = "";
    bad.push_back(entry);
  }
  const char collision_bytes[] = {';', '\t', '\r', '\n', '\0'};
  for (size_t f = 0u; f < 3u; ++f) {
    for (size_t b = 0u; b < 5u; ++b) {
      // Historical query TAB/CR/LF is cleaned, not rejected.
      if (f == 0u && b > 0u && b < 4u) continue;
      entry = valid;
      entry["v3_nlu_semantics"][0u][fields[f]] =
          std::string("a") + collision_bytes[b] + "b";
      bad.push_back(entry);
    }
  }
  const char* bad_keys[] = {"", "a=b", "a,b", "a;b", "a\tb", "a\rb", "a\nb"};
  for (size_t i = 0u; i < 7u; ++i) {
    entry = valid;
    entry["v3_nlu_semantics"][0u]["slots"][bad_keys[i]] = "value";
    bad.push_back(entry);
  }
  const char* bad_values[] = {"", "a,b", "a;b", "a\tb", "a\rb", "a\nb"};
  for (size_t i = 0u; i < 6u; ++i) {
    entry = valid;
    entry["v3_nlu_semantics"][0u]["slots"]["name"] = bad_values[i];
    bad.push_back(entry);
  }
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"]["name"] = std::string("a\0b", 3u);
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"]["name"] = 1;
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"][std::string("a\0b", 3u)] = "value";
  bad.push_back(entry);
  entry = valid;
  entry["v3_nlu_semantics"][0u]["slots"]["name"] = "   ";
  bad.push_back(entry);
  // Unknown training-history records are not synthesized or admitted here.
  entry = valid;
  entry["v3_nlu_semantics"][0u]["domain"] = "unknown";
  bad.push_back(entry);
  entry["v3_nlu_semantics"][0u].removeMember("intent");
  bad.push_back(entry);
  for (size_t i = 0u; i < bad.size(); ++i) {
    for (size_t position = 0u; position < 2u; ++position) {
      SCOPED_TRACE(i);
      SCOPED_TRACE(position);
      Nlu06BRequest request = MakeV10RequestForTest();
      request.histories.append(position == 0u ? bad[i] : valid);
      request.histories.append(position == 0u ? valid : bad[i]);
      const std::string saved = JsonHelper::ToString(request.histories);
      Json::Value result(Json::objectValue);
      result["stale"] = true;
      EXPECT_EQ(-1, backend->Process(request, &result));
      EXPECT_TRUE(result.isNull());
      EXPECT_EQ(saved, JsonHelper::ToString(request.histories));
      EXPECT_EQ(0, fake->post_count());
    }
  }
  const Json::Value wrong_arrays[] = {Json::Value("history"), Json::Value(1),
      Json::Value(false), Json::Value(Json::objectValue)};
  for (size_t i = 0u; i < 4u; ++i) {
    Nlu06BRequest request = MakeV10RequestForTest();
    request.histories = wrong_arrays[i];
    Json::Value result;
    EXPECT_EQ(-1, backend->Process(request, &result));
  }
  Nlu06BRequest request = MakeV10RequestForTest();
  request.query = std::string("a\0b", 3u);
  Json::Value result;
  EXPECT_EQ(-1, backend->Process(request, &result));
  EXPECT_EQ(0, fake->post_count());
}

TEST(Nlu06BHttpBackendTest, ProfileV10SingleNoSlotAndLosslessValues) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  const char* no_slots[] = {"fm\tstop", "fm\tstop\t",
      " \r\n\tfm\tstop\t \r\n\f\v", "intelligent_car_control\tset"};
  for (size_t i = 0u; i < 4u; ++i) {
    SCOPED_TRACE(i);
    fake->SetResponseBody(MakeEnvelope(no_slots[i]));
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
    ASSERT_EQ(1u, result["frames"].size());
    EXPECT_TRUE(result["frames"][0u]["slots"].isObject());
    EXPECT_TRUE(result["frames"][0u]["slots"].empty());
    EXPECT_FALSE(result["is_rejected"].asBool());
    EXPECT_FALSE(result["is_multi_intent"].asBool());
    EXPECT_EQ(no_slots[i], result["nlu_result"].asString());
  }
  const std::string content = "music\tplay\tsong=喀什葛尔的|原核,"
                              "payload=a=b=c|d,words=原样：；，＝";
  fake->SetResponseBody(MakeEnvelope(content));
  Json::Value result;
  ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
  EXPECT_EQ("喀什葛尔的|原核", result["frames"][0u]["slots"]["song"].asString());
  EXPECT_EQ("a=b=c|d", result["frames"][0u]["slots"]["payload"].asString());
  EXPECT_EQ("原样：；，＝", result["frames"][0u]["slots"]["words"].asString());
  EXPECT_TRUE(result["frames"][0u]["slots"]["song"].isString());
  EXPECT_EQ(content, result["nlu_result"].asString());
}

TEST(Nlu06BHttpBackendTest, ProfileV10MultiPrefixOnceAndIndependentOutputGate) {
  const char* responses[] = {
      "multi:fm\tplay\tcategory=搞笑段子;app_agent\tapp_call\tapp=航旅纵横",
      "multi:intelligent_car_control\tseat_position_control\tarea=座椅,"
      "gear_direction=向后,position=主驾;intelligent_car_control\tturn_on_device\t"
      "name=座椅加热,position=主驾;intelligent_car_control\tseat_massage_control\t"
      "position=主驾,time=20",
      "multi:fm\tstop\t;music\tplay\tsong=a|b,expression=x=y;help\thelp"};
  for (size_t gate = 0u; gate < 2u; ++gate) {
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string root = WriteV10FilesForTest(&directory, gate != 0u);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "v10", responses[0u], &fake);
    ASSERT_TRUE(backend);
    // Requests still contain only singleton historical semantics. The input
    // history policy and this output gate have independent responsibilities.
    Nlu06BRequest request = MakeProfileHistoryRequest();
    for (size_t i = 0u; i < 3u; ++i) {
      SCOPED_TRACE(gate);
      SCOPED_TRACE(i);
      fake->SetResponseBody(MakeEnvelope(responses[i]));
      Json::Value result;
      ASSERT_EQ(0, backend->Process(request, &result));
      EXPECT_EQ(gate == 0u, result["is_rejected"].asBool());
      EXPECT_EQ(gate != 0u, result["is_multi_intent"].asBool());
      EXPECT_EQ(gate == 0u ? "multi_intent_disabled" : "",
                result["reject_reason"].asString());
      EXPECT_EQ(gate == 0u ? 0u : (i == 0u ? 2u : 3u), result["frames"].size());
      if (gate != 0u && i == 2u) {
        EXPECT_EQ("a|b", result["frames"][1u]["slots"]["song"].asString());
        EXPECT_EQ("x=y", result["frames"][1u]["slots"]["expression"].asString());
      }
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10LeadingReasoningAndExactUnknown) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "unknown", &fake);
  ASSERT_TRUE(backend);
  const char* prefixes[] = {"", "<think></think>",
      " \n<think>analysis\nwith\ttabs</think>\r\n",
      "<reasoning>bounded analysis</reasoning>\n"};
  const char* payloads[] = {"unknown", "fm\tstop", "multi:fm\tstop;music\tplay"};
  for (size_t p = 0u; p < 4u; ++p) {
    for (size_t c = 0u; c < 3u; ++c) {
      SCOPED_TRACE(p);
      SCOPED_TRACE(c);
      const std::string raw = std::string(prefixes[p]) + payloads[c] + " \r\n";
      fake->SetResponseBody(MakeEnvelope(raw));
      Json::Value result;
      ASSERT_EQ(0, backend->Process(MakeV10RequestForTest(), &result));
      EXPECT_EQ(raw, result["nlu_result"].asString());
      EXPECT_EQ(c == 0u, result["is_rejected"].asBool());
      EXPECT_EQ(c == 0u ? "unknown" : "", result["reject_reason"].asString());
      EXPECT_EQ(c == 2u, result["is_multi_intent"].asBool());
      EXPECT_EQ(c == 0u ? 0u : (c == 1u ? 1u : 2u), result["frames"].size());
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10MalformedContentNeverReturnsPartialFrames) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
      root, "v10", "fm\tstop", &fake);
  ASSERT_TRUE(backend);
  const char* invalid[] = {
      "", " \r\n", "Unknown", "unknown!", "unknown\tfm", "flag:unknown",
      "fm", "\tstop", "fm\t\tname=window", "fm\tstop\tname=window\textra",
      "fm\tstop\tname", "fm\tstop\tname:", "fm\tstop\t=window",
      "fm\tstop\tname=", "fm\tstop\tname=   ,area=driver",
      "fm\tstop\tname=window,name=door",
      "fm\tstop\tname=window,", "fm\tstop\t,name=window",
      "fm\tstop\tname=window,,area=driver", "fm\tstop\tname=window,area:driver",
      "fm\tstop\tname：window", "fm\tstop\tname＝window",
      "fm\tstop\tname:window,area:driver", "fm\tstop\tname=window;area=driver",
      "fm\tstop;music\tplay", "multi:", "multi:fm\tstop", "multi:;fm\tstop",
      "multi:fm\tstop;", "multi:fm\tstop;;music\tplay",
      "multi:fm\tstop;unknown", "multi:unknown;fm\tstop",
      "multi:fm\tstop;multi:music\tplay", "multi:fm\tstop|music\tplay",
      "multi：fm\tstop;music\tplay", "multi:fm\tstop；music\tplay",
      "fm\tstop\tname=window;music\tplay", "multi:fm\tstop;music\tplay\tbad",
      "```\nfm\tstop\n```", "`fm\tstop`", "Here is the answer: fm\tstop",
      "fm\tstop explanation", "fm\tstop\nextra prose", "{fm\tstop}",
      "<think>unclosed", "<reasoning>unclosed", "</think>fm\tstop",
      "<think>x</reasoning>fm\tstop", "<think><think>x</think></think>fm\tstop",
      "<think><reasoning>x</reasoning></think>fm\tstop",
      "<reasoning><think>x</think></reasoning>fm\tstop",
      "<think>x</think><reasoning>y</reasoning>fm\tstop",
      "<think>x</think><think>y</think>fm\tstop", "<think>x</think>",
      "fm\tstop<think>x</think>", "fm\tstop\tname=<reasoning>x</reasoning>",
      "multi:fm\tstop;<think>x</think>music\tplay",
      "<think>x</think>Here is the answer: fm\tstop",
      "<think>x</think>```fm\tstop```"};
  for (size_t i = 0u; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
    SCOPED_TRACE(i);
    const std::string raw(invalid[i]);
    fake->SetResponseBody(MakeEnvelope(raw));
    Json::Value result(Json::objectValue);
    result["stale"] = true;
    EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
    ExpectDecodedContentFailure(result, raw);
  }
  const std::string nul = std::string("fm\tstop\tname=a") + '\0' + "b";
  fake->SetResponseBody(MakeEnvelope(nul));
  Json::Value result;
  EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
  ExpectDecodedContentFailure(result, nul);
  // Invalid multi output is not hidden by the disabled-output business gate.
  WriteProfileFiles(root, "v10", "nlu_06b_v10", false);
  backend = MakeProfileBackend(root, "v10", "multi:fm\tstop;music\tplay\tbad", &fake);
  ASSERT_TRUE(backend);
  EXPECT_EQ(-1, backend->Process(MakeV10RequestForTest(), &result));
  ExpectDecodedContentFailure(result, "multi:fm\tstop;music\tplay\tbad");
}

TEST(Nlu06BHttpBackendTest, ProfileV10RejectsConflictingMissingAndWrongTypeGrammar) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  // Assert codepoints and bytes, not merely visually similar glyphs.
  ASSERT_EQ(std::string(1u, static_cast<char>(0x09)), "\t");  // U+0009
  ASSERT_EQ(std::string(1u, static_cast<char>(0x3b)), u8";");  // U+003B
  ASSERT_EQ(std::string(1u, static_cast<char>(0x3a)), u8":");  // U+003A
  ASSERT_EQ(std::string(1u, static_cast<char>(0x3d)), u8"=");  // U+003D
  ASSERT_EQ(std::string("\xEF\xBC\x9B"), u8"；");  // U+FF1B
  ASSERT_EQ(std::string("\xEF\xBC\x9A"), u8"：");  // U+FF1A
  ASSERT_EQ(std::string("\xEF\xBC\x9D"), u8"＝");  // U+FF1D
  ASSERT_EQ(std::string("\xEF\xBC\x8C"), u8"，");  // U+FF0C
  const Json::Value valid = MakeProfileProtocol("nlu_06b_v10", Json::Value("="));
  std::vector<Json::Value> invalid;
  const char* fields[] = {"version", "request_field_prefixes", "field_delimiter",
      "request_slot_assignment", "request_slot_separator",
      "response_slot_assignment", "response_slot_separator",
      "response_frame_separator", "response_unknown_marker", "response_multi_marker"};
  const Json::Value wrong_types[] = {Json::Value(), Json::Value(1),
      Json::Value(false), Json::Value(Json::objectValue)};
  for (size_t f = 0u; f < sizeof(fields) / sizeof(fields[0]); ++f) {
    Json::Value missing = valid;
    missing.removeMember(fields[f]);
    invalid.push_back(missing);
    for (size_t t = 0u; t < 4u; ++t) {
      Json::Value changed = valid;
      changed[fields[f]] = wrong_types[t];
      invalid.push_back(changed);
    }
  }
  const char* delimiter_fields[] = {"field_delimiter", "request_slot_assignment",
      "request_slot_separator", "response_slot_assignment", "response_slot_separator",
      "response_frame_separator", "response_unknown_marker", "response_multi_marker"};
  const char* conflicts[] = {"|", ":", ";", ":=", ";", "|", "Unknown", "multi："};
  for (size_t f = 0u; f < 8u; ++f) {
    Json::Value changed = valid;
    changed[delimiter_fields[f]] = conflicts[f];
    invalid.push_back(changed);
    changed[delimiter_fields[f]] = "";
    invalid.push_back(changed);
    changed[delimiter_fields[f]] = Json::Value(Json::arrayValue);
    changed[delimiter_fields[f]].append(valid[delimiter_fields[f]]);
    invalid.push_back(changed);
  }
  Json::Value changed = valid;
  changed["request_field_prefixes"][0u] = "history：";
  invalid.push_back(changed);
  changed = valid;
  changed["request_field_prefixes"][1u] = "query:";
  invalid.push_back(changed);
  changed["request_field_prefixes"][1u] = 1;
  invalid.push_back(changed);
  changed = valid;
  changed["request_field_prefixes"].append("");
  invalid.push_back(changed);
  changed = valid;
  changed["request_field_prefixes"] = Json::Value(Json::arrayValue);
  invalid.push_back(changed);
  changed = valid;
  changed["response_frame_separator"] = "；";
  invalid.push_back(changed);
  changed = valid;
  changed["response_slot_assignment"] = "＝";
  invalid.push_back(changed);
  changed = valid;
  changed["response_slot_separator"] = "，";
  invalid.push_back(changed);
  changed = valid;
  changed["empty_history_request"] = Json::Value();
  invalid.push_back(changed);
  changed["empty_history_request"] = MakeEmptyHistoryOptionForTest("None", "query: ");
  invalid.push_back(changed);
  changed = valid;
  changed["response_flag_prefix"] = "flag:";
  invalid.push_back(changed);
  changed.removeMember("response_unknown_marker");
  changed.removeMember("response_multi_marker");
  invalid.push_back(changed);
  for (size_t i = 0u; i < invalid.size(); ++i) {
    SCOPED_TRACE(i);
    WriteProfileProtocol(root, invalid[i]);
    FakeTransport* fake = nullptr;
    EXPECT_FALSE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  }
  WriteProfileProtocol(root, valid);
  FakeTransport* fake = nullptr;
  EXPECT_TRUE(MakeProfileBackend(root, "v10", "fm\tstop", &fake));
  Json::Value flat = MakeConfig();
  flat["response_protocol"] = "nlu_06b_v10";
  EXPECT_FALSE(MakeBackend(flat, 0, 200, MakeEnvelope("fm\tstop"), &fake));
}

TEST(Nlu06BHttpBackendTest, ProfileV10DoesNotRelaxOlderNamedProfiles) {
  const char* versions[] = {"nlu_06b_v3", "nlu_06b_v4"};
  const char* invalid[] = {"fm\tstop", "unknown", "multi:fm\tstop;music\tplay",
      "`fm\tstop\t`", "fm\tstop\tname=window\textra"};
  for (size_t v = 0u; v < 2u; ++v) {
    ScopedCaptureDirectory directory;
    ASSERT_TRUE(directory.valid());
    const std::string root = WriteV10FilesForTest(&directory);
    WriteProfileFiles(root, "old", versions[v], true);
    FakeTransport* fake = nullptr;
    std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(
        root, "old", "flag:multi|fm\tstop\t|music\tplay\t", &fake);
    ASSERT_TRUE(backend);
    Json::Value result;
    ASSERT_EQ(0, backend->Process(MakeProfileHistoryRequest(), &result));
    EXPECT_EQ(2u, result["frames"].size());
    for (size_t i = 0u; i < 5u; ++i) {
      SCOPED_TRACE(v);
      SCOPED_TRACE(i);
      fake->SetResponseBody(MakeEnvelope(invalid[i]));
      EXPECT_EQ(-1, backend->Process(MakeProfileHistoryRequest(), &result));
      ExpectDecodedContentFailure(result, invalid[i]);
    }
  }
}

TEST(Nlu06BHttpBackendTest, ProfileV10PreservesRawCaptureAndSanitizedFailureIdentity) {
  ScopedCaptureDirectory directory;
  ASSERT_TRUE(directory.valid());
  const std::string root = WriteV10FilesForTest(&directory);
  const std::string capture_path = directory.NewFile("v10-capture.jsonl");
  Json::Value catalog = JsonHelper::ParseJsonFromFile(root + "/catalog.json");
  Json::Value& profile = catalog["profiles"]["v10"];
  profile["diagnostic_capture_enabled"] = true;
  profile["diagnostic_capture_output_path"] = capture_path;
  profile["diagnostic_capture_request_id_prefix"] = "v10-capture-";
  profile["diagnostic_capture_max_entries"] = 1;
  profile["diagnostic_capture_max_content_bytes"] = 1024;
  {
    std::ofstream output((root + "/catalog.json").c_str());
    output << JsonHelper::ToString(catalog);
  }
  const std::string raw = "<think>synthetic-private-analysis</think>"
                          "multi:fm\tstop;music\tplay\tbad";
  FakeTransport* fake = nullptr;
  std::unique_ptr<Nlu06BBackend> backend = MakeProfileBackend(root, "v10", raw, &fake);
  ASSERT_TRUE(backend);
  Nlu06BRequest request = MakeV10RequestForTest();
  request.request_id = "v10-capture-test";
  request.query = "synthetic-private-query";
  ScopedLogCapture logs;
  Json::Value result;
  ASSERT_EQ(-1, backend->Process(request, &result));
  ExpectDecodedContentFailure(result, raw);
  const std::vector<Json::Value> records = ReadCaptureRecords(capture_path);
  ASSERT_EQ(1u, records.size());
  EXPECT_EQ(raw, records[0u]["content"].asString());
  EXPECT_EQ("invalid_slot_pair", records[0u]["schema_detail"].asString());
  EXPECT_TRUE(records[0u]["parsed_result"].isNull());
  const std::string messages = logs.messages();
  EXPECT_NE(std::string::npos, messages.find("request_id=v10-capture-test"));
  EXPECT_NE(std::string::npos, messages.find("response_protocol=nlu_06b_v10"));
  EXPECT_NE(std::string::npos, messages.find("schema_detail=invalid_slot_pair"));
  EXPECT_EQ(std::string::npos, messages.find("synthetic-private-analysis"));
  EXPECT_EQ(std::string::npos, messages.find(request.query));
  EXPECT_EQ(std::string::npos, messages.find(kV10SystemPromptForTest));
  EXPECT_EQ(std::string::npos, messages.find(raw));
}

}  // namespace nlptk
