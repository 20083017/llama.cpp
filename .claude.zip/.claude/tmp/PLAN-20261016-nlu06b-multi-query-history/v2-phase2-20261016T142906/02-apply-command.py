PATCH_SHA='0dcc51737cfc4da192ae427ab5e963652f9ae39e448e56300a1279de3d66bec5'
import os,sys,json,base64,pathlib,subprocess,stat,shutil,hashlib
P=pathlib.Path('/home/daigd/dialogue')
F=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/v3_linux_offline_test.cc']
H='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert P.resolve(strict=True)==P, 'Project path mismatch'
for f in F:
 p=P/f
 assert not p.is_symlink() and p.resolve(strict=True)==p and p.is_file(), 'Product path escape/nonregular'
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_EXTERNAL_DIFF='')
G=['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-C',str(P)]
def git(args):
 r=subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==0, r.stderr.decode(errors='replace')
 return r.stdout
assert git(['rev-parse','HEAD']).decode().strip()==H, 'HEAD drift'
assert git(['symbolic-ref','--short','HEAD']).decode().strip()=='feat/v3-nlu-linux', 'Branch drift'
T=pathlib.Path('/home/daigd/.wtp184-transactions/PLAN-20261016-nlu06b-multi-query-history-v2-20261016T062908Z')
assert T.parent==pathlib.Path('/home/daigd/.wtp184-transactions')
assert T.name.startswith('PLAN-20261016-nlu06b-multi-query-history-v2-') and len(T.name)==len('PLAN-20261016-nlu06b-multi-query-history-v2-20261016T000000Z')
T.parent.mkdir(mode=0o700,exist_ok=True)
assert T.parent.resolve(strict=True)==T.parent and not T.exists(), 'Transaction escape/collision'
T.mkdir(mode=0o700);assert T.resolve(strict=True)==T
os.umask(0o077)
b=sys.stdin.buffer.read(50231);assert len(b)==50230 and len(b.splitlines())==1067
assert hashlib.sha256(b).hexdigest()==PATCH_SHA, 'Patch transfer mismatch'
print('PATCH TRANSFER SHA256 MATCH '+PATCH_SHA)
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'--- ')]==['a/'+f for f in F]
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'+++ ')]==['b/'+f for f in F]
patch=T/'v2.patch';patch.write_bytes(b)
assert not git(['status','--porcelain=v1','--untracked-files=all','--']+F), 'Scoped drift before apply'
meta={}
for f in F:
 p=P/f;original=p.read_bytes();assert original==git(['show','HEAD:'+f]), 'Preimage changed before apply'
 s=p.stat();meta[f]=(s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode))
 q=T/'preimages'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(p),str(q));assert q.read_bytes()==original
(T/'preimage-metadata.json').write_text(json.dumps(meta))
def patchrun(dry):
 args=['patch','--batch','--forward','--fuzz=0','--no-backup-if-mismatch','--reject-file='+str(T/'patch-rejects.txt'),'-p1','-i',str(patch)]
 if dry:args.insert(1,'--dry-run')
 r=subprocess.run(args,cwd=str(P),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 text=r.stdout.decode(errors='replace');name='dry-run' if dry else 'apply'
 (T/(name+'.log')).write_text(text);print(name+' EXIT '+str(r.returncode));print(text,end='')
 assert r.returncode==0, name+' failed'
 assert 'offset' not in text.lower() and 'fuzz' not in text.lower(), 'Patch did not match exact locations'
patchrun(True)
for f in F:assert (P/f).read_bytes()==(T/'preimages'/f).read_bytes(), 'Preimage drift after dry-run'
patchrun(False)
for f in F:
 s=(P/f).stat();assert (s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode))==meta[f], 'Product metadata changed'
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F), 'Unexpected staged changes'
assert git(['diff','--no-ext-diff','--no-textconv','--name-only','--']+F).decode().splitlines()==F, 'Scoped changed-name mismatch'
ws=subprocess.run(G+['diff','--no-ext-diff','--no-textconv','--check','--']+F,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
(T/'whitespace.log').write_bytes(ws.stdout);print('WHITESPACE EXIT '+str(ws.returncode));print(ws.stdout.decode(errors='replace'),end='');assert ws.returncode==0, 'Whitespace audit failed; owner correction required'
for label,args in [('scoped-status',['status','--porcelain=v1','--untracked-files=all','--']+F),('scoped-stat',['diff','--no-ext-diff','--no-textconv','--stat','--']+F),('scoped-numstat',['diff','--no-ext-diff','--no-textconv','--numstat','--']+F),('scoped-diff',['diff','--no-ext-diff','--no-textconv','--']+F)]:
 data=git(args);(T/(label+'.txt')).write_bytes(data)
 if label!='scoped-diff':print(label+' EXIT 0\n'+data.decode(),end='')
print('TRANSACTION '+str(T));print('METADATA PRESERVED; STAGED DIFF EMPTY; HEAD/BRANCH UNCHANGED')
