import os,sys,json,base64,pathlib,subprocess,stat,shutil,hashlib
P=pathlib.Path('/home/daigd/dialogue')
F=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/v3_linux_offline_test.cc']
H='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert P.resolve(strict=True)==P, 'Project path mismatch'
for f in F:
 p=P/f
 assert not p.is_symlink() and p.resolve(strict=True)==p and p.is_file(), 'Product path escape/nonregular'
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_EXTERNAL_DIFF='')
G=['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-C',str(P)]
def git(args):
 r=subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==0, r.stderr.decode(errors='replace')
 return r.stdout
assert git(['rev-parse','HEAD']).decode().strip()==H, 'HEAD drift'
assert git(['branch','--show-current']).decode().strip()=='feat/v3-nlu-linux', 'Branch drift'
S=git(['status','--porcelain=v1','--untracked-files=all','--']+F)
assert not S, 'Scoped preimage drift: '+S.decode()
assert not git(['diff','--no-ext-diff','--no-textconv','--']+F)
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F)
D={}
for f in F:
 b=(P/f).read_bytes();assert b==git(['show','HEAD:'+f]), 'Working preimage differs from HEAD'
 D[f]=base64.b64encode(b).decode()
print(json.dumps({'head':H,'branch':'feat/v3-nlu-linux','preimages':D}))
