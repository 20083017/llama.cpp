// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_V3_QUERY_HISTORY_POLICY_H_
#define CU_V3_QUERY_HISTORY_POLICY_H_

#include <cstddef>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "clu/common/query.h"
#include "cu/dialogue_request.h"
#include "cu/dialogue_response.h"
#include "dialog/context_manager.h"
#include "json/json.h"
#include "nlu/semantic_frames.h"

namespace nlptk {

int RestoreV3QueryHistory(
    const DialogueRequest& request, size_t max_query_records,
    dialog::ContextManager* context_manager,
    std::vector<std::shared_ptr<clu::Query> >* queries);

int StoreV3QueryHistory(
    bool frames_transferred, bool after_process_succeeded,
    bool history_eligible, size_t max_query_records,
    dialog::ContextManager* context_manager, DialogueResponse* response);

int BuildV3NluHistorySemantics(const std::string& query,
                               const nlu::SemanticFrames& frames,
                               Json::Value* semantics);
int AttachV3NluHistorySemantics(const Json::Value& semantics,
                                clu::Query* query);
int ProjectV3QueryHistories(
    const std::vector<std::shared_ptr<clu::Query> >& queries,
    const std::string& current_request_id, size_t max_history_rounds,
    size_t max_history_bytes, bool allow_multi_intent_input,
    Json::Value* histories, Json::Value* selected_semantics);
int BuildV3ModelLastContext(
    const std::map<std::string, std::string>& context_variables,
    const Json::Value& selected_semantics, Json::Value* model_last_context);

}  // namespace nlptk

#endif  // CU_V3_QUERY_HISTORY_POLICY_H_
