// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/v3_query_history_policy.h"

#include <atomic>
#include <chrono>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "cu/dialogue_request.h"
#include "cu/dialogue_response.h"
#include "dialog/local_context_manager.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace {

class SharedFakeClock : public dialog::LocalContextClock {
 public:
  SharedFakeClock() : now_ms_(0) {}

  int64_t NowSeconds() const override { return now_ms_.load() / 1000; }
  void SetMs(int64_t now_ms) { now_ms_.store(now_ms); }

 private:
  std::atomic<int64_t> now_ms_;
};

Json::Value LocalConfig() {
  Json::Value config(Json::objectValue);
  config["interval"] = 3600;
  config["expire_strategy"]["user_session"] = 10;
  config["expire_strategy"]["llm_simple_cache"] = -1;
  config["expire_strategy"]["query_records"] = 5;
  return config;
}

DialogueRequest MakeRequest(const std::string& id,
                            bool first_wakeup = false) {
  DialogueRequest request;
  request.id = id;
  request.session_id = "linux-offline-session";
  request.query = "query-" + id;
  request.first_wakeup = first_wakeup;
  return request;
}

void AttachSingleSemantic(const std::string& domain,
                          const std::string& intent,
                          const std::shared_ptr<clu::Query>& query) {
  ASSERT_TRUE(query);
  Json::Value semantic(Json::objectValue);
  semantic["domain"] = domain;
  semantic["intent"] = intent;
  semantic["query"] = query->GetQuery();
  semantic["slots"] = Json::Value(Json::objectValue);
  Json::Value semantics(Json::arrayValue);
  semantics.append(semantic);
  ASSERT_EQ(0, AttachV3NluHistorySemantics(semantics, query.get()));
}

std::vector<std::shared_ptr<clu::Query> > Restore(
    const DialogueRequest& request, size_t capacity,
    const std::shared_ptr<dialog::ContextManager>& context_manager) {
  std::vector<std::shared_ptr<clu::Query> > queries;
  EXPECT_EQ(0, RestoreV3QueryHistory(request, capacity,
                                     context_manager.get(), &queries));
  return queries;
}

int StoreRestoredCurrent(
    const DialogueRequest& request, size_t capacity,
    const std::shared_ptr<dialog::ContextManager>& context_manager,
    const std::vector<std::shared_ptr<clu::Query> >& queries) {
  DialogueResponse response;
  response.request_id = request.id;
  response.session_id = request.session_id;
  response.query_histories = queries;
  return StoreV3QueryHistory(true, true, true, capacity,
                             context_manager.get(), &response);
}

TEST(V3LinuxOfflineTest,
     ConfiguredLocalManagerStoresOrdersCapsAndProjectsWithoutRepository) {
  std::shared_ptr<SharedFakeClock> clock(new SharedFakeClock());
  std::shared_ptr<dialog::LocalContextManager> local(
      new dialog::LocalContextManager(clock));
  ASSERT_EQ(0, local->Initialize(LocalConfig()));
  std::shared_ptr<dialog::ContextManager> context = local;

  const char* ids[] = {"first", "second", "third"};
  for (size_t index = 0; index < 3u; ++index) {
    const DialogueRequest request = MakeRequest(ids[index]);
    std::vector<std::shared_ptr<clu::Query> > queries =
        Restore(request, 2u, context);
    ASSERT_FALSE(queries.empty());
    queries.back()->SetTimeStamp(
        std::chrono::milliseconds(static_cast<int64_t>(index + 1u) * 10));
    AttachSingleSemantic("domain-" + std::string(ids[index]),
                         "intent-" + std::string(ids[index]),
                         queries.back());
    ASSERT_EQ(0, StoreRestoredCurrent(request, 2u, context, queries));
  }

  const DialogueRequest fourth = MakeRequest("fourth");
  const std::vector<std::shared_ptr<clu::Query> > restored =
      Restore(fourth, 2u, context);
  ASSERT_EQ(3u, restored.size());
  EXPECT_EQ("second", restored[0]->GetRequestId());
  EXPECT_EQ("third", restored[1]->GetRequestId());
  EXPECT_EQ("fourth", restored[2]->GetRequestId());

  Json::Value histories;
  Json::Value selected;
  ASSERT_EQ(0, ProjectV3QueryHistories(restored, fourth.id, 2u, 65536u,
                                      false, &histories, &selected));
  ASSERT_EQ(2u, histories.size());
  EXPECT_EQ("second", histories[0u]["id"].asString());
  EXPECT_EQ("third", histories[1u]["id"].asString());
  ASSERT_EQ(1u, selected.size());
  EXPECT_EQ("domain-third", selected[0u]["domain"].asString());
}

TEST(V3LinuxOfflineTest, ConfiguredQueryTtlIsRenewedOnlyByStore) {
  std::shared_ptr<SharedFakeClock> clock(new SharedFakeClock());
  std::shared_ptr<dialog::LocalContextManager> local(
      new dialog::LocalContextManager(clock));
  ASSERT_EQ(0, local->Initialize(LocalConfig()));
  std::shared_ptr<dialog::ContextManager> context = local;

  const DialogueRequest stored = MakeRequest("stored");
  std::vector<std::shared_ptr<clu::Query> > stored_queries =
      Restore(stored, 2u, context);
  AttachSingleSemantic("vehicle", "open", stored_queries.back());
  ASSERT_EQ(0, StoreRestoredCurrent(stored, 2u, context, stored_queries));

  clock->SetMs(4999);
  EXPECT_EQ(2u, Restore(MakeRequest("before"), 2u, context).size());

  clock->SetMs(5000);
  const std::vector<std::shared_ptr<clu::Query> > expired =
      Restore(MakeRequest("expired"), 2u, context);
  ASSERT_EQ(1u, expired.size());
  EXPECT_EQ("expired", expired[0]->GetRequestId());
}

TEST(V3LinuxOfflineTest, EveryFirstWakeupClearsConfiguredManagerHistory) {
  std::shared_ptr<SharedFakeClock> clock(new SharedFakeClock());
  std::shared_ptr<dialog::LocalContextManager> local(
      new dialog::LocalContextManager(clock));
  ASSERT_EQ(0, local->Initialize(LocalConfig()));
  std::shared_ptr<dialog::ContextManager> context = local;

  const DialogueRequest stored = MakeRequest("stored");
  std::vector<std::shared_ptr<clu::Query> > stored_queries =
      Restore(stored, 2u, context);
  AttachSingleSemantic("vehicle", "open", stored_queries.back());
  ASSERT_EQ(0, StoreRestoredCurrent(stored, 2u, context, stored_queries));

  const DialogueRequest wake = MakeRequest("wake", true);
  std::vector<std::shared_ptr<clu::Query> > wake_queries =
      Restore(wake, 2u, context);
  ASSERT_EQ(1u, wake_queries.size());
  EXPECT_TRUE(wake_queries[0]->IsFirstWakeUp());
  AttachSingleSemantic("vehicle", "wake", wake_queries.back());
  ASSERT_EQ(0, StoreRestoredCurrent(wake, 2u, context, wake_queries));

  const std::vector<std::shared_ptr<clu::Query> > repeated =
      Restore(wake, 2u, context);
  ASSERT_EQ(1u, repeated.size());
  EXPECT_EQ("wake", repeated[0]->GetRequestId());
  EXPECT_TRUE(repeated[0]->IsFirstWakeUp());
}

}  // namespace
}  // namespace nlptk
