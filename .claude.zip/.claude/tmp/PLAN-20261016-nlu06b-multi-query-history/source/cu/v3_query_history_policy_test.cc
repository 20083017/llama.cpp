// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/v3_query_history_policy.h"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "base/json_helper.h"
#include "common/simple_semantic.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace {

class FakeContextManager : public dialog::ContextManager {
 public:
  FakeContextManager()
      : reverse_reads(false),
        hset_result(0),
        hget_calls(0),
        hset_calls(0),
        successful_hsets(0),
        hdel_calls(0),
        del_calls(0),
        last_type(dialog::ContextManager::kUserSession) {}

  int Initialize(const std::string&) override { return 0; }
  int Initialize(const Json::Value&) override { return 0; }
  int Get(const std::string&, std::vector<dialog::Turn*>* session) const override {
    session->clear();
    return 0;
  }
  int Put(const std::string&,
          const std::vector<dialog::Turn*>&) override { return 0; }
  int Get(const std::string& key, std::string* value) const override {
    events.push_back("get:" + key);
    const std::map<std::string, std::string>::const_iterator found =
        values.find(key);
    *value = found == values.end() ? std::string() : found->second;
    return 0;
  }
  int Put(const std::string& key, const std::string& value,
          const ContextType&) override {
    values[key] = value;
    return 0;
  }
  int ZGet(const std::string&, int,
           std::vector<std::string>* output) const override {
    output->clear();
    return 0;
  }
  int ZAdd(const std::string&, const std::string&, double,
           const ContextType&) override { return 0; }

  int HGet(const std::string& key,
           std::vector<std::string>* output) const override {
    events.push_back("hget:" + key);
    ++hget_calls;
    output->clear();
    const std::map<std::string, std::map<std::string, std::string> >::
        const_iterator bucket = hashes.find(key);
    if (bucket == hashes.end()) {
      return 0;
    }
    for (std::map<std::string, std::string>::const_iterator it =
             bucket->second.begin();
         it != bucket->second.end(); ++it) {
      output->push_back(it->second);
    }
    if (reverse_reads) {
      std::reverse(output->begin(), output->end());
    }
    return 0;
  }

  int HSet(const std::string& key, const std::string& field,
           const std::string& value, const ContextType& type) override {
    events.push_back("hset:" + key + ":" + field);
    ++hset_calls;
    if (hset_result < 0) {
      return hset_result;
    }
    hashes[key][field] = value;
    ++successful_hsets;
    last_type = type;
    return 0;
  }

  int HDel(const std::string& key, const std::string& field) override {
    events.push_back("hdel:" + key + ":" + field);
    ++hdel_calls;
    hashes[key].erase(field);
    if (hashes[key].empty()) {
      hashes.erase(key);
    }
    return 0;
  }

  int Del(const std::string& key) override {
    events.push_back("del:" + key);
    ++del_calls;
    hashes.erase(key);
    return 0;
  }

  void Seed(const std::string& key, const std::string& field,
            const std::string& value) {
    hashes[key][field] = value;
  }
  size_t HashSize(const std::string& key) const {
    const std::map<std::string, std::map<std::string, std::string> >::
        const_iterator found = hashes.find(key);
    return found == hashes.end() ? 0u : found->second.size();
  }
  std::string Stored(const std::string& key, const std::string& field) const {
    const std::map<std::string, std::map<std::string, std::string> >::
        const_iterator bucket = hashes.find(key);
    if (bucket == hashes.end()) return std::string();
    const std::map<std::string, std::string>::const_iterator value =
        bucket->second.find(field);
    return value == bucket->second.end() ? std::string() : value->second;
  }

  bool reverse_reads;
  int hset_result;
  mutable int hget_calls;
  int hset_calls;
  int successful_hsets;
  int hdel_calls;
  int del_calls;
  ContextType last_type;
  mutable std::vector<std::string> events;
  std::map<std::string, std::string> values;
  std::map<std::string, std::map<std::string, std::string> > hashes;
};

DialogueRequest MakeRequest(const std::string& id,
                            bool first_wakeup = false) {
  DialogueRequest request;
  request.id = id;
  request.session_id = "session";
  request.query = "query-" + id;
  request.first_wakeup = first_wakeup;
  return request;
}

Json::Value MakeSemantics(
    const std::vector<std::pair<std::string, std::string> >& values) {
  Json::Value semantics(Json::arrayValue);
  for (const std::pair<std::string, std::string>& value : values) {
    Json::Value semantic(Json::objectValue);
    semantic["domain"] = value.first;
    semantic["intent"] = value.second;
    semantic["query"] = "query-" + value.first;
    semantic["slots"] = Json::Value(Json::objectValue);
    semantics.append(semantic);
  }
  return semantics;
}

std::shared_ptr<clu::Query> MakeHistoryQuery(
    const std::string& id, int64_t timestamp,
    const Json::Value& semantics) {
  std::shared_ptr<clu::Query> query(new clu::Query("query-" + id));
  query->SetRequestId(id);
  query->SetTimeStamp(std::chrono::milliseconds(timestamp));
  EXPECT_EQ(0, AttachV3NluHistorySemantics(semantics, query.get()));
  return query;
}

std::string Serialize(const std::shared_ptr<clu::Query>& query) {
  return JsonHelper::ToString(query->Serialize());
}

DialogueResponse MakeResponse(
    const DialogueRequest& request,
    const std::vector<std::shared_ptr<clu::Query> >& queries) {
  DialogueResponse response;
  response.request_id = request.id;
  response.session_id = request.session_id;
  response.query_histories = queries;
  return response;
}

std::vector<std::shared_ptr<clu::Query> > Restore(
    FakeContextManager* context, const DialogueRequest& request,
    size_t capacity) {
  std::vector<std::shared_ptr<clu::Query> > queries;
  EXPECT_EQ(0, RestoreV3QueryHistory(request, capacity, context, &queries));
  return queries;
}

int Store(FakeContextManager* context, const DialogueRequest& request,
          size_t capacity,
          const std::vector<std::shared_ptr<clu::Query> >& queries,
          bool eligible = true) {
  DialogueResponse response = MakeResponse(request, queries);
  return StoreV3QueryHistory(true, true, eligible, capacity, context,
                             &response);
}

TEST(V3QueryHistoryPolicyTest, Q1Q2Q3StoresExactCapacityAfterHSet) {
  FakeContextManager context;
  const char* ids[] = {"q1", "q2", "q3"};
  for (size_t index = 0; index < 3u; ++index) {
    const DialogueRequest request = MakeRequest(ids[index]);
    std::vector<std::shared_ptr<clu::Query> > queries =
        Restore(&context, request, 2u);
    queries.back()->SetTimeStamp(
        std::chrono::milliseconds(static_cast<int64_t>(index + 1u) * 10));
    ASSERT_EQ(0, AttachV3NluHistorySemantics(
                     MakeSemantics({{"domain-" + std::string(ids[index]),
                                     "intent"}}),
                     queries.back().get()));
    ASSERT_EQ(0, Store(&context, request, 2u, queries));
  }

  EXPECT_EQ(2u, context.HashSize("Query:session"));
  EXPECT_TRUE(context.Stored("Query:session", "q1").empty());
  EXPECT_FALSE(context.Stored("Query:session", "q2").empty());
  EXPECT_FALSE(context.Stored("Query:session", "q3").empty());
  ASSERT_GE(context.events.size(), 2u);
  EXPECT_EQ("hset:Query:session:q3",
            context.events[context.events.size() - 2u]);
  EXPECT_EQ("hdel:Query:session:q1", context.events.back());

  const std::vector<std::shared_ptr<clu::Query> > next =
      Restore(&context, MakeRequest("q4"), 2u);
  ASSERT_EQ(3u, next.size());
  EXPECT_EQ("q2", next[0]->GetRequestId());
  EXPECT_EQ("q3", next[1]->GetRequestId());
  EXPECT_EQ("q4", next[2]->GetRequestId());
}

TEST(V3QueryHistoryPolicyTest,
     EveryFirstWakeupClearsAndOnlyEligibleHSetRecreates) {
  FakeContextManager context;
  context.Seed("Query:session", "old",
               Serialize(MakeHistoryQuery(
                   "old", 1, MakeSemantics({{"old", "old"}}))));
  const DialogueRequest wake = MakeRequest("wake", true);
  std::vector<std::shared_ptr<clu::Query> > queries =
      Restore(&context, wake, 4u);
  ASSERT_EQ(1u, queries.size());
  EXPECT_TRUE(queries.back()->IsFirstWakeUp());
  EXPECT_EQ(1, context.del_calls);
  EXPECT_EQ(0u, context.HashSize("Query:session"));

  EXPECT_EQ(1, Store(&context, wake, 4u, queries, false));
  EXPECT_EQ(0, context.hset_calls);
  EXPECT_EQ(0u, context.HashSize("Query:session"));

  ASSERT_EQ(0, AttachV3NluHistorySemantics(
                   MakeSemantics({{"vehicle", "wake"}}),
                   queries.back().get()));
  ASSERT_EQ(0, Store(&context, wake, 4u, queries));
  EXPECT_EQ(1u, context.HashSize("Query:session"));

  const std::vector<std::shared_ptr<clu::Query> > repeated =
      Restore(&context, wake, 4u);
  ASSERT_EQ(1u, repeated.size());
  EXPECT_EQ(2, context.del_calls);
  EXPECT_EQ(0u, context.HashSize("Query:session"));
}

TEST(V3QueryHistoryPolicyTest, SameIdUpsertsAndIsExcludedFromItsRestore) {
  FakeContextManager context;
  const DialogueRequest request = MakeRequest("same");
  std::vector<std::shared_ptr<clu::Query> > first =
      Restore(&context, request, 4u);
  first.back()->SetTimeStamp(std::chrono::milliseconds(10));
  ASSERT_EQ(0, AttachV3NluHistorySemantics(
                   MakeSemantics({{"vehicle", "first"}}),
                   first.back().get()));
  ASSERT_EQ(0, Store(&context, request, 4u, first));

  std::vector<std::shared_ptr<clu::Query> > repeated =
      Restore(&context, request, 4u);
  ASSERT_EQ(1u, repeated.size());
  EXPECT_EQ("same", repeated.back()->GetRequestId());
  repeated.back()->SetResponse("updated");
  repeated.back()->SetTimeStamp(std::chrono::milliseconds(20));
  ASSERT_EQ(0, AttachV3NluHistorySemantics(
                   MakeSemantics({{"vehicle", "updated"}}),
                   repeated.back().get()));
  ASSERT_EQ(0, Store(&context, request, 4u, repeated));
  EXPECT_EQ(1u, context.HashSize("Query:session"));
  EXPECT_EQ(2, context.successful_hsets);

  const Json::Value stored = JsonHelper::ParseJsonFromString(
      context.Stored("Query:session", "same"));
  EXPECT_EQ("updated", stored["response"].asString());
}

TEST(V3QueryHistoryPolicyTest, OnlySuccessfulEligibleHSetRenewsQueryTtl) {
  FakeContextManager context;
  context.Seed("Query:session", "old",
               Serialize(MakeHistoryQuery(
                   "old", 1, MakeSemantics({{"old", "old"}}))));
  const DialogueRequest request = MakeRequest("current");
  std::vector<std::shared_ptr<clu::Query> > queries =
      Restore(&context, request, 1u);
  ASSERT_EQ(2u, queries.size());
  EXPECT_EQ(1, context.hget_calls);
  EXPECT_EQ(0, context.successful_hsets);

  DialogueResponse response = MakeResponse(request, queries);
  EXPECT_EQ(1, StoreV3QueryHistory(true, true, false, 1u, &context,
                                   &response));
  EXPECT_EQ(1, StoreV3QueryHistory(false, true, true, 1u, &context,
                                   &response));
  EXPECT_EQ(0, context.hset_calls);
  EXPECT_EQ(0, context.successful_hsets);

  ASSERT_EQ(0, AttachV3NluHistorySemantics(
                   MakeSemantics({{"vehicle", "current"}}),
                   queries.back().get()));
  DialogueResponse eligible_response = MakeResponse(request, queries);
  ASSERT_EQ(0, StoreV3QueryHistory(true, true, true, 1u, &context,
                                   &eligible_response));
  EXPECT_EQ(1, context.successful_hsets);
  EXPECT_EQ(1, context.hdel_calls);
  EXPECT_EQ(dialog::ContextManager::KQueryRecords, context.last_type);

  const int renewals = context.successful_hsets;
  const std::vector<std::shared_ptr<clu::Query> > wake =
      Restore(&context, MakeRequest("wake", true), 1u);
  EXPECT_EQ(1u, wake.size());
  EXPECT_EQ(renewals, context.successful_hsets);

  FakeContextManager failure;
  std::vector<std::shared_ptr<clu::Query> > failed_queries =
      Restore(&failure, request, 1u);
  ASSERT_EQ(0, AttachV3NluHistorySemantics(
                   MakeSemantics({{"vehicle", "current"}}),
                   failed_queries.back().get()));
  failure.hset_result = -1;
  EXPECT_LT(Store(&failure, request, 1u, failed_queries), 0);
  EXPECT_EQ(1, failure.hset_calls);
  EXPECT_EQ(0, failure.successful_hsets);
  EXPECT_EQ(0, failure.hdel_calls);
}

TEST(V3QueryHistoryPolicyTest,
     ScrambledBackendOrderHasDeterministicParityAndMergesClientHistory) {
  FakeContextManager forward;
  FakeContextManager reverse;
  reverse.reverse_reads = true;
  const std::shared_ptr<clu::Query> b = MakeHistoryQuery(
      "b", 10, MakeSemantics({{"domain-b", "intent-b"}}));
  const std::shared_ptr<clu::Query> a = MakeHistoryQuery(
      "a", 10, MakeSemantics({{"domain-a", "intent-a"}}));
  const std::shared_ptr<clu::Query> c = MakeHistoryQuery(
      "c", 20, MakeSemantics({{"domain-c", "intent-c"}}));
  const std::shared_ptr<clu::Query> self = MakeHistoryQuery(
      "current", 30,
      MakeSemantics({{"wrong-self", "wrong-self"}}));
  FakeContextManager* contexts[] = {&forward, &reverse};
  for (size_t index = 0; index < 2u; ++index) {
    contexts[index]->Seed("Query:session", "b", Serialize(b));
    contexts[index]->Seed("Query:session", "a", Serialize(a));
    contexts[index]->Seed("Query:session", "c", Serialize(c));
    contexts[index]->Seed("Query:session", "current", Serialize(self));
    contexts[index]->values["SubQuery:session"] =
        "query-c->|client-child|";
  }
  DialogueRequest request = MakeRequest("current");
  HistoryQA direct;
  direct.request_id = "b";
  direct.response = "direct-response";
  request.histories.push_back(direct);
  HistoryQA child;
  child.query = "client-child";
  child.response = "child-response";
  request.histories.push_back(child);

  const std::vector<std::shared_ptr<clu::Query> > first =
      Restore(&forward, request, 8u);
  const std::vector<std::shared_ptr<clu::Query> > second =
      Restore(&reverse, request, 8u);
  ASSERT_EQ(4u, first.size());
  ASSERT_EQ(first.size(), second.size());
  for (size_t index = 0; index < first.size(); ++index) {
    EXPECT_EQ(first[index]->GetRequestId(), second[index]->GetRequestId());
  }
  EXPECT_EQ("a", first[0]->GetRequestId());
  EXPECT_EQ("b", first[1]->GetRequestId());
  EXPECT_EQ("c", first[2]->GetRequestId());
  EXPECT_EQ("current", first[3]->GetRequestId());
  EXPECT_EQ("direct-response", first[1]->GetResponse());
  EXPECT_EQ("child-response", first[2]->GetResponse());
}

TEST(V3QueryHistoryPolicyTest,
     ProjectionSkipsIneligibleSensitiveRejectedAndIncompleteRecords) {
  std::vector<std::shared_ptr<clu::Query> > queries;
  queries.push_back(MakeHistoryQuery(
      "eligible", 1,
      MakeSemantics({{"navigation", "navigate"}})));
  std::shared_ptr<clu::Query> incomplete(new clu::Query("incomplete"));
  incomplete->SetRequestId("incomplete");
  incomplete->SetExtraData("v3_nlu_semantics", "not-json");
  queries.push_back(incomplete);
  std::shared_ptr<clu::Query> expired = MakeHistoryQuery(
      "expired", 3, MakeSemantics({{"expired", "expired"}}));
  expired->UpdateStatus(clu::Query::Status::kLlmExpried);
  queries.push_back(expired);
  std::shared_ptr<clu::Query> rejected = MakeHistoryQuery(
      "rejected", 4, MakeSemantics({{"other", "other"}}));
  rejected->UpdateStatus(clu::Query::Status::kRejected);
  queries.push_back(rejected);
  queries.push_back(MakeHistoryQuery(
      "sensitive", 5,
      MakeSemantics({{"sensitive", "sensitive"}})));
  std::shared_ptr<clu::Query> current(new clu::Query("current"));
  current->SetRequestId("current");
  queries.push_back(current);

  Json::Value histories;
  Json::Value selected;
  ASSERT_EQ(0, ProjectV3QueryHistories(
                   queries, "current", 4u, 65536u, true,
                   &histories, &selected));
  ASSERT_EQ(1u, histories.size());
  EXPECT_EQ("eligible", histories[0u]["id"].asString());
  ASSERT_EQ(1u, selected.size());
  EXPECT_EQ("navigation", selected[0u]["domain"].asString());
}

TEST(V3QueryHistoryPolicyTest,
     MultiRoundProjectionUsesCumulativeBytesAndEmitsOldestToNewest) {
  std::vector<std::shared_ptr<clu::Query> > queries;
  std::shared_ptr<clu::Query> q1 = MakeHistoryQuery(
      "q1", 1, MakeSemantics({{"domain-q1", "intent-q1"}}));
  std::shared_ptr<clu::Query> q2 = MakeHistoryQuery(
      "q2", 2, MakeSemantics({{"domain-q2", "intent-q2"}}));
  std::shared_ptr<clu::SimpleSemantic> legacy(new clu::SimpleSemantic());
  legacy->domain = "legacy-domain";
  legacy->intent = "legacy-intent";
  legacy->query = "legacy-query";
  q2->SetLastSemantic(legacy);
  std::shared_ptr<clu::Query> q3 = MakeHistoryQuery(
      "q3", 3, MakeSemantics({{"domain-q3", "intent-q3"}}));
  std::shared_ptr<clu::Query> current(new clu::Query("current"));
  current->SetRequestId("current");
  queries.push_back(q1);
  queries.push_back(q2);
  queries.push_back(q3);
  queries.push_back(current);

  Json::Value full;
  Json::Value selected;
  ASSERT_EQ(0, ProjectV3QueryHistories(
                   queries, "current", 3u, 65536u, false,
                   &full, &selected));
  ASSERT_EQ(3u, full.size());
  EXPECT_EQ("q1", full[0u]["id"].asString());
  EXPECT_EQ("q2", full[1u]["id"].asString());
  EXPECT_EQ("q3", full[2u]["id"].asString());
  const size_t newest_two_bytes =
      JsonHelper::ToString(full[1u]).size() +
      JsonHelper::ToString(full[2u]).size();

  Json::Value bounded;
  ASSERT_EQ(0, ProjectV3QueryHistories(
                   queries, "current", 3u, newest_two_bytes, false,
                   &bounded, &selected));
  ASSERT_EQ(2u, bounded.size());
  EXPECT_EQ("q2", bounded[0u]["id"].asString());
  EXPECT_EQ("q3", bounded[1u]["id"].asString());
  EXPECT_FALSE(bounded[0u].isMember("last_semantic"));
  ASSERT_TRUE(q2->GetLastSemantic());
  EXPECT_EQ("legacy-domain", q2->GetLastSemantic()->domain);
  ASSERT_EQ(1u, selected.size());
  EXPECT_EQ("domain-q3", selected[0u]["domain"].asString());

  Json::Value one_round;
  ASSERT_EQ(0, ProjectV3QueryHistories(
                   queries, "current", 1u, 65536u, false,
                   &one_round, &selected));
  ASSERT_EQ(1u, one_round.size());
  EXPECT_EQ("q3", one_round[0u]["id"].asString());
}

TEST(V3QueryHistoryPolicyTest,
     ModelLastContextRebuildsOneCoherentGroupAndPreservesUnrelatedValues) {
  Json::Value selected =
      MakeSemantics({{"navigation", "navigate"}});
  selected[0u]["slots"]["poi"] = "home";
  std::map<std::string, std::string> variables;
  variables["last_semantic"] = "stale";
  variables["last_domain"] = "music";
  variables["last_intent"] = "play";
  variables["last_slot_artist"] = "stale";
  variables["last_slots_size"] = "4";
  variables["last_response"] = "preserved-response";
  variables["last_query"] = "preserved-query";
  variables["last_query.microphone.position"] = "driver";
  variables["first_wakeup"] = "false";

  Json::Value context;
  ASSERT_EQ(0, BuildV3ModelLastContext(variables, selected, &context));
  EXPECT_EQ("navigation", context["last_domain"].asString());
  EXPECT_EQ("navigate", context["last_intent"].asString());
  EXPECT_EQ("home", context["last_slot_poi"].asString());
  EXPECT_EQ("1", context["last_slots_size"].asString());
  EXPECT_FALSE(context.isMember("last_slot_artist"));
  EXPECT_EQ("navigation",
            context["last_semantic"]["domain"].asString());
  EXPECT_EQ("preserved-response",
            context["last_response"].asString());
  EXPECT_EQ("preserved-query", context["last_query"].asString());
  EXPECT_EQ("driver",
            context["last_query.microphone.position"].asString());
  EXPECT_EQ("false", context["first_wakeup"].asString());
}

TEST(V3QueryHistoryPolicyTest,
     AllowedNewestMultiIntentKeepsArrayAndLeavesSingularGroupEmpty) {
  const Json::Value expected = MakeSemantics(
      {{"music", "play"}, {"vehicle", "open"}});
  std::vector<std::shared_ptr<clu::Query> > queries;
  queries.push_back(MakeHistoryQuery(
      "older", 1, MakeSemantics({{"navigation", "navigate"}})));
  queries.push_back(MakeHistoryQuery("multi", 2, expected));
  std::shared_ptr<clu::Query> current(new clu::Query("current"));
  current->SetRequestId("current");
  queries.push_back(current);
  Json::Value histories;
  Json::Value selected;
  ASSERT_EQ(0, ProjectV3QueryHistories(
                   queries, "current", 2u, 65536u, true,
                   &histories, &selected));
  ASSERT_EQ(2u, histories.size());
  EXPECT_EQ("older", histories[0u]["id"].asString());
  EXPECT_EQ("multi", histories[1u]["id"].asString());
  EXPECT_EQ(JsonHelper::ToString(expected),
            JsonHelper::ToString(selected));

  std::map<std::string, std::string> variables;
  variables["last_semantic"] = "stale";
  variables["last_domain"] = "stale";
  variables["last_intent"] = "stale";
  variables["last_slot_artist"] = "stale";
  variables["last_slots_size"] = "1";
  variables["last_response"] = "preserved";
  Json::Value context;
  ASSERT_EQ(0, BuildV3ModelLastContext(variables, selected, &context));
  EXPECT_FALSE(context.isMember("last_semantic"));
  EXPECT_FALSE(context.isMember("last_domain"));
  EXPECT_FALSE(context.isMember("last_intent"));
  EXPECT_FALSE(context.isMember("last_slot_artist"));
  EXPECT_FALSE(context.isMember("last_slots_size"));
  EXPECT_EQ("preserved", context["last_response"].asString());
}

}  // namespace
}  // namespace nlptk
