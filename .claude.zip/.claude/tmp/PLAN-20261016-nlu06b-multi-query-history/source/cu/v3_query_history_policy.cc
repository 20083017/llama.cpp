// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/v3_query_history_policy.h"

#include <algorithm>
#include <cstdint>
#include <set>
#include <utility>

#include "base/json_helper.h"
#include "base/logging.h"
#include "common/simple_semantic.h"
#include "common/slot_utils.h"
#include "cu/dialogue_internal.h"

namespace nlptk {
namespace {

const char kQueryKeyPrefix[] = "Query:";
const char kSubQueryKeyPrefix[] = "SubQuery:";
const char kV3NluSemanticsKey[] = "v3_nlu_semantics";
const char kProjectedV3NluSemanticsKey[] = "v3_nlu_semantics";

bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output) {
  if (output == nullptr || text.empty()) {
    return false;
  }
  Json::CharReaderBuilder builder;
  JSONCPP_STRING errors;
  std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
  Json::Value parsed;
  if (!reader || !reader->parse(text.data(), text.data() + text.size(),
                                &parsed, &errors)) {
    return false;
  }
  *output = parsed;
  return true;
}

bool EarlierQuery(const std::shared_ptr<clu::Query>& left,
                  const std::shared_ptr<clu::Query>& right) {
  if (left->GetTimeStamp() != right->GetTimeStamp()) {
    return left->GetTimeStamp() < right->GetTimeStamp();
  }
  return left->GetRequestId() < right->GetRequestId();
}

bool IsCompleteSemanticArray(const Json::Value& semantics) {
  if (!semantics.isArray() || semantics.empty()) {
    return false;
  }
  for (const Json::Value& semantic : semantics) {
    if (!semantic.isObject() || !semantic["domain"].isString() ||
        semantic["domain"].asString().empty() ||
        !semantic["intent"].isString() ||
        semantic["intent"].asString().empty() ||
        !semantic["query"].isString() ||
        semantic["query"].asString().empty() ||
        !semantic["slots"].isObject()) {
      return false;
    }
    const Json::Value& slots = semantic["slots"];
    for (Json::ValueConstIterator slot = slots.begin(); slot != slots.end();
         ++slot) {
      if (slot.name().empty() || !(*slot).isString()) {
        return false;
      }
    }
  }
  return true;
}

bool HasLlmCommandCategory(const std::string& commands,
                           const std::string& category) {
  size_t begin = 0;
  while (begin < commands.size()) {
    const size_t end = commands.find(";", begin);
    const size_t command_end =
        end == std::string::npos ? commands.size() : end;
    const size_t separator = commands.rfind(":", command_end - 1);
    if (separator != std::string::npos && separator >= begin &&
        commands.substr(separator + 1, command_end - separator - 1) ==
            category) {
      return true;
    }
    if (end == std::string::npos) {
      break;
    }
    begin = end + 1;
  }
  return false;
}

bool IsSingularLastKey(const std::string& key) {
  return key == "last_semantic" || key == "last_domain" ||
         key == "last_intent" || key == "last_slots_size" ||
         key.compare(0, 10, "last_slot_") == 0;
}

int ReadEligibleSemantics(const clu::Query& query, Json::Value* semantics) {
  if (semantics == nullptr) {
    return -1;
  }
  std::string serialized;
  if (query.GetExtraData(kV3NluSemanticsKey, &serialized) < 0 ||
      serialized.empty()) {
    return 1;
  }
  Json::Value parsed;
  if (!ParseJsonWithoutLogging(serialized, &parsed) ||
      !IsCompleteSemanticArray(parsed)) {
    return 1;
  }
  dialogue_internal::V3NluHistoryEligibility eligibility;
  eligibility.sensitive =
      HasLlmCommandCategory(query.GetLLMCommand(), "sensitive");
  eligibility.status_ok =
      query.GetStatus() == static_cast<int>(clu::Query::Status::kOk);
  eligibility.rejected =
      (query.GetStatus() &
       static_cast<int>(clu::Query::Status::kRejected)) != 0;
  eligibility.semantics_complete = true;
  eligibility.multi_intent = query.IsMultiIntents();
  eligibility.semantic_count = parsed.size();

  for (const Json::Value& semantic : parsed) {
    eligibility.sensitive =
        eligibility.sensitive ||
        semantic["domain"].asString() == "sensitive";
  }
  if (!dialogue_internal::IsNluHistoryEligible(eligibility)) {
    return 1;
  }
  *semantics = parsed;
  return 0;
}

struct QueryIdentity {
  explicit QueryIdentity(const std::shared_ptr<clu::Query>& value_query)
      : request_id(value_query->GetRequestId()),
        timestamp(value_query->GetTimeStamp().count()) {}

  std::string request_id;
  int64_t timestamp;
};

bool EarlierIdentity(const QueryIdentity& left, const QueryIdentity& right) {
  if (left.timestamp != right.timestamp) {
    return left.timestamp < right.timestamp;
  }
  return left.request_id < right.request_id;
}

int BuildEvictionOrder(const DialogueResponse& response,
                       const std::shared_ptr<clu::Query>& current,
                       std::vector<QueryIdentity>* identities) {
  if (!current || identities == nullptr || response.query_histories.empty() ||
      current->GetRequestId().empty() || response.request_id.empty() ||
      current->GetRequestId() != response.request_id ||
      !response.query_histories.back() ||
      response.query_histories.back()->GetRequestId() != response.request_id) {
    return -1;
  }
  std::set<std::string> request_ids;
  for (const std::shared_ptr<clu::Query>& query : response.query_histories) {
    if (!query || query->GetRequestId().empty() ||
        !request_ids.insert(query->GetRequestId()).second) {
      return -1;
    }
    identities->push_back(QueryIdentity(
        query->GetRequestId() == current->GetRequestId() ? current : query));
  }
  std::sort(identities->begin(), identities->end(), EarlierIdentity);
  return 0;
}

struct ProjectedHistory {
  Json::Value query;
};

}  // namespace

int RestoreV3QueryHistory(
    const DialogueRequest& request, size_t max_query_records,
    dialog::ContextManager* context_manager,
    std::vector<std::shared_ptr<clu::Query> >* queries) {
  if (context_manager == nullptr || queries == nullptr ||
      max_query_records == 0 || request.id.empty() || request.query.empty()) {
    LOG(ERROR) << "component=v3_history_policy "
               << "event=v3_history_restore_result stage=input outcome=error "
               << "request_id=" << request.id << " reason=invalid_input";
    return -1;
  }

  const std::string query_key =
      std::string(kQueryKeyPrefix) + request.session_id;
  std::vector<std::shared_ptr<clu::Query> > restored;
  if (request.first_wakeup) {
    if (context_manager->Del(query_key) < 0) {
      LOG(ERROR) << "component=v3_history_policy "
                 << "event=v3_history_restore_result stage=clear "
                 << "outcome=error request_id=" << request.id
                 << " reason=context_delete_failed";
      return -1;
    }
  } else {
    std::vector<std::string> serialized_queries;
    if (context_manager->HGet(query_key, &serialized_queries) < 0) {
      LOG(ERROR) << "component=v3_history_policy "
                 << "event=v3_history_restore_result stage=query_read "
                 << "outcome=error request_id=" << request.id
                 << " reason=context_read_failed";
      return -1;
    }
    std::set<std::string> request_ids;
    for (const std::string& serialized : serialized_queries) {
      Json::Value value;
      std::shared_ptr<clu::Query> query(new clu::Query(""));
      if (!ParseJsonWithoutLogging(serialized, &value) || value.isNull() ||
          query->Deserialize(value) < 0 || query->GetRequestId().empty() ||
          !request_ids.insert(query->GetRequestId()).second) {
        LOG(ERROR) << "component=v3_history_policy "
                   << "event=v3_history_restore_result "
                   << "stage=query_deserialize outcome=error request_id="
                   << request.id << " reason=invalid_query_record";
        return -1;
      }
      if (query->GetRequestId() != request.id) {
        restored.push_back(query);
      }
    }
    std::sort(restored.begin(), restored.end(), EarlierQuery);

    const std::string sub_query_key =
        std::string(kSubQueryKeyPrefix) + request.session_id;
    std::string sub_query_context;
    if (context_manager->Get(sub_query_key, &sub_query_context) < 0) {
      LOG(ERROR) << "component=v3_history_policy "
                 << "event=v3_history_restore_result stage=sub_query_read "
                 << "outcome=error request_id=" << request.id
                 << " reason=context_read_failed";
      return -1;
    }
    std::string last_query;
    std::string last_sub_queries;
    if (!sub_query_context.empty()) {
      const size_t separator = sub_query_context.find("->");
      if (separator == std::string::npos) {
        LOG(WARNING) << "component=v3_history_policy "
                     << "event=v3_history_restore_result "
                     << "stage=sub_query_parse outcome=degraded request_id="
                     << request.id << " reason=invalid_sub_query_context";
      } else {
        last_query = sub_query_context.substr(0, separator);
        last_sub_queries = sub_query_context.substr(separator + 2);
      }
    }
    for (const HistoryQA& history_response : request.histories) {
      for (std::vector<std::shared_ptr<clu::Query> >::reverse_iterator it =
               restored.rbegin();
           it != restored.rend(); ++it) {
        if (!history_response.request_id.empty() &&
            (*it)->GetRequestId() == history_response.request_id) {
          (*it)->SetResponse(history_response.response);
          break;
        }
        if (history_response.request_id.empty() &&
            (*it)->GetQuery() == history_response.query) {
          (*it)->SetResponse(history_response.response);
          break;
        }
        if ((*it)->GetQuery() == last_query &&
            last_sub_queries.find("|" + history_response.query + "|") !=
                std::string::npos) {
          (*it)->SetResponse(history_response.response, true);
          break;
        }
      }
    }
  }

  std::shared_ptr<clu::Query> current(new clu::Query(request.query));
  current->SetFirstWakeUp(request.first_wakeup);
  current->SetRequestId(request.id);
  restored.push_back(current);
  queries->swap(restored);
  LOGI << "component=v3_history_policy event=v3_history_restore_result "
       << "stage=complete outcome=ok request_id=" << request.id
       << " history_count=" << queries->size();
  return 0;
}

int StoreV3QueryHistory(
    bool frames_transferred, bool after_process_succeeded,
    bool history_eligible, size_t max_query_records,
    dialog::ContextManager* context_manager, DialogueResponse* response) {
  const std::string request_id =
      response == nullptr ? std::string() : response->request_id;
  if (!frames_transferred || !after_process_succeeded || !history_eligible) {
    LOGI << "component=v3_history_policy event=v3_history_store_result "
         << "stage=admission outcome=skipped request_id=" << request_id;
    return 1;
  }
  if (context_manager == nullptr || response == nullptr ||
      max_query_records == 0) {
    LOG(ERROR) << "component=v3_history_policy event=v3_history_store_result "
               << "stage=input outcome=error request_id=" << request_id
               << " reason=invalid_input";
    return -1;
  }

  std::shared_ptr<clu::Query> current;
  if (dialogue_internal::PrepareCurrentQueryForStorage(response, &current) <
          0 ||
      !current) {
    LOG(ERROR) << "component=v3_history_policy event=v3_history_store_result "
               << "stage=prepare outcome=error request_id=" << request_id
               << " reason=prepare_failed";
    return -1;
  }
  std::vector<QueryIdentity> identities;
  if (BuildEvictionOrder(*response, current, &identities) < 0) {
    LOG(ERROR) << "component=v3_history_policy event=v3_history_store_result "
               << "stage=capacity_plan outcome=error request_id="
               << request_id << " reason=invalid_query_history";
    return -1;
  }
  const std::string serialized = JsonHelper::ToString(current->Serialize());
  if (serialized.empty()) {
    LOG(ERROR) << "component=v3_history_policy event=v3_history_store_result "
               << "stage=serialize outcome=error request_id=" << request_id;
    return -1;
  }
  const std::string key =
      std::string(kQueryKeyPrefix) + response->session_id;
  if (context_manager->HSet(key, current->GetRequestId(), serialized,
                            dialog::ContextManager::KQueryRecords) < 0) {
    LOG(ERROR) << "component=v3_history_policy event=v3_history_store_result "
               << "stage=context_write outcome=error request_id="
               << request_id << " reason=context_write_failed";
    return -1;
  }

  const size_t remove_count =
      identities.size() > max_query_records
          ? identities.size() - max_query_records
          : 0;
  for (size_t index = 0; index < remove_count; ++index) {
    if (context_manager->HDel(key, identities[index].request_id) < 0) {
      LOG(ERROR) << "component=v3_history_policy "
                 << "event=v3_history_store_result stage=capacity "
                 << "outcome=error request_id=" << request_id
                 << " reason=context_delete_failed delete_request_id="
                 << identities[index].request_id;
      return -1;
    }
  }
  LOGI << "component=v3_history_policy event=v3_history_store_result "
       << "stage=complete outcome=stored request_id=" << request_id
       << " removed_count=" << remove_count;
  return 0;
}

int BuildV3NluHistorySemantics(const std::string& query,
                               const nlu::SemanticFrames& frames,
                               Json::Value* semantics) {
  if (semantics == nullptr || query.empty() ||
      !dialogue_internal::AreCompleteSemanticFrames(frames)) {
    return -1;
  }
  Json::Value built(Json::arrayValue);
  for (const nlu::SemanticFrame* frame : frames) {
    clu::SimpleSemantic semantic;
    semantic.domain = frame->domain.value;
    semantic.intent = frame->intents.front().value;
    semantic.query = query;
    std::vector<nlu::Slot*> slots;
    frame->slots.List("", &slots);
    for (const nlu::Slot* slot : slots) {
      if (slot == nullptr || slot->name.empty()) {
        return -1;
      }
      semantic.slots.push_back(std::make_pair(
          slot->name, clu::SlotUtils::GetSlotNormalValue(*slot)));
    }
    Json::Value value = semantic.Serialize();
    if (!value["slots"].isObject()) {
      value["slots"] = Json::Value(Json::objectValue);
    }
    built.append(value);
  }
  if (!IsCompleteSemanticArray(built)) {
    return -1;
  }
  *semantics = built;
  return 0;
}

int AttachV3NluHistorySemantics(const Json::Value& semantics,
                                clu::Query* query) {
  if (query == nullptr || !IsCompleteSemanticArray(semantics)) {
    return -1;
  }
  query->SetMultiIntents(semantics.size() > 1);
  return query->SetExtraData(kV3NluSemanticsKey,
                             JsonHelper::ToString(semantics));
}

int ProjectV3QueryHistories(
    const std::vector<std::shared_ptr<clu::Query> >& queries,
    const std::string& current_request_id, size_t max_history_rounds,
    size_t max_history_bytes, bool allow_multi_intent_input,
    Json::Value* histories, Json::Value* selected_semantics) {
  if (histories == nullptr || selected_semantics == nullptr ||
      queries.empty() || current_request_id.empty() ||
      max_history_rounds == 0 || max_history_bytes == 0) {
    return -1;
  }
  *histories = Json::Value(Json::arrayValue);
  *selected_semantics = Json::Value(Json::arrayValue);
  std::vector<ProjectedHistory> selected;
  size_t cumulative_bytes = 0;
  for (size_t index = queries.size(); index > 0; --index) {
    const std::shared_ptr<clu::Query>& candidate = queries[index - 1];
    if (!candidate || candidate->GetRequestId() == current_request_id) {
      continue;
    }
    Json::Value semantics;
    if (ReadEligibleSemantics(*candidate, &semantics) != 0) {
      continue;
    }
    if (!allow_multi_intent_input && candidate->IsMultiIntents()) {
      continue;
    }
    Json::Value serialized = candidate->Serialize();
    serialized.removeMember("last_semantic");
    serialized[kProjectedV3NluSemanticsKey] = semantics;
    const size_t serialized_bytes = JsonHelper::ToString(serialized).size();
    if (serialized_bytes > max_history_bytes - cumulative_bytes) {
      break;
    }
    ProjectedHistory projected;
    projected.query = serialized;
    selected.push_back(projected);
    cumulative_bytes += serialized_bytes;
    if (selected.size() == 1u) {
      *selected_semantics = semantics;
    }
    if (selected.size() >= max_history_rounds) {
      break;
    }
  }
  for (std::vector<ProjectedHistory>::reverse_iterator it =
           selected.rbegin();
       it != selected.rend(); ++it) {
    histories->append(it->query);
  }
  return 0;
}

int BuildV3ModelLastContext(
    const std::map<std::string, std::string>& context_variables,
    const Json::Value& selected_semantics, Json::Value* model_last_context) {
  if (model_last_context == nullptr || !selected_semantics.isArray()) {
    return -1;
  }
  Json::Value context(Json::objectValue);
  for (const std::pair<const std::string, std::string>& variable :
       context_variables) {
    if (!IsSingularLastKey(variable.first)) {
      context[variable.first] = variable.second;
    }
  }
  if (selected_semantics.empty() || selected_semantics.size() > 1) {
    *model_last_context = context;
    return selected_semantics.empty() ||
                   IsCompleteSemanticArray(selected_semantics)
               ? 0
               : -1;
  }
  if (!IsCompleteSemanticArray(selected_semantics)) {
    return -1;
  }
  const Json::Value& semantic = selected_semantics[0];
  context["last_semantic"] = semantic;
  context["last_domain"] = semantic["domain"].asString();
  context["last_intent"] = semantic["intent"].asString();
  const Json::Value& slots = semantic["slots"];
  for (Json::ValueConstIterator slot = slots.begin(); slot != slots.end();
       ++slot) {
    context["last_slot_" + slot.name()] = (*slot).asString();
  }
  context["last_slots_size"] = std::to_string(slots.size());
  *model_last_context = context;
  return 0;
}

}  // namespace nlptk
