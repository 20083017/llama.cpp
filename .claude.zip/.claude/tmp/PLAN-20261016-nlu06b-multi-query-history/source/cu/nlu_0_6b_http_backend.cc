// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/nlu_0_6b_http_backend.h"

#include <curl/curl.h>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <fcntl.h>
#include <fstream>
#include <sstream>
#include <limits>
#include <memory>
#include <mutex>
#include <set>
#include <sys/stat.h>
#include <unistd.h>
#include <string>
#include <utility>
#include <vector>

#include "base/logging.h"
#include "common/curl.h"
#include "common/utils.h"

namespace nlptk {
namespace {

const int kDefaultConnectTimeoutMs = 5000;
const int kDefaultTotalTimeoutMs = 30000;
const int kDefaultMaxResponseBytes = 1024 * 1024;
const int kMaximumResponseBytes = 16 * 1024 * 1024;
const int kMaximumTimeoutMs = 10 * 60 * 1000;
const int kMaximumDiagnosticCaptureEntries = 10000;
const int kMaximumDiagnosticCaptureContentBytes = 1024 * 1024;
const size_t kMaximumLoggedEndpointBytes = 256u;
const size_t kMaximumLoggedModelBytes = 128u;
const int kHttpResponseTooLarge = -2;
const size_t kMaximumProfileTextBytes = 128u;
// Named V3 forbids U+FF1A/U+FF1B/U+FF1D in response slots, not payload
// normalization. UTF-8 bytes: EF BC 9A / EF BC 9B / EF BC 9D.
const char kProfileV3FullwidthColon[] = "\xEF\xBC\x9A";
const char kProfileV3FullwidthSemicolon[] = "\xEF\xBC\x9B";
const char kProfileV3FullwidthEquals[] = "\xEF\xBC\x9D";
const char kPipeV1FullwidthSlotSeparator[] = "\xEF\xBC\x9B";
const char kPipeV1FullwidthSlotAssignment[] = "\xEF\xBC\x9A";
const char kTsvV1SlotSeparator = ';';
const char kTsvV1ColonAssignment = ':';
const char kTsvV1EqualsAssignment = '=';
const char kTsvV1ForbiddenFullwidthColon[] = "\xEF\xBC\x9A";
const char kTsvV1ForbiddenFullwidthSemicolon[] = "\xEF\xBC\x9B";

enum ResponseProtocol {
  kResponseProtocolPipeV1 = 0,
  kResponseProtocolTsvV1,
  kResponseProtocolProfileV3,
  kResponseProtocolProfileV4,
};

struct HttpBackendConfig {
  std::string endpoint;
  std::string api_key;
  std::string model;
  std::string system_prompt;
  ResponseProtocol response_protocol;
  int connect_timeout_ms;
  int total_timeout_ms;
  int max_response_bytes;
  double temperature;
  double top_p;
  int top_k;
  int max_tokens;
  bool enable_thinking;
  bool profile_mode;
  bool allow_multi_intent_output;
  std::vector<std::string> request_prefixes;
  std::vector<std::string> empty_history_request_prefixes;
  char field_delimiter;
  char request_slot_assignment;
  char request_slot_separator;
  std::vector<char> response_slot_assignments;
  std::vector<char> response_slot_separators;
  std::vector<char> response_frame_separators;
  std::string response_unknown_marker;
  std::string response_multi_marker;
  bool diagnostic_capture_enabled;
  std::string diagnostic_capture_output_path;
  std::string diagnostic_capture_request_id_prefix;
  int diagnostic_capture_max_entries;
  int diagnostic_capture_max_content_bytes;
};

const char* HttpStatusCategory(long status_code) {
  if (status_code >= 200 && status_code < 300) {
    return "2xx";
  }
  if (status_code >= 400 && status_code < 500) {
    return "4xx";
  }
  if (status_code >= 500 && status_code < 600) {
    return "5xx";
  }
  return "other";
}

bool IsAsciiSpace(char value) {
  return std::isspace(static_cast<unsigned char>(value)) != 0;
}

std::string TrimAsciiSpace(const std::string& value) {
  size_t begin = 0;
  while (begin < value.size() && IsAsciiSpace(value[begin])) {
    ++begin;
  }
  size_t end = value.size();
  while (end > begin && IsAsciiSpace(value[end - 1])) {
    --end;
  }
  return value.substr(begin, end - begin);
}

bool ReadRequiredString(const Json::Value& config, const char* name,
                        std::string* output) {
  if (output == nullptr || !config.isMember(name) ||
      !config[name].isString()) {
    return false;
  }
  *output = config[name].asString();
  return !output->empty();
}

bool ReadOptionalInt(const Json::Value& config, const char* name,
                     int default_value, int minimum, int maximum, int* output) {
  if (output == nullptr) {
    return false;
  }
  *output = default_value;
  if (!config.isMember(name)) {
    return true;
  }
  if (!config[name].isInt()) {
    return false;
  }
  const int value = config[name].asInt();
  if (value < minimum || value > maximum) {
    return false;
  }
  *output = value;
  return true;
}

bool ReadOptionalDouble(const Json::Value& config, const char* name,
                        double default_value, double minimum,
                        double maximum, bool minimum_inclusive,
                        double* output) {
  if (output == nullptr) {
    return false;
  }
  *output = default_value;
  if (!config.isMember(name)) {
    return true;
  }
  if (!config[name].isNumeric()) {
    return false;
  }
  const double value = config[name].asDouble();
  const bool below_minimum =
      minimum_inclusive ? value < minimum : value <= minimum;
  if (below_minimum || value > maximum) {
    return false;
  }
  *output = value;
  return true;
}

bool IsDiagnosticRequestIdPrefix(const std::string& value) {
  if (value.empty() || value.size() > 64u) {
    return false;
  }
  for (size_t i = 0; i < value.size(); ++i) {
    const unsigned char current = static_cast<unsigned char>(value[i]);
    if (!std::isalnum(current) && value[i] != '_' && value[i] != '-') {
      return false;
    }
  }
  return true;
}

bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output);

bool ReadFileJson(const std::string& path, Json::Value* output) {
  std::ifstream input(path.c_str(), std::ios::in | std::ios::binary);
  if (!input || output == nullptr) return false;
  std::ostringstream text;
  text << input.rdbuf();
  return ParseJsonWithoutLogging(text.str(), output);
}

bool ResolveModelPath(const std::string& base_path, const std::string& relative,
                      std::string* resolved) {
  if (resolved == nullptr || base_path.empty() || relative.empty() ||
      relative[0] == '/') return false;
  char base_buffer[PATH_MAX];
  char path_buffer[PATH_MAX];
  if (realpath(base_path.c_str(), base_buffer) == nullptr ||
      realpath((base_path + "/" + relative).c_str(), path_buffer) == nullptr)
    return false;
  const std::string base(base_buffer);
  const std::string path(path_buffer);
  if (path.compare(0, base.size(), base) != 0 ||
      (path.size() > base.size() && path[base.size()] != '/')) return false;
  *resolved = path;
  return true;
}

bool ReadRequiredBoolValue(const Json::Value& value, const char* name,
                           bool* output) {
  if (output == nullptr || !value.isMember(name) || !value[name].isBool())
    return false;
  *output = value[name].asBool();
  return true;
}

bool IsPrintableDelimiter(char value) {
  const unsigned char byte = static_cast<unsigned char>(value);
  return byte >= 0x21u && byte <= 0x7eu;
}

bool ContainsProfileRecordDelimiter(const std::string& value,
                                    char field_delimiter) {
  return value.find('\0') != std::string::npos ||
         value.find('\t') != std::string::npos ||
         value.find('\r') != std::string::npos ||
         value.find('\n') != std::string::npos ||
         value.find(field_delimiter) != std::string::npos;
}

bool ReadDelimiter(const Json::Value& value, const char* name,
                   bool allow_tab, char* output) {
  if (output == nullptr || !value.isMember(name) || !value[name].isString())
    return false;
  const std::string configured = value[name].asString();
  if (configured.size() != 1u ||
      (!IsPrintableDelimiter(configured[0]) &&
       !(allow_tab && configured[0] == '\t'))) return false;
  *output = configured[0];
  return true;
}

bool ReadResponseDelimiterCandidates(const Json::Value& value,
                                     const char* name,
                                     bool allow_compact_string,
                                     std::vector<char>* output) {
  if (output == nullptr || !value.isMember(name)) return false;
  const Json::Value& configured = value[name];
  std::vector<char> parsed;
  if (configured.isString()) {
    const std::string candidates = configured.asString();
    if (candidates.size() > 94u ||
        (!allow_compact_string && candidates.size() != 1u)) return false;
    parsed.assign(candidates.begin(), candidates.end());
  } else if (configured.isArray()) {
    if (configured.size() > 94u) return false;
    for (Json::ArrayIndex i = 0u; i < configured.size(); ++i) {
      if (!configured[i].isString() || configured[i].asString().size() != 1u)
        return false;
      parsed.push_back(configured[i].asString()[0]);
    }
  } else {
    return false;
  }
  if (parsed.empty()) return false;
  std::set<char> unique;
  for (size_t i = 0u; i < parsed.size(); ++i) {
    if (!IsPrintableDelimiter(parsed[i]) || !unique.insert(parsed[i]).second)
      return false;
  }
  output->swap(parsed);
  return true;
}

bool IsDelimiterCandidate(const std::vector<char>& candidates, char byte) {
  return std::find(candidates.begin(), candidates.end(), byte) !=
         candidates.end();
}

bool ProfileRolesAreDistinct(const HttpBackendConfig& config) {
  if (config.field_delimiter == config.request_slot_assignment ||
      config.field_delimiter == config.request_slot_separator ||
      config.request_slot_assignment == config.request_slot_separator)
    return false;
  std::set<char> response_roles;
  response_roles.insert(config.field_delimiter);
  const std::vector<char>* roles[] = {&config.response_slot_assignments,
      &config.response_slot_separators, &config.response_frame_separators};
  for (size_t i = 0u; i < sizeof(roles) / sizeof(roles[0]); ++i) {
    for (size_t j = 0u; j < roles[i]->size(); ++j) {
      if (!response_roles.insert((*roles[i])[j]).second) return false;
    }
  }
  return true;
}

bool ReadProfileMarkers(const Json::Value& protocol,
                        HttpBackendConfig* parsed) {
  const bool legacy = protocol.isMember("response_flag_prefix");
  const bool unknown = protocol.isMember("response_unknown_marker");
  const bool multi = protocol.isMember("response_multi_marker");
  if (legacy) {
    std::string prefix;
    if (unknown || multi ||
        !ReadRequiredString(protocol, "response_flag_prefix", &prefix))
      return false;
    parsed->response_unknown_marker = prefix + "unknown";
    parsed->response_multi_marker = prefix + "multi";
  } else if (!unknown || !multi ||
             !ReadRequiredString(protocol, "response_unknown_marker",
                                 &parsed->response_unknown_marker) ||
             !ReadRequiredString(protocol, "response_multi_marker",
                                 &parsed->response_multi_marker)) {
    return false;
  }
  const std::string* markers[] = {&parsed->response_unknown_marker,
                                  &parsed->response_multi_marker};
  for (size_t i = 0u; i < 2u; ++i) {
    if (markers[i]->size() > kMaximumProfileTextBytes ||
        ContainsProfileRecordDelimiter(*markers[i], parsed->field_delimiter))
      return false;
    for (size_t j = 0u; j < parsed->response_frame_separators.size(); ++j) {
      if (markers[i]->find(parsed->response_frame_separators[j]) !=
          std::string::npos) return false;
    }
  }
  return parsed->response_unknown_marker != parsed->response_multi_marker;
}

bool LoadProfileConfig(const Json::Value& selector, const std::string& base_path,
                       Json::Value* profile, HttpBackendConfig* parsed) {
  std::string catalog_relative;
  std::string profile_name;
  if (!ReadRequiredString(selector, "profile_catalog_path", &catalog_relative) ||
      !ReadRequiredString(selector, "profile", &profile_name) ||
      profile_name.empty()) return false;
  std::string catalog_path;
  Json::Value catalog;
  if (!ResolveModelPath(base_path, catalog_relative, &catalog_path) ||
      !ReadFileJson(catalog_path, &catalog) || !catalog.isObject() ||
      !catalog.isMember("profiles") || !catalog["profiles"].isObject() ||
      !catalog["profiles"].isMember(profile_name) ||
      !catalog["profiles"][profile_name].isObject()) return false;
  *profile = catalog["profiles"][profile_name];
  const char* required[] = {"endpoint", "model", "system_prompt", "stream",
      "connect_timeout_ms", "total_timeout_ms", "temperature", "top_p",
      "top_k", "max_tokens", "enable_thinking", "allow_multi_intent_output"};
  for (size_t i = 0u; i < sizeof(required) / sizeof(required[0]); ++i) {
    if (!profile->isMember(required[i])) return false;
  }
  if (profile->isMember("response_protocol")) return false;
  std::string protocol_relative;
  if (!ReadRequiredString(*profile, "protocol_path", &protocol_relative))
    return false;
  std::string protocol_path;
  Json::Value protocol;
  if (!ResolveModelPath(base_path, protocol_relative, &protocol_path) ||
      !ReadFileJson(protocol_path, &protocol) || !protocol.isObject() ||
      !protocol.isMember("version") || !protocol["version"].isString() ||
      !protocol.isMember("request_field_prefixes") ||
      !protocol["request_field_prefixes"].isArray()) return false;
  const std::string protocol_version = protocol["version"].asString();
  if (protocol_version != "nlu_06b_v3" &&
      protocol_version != "nlu_06b_v4") return false;
  const bool v3 = protocol_version == "nlu_06b_v3";
  if (!ReadDelimiter(protocol, "field_delimiter", true,
                     &parsed->field_delimiter) ||
      !ReadDelimiter(protocol, "request_slot_assignment", false,
                     &parsed->request_slot_assignment) ||
      !ReadDelimiter(protocol, "request_slot_separator", false,
                     &parsed->request_slot_separator) ||
      !ReadResponseDelimiterCandidates(protocol, "response_slot_assignment",
                                       true, &parsed->response_slot_assignments) ||
      !ReadResponseDelimiterCandidates(protocol, "response_slot_separator",
                                       false, &parsed->response_slot_separators) ||
      !ReadResponseDelimiterCandidates(protocol, "response_frame_separator",
                                       false, &parsed->response_frame_separators) ||
      !ProfileRolesAreDistinct(*parsed) || !ReadProfileMarkers(protocol, parsed))
    return false;
  const size_t count = v3 ? 7u : 6u;
  if (protocol["request_field_prefixes"].size() != count) return false;
  parsed->request_prefixes.clear();
  for (size_t i = 0u; i < count; ++i) {
    const Json::Value& prefix = protocol["request_field_prefixes"]
        [static_cast<Json::ArrayIndex>(i)];
    if (!prefix.isString()) return false;
    const std::string text = prefix.asString();
    if (text.size() > kMaximumProfileTextBytes ||
        ContainsProfileRecordDelimiter(text, parsed->field_delimiter))
      return false;
    parsed->request_prefixes.push_back(text);
  }
  parsed->empty_history_request_prefixes.clear();
  if (protocol.isMember("empty_history_request")) {
    const Json::Value& option = protocol["empty_history_request"];
    if (!option.isObject() || option.size() != 2u ||
        !option["history_field"].isString() ||
        !option["query_prefix"].isString())
      return false;

    const std::string history_field = option["history_field"].asString();
    const std::string query_prefix = option["query_prefix"].asString();
    if (history_field.empty() ||
        history_field.size() > kMaximumProfileTextBytes ||
        query_prefix.size() > kMaximumProfileTextBytes ||
        ContainsProfileRecordDelimiter(history_field,
                                       parsed->field_delimiter) ||
        ContainsProfileRecordDelimiter(query_prefix,
                                       parsed->field_delimiter))
      return false;

    parsed->empty_history_request_prefixes.push_back(history_field);
    parsed->empty_history_request_prefixes.push_back(query_prefix);
  }

  parsed->response_protocol = v3 ? kResponseProtocolProfileV3
                                 : kResponseProtocolProfileV4;
  parsed->profile_mode = true;
  return true;
}

bool ParseConfig(const Json::Value& config, const std::string& base_path,
                 HttpBackendConfig* output) {
  if (output == nullptr || !config.isObject()) {
    return false;
  }
  HttpBackendConfig parsed;
  parsed.profile_mode = false;
  parsed.allow_multi_intent_output = false;
  parsed.field_delimiter = '\t';
  parsed.response_frame_separators.assign(1u, '|');
  parsed.request_slot_assignment = '=';
  parsed.request_slot_separator = ';';
  parsed.response_slot_separators.assign(1u, ';');
  Json::Value effective = config;
  if (effective.isMember("profile") || effective.isMember("profile_catalog_path")) {
    if (!LoadProfileConfig(config, base_path, &effective, &parsed) ||
        !ReadRequiredBoolValue(effective, "allow_multi_intent_output",
                               &parsed.allow_multi_intent_output)) return false;
  }
  std::string configured_endpoint;
  if (!ReadRequiredString(effective, "endpoint", &configured_endpoint) ||
      !ReadRequiredString(effective, "model", &parsed.model) ||
      !ReadRequiredString(effective, "system_prompt", &parsed.system_prompt)) {
    return false;
  }
  if (!parsed.profile_mode) parsed.response_protocol = kResponseProtocolPipeV1;
  if (effective.isMember("response_protocol")) {
    if (!effective["response_protocol"].isString()) {
      return false;
    }
    const std::string response_protocol =
        effective["response_protocol"].asString();
    if (response_protocol == "pipe_v1") {
      parsed.response_protocol = kResponseProtocolPipeV1;
    } else if (response_protocol == "tsv_v1") {
      parsed.response_protocol = kResponseProtocolTsvV1;
    } else {
      return false;
    }
  }
  if (configured_endpoint.size() >= 4 && configured_endpoint[0] == '$' &&
      configured_endpoint[1] == '{' && configured_endpoint.back() == '}') {
    parsed.endpoint = clu::GetEnv(configured_endpoint);
  } else {
    parsed.endpoint = configured_endpoint;
  }
  if (parsed.endpoint.compare(0, 7, "http://") != 0 &&
      parsed.endpoint.compare(0, 8, "https://") != 0) {
    return false;
  }

  parsed.api_key.clear();
  if (effective.isMember("api_key_env")) {
    if (!effective["api_key_env"].isString()) {
      return false;
    }
    const std::string key_name = effective["api_key_env"].asString();
    if (!key_name.empty()) {
      parsed.api_key = clu::GetEnv(key_name);
      if (parsed.api_key.empty()) {
        return false;
      }
    }
  }
  if (!ReadOptionalInt(effective, "connect_timeout_ms", kDefaultConnectTimeoutMs,
                       1, kMaximumTimeoutMs, &parsed.connect_timeout_ms) ||
      !ReadOptionalInt(effective, "total_timeout_ms", kDefaultTotalTimeoutMs, 1,
                       kMaximumTimeoutMs, &parsed.total_timeout_ms) ||
      !ReadOptionalInt(effective, "max_response_bytes", kDefaultMaxResponseBytes,
                       1, kMaximumResponseBytes,
                       &parsed.max_response_bytes) ||
      !ReadOptionalDouble(effective, "temperature", 0.01, 0.0, 2.0, true,
                          &parsed.temperature) ||
      !ReadOptionalDouble(effective, "top_p", 0.95, 0.0, 1.0, false,
                          &parsed.top_p) ||
      !ReadOptionalInt(effective, "top_k", 20, 1, 1000, &parsed.top_k) ||
      !ReadOptionalInt(effective, "max_tokens", 1024, 1, 65536,
                       &parsed.max_tokens)) {
    return false;
  }
  if (parsed.total_timeout_ms < parsed.connect_timeout_ms) {
    return false;
  }
  parsed.enable_thinking = false;
  if (parsed.profile_mode && (!effective.isMember("stream") ||
      !effective["stream"].isBool() || effective["stream"].asBool())) return false;
  if (effective.isMember("enable_thinking")) {
    if (!effective["enable_thinking"].isBool()) {
      return false;
    }
    parsed.enable_thinking = effective["enable_thinking"].asBool();
  }

  parsed.diagnostic_capture_enabled = false;
  if (effective.isMember("diagnostic_capture_enabled")) {
    if (!effective["diagnostic_capture_enabled"].isBool()) {
      return false;
    }
    parsed.diagnostic_capture_enabled =
        effective["diagnostic_capture_enabled"].asBool();
  }
  parsed.diagnostic_capture_output_path.clear();
  if (effective.isMember("diagnostic_capture_output_path")) {
    if (!effective["diagnostic_capture_output_path"].isString()) {
      return false;
    }
    parsed.diagnostic_capture_output_path =
        effective["diagnostic_capture_output_path"].asString();
  }
  parsed.diagnostic_capture_request_id_prefix.clear();
  if (effective.isMember("diagnostic_capture_request_id_prefix")) {
    if (!effective["diagnostic_capture_request_id_prefix"].isString()) {
      return false;
    }
    parsed.diagnostic_capture_request_id_prefix =
        effective["diagnostic_capture_request_id_prefix"].asString();
  }
  if (!ReadOptionalInt(effective, "diagnostic_capture_max_entries", 0, 0,
                       kMaximumDiagnosticCaptureEntries,
                       &parsed.diagnostic_capture_max_entries) ||
      !ReadOptionalInt(effective, "diagnostic_capture_max_content_bytes", 0, 0,
                       kMaximumDiagnosticCaptureContentBytes,
                       &parsed.diagnostic_capture_max_content_bytes)) {
    return false;
  }
  if (parsed.diagnostic_capture_enabled &&
      (parsed.diagnostic_capture_output_path.empty() ||
       parsed.diagnostic_capture_output_path[0] != '/' ||
       !IsDiagnosticRequestIdPrefix(
           parsed.diagnostic_capture_request_id_prefix) ||
       parsed.diagnostic_capture_max_entries <= 0 ||
       parsed.diagnostic_capture_max_content_bytes <= 0 ||
       parsed.diagnostic_capture_max_content_bytes >
           parsed.max_response_bytes)) {
    return false;
  }
  *output = parsed;
  return true;
}

bool ParseJsonWithoutLogging(const std::string& text, Json::Value* output) {
  if (output == nullptr || text.empty()) {
    return false;
  }
  Json::CharReaderBuilder builder;
  JSONCPP_STRING errors;
  std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
  Json::Value parsed;
  if (!reader || !reader->parse(text.data(), text.data() + text.size(),
                                &parsed, &errors)) {
    return false;
  }
  *output = parsed;
  return true;
}

std::string JsonToString(const Json::Value& value) {
  Json::StreamWriterBuilder builder;
  builder.settings_["commentStyle"] = "None";
  builder.settings_["indentation"] = "";
  builder.settings_["escapeString"] = false;
  return Json::writeString(builder, value);
}

bool ContainsTsvRecordDelimiter(const std::string& value) {
  return value.find('\t') != std::string::npos ||
         value.find('\r') != std::string::npos ||
         value.find('\n') != std::string::npos;
}

bool ContainsTsvV1ForbiddenSlotPunctuation(const std::string& value) {
  return value.find(kTsvV1ForbiddenFullwidthColon) != std::string::npos ||
         value.find(kTsvV1ForbiddenFullwidthSemicolon) !=
             std::string::npos;
}

bool ContainsTsvSlotDelimiter(const std::string& value) {
  return ContainsTsvRecordDelimiter(value) ||
         value.find(kTsvV1SlotSeparator) != std::string::npos ||
         value.find(kTsvV1ColonAssignment) != std::string::npos ||
         value.find(kTsvV1EqualsAssignment) != std::string::npos ||
         ContainsTsvV1ForbiddenSlotPunctuation(value);
}

bool ReadNewestTsvHistory(const Json::Value& histories,
                          std::string* query, std::string* domain,
                          std::string* intent, std::string* slot_text) {
  if (query == nullptr || domain == nullptr || intent == nullptr ||
      slot_text == nullptr || !histories.isArray() || histories.empty()) {
    return false;
  }
  const Json::Value& history = histories[histories.size() - 1u];
  if (!history.isObject() || !history.isMember("v3_nlu_semantics")) {
    return false;
  }
  const Json::Value& semantics = history["v3_nlu_semantics"];
  if (!semantics.isArray() || semantics.size() != 1u ||
      !semantics[0u].isObject()) {
    return false;
  }
  const Json::Value& semantic = semantics[0u];
  if (!semantic.isMember("query") || !semantic["query"].isString() ||
      semantic["query"].asString().empty() ||
      !semantic.isMember("domain") || !semantic["domain"].isString() ||
      semantic["domain"].asString().empty() ||
      !semantic.isMember("intent") || !semantic["intent"].isString() ||
      semantic["intent"].asString().empty() ||
      !semantic.isMember("slots") || !semantic["slots"].isObject()) {
    return false;
  }

  const std::string parsed_query = semantic["query"].asString();
  const std::string parsed_domain = semantic["domain"].asString();
  const std::string parsed_intent = semantic["intent"].asString();
  if (ContainsTsvRecordDelimiter(parsed_query) ||
      ContainsTsvRecordDelimiter(parsed_domain) ||
      ContainsTsvRecordDelimiter(parsed_intent)) {
    return false;
  }

  std::vector<std::pair<std::string, std::string> > sorted_slots;
  const Json::Value& slots = semantic["slots"];
  for (Json::ValueConstIterator slot = slots.begin(); slot != slots.end();
       ++slot) {
    const std::string name = slot.name();
    if (name.empty() || !(*slot).isString()) {
      return false;
    }
    const std::string value = (*slot).asString();
    if (ContainsTsvSlotDelimiter(name) ||
        ContainsTsvSlotDelimiter(value)) {
      return false;
    }
    sorted_slots.push_back(std::make_pair(name, value));
  }
  std::sort(sorted_slots.begin(), sorted_slots.end());

  std::string serialized_slots;
  for (size_t i = 0u; i < sorted_slots.size(); ++i) {
    if (i != 0u) {
      serialized_slots.push_back(kTsvV1SlotSeparator);
    }
    serialized_slots.append(sorted_slots[i].first);
    serialized_slots.push_back(kTsvV1EqualsAssignment);
    serialized_slots.append(sorted_slots[i].second);
  }
  *query = parsed_query;
  *domain = parsed_domain;
  *intent = parsed_intent;
  *slot_text = serialized_slots;
  return true;
}

bool BuildTsvUserContent(const Nlu06BRequest& request,
                         std::string* content) {
  if (content == nullptr || request.query.empty() ||
      ContainsTsvRecordDelimiter(request.query)) {
    return false;
  }
  std::string history_query;
  std::string history_domain;
  std::string history_intent;
  std::string history_slots;
  ReadNewestTsvHistory(request.histories, &history_query, &history_domain,
                       &history_intent, &history_slots);

  content->assign("history:\t");
  content->append(history_query);
  content->push_back('\t');
  content->append(history_domain);
  content->push_back('\t');
  content->append(history_intent);
  content->push_back('\t');
  content->append(history_slots);
  content->append("\t\t");
  content->append(request.query);
  return true;
}

bool ReadNewestProfileHistory(const Json::Value& histories,
                              const HttpBackendConfig& config,
                              std::vector<std::string>* fields) {
  const char assignment = config.request_slot_assignment;
  const char separator = config.request_slot_separator;
  if (fields == nullptr) return false;
  if (!histories.isArray() || histories.empty()) return false;
  const Json::Value& history = histories[histories.size() - 1u];
  if (!history.isObject() || !history.isMember("v3_nlu_semantics") ||
      !history["v3_nlu_semantics"].isArray() ||
      history["v3_nlu_semantics"].size() != 1u ||
      !history["v3_nlu_semantics"][0u].isObject()) return false;
  const Json::Value& semantic = history["v3_nlu_semantics"][0u];
  if (!semantic.isMember("query") || !semantic["query"].isString() ||
      semantic["query"].asString().empty() ||
      !semantic.isMember("domain") || !semantic["domain"].isString() ||
      semantic["domain"].asString().empty() ||
      !semantic.isMember("intent") || !semantic["intent"].isString() ||
      semantic["intent"].asString().empty() ||
      !semantic.isMember("slots") || !semantic["slots"].isObject()) return false;
  const std::string query = semantic["query"].asString();
  const std::string domain = semantic["domain"].asString();
  const std::string intent = semantic["intent"].asString();
  if (ContainsProfileRecordDelimiter(query, config.field_delimiter) ||
      ContainsProfileRecordDelimiter(domain, config.field_delimiter) ||
      ContainsProfileRecordDelimiter(intent, config.field_delimiter)) return false;
  std::vector<std::pair<std::string, std::string> > slots;
  for (Json::ValueConstIterator slot = semantic["slots"].begin();
       slot != semantic["slots"].end(); ++slot) {
    const std::string name = slot.name();
    if (name.empty() || !(*slot).isString()) return false;
    const std::string value = (*slot).asString();
    if (ContainsProfileRecordDelimiter(name, config.field_delimiter) ||
        ContainsProfileRecordDelimiter(value, config.field_delimiter) ||
        name.find(assignment) != std::string::npos ||
        name.find(separator) != std::string::npos ||
        value.find(assignment) != std::string::npos ||
        value.find(separator) != std::string::npos) return false;
    slots.push_back(std::make_pair(name, value));
  }
  std::sort(slots.begin(), slots.end());
  std::string slot_text;
  for (size_t i = 0; i < slots.size(); ++i) {
    if (i != 0u) slot_text.push_back(separator);
    slot_text.append(slots[i].first);
    slot_text.push_back(assignment);
    slot_text.append(slots[i].second);
  }
  std::string tts;
  if (semantic.isMember("tts")) {
    if (!semantic["tts"].isString() ||
        ContainsProfileRecordDelimiter(semantic["tts"].asString(),
                                       config.field_delimiter)) return false;
    tts = semantic["tts"].asString();
  }
  fields->clear();
  fields->push_back(query);
  fields->push_back(domain);
  fields->push_back(intent);
  fields->push_back(slot_text);
  fields->push_back(tts);
  return true;
}

bool IsNewestProfileHistoryQueryAbsent(const Nlu06BRequest& request) {
  if (request.histories.isNull()) return true;
  if (!request.histories.isArray()) return false;
  if (request.histories.empty()) return true;

  const Json::Value& newest = request.histories[
      static_cast<Json::ArrayIndex>(request.histories.size() - 1u)];
  if (!newest.isObject()) return false;
  if (!newest.isMember("v3_nlu_semantics")) return true;

  const Json::Value& semantics = newest["v3_nlu_semantics"];
  if (!semantics.isArray()) return false;
  if (semantics.empty()) return true;
  if (semantics.size() != 1u) return false;

  const Json::Value& semantic = semantics[static_cast<Json::ArrayIndex>(0u)];
  if (!semantic.isObject()) return false;
  if (!semantic.isMember("query")) return true;

  const Json::Value& query = semantic["query"];
  return query.isString() && query.asString().empty();
}

bool BuildProfileUserContent(const Nlu06BRequest& request,
                             const HttpBackendConfig& config,
                             std::string* content) {
  if (content == nullptr || request.query.empty() ||
      ContainsProfileRecordDelimiter(request.query, config.field_delimiter))
    return false;

  const bool use_empty_history_request =
      !config.empty_history_request_prefixes.empty() &&
      IsNewestProfileHistoryQueryAbsent(request);
  const std::vector<std::string>& prefixes =
      use_empty_history_request ? config.empty_history_request_prefixes
                                : config.request_prefixes;

  std::vector<std::string> values;
  if (use_empty_history_request) {
    values.push_back(std::string());
    values.push_back(request.query);
  } else {
    std::vector<std::string> history_fields;
    ReadNewestProfileHistory(request.histories, config, &history_fields);
    if (history_fields.empty()) history_fields.resize(5u);
    values = history_fields;
    values.push_back(request.query);
    if (config.response_protocol == kResponseProtocolProfileV3)
      values.insert(values.begin(), std::string());
  }

  if (values.size() != prefixes.size()) return false;
  content->clear();
  for (size_t i = 0; i < values.size(); ++i) {
    if (i != 0u) content->push_back(config.field_delimiter);
    content->append(prefixes[i]);
    content->append(values[i]);
  }
  return true;
}

bool ParseTopLevelField(const std::string& field, const std::string& name,
                        bool allow_slot_assignments,
                        std::string* value) {
  if (value == nullptr) {
    return false;
  }
  const std::string trimmed = TrimAsciiSpace(field);
  const std::string ascii_prefix = name + "=";
  const std::string fullwidth_prefix =
      name + kPipeV1FullwidthSlotAssignment;
  size_t prefix_size = 0u;
  if (trimmed.compare(0, ascii_prefix.size(), ascii_prefix) == 0) {
    prefix_size = ascii_prefix.size();
  } else if (trimmed.compare(0, fullwidth_prefix.size(),
                             fullwidth_prefix) == 0) {
    prefix_size = fullwidth_prefix.size();
  } else {
    return false;
  }
  if (trimmed.find('=', prefix_size) != std::string::npos ||
      (!allow_slot_assignments &&
       trimmed.find(kPipeV1FullwidthSlotAssignment, prefix_size) !=
           std::string::npos)) {
    return false;
  }
  *value = TrimAsciiSpace(trimmed.substr(prefix_size));
  return true;
}

enum ContentParseResult {
  kContentSuccess = 0,
  kContentNullResult,
  kContentMissingPipe,
  kContentExtraPipe,
  kContentInvalidDomainField,
  kContentInvalidIntentField,
  kContentInvalidSlotField,
  kContentEmptyDomain,
  kContentEmptyIntent,
  kContentInvalidSlotPair,
  kContentEmptySlotName,
  kContentEmptySlotValue,
  kContentDuplicateSlot,
  kContentTrailingSlotSeparator,
  kContentInvalidWrapper,
  kContentMissingTab,
  kContentExtraTab,
  kContentForbiddenPunctuation,
  kContentUnsupportedProtocol,
};

const char* ContentParseResultName(ContentParseResult result) {
  switch (result) {
    case kContentSuccess:
      return "success";
    case kContentNullResult:
      return "null_result";
    case kContentMissingPipe:
      return "missing_pipe";
    case kContentExtraPipe:
      return "extra_pipe";
    case kContentInvalidDomainField:
      return "invalid_domain_field";
    case kContentInvalidIntentField:
      return "invalid_intent_field";
    case kContentInvalidSlotField:
      return "invalid_slot_field";
    case kContentEmptyDomain:
      return "empty_domain";
    case kContentEmptyIntent:
      return "empty_intent";
    case kContentInvalidSlotPair:
      return "invalid_slot_pair";
    case kContentEmptySlotName:
      return "empty_slot_name";
    case kContentEmptySlotValue:
      return "empty_slot_value";
    case kContentDuplicateSlot:
      return "duplicate_slot";
    case kContentTrailingSlotSeparator:
      return "trailing_slot_separator";
    case kContentInvalidWrapper:
      return "invalid_wrapper";
    case kContentMissingTab:
      return "missing_tab";
    case kContentExtraTab:
      return "extra_tab";
    case kContentForbiddenPunctuation:
      return "forbidden_punctuation";
    case kContentUnsupportedProtocol:
      return "unsupported_protocol";
  }
  return "unknown";
}

void BuildSingleFrameResult(const std::string& domain,
                            const std::string& intent,
                            const Json::Value& slots,
                            Json::Value* result) {
  Json::Value frame(Json::objectValue);
  frame["domain"] = domain;
  frame["intents"] = Json::Value(Json::arrayValue);
  frame["intents"].append(intent);
  frame["slots"] = slots;

  Json::Value parsed(Json::objectValue);
  parsed["is_rejected"] = false;
  parsed["reject_reason"] = "";
  parsed["is_multi_intent"] = false;
  parsed["frames"] = Json::Value(Json::arrayValue);
  parsed["frames"].append(frame);
  *result = parsed;
}

ContentParseResult ParsePipeContent(const std::string& content,
                                    Json::Value* result) {
  if (result == nullptr) {
    return kContentNullResult;
  }
  const std::string text = TrimAsciiSpace(content);
  const size_t first_pipe = text.find('|');
  if (first_pipe == std::string::npos) {
    return kContentMissingPipe;
  }
  const size_t second_pipe = text.find('|', first_pipe + 1);
  if (second_pipe != std::string::npos &&
      text.find('|', second_pipe + 1) != std::string::npos) {
    return kContentExtraPipe;
  }

  std::string domain;
  std::string intent;
  std::string slot_text;
  if (!ParseTopLevelField(text.substr(0, first_pipe), "domain", false,
                          &domain)) {
    return kContentInvalidDomainField;
  }
  if (second_pipe == std::string::npos) {
    if (!ParseTopLevelField(text.substr(first_pipe + 1), "intent", false,
                            &intent)) {
      return kContentInvalidIntentField;
    }
  } else {
    if (!ParseTopLevelField(text.substr(first_pipe + 1,
                                        second_pipe - first_pipe - 1),
                            "intent", false, &intent)) {
      return kContentInvalidIntentField;
    }
    if (!ParseTopLevelField(text.substr(second_pipe + 1), "slot", true,
                            &slot_text)) {
      return kContentInvalidSlotField;
    }
  }
  if (domain.empty()) {
    return kContentEmptyDomain;
  }
  if (intent.empty()) {
    return kContentEmptyIntent;
  }

  Json::Value slots(Json::objectValue);
  std::set<std::string> slot_names;
  size_t offset = 0;
  while (offset < slot_text.size()) {
    const size_t separator =
        slot_text.find(kPipeV1FullwidthSlotSeparator, offset);
    const std::string pair = TrimAsciiSpace(slot_text.substr(
        offset, separator == std::string::npos ? std::string::npos
                                               : separator - offset));
    const size_t assignment = pair.find(kPipeV1FullwidthSlotAssignment);
    if (pair.empty() || assignment == std::string::npos ||
        pair.find(kPipeV1FullwidthSlotAssignment,
                  assignment +
                      sizeof(kPipeV1FullwidthSlotAssignment) - 1) !=
            std::string::npos) {
      return kContentInvalidSlotPair;
    }
    const std::string name = TrimAsciiSpace(pair.substr(0, assignment));
    const std::string value = TrimAsciiSpace(
        pair.substr(assignment +
                    sizeof(kPipeV1FullwidthSlotAssignment) - 1));
    if (name.empty()) {
      return kContentEmptySlotName;
    }
    if (value.empty()) {
      return kContentEmptySlotValue;
    }
    if (!slot_names.insert(name).second) {
      return kContentDuplicateSlot;
    }
    slots[name] = value;
    if (separator == std::string::npos) {
      offset = slot_text.size();
    } else {
      offset = separator + sizeof(kPipeV1FullwidthSlotSeparator) - 1;
      if (offset == slot_text.size()) {
        return kContentTrailingSlotSeparator;
      }
    }
  }

  BuildSingleFrameResult(domain, intent, slots, result);
  return kContentSuccess;
}

bool HasTsvWrapper(const std::string& content) {
  if (content.find('`') != std::string::npos ||
      content.find('\r') != std::string::npos ||
      content.find('\n') != std::string::npos ||
      content.find('\f') != std::string::npos ||
      content.find('\v') != std::string::npos) {
    return true;
  }
  const size_t first = content.find_first_not_of(' ');
  const size_t last = content.find_last_not_of(' ');
  if (first == std::string::npos || last == std::string::npos) {
    return false;
  }
  const char first_character = content[first];
  const char last_character = content[last];
  return (first_character == '"' && last_character == '"') ||
         (first_character == '\'' && last_character == '\'') ||
         (first_character == '{' && last_character == '}') ||
         (first_character == '[' && last_character == ']');
}

ContentParseResult ParseTsvContent(const std::string& content,
                                   Json::Value* result) {
  if (result == nullptr) {
    return kContentNullResult;
  }
  if (HasTsvWrapper(content)) {
    return kContentInvalidWrapper;
  }
  const size_t first_tab = content.find('\t');
  if (first_tab == std::string::npos) {
    return kContentMissingTab;
  }
  const size_t second_tab = content.find('\t', first_tab + 1);
  if (second_tab == std::string::npos) {
    return kContentMissingTab;
  }
  if (content.find('\t', second_tab + 1) != std::string::npos) {
    return kContentExtraTab;
  }

  const std::string domain = TrimAsciiSpace(content.substr(0, first_tab));
  const std::string intent = TrimAsciiSpace(content.substr(
      first_tab + 1, second_tab - first_tab - 1));
  const std::string slot_text =
      TrimAsciiSpace(content.substr(second_tab + 1));
  if (domain.empty()) {
    return kContentEmptyDomain;
  }
  if (intent.empty()) {
    return kContentEmptyIntent;
  }

  if (ContainsTsvV1ForbiddenSlotPunctuation(slot_text)) {
    return kContentForbiddenPunctuation;
  }

  Json::Value slots(Json::objectValue);
  std::set<std::string> slot_names;
  char response_assignment = '\0';
  size_t offset = 0u;
  while (offset < slot_text.size()) {
    const size_t separator = slot_text.find(kTsvV1SlotSeparator, offset);
    const std::string pair = TrimAsciiSpace(slot_text.substr(
        offset, separator == std::string::npos ? std::string::npos
                                               : separator - offset));
    const size_t equals_assignment = pair.find(kTsvV1EqualsAssignment);
    const size_t colon_assignment = pair.find(kTsvV1ColonAssignment);
    if (pair.empty() ||
        (equals_assignment == std::string::npos &&
         colon_assignment == std::string::npos) ||
        (equals_assignment != std::string::npos &&
         colon_assignment != std::string::npos)) {
      return kContentInvalidSlotPair;
    }
    const char pair_assignment =
        equals_assignment == std::string::npos
            ? kTsvV1ColonAssignment
            : kTsvV1EqualsAssignment;
    const size_t assignment =
        equals_assignment == std::string::npos ? colon_assignment
                                               : equals_assignment;
    if (pair.find(pair_assignment, assignment + 1) != std::string::npos ||
        (response_assignment != '\0' &&
         response_assignment != pair_assignment)) {
      return kContentInvalidSlotPair;
    }
    response_assignment = pair_assignment;
    const std::string name = TrimAsciiSpace(pair.substr(0, assignment));
    const std::string value = TrimAsciiSpace(pair.substr(assignment + 1));
    if (name.empty()) {
      return kContentEmptySlotName;
    }
    if (value.empty()) {
      return kContentEmptySlotValue;
    }
    if (!slot_names.insert(name).second) {
      return kContentDuplicateSlot;
    }
    slots[name] = value;
    if (separator == std::string::npos) {
      offset = slot_text.size();
    } else {
      offset = separator + 1;
      if (offset == slot_text.size()) {
        return kContentTrailingSlotSeparator;
      }
    }
  }

  BuildSingleFrameResult(domain, intent, slots, result);
  return kContentSuccess;
}

bool IsProfileResponseSyntax(const HttpBackendConfig& config, char byte) {
  return byte == config.field_delimiter ||
         IsDelimiterCandidate(config.response_slot_separators, byte) ||
         IsDelimiterCandidate(config.response_frame_separators, byte) ||
         IsDelimiterCandidate(config.response_slot_assignments, byte);
}

bool HasProfileWrapper(const std::string& content,
                       const HttpBackendConfig& config) {
  if (content.find('\0') != std::string::npos ||
      content.find('\r') != std::string::npos ||
      content.find('\n') != std::string::npos ||
      content.find('\f') != std::string::npos ||
      content.find('\v') != std::string::npos ||
      (config.field_delimiter != '\t' &&
       content.find('\t') != std::string::npos) ||
      (!IsProfileResponseSyntax(config, '`') &&
       content.find('`') != std::string::npos)) return true;
  const size_t first = content.find_first_not_of(' ');
  const size_t last = content.find_last_not_of(' ');
  if (first == std::string::npos || last == std::string::npos) return false;
  const char begin = content[first];
  const char end = content[last];
  // Preserve wrapper rejection unless the punctuation is configured syntax.
  if (IsProfileResponseSyntax(config, begin) ||
      IsProfileResponseSyntax(config, end)) return false;
  return (begin == '"' && end == '"') || (begin == '\'' && end == '\'') ||
         (begin == '{' && end == '}') || (begin == '[' && end == ']');
}

ContentParseResult ParseProfileFrame(
    const std::string& content, const HttpBackendConfig& config,
    char* response_assignment, char* response_slot_separator,
    Json::Value* frame) {
  const std::vector<char>& assignments = config.response_slot_assignments;
  if (frame == nullptr || response_assignment == nullptr ||
      response_slot_separator == nullptr || assignments.empty() ||
      config.response_slot_separators.empty() ||
      HasProfileWrapper(content, config)) {
    return kContentInvalidWrapper;
  }
  const size_t first = content.find(config.field_delimiter);
  const size_t second = first == std::string::npos ? std::string::npos
      : content.find(config.field_delimiter, first + 1u);
  if (first == std::string::npos || second == std::string::npos)
    return kContentMissingTab;
  if (content.find(config.field_delimiter, second + 1u) != std::string::npos)
    return kContentExtraTab;
  const std::string domain = TrimAsciiSpace(content.substr(0u, first));
  const std::string intent = TrimAsciiSpace(
      content.substr(first + 1u, second - first - 1u));
  const std::string slot_text = content.substr(second + 1u);
  if (domain.empty()) return kContentEmptyDomain;
  if (intent.empty()) return kContentEmptyIntent;
  if (config.response_protocol == kResponseProtocolProfileV3 &&
      (slot_text.find(kProfileV3FullwidthColon) != std::string::npos ||
       slot_text.find(kProfileV3FullwidthSemicolon) != std::string::npos ||
       slot_text.find(kProfileV3FullwidthEquals) != std::string::npos))
    return kContentForbiddenPunctuation;
  // Only slot fields select a separator; retain one style across all frames.
  for (size_t i = 0u; i < config.response_slot_separators.size(); ++i) {
    const char candidate = config.response_slot_separators[i];
    if (slot_text.find(candidate) == std::string::npos) continue;
    if (*response_slot_separator != '\0' &&
        *response_slot_separator != candidate) return kContentInvalidSlotPair;
    *response_slot_separator = candidate;
  }
  const char separator = *response_slot_separator;
  Json::Value slots(Json::objectValue);
  std::set<std::string> names;
  size_t offset = 0u;
  while (offset < slot_text.size()) {
    // Empty/one-pair fields need not select any separator.
    const size_t end = separator == '\0' ? std::string::npos
                                         : slot_text.find(separator, offset);
    const std::string pair = slot_text.substr(
        offset, end == std::string::npos ? std::string::npos : end - offset);
    char pair_assignment = '\0';
    size_t split = std::string::npos;
    for (size_t i = 0u; i < assignments.size(); ++i) {
      const size_t candidate = pair.find(assignments[i]);
      if (candidate == std::string::npos) continue;
      if (pair_assignment != '\0' ||
          pair.find(assignments[i], candidate + 1u) != std::string::npos) {
        return kContentInvalidSlotPair;
      }
      pair_assignment = assignments[i];
      split = candidate;
    }
    if (pair.empty() || pair_assignment == '\0' ||
        (*response_assignment != '\0' &&
         *response_assignment != pair_assignment)) {
      return kContentInvalidSlotPair;
    }
    *response_assignment = pair_assignment;
    const std::string name = pair.substr(0u, split);
    const std::string value = pair.substr(split + 1u);
    if (name.empty()) return kContentEmptySlotName;
    if (value.empty()) return kContentEmptySlotValue;
    if (!names.insert(name).second) return kContentDuplicateSlot;
    slots[name] = value;
    if (end == std::string::npos) break;
    offset = end + 1u;
    if (offset == slot_text.size()) return kContentTrailingSlotSeparator;
  }
  (*frame)["domain"] = domain;
  (*frame)["intents"] = Json::Value(Json::arrayValue);
  (*frame)["intents"].append(intent);
  (*frame)["slots"] = slots;
  return kContentSuccess;
}

ContentParseResult ParseProfileContent(const HttpBackendConfig& config,
                                       const std::string& content,
                                       Json::Value* result) {
  if (result == nullptr) return kContentNullResult;
  if (content == config.response_unknown_marker) {
    (*result)["is_rejected"] = true;
    (*result)["reject_reason"] = "unknown";
    (*result)["is_multi_intent"] = false;
    (*result)["frames"] = Json::Value(Json::arrayValue);
    return kContentSuccess;
  }
  char response_frame_separator = '\0';
  const size_t marker_size = config.response_multi_marker.size();
  if (content.size() > marker_size &&
      content.compare(0u, marker_size, config.response_multi_marker) == 0 &&
      IsDelimiterCandidate(config.response_frame_separators,
                           content[marker_size])) {
    response_frame_separator = content[marker_size];
  }
  // The prefix selects the only frame style; single output selects none.
  for (size_t i = 0u; i < config.response_frame_separators.size(); ++i) {
    const char candidate = config.response_frame_separators[i];
    if (candidate != response_frame_separator &&
        content.find(candidate) != std::string::npos)
      return kContentInvalidWrapper;
  }
  std::vector<std::string> records;
  if (response_frame_separator != '\0') {
    size_t offset = marker_size + 1u;
    while (offset <= content.size()) {
      const size_t end = content.find(response_frame_separator, offset);
      records.push_back(content.substr(
          offset, end == std::string::npos ? std::string::npos : end - offset));
      if (end == std::string::npos) break;
      offset = end + 1u;
    }
    if (records.size() < 2u) return kContentInvalidWrapper;
  } else {
    records.push_back(content);
  }
  Json::Value frames(Json::arrayValue);
  char response_assignment = '\0';
  char response_slot_separator = '\0';
  for (size_t i = 0u; i < records.size(); ++i) {
    Json::Value frame(Json::objectValue);
    const ContentParseResult code = ParseProfileFrame(
        records[i], config, &response_assignment, &response_slot_separator, &frame);
    if (code != kContentSuccess) return code;
    frames.append(frame);
  }
  if (frames.size() > 1u && !config.allow_multi_intent_output) {
    (*result)["is_rejected"] = true;
    (*result)["reject_reason"] = "multi_intent_disabled";
    (*result)["is_multi_intent"] = false;
    (*result)["frames"] = Json::Value(Json::arrayValue);
    return kContentSuccess;
  }
  (*result)["is_rejected"] = false;
  (*result)["reject_reason"] = "";
  (*result)["is_multi_intent"] = frames.size() > 1u;
  (*result)["frames"] = frames;
  return kContentSuccess;
}

ContentParseResult ParseContent(ResponseProtocol protocol,
                                const std::string& content,
                                Json::Value* result) {
  if (protocol == kResponseProtocolPipeV1) {
    return ParsePipeContent(content, result);
  }
  if (protocol == kResponseProtocolTsvV1) {
    return ParseTsvContent(content, result);
  }
  return kContentUnsupportedProtocol;
}

size_t BoundedUtf8PrefixSize(const std::string& value,
                             size_t maximum_bytes) {
  size_t size = std::min(value.size(), maximum_bytes);
  if (size == value.size()) {
    return size;
  }
  while (size > 0u &&
         (static_cast<unsigned char>(value[size]) & 0xc0u) == 0x80u) {
    --size;
  }
  return size;
}

std::string SanitizeLogValue(const std::string& value,
                             size_t maximum_bytes) {
  std::string sanitized =
      value.substr(0u, BoundedUtf8PrefixSize(value, maximum_bytes));
  for (size_t i = 0u; i < sanitized.size(); ++i) {
    const unsigned char current =
        static_cast<unsigned char>(sanitized[i]);
    if (std::iscntrl(current) != 0 || std::isspace(current) != 0) {
      sanitized[i] = static_cast<char>(95);
    }
  }
  return sanitized;
}

std::string SanitizeEndpointForLog(const std::string& endpoint) {
  const size_t scheme_separator = endpoint.find("://");
  if (scheme_separator == std::string::npos) {
    return "invalid_endpoint";
  }
  const size_t authority_begin = scheme_separator + 3u;
  const size_t authority_end = endpoint.find_first_of("/?#", authority_begin);
  std::string authority = endpoint.substr(
      authority_begin,
      authority_end == std::string::npos ? std::string::npos
                                         : authority_end - authority_begin);
  const size_t userinfo_separator = authority.rfind("@");
  if (userinfo_separator != std::string::npos) {
    authority.erase(0u, userinfo_separator + 1u);
  }

  std::string sanitized_endpoint =
      endpoint.substr(0u, authority_begin) + authority;
  if (authority_end != std::string::npos &&
      endpoint.compare(authority_end, 1u, "/") == 0) {
    const size_t path_end = endpoint.find_first_of("?#", authority_end);
    sanitized_endpoint.append(
        endpoint, authority_end,
        path_end == std::string::npos ? std::string::npos
                                      : path_end - authority_end);
  }
  return SanitizeLogValue(sanitized_endpoint,
                          kMaximumLoggedEndpointBytes);
}

const char* ResponseProtocolName(ResponseProtocol protocol) {
  if (protocol == kResponseProtocolTsvV1) return "tsv_v1";
  if (protocol == kResponseProtocolProfileV3) return "nlu_06b_v3";
  if (protocol == kResponseProtocolProfileV4) return "nlu_06b_v4";
  return "pipe_v1";
}

std::string BackendIdentityForLog(const std::string& endpoint,
                                  const std::string& model,
                                  ResponseProtocol protocol) {
  return std::string(" endpoint_url=") + SanitizeEndpointForLog(endpoint) +
         " model=" +
         SanitizeLogValue(model, kMaximumLoggedModelBytes) +
         " response_protocol=" + ResponseProtocolName(protocol);
}

enum DiagnosticCaptureWriteResult {
  kDiagnosticCaptureWritten = 0,
  kDiagnosticCaptureLimitReached,
  kDiagnosticCaptureWriteError,
};

class DiagnosticCaptureWriter {
 public:
  static std::unique_ptr<DiagnosticCaptureWriter> Create(
      const HttpBackendConfig& config) {
    const std::string& path = config.diagnostic_capture_output_path;
    const size_t separator = path.find_last_of('/');
    if (separator == std::string::npos || separator + 1 >= path.size()) {
      return std::unique_ptr<DiagnosticCaptureWriter>();
    }
    const std::string parent = separator == 0u ? "/" : path.substr(0, separator);
    struct stat parent_status;
    if (stat(parent.c_str(), &parent_status) != 0 ||
        !S_ISDIR(parent_status.st_mode)) {
      return std::unique_ptr<DiagnosticCaptureWriter>();
    }
    const int descriptor = open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL |
                                 O_CLOEXEC, S_IRUSR | S_IWUSR);
    if (descriptor < 0) {
      return std::unique_ptr<DiagnosticCaptureWriter>();
    }
    return std::unique_ptr<DiagnosticCaptureWriter>(
        new DiagnosticCaptureWriter(
            descriptor, config.diagnostic_capture_request_id_prefix,
            static_cast<size_t>(config.diagnostic_capture_max_entries),
            static_cast<size_t>(
                config.diagnostic_capture_max_content_bytes)));
  }

  ~DiagnosticCaptureWriter() {
    if (descriptor_ >= 0) {
      close(descriptor_);
    }
  }

  bool Matches(const std::string& request_id) const {
    return request_id.compare(0, request_id_prefix_.size(),
                              request_id_prefix_) == 0;
  }

  DiagnosticCaptureWriteResult Write(
      const Nlu06BRequest& request, long http_status, size_t response_bytes,
      const std::string& content, ContentParseResult parse_result,
      const Json::Value& parsed_result) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (failed_) {
      return kDiagnosticCaptureWriteError;
    }
    if (entries_written_ >= max_entries_) {
      return kDiagnosticCaptureLimitReached;
    }

    const size_t captured_bytes =
        BoundedUtf8PrefixSize(content, max_content_bytes_);
    Json::Value record(Json::objectValue);
    record["request_id"] = request.request_id;
    record["query"] = request.query;
    record["outcome"] = parse_result == kContentSuccess
                            ? "success"
                            : "failure";
    record["content"] = content.substr(0, captured_bytes);
    record["schema_detail"] = ContentParseResultName(parse_result);
    record["parsed_result"] = parse_result == kContentSuccess
                                  ? parsed_result
                                  : Json::Value();
    record["http_status"] = static_cast<Json::LargestInt>(http_status);
    record["response_bytes"] =
        static_cast<Json::LargestUInt>(response_bytes);
    record["content_bytes"] =
        static_cast<Json::LargestUInt>(content.size());
    record["captured_content_bytes"] =
        static_cast<Json::LargestUInt>(captured_bytes);
    record["truncated"] = captured_bytes != content.size();
    const std::string line = JsonToString(record) + "\n";

    const off_t starting_offset = lseek(descriptor_, 0, SEEK_CUR);
    if (starting_offset < 0 || !WriteAll(line.data(), line.size())) {
      if (starting_offset >= 0) {
        while (ftruncate(descriptor_, starting_offset) != 0 &&
               errno == EINTR) {
        }
        while (lseek(descriptor_, starting_offset, SEEK_SET) < 0 &&
               errno == EINTR) {
        }
      }
      failed_ = true;
      return kDiagnosticCaptureWriteError;
    }
    ++entries_written_;
    return kDiagnosticCaptureWritten;
  }

 private:
  DiagnosticCaptureWriter(int descriptor, const std::string& request_id_prefix,
                          size_t max_entries, size_t max_content_bytes)
      : descriptor_(descriptor),
        request_id_prefix_(request_id_prefix),
        max_entries_(max_entries),
        max_content_bytes_(max_content_bytes),
        entries_written_(0u),
        failed_(false) {}

  bool WriteAll(const char* data, size_t size) {
    size_t offset = 0u;
    while (offset < size) {
      const ssize_t written =
          write(descriptor_, data + offset, size - offset);
      if (written < 0) {
        if (errno == EINTR) {
          continue;
        }
        return false;
      }
      if (written == 0) {
        return false;
      }
      offset += static_cast<size_t>(written);
    }
    return true;
  }

  int descriptor_;
  const std::string request_id_prefix_;
  const size_t max_entries_;
  const size_t max_content_bytes_;
  size_t entries_written_;
  bool failed_;
  std::mutex mutex_;
};

struct ResponseBuffer {
  ResponseBuffer(std::string* response_body, size_t maximum_bytes)
      : body(response_body), max_bytes(maximum_bytes), overflow(false) {}

  std::string* body;
  size_t max_bytes;
  bool overflow;
};

size_t WriteResponse(void* contents, size_t size, size_t count, void* user_data) {
  ResponseBuffer* buffer = static_cast<ResponseBuffer*>(user_data);
  if (buffer == nullptr || buffer->body == nullptr ||
      (size != 0 && count > std::numeric_limits<size_t>::max() / size)) {
    return 0;
  }
  const size_t bytes = size * count;
  if (bytes > buffer->max_bytes - buffer->body->size()) {
    buffer->overflow = true;
    return 0;
  }
  buffer->body->append(static_cast<const char*>(contents), bytes);
  return bytes;
}

class CurlGlobalReference {
 public:
  CurlGlobalReference() { clu::Curl::InitCurl(); }
  ~CurlGlobalReference() { clu::Curl::CleanupCurl(); }

 private:
  CurlGlobalReference(const CurlGlobalReference&) = delete;
  CurlGlobalReference& operator=(const CurlGlobalReference&) = delete;
};

class CurlHttpTransport : public Nlu06BHttpTransport {
 public:
  CurlHttpTransport() {}

  int Post(const Nlu06BHttpRequest& request,
           Nlu06BHttpResponse* response) const override {
    if (response == nullptr || request.endpoint.empty() || request.body.empty() ||
        request.connect_timeout_ms <= 0 || request.total_timeout_ms <= 0 ||
        request.max_response_bytes == 0) {
      return -1;
    }
    response->status_code = 0;
    response->body.clear();
    CURL* handle = curl_easy_init();
    if (handle == nullptr) {
      return -1;
    }
    curl_slist* headers = nullptr;
    for (const auto& header : request.headers) {
      curl_slist* appended = curl_slist_append(headers, header.c_str());
      if (appended == nullptr) {
        curl_slist_free_all(headers);
        curl_easy_cleanup(handle);
        return -1;
      }
      headers = appended;
    }

    std::string response_body;
    ResponseBuffer buffer(&response_body, request.max_response_bytes);
    bool options_ok = true;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_URL, request.endpoint.c_str()) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_POST, 1L) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_POSTFIELDS, request.body.data()) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_POSTFIELDSIZE_LARGE,
                         static_cast<curl_off_t>(request.body.size())) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_HTTPHEADER, headers) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, WriteResponse) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_WRITEDATA, &buffer) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_NOSIGNAL, 1L) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_CONNECTTIMEOUT_MS,
                         request.connect_timeout_ms) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_TIMEOUT_MS,
                         request.total_timeout_ms) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_FOLLOWLOCATION, 0L) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_SSL_VERIFYPEER, 1L) == CURLE_OK;
    options_ok = options_ok &&
        curl_easy_setopt(handle, CURLOPT_SSL_VERIFYHOST, 2L) == CURLE_OK;

    const CURLcode perform_code =
        options_ok ? curl_easy_perform(handle) : CURLE_FAILED_INIT;
    long status_code = 0;
    const CURLcode info_code =
        curl_easy_getinfo(handle, CURLINFO_RESPONSE_CODE, &status_code);
    curl_slist_free_all(headers);
    curl_easy_cleanup(handle);
    if (buffer.overflow) {
      return kHttpResponseTooLarge;
    }
    if (perform_code != CURLE_OK || info_code != CURLE_OK) {
      return -1;
    }
    response->status_code = status_code;
    response->body.swap(response_body);
    return 0;
  }

 private:
  CurlGlobalReference curl_global_reference_;
};

class HttpBackend : public Nlu06BBackend {
 public:
  HttpBackend(const HttpBackendConfig& config,
              std::unique_ptr<Nlu06BHttpTransport> transport,
              std::unique_ptr<DiagnosticCaptureWriter> capture_writer)
      : config_(config),
        transport_(std::move(transport)),
        capture_writer_(std::move(capture_writer)) {}

  int Process(const Nlu06BRequest& request,
              Json::Value* result) const override {
    if (result == nullptr || !transport_ || request.query.empty() ||
        (config_.response_protocol == kResponseProtocolTsvV1 &&
         ContainsTsvRecordDelimiter(request.query))) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=input outcome=error request_id="
                 << request.request_id << " reason=invalid_input";
      return -1;
    }
    *result = Json::Value();

    std::string user_content;
    if (config_.response_protocol == kResponseProtocolPipeV1) {
      Json::Value model_input(Json::objectValue);
      model_input["query"] = request.query;
      model_input["histories"] = request.histories;
      model_input["model_last_context"] = request.model_last_context;
      user_content = JsonToString(model_input);
    } else if (config_.response_protocol == kResponseProtocolTsvV1) {
      if (!BuildTsvUserContent(request, &user_content)) {
        LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=input outcome=error request_id="
                 << request.request_id << " reason=invalid_input";
        return -1;
      }
    } else if (!BuildProfileUserContent(request, config_, &user_content)) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=input outcome=error request_id="
                 << request.request_id << " reason=invalid_input";
      return -1;
    }

    Json::Value payload(Json::objectValue);
    payload["model"] = config_.model;
    payload["messages"] = Json::Value(Json::arrayValue);
    Json::Value system_message(Json::objectValue);
    system_message["role"] = "system";
    system_message["content"] = config_.system_prompt;
    payload["messages"].append(system_message);
    Json::Value user_message(Json::objectValue);
    user_message["role"] = "user";
    user_message["content"] = user_content;
    payload["messages"].append(user_message);
    payload["temperature"] = config_.temperature;
    payload["top_p"] = config_.top_p;
    payload["top_k"] = config_.top_k;
    payload["max_tokens"] = config_.max_tokens;
    if (config_.response_protocol == kResponseProtocolPipeV1) {
      payload["stream"] = false;
      payload["enable_thinking"] = config_.enable_thinking;
      payload["chat_template_kwargs"]["enable_thinking"] =
          config_.enable_thinking;
    } else if (config_.profile_mode) {
      payload["stream"] = false;
      payload["enable_thinking"] = config_.enable_thinking;
    }

    Nlu06BHttpRequest http_request;
    http_request.endpoint = config_.endpoint;
    http_request.headers.push_back("Content-Type: application/json");
    if (!config_.api_key.empty()) {
      http_request.headers.push_back("Authorization: Bearer " +
                                     config_.api_key);
    }
    http_request.body = JsonToString(payload);
    http_request.connect_timeout_ms = config_.connect_timeout_ms;
    http_request.total_timeout_ms = config_.total_timeout_ms;
    http_request.max_response_bytes =
        static_cast<size_t>(config_.max_response_bytes);

    Nlu06BHttpResponse response;
    const int post_code = transport_->Post(http_request, &response);
    if (post_code == kHttpResponseTooLarge ||
        response.body.size() > http_request.max_response_bytes) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=response outcome=error request_id="
                 << request.request_id << " reason=response_too_large "
                 << "max_response_bytes=" << http_request.max_response_bytes;
      return -1;
    }
    if (post_code < 0) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=transport outcome=error request_id="
                 << request.request_id << " reason=transport";
      return -1;
    }
    if (response.status_code < 200 || response.status_code >= 300) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=http_status outcome=error request_id="
                 << request.request_id << " reason=http_status status_category="
                 << HttpStatusCategory(response.status_code);
      return -1;
    }

    Json::Value envelope;
    if (!ParseJsonWithoutLogging(response.body, &envelope)) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=envelope outcome=error request_id="
                 << request.request_id << " reason=envelope_parse "
                 << "response_bytes=" << response.body.size();
      return -1;
    }
    if (!envelope.isObject() || !envelope.isMember("choices") ||
        !envelope["choices"].isArray() ||
        envelope["choices"].size() != 1u ||
        !envelope["choices"][0u].isObject() ||
        !envelope["choices"][0u].isMember("message") ||
        !envelope["choices"][0u]["message"].isObject() ||
        !envelope["choices"][0u]["message"].isMember("content") ||
        !envelope["choices"][0u]["message"]["content"].isString()) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=envelope outcome=error request_id="
                 << request.request_id << " reason=envelope_schema "
                 << "response_bytes=" << response.body.size();
      return -1;
    }
    const std::string content =
        envelope["choices"][0u]["message"]["content"].asString();
    const ContentParseResult parse_result = config_.profile_mode
        ? ParseProfileContent(config_, content, result)
        : ParseContent(config_.response_protocol, content, result);
    if (capture_writer_ && capture_writer_->Matches(request.request_id)) {
      const DiagnosticCaptureWriteResult capture_result =
          capture_writer_->Write(request, response.status_code,
                                 response.body.size(), content, parse_result,
                                 *result);
      if (capture_result == kDiagnosticCaptureWriteError) {
        LOG(ERROR) << "component=nlu06b_http "
                   << "event=nlu06b_diagnostic_capture_failure "
                   << "stage=write outcome=error request_id="
                   << request.request_id << " reason=write_failed";
      }
    }
    // Request-local diagnostics are not part of the protected parsed_result.
    // Move the original decoded JSON string only after the capture above.
    (*result)["nlu_result"].swap(
        envelope["choices"][0u]["message"]["content"]);
    if (parse_result != kContentSuccess) {
      LOG(ERROR) << "component=nlu06b_http event=nlu06b_http_failure "
                 << "stage=content outcome=error request_id="
                 << request.request_id << " backend=openai_http "
                 << "reason=content_schema schema_detail="
                 << ContentParseResultName(parse_result) +
                    BackendIdentityForLog(config_.endpoint, config_.model,
                                          config_.response_protocol)
                 << " http_status=" << response.status_code
                 << " response_bytes=" << response.body.size()
                 << " content_bytes=" << content.size();
      return -1;
    }
    return 0;
  }

  const char* result_source() const override { return "nlu06b"; }

 private:
  const HttpBackendConfig config_;
  const std::unique_ptr<Nlu06BHttpTransport> transport_;
  const std::unique_ptr<DiagnosticCaptureWriter> capture_writer_;
};

std::unique_ptr<Nlu06BBackend> CreateFromConfig(
    const Json::Value& config, const std::string& base_path,
    std::unique_ptr<Nlu06BHttpTransport> transport) {
  HttpBackendConfig parsed;
  if (!transport || !ParseConfig(config, base_path, &parsed)) {
    return std::unique_ptr<Nlu06BBackend>();
  }
  std::unique_ptr<DiagnosticCaptureWriter> capture_writer;
  if (parsed.diagnostic_capture_enabled) {
    capture_writer = DiagnosticCaptureWriter::Create(parsed);
    if (!capture_writer) {
      return std::unique_ptr<Nlu06BBackend>();
    }
  }
  return std::unique_ptr<Nlu06BBackend>(new HttpBackend(
      parsed, std::move(transport), std::move(capture_writer)));
}

}  // namespace

std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config, const std::string& base_path) {
  return CreateFromConfig(
      config, base_path,
      std::unique_ptr<Nlu06BHttpTransport>(new CurlHttpTransport()));
}

std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config) {
  return CreateNlu06BHttpBackend(config, std::string());
}

std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config, const std::string& base_path,
    std::unique_ptr<Nlu06BHttpTransport> transport) {
  return CreateFromConfig(config, base_path, std::move(transport));
}

std::unique_ptr<Nlu06BBackend> CreateNlu06BHttpBackend(
    const Json::Value& config,
    std::unique_ptr<Nlu06BHttpTransport> transport) {
  return CreateFromConfig(config, std::string(), std::move(transport));
}

}  // namespace nlptk
