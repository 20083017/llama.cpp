// Copyright 2022 the project authors. All Rights Reserved.

#include "dialog/local_context_manager.h"

#include <cassert>
#include <chrono>
#include <time.h>

#include "base/json_helper.h"

namespace nlptk {
namespace dialog {

using std::map;
using std::string;
using std::vector;

namespace {

const int kDefaultExpireSeconds = 300;

class SystemLocalContextClock : public LocalContextClock {
 public:
  int64_t NowSeconds() const override {
    struct timespec value;
    if (clock_gettime(CLOCK_BOOTTIME, &value) == 0 && value.tv_sec >= 0) {
      return static_cast<int64_t>(value.tv_sec);
    }
    return std::chrono::duration_cast<std::chrono::seconds>(
               std::chrono::steady_clock::now().time_since_epoch())
        .count();
  }
};

}  // namespace

const char LocalContextManager::kType[] = "local";
const int LocalContextManager::kOperationalNeverExpiresSeconds =
    7 * 24 * 60 * 60;

LocalContextManager::Context::Context(const std::string& value,
                                      const ContextType& value_type,
                                      int64_t value_update_time)
    : update_time(value_update_time), ctx(value), type(value_type) {}

LocalContextManager::LocalContextManager()
    : LocalContextManager(std::shared_ptr<LocalContextClock>(
          new SystemLocalContextClock())) {}

LocalContextManager::LocalContextManager(
    const std::shared_ptr<LocalContextClock>& clock)
    : interval_(std::chrono::seconds(60)),
      clock_(clock ? clock
                   : std::shared_ptr<LocalContextClock>(
                         new SystemLocalContextClock())),
      stop_thread_(false) {
  expire_map_[ContextType::kNeverExpires] =
      kOperationalNeverExpiresSeconds;
  timed_cleaner_ = std::thread(&LocalContextManager::TimedCleanCtx, this);
}

LocalContextManager::~LocalContextManager() {
  {
    std::lock_guard<std::mutex> lock(mutex_);
    stop_thread_ = true;
  }
  cleaner_cv_.notify_all();
  if (timed_cleaner_.joinable()) {
    timed_cleaner_.join();
  }
}

int LocalContextManager::Initialize(const string& config_file) {
  return 0;
}

int LocalContextManager::Initialize(const Json::Value& config) {
  const int interval_value =
      JsonHelper::ResolveJPath<int>(config, "interval", 60);
  if (interval_value <= 0) {
    LOG(ERROR) << "Invalid local context cleanup interval: "
               << interval_value;
    return -1;
  }

  std::map<ContextType, int> expire_map;
  const Json::Value expire_obj =
      JsonHelper::ResolveJPath(config, "expire_strategy");
  for (Json::ValueConstIterator it = expire_obj.begin();
       it != expire_obj.end(); ++it) {
    if (it.name() == "user_session") {
      expire_map[ContextType::kUserSession] = it->asInt();
    } else if (it.name() == "llm_simple_cache") {
      expire_map[ContextType::kLLMSimpleCache] = it->asInt();
    } else if (it.name() == "query_records") {
      expire_map[ContextType::KQueryRecords] = it->asInt();
    } else {
      LOG(ERROR) << "Unknown expire strategy: " << it.name();
      return -1;
    }
  }
  expire_map[ContextType::kNeverExpires] =
      kOperationalNeverExpiresSeconds;

  {
    std::lock_guard<std::mutex> lock(mutex_);
    interval_ = std::chrono::seconds(interval_value);
    expire_map_.swap(expire_map);
  }
  cleaner_cv_.notify_all();
  return 0;
}

int LocalContextManager::GetExpireTimeLocked(
    const ContextType& type) const {
  const std::map<ContextType, int>::const_iterator found =
      expire_map_.find(type);
  if (found != expire_map_.end()) {
    return found->second;
  }
  LOG(WARNING) << "Context type " << type
               << " not found in context map.";
  return kDefaultExpireSeconds;
}

bool LocalContextManager::IsExpiredLocked(
    const Context& context, int64_t now_seconds) const {
  const int expire_seconds = GetExpireTimeLocked(context.type);
  if (expire_seconds < 0) {
    return true;
  }
  if (now_seconds < context.update_time) {
    return false;
  }
  return now_seconds - context.update_time >=
         static_cast<int64_t>(expire_seconds);
}

size_t LocalContextManager::RemoveExpiredLocked(
    int64_t now_seconds) const {
  size_t count = 0;
  for (std::map<std::string, Context>::iterator it = cache_.begin();
       it != cache_.end();) {
    if (IsExpiredLocked(it->second, now_seconds)) {
      cache_.erase(it++);
      ++count;
    } else {
      ++it;
    }
  }
  return count;
}

int LocalContextManager::Get(const string& session_id,
                             vector<Turn*>* session) const {
  assert(session);
  session->clear();

  std::string content;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    std::map<std::string, Context>::iterator found = cache_.find(session_id);
    if (found == cache_.end()) {
      return 0;
    }
    const int64_t now_seconds = clock_->NowSeconds();
    if (IsExpiredLocked(found->second, now_seconds)) {
      cache_.erase(found);
      return 0;
    }
    content = found->second.ctx;
  }

  const Json::Value list = JsonHelper::ParseJsonFromString(content);
  for (const Json::Value& item : list) {
    Turn* turn = new Turn;
    if (turn != nullptr && turn->Deserialize(item) >= 0) {
      session->push_back(turn);
    } else {
      delete turn;
      LOG(ERROR) << "Failed to deserialize object from: "
                 << JsonHelper::ToString(item);
    }
  }
  return 0;
}

int LocalContextManager::Put(const string& session_id,
                             const vector<Turn*>& session) {
  Json::Value list(Json::arrayValue);
  for (const Turn* turn : session) {
    if (turn != nullptr) {
      list.append(turn->Serialize());
    }
  }
  const std::string content = JsonHelper::ToString(list);
  const int64_t now_seconds = clock_->NowSeconds();
  size_t count = 0;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (GetExpireTimeLocked(ContextType::kUserSession) < 0) {
      LOGI << "The ContentType:" << ContextType::kUserSession
           << " is expired right now, so do not save it to memory.";
      return 0;
    }
    std::map<std::string, Context>::iterator found = cache_.find(session_id);
    if (found != cache_.end() && IsExpiredLocked(found->second, now_seconds)) {
      cache_.erase(found);
      found = cache_.end();
    }
    if (found != cache_.end()) {
      found->second.ctx = content;
      found->second.update_time = now_seconds;
      found->second.type = ContextType::kUserSession;
    } else {
      cache_.insert(std::make_pair(
          session_id,
          Context(content, ContextType::kUserSession, now_seconds)));
    }
    count = cache_.size();
  }
  LOGI << "Store session context up to " << count
       << " with Id: " << session_id;
  return 0;
}

int LocalContextManager::Get(const string& key, std::string* value) const {
  assert(value);
  value->clear();
  std::lock_guard<std::mutex> lock(mutex_);
  std::map<std::string, Context>::iterator found = cache_.find(key);
  if (found == cache_.end()) {
    return 0;
  }
  const int64_t now_seconds = clock_->NowSeconds();
  if (IsExpiredLocked(found->second, now_seconds)) {
    cache_.erase(found);
    return 0;
  }
  *value = found->second.ctx;
  return 0;
}

int LocalContextManager::Put(const string& key, const std::string& value,
                             const ContextType& type) {
  const int64_t now_seconds = clock_->NowSeconds();
  size_t count = 0;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (GetExpireTimeLocked(type) < 0) {
      LOGI << "The ContentType:" << type
           << " is expired right now, so do not save it to memory.";
      return 0;
    }
    std::map<std::string, Context>::iterator found = cache_.find(key);
    if (found != cache_.end() && IsExpiredLocked(found->second, now_seconds)) {
      cache_.erase(found);
      found = cache_.end();
    }
    if (found != cache_.end()) {
      found->second.ctx = value;
      found->second.update_time = now_seconds;
      found->second.type = type;
    } else {
      cache_.insert(std::make_pair(key, Context(value, type, now_seconds)));
    }
    count = cache_.size();
  }
  LOGI << "Store query-info context with Id: '" << key
       << "', context size:" << count;
  return 0;
}

void LocalContextManager::TimedCleanCtx() {
  LOGI << "Start to TimedCleanCtx.";
  std::unique_lock<std::mutex> lock(mutex_);
  while (!stop_thread_) {
    cleaner_cv_.wait_for(lock, interval_);
    if (stop_thread_) {
      break;
    }
    const size_t count = RemoveExpiredLocked(clock_->NowSeconds());
    const size_t remaining = cache_.size();
    if (count > 0) {
      LOGI << "TimedCleanCtx: removed expired " << count
           << " keys, remaining cache-size: " << remaining;
    }
  }
}

int LocalContextManager::ZGet(const std::string& key, int zrange,
                              std::vector<std::string>* values) const {
  assert(values);
  values->clear();
  std::lock_guard<std::mutex> lock(mutex_);
  std::map<std::string, Context>::iterator found = cache_.find(key);
  if (found == cache_.end()) {
    return 0;
  }
  const int64_t now_seconds = clock_->NowSeconds();
  if (IsExpiredLocked(found->second, now_seconds)) {
    cache_.erase(found);
    return 0;
  }
  std::vector<MemberScore> list;
  found->second.sorted_set.GetAll(&list);
  int count = 0;
  for (std::vector<MemberScore>::reverse_iterator it = list.rbegin();
       it != list.rend() && count < zrange; ++it, ++count) {
    values->push_back(it->member);
  }
  return 0;
}

int LocalContextManager::ZAdd(const std::string& key,
                              const std::string& value, double score,
                              const ContextType& type) {
  const int64_t now_seconds = clock_->NowSeconds();
  size_t count = 0;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (GetExpireTimeLocked(type) < 0) {
      LOGI << "The ContentType:" << type
           << " is expired right now, so do not save it to memory.";
      return 0;
    }
    std::map<std::string, Context>::iterator found = cache_.find(key);
    if (found != cache_.end() && IsExpiredLocked(found->second, now_seconds)) {
      cache_.erase(found);
      found = cache_.end();
    }
    if (found != cache_.end()) {
      found->second.sorted_set.Add(value, score);
      found->second.update_time = now_seconds;
      found->second.type = type;
    } else {
      Context context("", type, now_seconds);
      context.sorted_set.Add(value, score);
      cache_.insert(std::make_pair(key, context));
    }
    count = cache_.size();
  }
  LOGI << "Store query-info context with Id: '" << key
       << "', context size:" << count;
  return 0;
}

int LocalContextManager::HGet(const std::string& key,
                              std::vector<std::string>* values) const {
  assert(values);
  values->clear();
  std::lock_guard<std::mutex> lock(mutex_);
  std::map<std::string, Context>::iterator found = cache_.find(key);
  if (found == cache_.end()) {
    return 0;
  }
  const int64_t now_seconds = clock_->NowSeconds();
  if (IsExpiredLocked(found->second, now_seconds)) {
    cache_.erase(found);
    return 0;
  }
  for (HMap::const_iterator it = found->second.hmap.begin();
       it != found->second.hmap.end(); ++it) {
    values->push_back(it->second);
  }
  return 0;
}

int LocalContextManager::HSet(const std::string& key,
                              const std::string& field,
                              const std::string& value,
                              const ContextType& type) {
  const int64_t now_seconds = clock_->NowSeconds();
  std::lock_guard<std::mutex> lock(mutex_);
  if (GetExpireTimeLocked(type) < 0) {
    LOGI << "The ContentType:" << type
         << " is expired right now, so do not save it to memory.";
    return 0;
  }
  std::map<std::string, Context>::iterator found = cache_.find(key);
  if (found != cache_.end() && IsExpiredLocked(found->second, now_seconds)) {
    cache_.erase(found);
    found = cache_.end();
  }
  if (found != cache_.end()) {
    found->second.hmap[field] = value;
    found->second.update_time = now_seconds;
    found->second.type = type;
  } else {
    Context context("", type, now_seconds);
    context.hmap[field] = value;
    cache_.insert(std::make_pair(key, context));
  }
  return 0;
}

int LocalContextManager::HDel(const std::string& key,
                              const std::string& field) {
  std::lock_guard<std::mutex> lock(mutex_);
  std::map<std::string, Context>::iterator found = cache_.find(key);
  if (found == cache_.end()) {
    return 0;
  }
  const int64_t now_seconds = clock_->NowSeconds();
  if (IsExpiredLocked(found->second, now_seconds)) {
    cache_.erase(found);
    return 0;
  }
  found->second.hmap.erase(field);
  if (found->second.hmap.empty()) {
    cache_.erase(found);
  }
  return 0;
}

int LocalContextManager::Del(const std::string& key) {
  std::lock_guard<std::mutex> lock(mutex_);
  cache_.erase(key);
  return 0;
}

}  // namespace dialog
}  // namespace nlptk
