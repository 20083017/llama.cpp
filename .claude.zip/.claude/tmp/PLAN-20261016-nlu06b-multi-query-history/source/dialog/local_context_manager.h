// Copyright 2022 the project authors. All Rights Reserved.

#ifndef DIALOG_LOCAL_CONTEXT_MANAGER_H_
#define DIALOG_LOCAL_CONTEXT_MANAGER_H_

#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "common/sorted_set.hpp"
#include "dialog/context_manager.h"

namespace nlptk {
namespace dialog {

using HMap = std::map<std::string, std::string>;

class LocalContextClock {
 public:
  virtual ~LocalContextClock() {}
  virtual int64_t NowSeconds() const = 0;
};

class LocalContextManager : public ContextManager {
 public:
  static const char kType[];
  static const int kOperationalNeverExpiresSeconds;

  struct Context {
    int64_t update_time;
    std::string ctx;
    SortedSet sorted_set;
    HMap hmap;
    ContextType type;

    Context(const std::string& ctx, const ContextType& type,
            int64_t update_time);
  };

 public:
  LocalContextManager();
  explicit LocalContextManager(
      const std::shared_ptr<LocalContextClock>& clock);
  virtual ~LocalContextManager();

  int Initialize(const std::string& config_file) override;
  int Initialize(const Json::Value& config) override;

  int Get(const std::string& session_id,
          std::vector<Turn*>* session) const override;

  int Put(const std::string& session_id,
          const std::vector<Turn*>& session) override;

  int Get(const std::string& key, std::string* value) const override;

  int Put(const std::string& key, const std::string& value,
          const ContextType& type) override;

  int ZGet(const std::string& key, int zrange,
           std::vector<std::string>* values) const override;

  int ZAdd(const std::string& key, const std::string& value, double score,
           const ContextType& type) override;

  int HGet(const std::string& key,
           std::vector<std::string>* values) const override;

  int HSet(const std::string& key, const std::string& field,
           const std::string& value, const ContextType& type) override;
  int HDel(const std::string& key, const std::string& field) override;

  int Del(const std::string& key) override;

 private:
  int GetExpireTimeLocked(const ContextType& type) const;
  bool IsExpiredLocked(const Context& context, int64_t now_seconds) const;
  size_t RemoveExpiredLocked(int64_t now_seconds) const;
  void TimedCleanCtx();

 private:
  std::chrono::seconds interval_;
  mutable std::mutex mutex_;
  std::condition_variable cleaner_cv_;
  mutable std::map<std::string, Context> cache_;
  std::thread timed_cleaner_;
  std::map<ContextType, int> expire_map_;
  std::shared_ptr<LocalContextClock> clock_;
  bool stop_thread_;

  LocalContextManager(const LocalContextManager&) = delete;
  LocalContextManager& operator=(const LocalContextManager&) = delete;
};

}  // namespace dialog
}  // namespace nlptk

#endif  // DIALOG_LOCAL_CONTEXT_MANAGER_H_
