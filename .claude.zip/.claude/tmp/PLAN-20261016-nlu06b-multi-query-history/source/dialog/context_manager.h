// Copyright 2022 the project authors. All Rights Reserved.

#ifndef DIALOG_CONTEXT_MANAGER_H_
#define DIALOG_CONTEXT_MANAGER_H_

#include <string>
#include <vector>

#include "dialog/turn.h"
#include "json/json.h"

namespace nlptk {
namespace dialog {

class ContextManager {
 public:
  enum ContextType {
    kUserSession,
    kLLMSimpleCache,
    KQueryRecords,
    kNeverExpires
  };

 public:
  static ContextManager* Create(const std::string& type);
  static ContextManager* Create(const std::string& type,
                                const Json::Value& config);
  static ContextManager* Create(const std::string& type,
                                const std::string& config_file);

 public:
  virtual ~ContextManager();

 public:
  virtual int Initialize(const std::string& config_file) = 0;
  virtual int Initialize(const Json::Value& config) = 0;

  virtual int Get(const std::string& session_id,
                  std::vector<Turn*>* session) const = 0;

  virtual int Put(const std::string& session_id,
                  const std::vector<Turn*>& session) = 0;

  virtual int Get(const std::string& key, std::string* value) const = 0;

  virtual int Put(const std::string& key, const std::string& value,
                  const ContextType& type) = 0;

  virtual int ZGet(const std::string& key, int zrange, std::vector<std::string> *values) const = 0;

  virtual int ZAdd(const std::string& key, const std::string &value, double score,
          const ContextType& type) = 0;

  virtual int HGet(const std::string& key, std::vector<std::string> *values) const = 0;

  virtual int HSet(const std::string& key, const std::string &field, const std::string &value,
          const ContextType& type) = 0;
  
  virtual int HDel(const std::string& key, const std::string &field) = 0;
  virtual int Del(const std::string& key) = 0;
};

}  // namespace dialog
}  // namespace nlptk

#endif  // DIALOG_CONTEXT_MANAGER_H_
