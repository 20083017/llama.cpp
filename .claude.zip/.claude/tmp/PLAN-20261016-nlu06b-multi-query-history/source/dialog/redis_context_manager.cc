// Copyright 2022 the project authors. All Rights Reserved.

#include "dialog/redis_context_manager.h"

#include <cassert>
#include <chrono>
#include <map>

#include "base/json_helper.h"
#include "base/string_util.h"
#include "common/utils.h"
#include "redis-plus-plus/command_options.h"
#include "redis-plus-plus/connection.h"
#include "redis-plus-plus/connection_pool.h"
#include "redis-plus-plus/utils.h"

namespace nlptk {
namespace dialog {

namespace {
int GetExpireTime(const std::map<ContextManager::ContextType, int>& ctx,
                  const ContextManager::ContextType& type) {
  int expire_time = 0;
  if (ctx.find(type) != ctx.end()) {
    expire_time = ctx.at(type);
  } else {
    LOG(WARNING) << "Context type " << type << " not found in context map.";
  }
  return expire_time;
}
}  // namespace

using std::string;
using std::vector;
using sw::redis::ConnectionOptions;
using sw::redis::ConnectionPoolOptions;
using sw::redis::Redis;
using sw::redis::RedisCluster;

static const char kContextHeader[] = "dialog_context_";
const char RedisContextManager::kType[] = "redis";

RedisContextManager::RedisContextManager()
    : cluster_(nullptr), redis_(nullptr) {}

RedisContextManager::~RedisContextManager() {
  if (cluster_) {
    delete cluster_;
    cluster_ = nullptr;
  }

  if (redis_) {
    delete redis_;
    redis_ = nullptr;
  }
}

int RedisContextManager::Initialize(const string& config_file) {
  if (StringUtil::EmptyOrSpaces(config_file)) {
    LOG(ERROR) << "Empty config file is given: " << config_file;
    return -1;
  }

  auto config = JsonHelper::ParseJsonFromFile(config_file);
  if (config.isNull() || config.empty()) {
    LOG(ERROR) << "Invalid config is given from: "
               << JsonHelper::ToString(config);
    return -1;
  }

  return Initialize(config);
}

int RedisContextManager::Initialize(const Json::Value& config) {
  auto expire_obj = JsonHelper::ResolveJPath(config, "expire_strategy");
  for (auto itor = expire_obj.begin(); itor != expire_obj.end(); ++itor) {
    if (itor.name() == "user_session") {
      expire_map_[ContextType::kUserSession] = itor->asInt();
    } else if (itor.name() == "llm_simple_cache") {
      expire_map_[ContextType::kLLMSimpleCache] = itor->asInt();
    } else if (itor.name() == "query_records") {
      expire_map_[ContextType::KQueryRecords] = itor->asInt();
    } else {
      LOG(ERROR) << "Unknown expire strategy: " << itor.name();
      return -1;
    }
  }
  expire_map_[ContextType::kNeverExpires] = 0;
  auto host =
      StringUtil::Trim(JsonHelper::ResolveJPath<string>(config, "host", ""));
  if (host.empty()) {
    LOG(ERROR) << "Empty redis host is given: " << JsonHelper::ToString(config);
    return -1;
  }
  if (host.find("$") != string::npos) {
    host = clu::GetEnv(host, "");
  }
  if (host.empty()) {
    LOG(ERROR) << "Empty redis host is given: " << JsonHelper::ToString(config);
    return -1;
  }
  auto port = JsonHelper::ResolveJPath<std::string>(config, "port", "6379");
  if (port.find("$") != string::npos) {
    port = clu::GetEnv(port, "6379");
  }
  int redis_port;
  if (!clu::ParseInt(port, &redis_port) || redis_port <= 0) {
    LOG(ERROR) << "Invalid redis port is given: " << port;
    return -1;
  }

  auto auth = JsonHelper::ResolveJPath<string>(config, "auth", "${REDIS_AUTH}");
  if (auth.find("$") != string::npos) {
    auth = clu::GetEnv(auth, "");
  }
  if (auth.empty()) {
    LOG(WARNING) << "Empty redis auth is empty.";
  }

  auto db = JsonHelper::ResolveJPath<std::string>(config, "db", "${REDIS_DB}");
  if (db.find("$") != string::npos) {
    db = clu::GetEnv(db, "0");
  }
  int redis_db;
  if (!clu::ParseInt(db, &redis_db) || redis_db < 0) {
    LOG(ERROR) << "Invalid redis db is given: " << db;
    return -1;
  }
  LOGI << "Redis host: " << host <<", port: "<< port << ", db: " << redis_db;
  auto wait_timeout = std::chrono::milliseconds(
      JsonHelper::ResolveJPath<int32_t>(config, "wait_timeout", 500));
  auto pool_size =
      JsonHelper::ResolveJPath<int8_t>(config, "redis_pool_size", 4);

  mode_ = JsonHelper::ResolveJPath<string>(config, "mode", "cluster");
  ConnectionOptions connection_options;
  connection_options.host = host;
  connection_options.port = redis_port;
  if (!auth.empty()) {
    connection_options.password = auth;
  }

  connection_options.db = redis_db;
  ConnectionPoolOptions pool_options;
  pool_options.wait_timeout = wait_timeout;
  pool_options.size = pool_size;

  try {
    if (mode_ == "single") {
      redis_ = new Redis(connection_options, pool_options);
    } else if (mode_ == "cluster") {
      cluster_ = new RedisCluster(connection_options, pool_options);
    } else {
      LOG(ERROR) << "Failed to redis mode: " << mode_;
      return -1;
    }
  } catch (const sw::redis::ReplyError& err) {
    LOG(ERROR) << "Failed to connect to redis(ReplyError)" << err.what();
    return -1;
  } catch (const sw::redis::TimeoutError& err) {
    LOG(ERROR) << "Failed to connect to redis(TimeoutError)" << err.what();
    return -1;
  } catch (const sw::redis::ClosedError& err) {
    LOG(ERROR) << "Failed to connect to redis(ClosedError)" << err.what();
    return -1;
  } catch (const sw::redis::IoError& err) {
    LOG(ERROR) << "Failed to connect to redis(IoError)" << err.what();
    return -1;
  } catch (const sw::redis::Error& err) {
    LOG(ERROR) << "Failed to connect to redis(OtherErrors)" << err.what();
    return -1;
  }

  return 0;
}

int RedisContextManager::Get(const string& session_id,
                             vector<Turn*>* session) const {
  assert(session);

  session->clear();
  string key;
  if (BuildKey(session_id, &key) < 0) {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid session id: " << session_id;
    return -1;
  }

  string content;
  if (mode_ == "single" && redis_) {
    auto value = redis_->get(key);
    content = *value;
    if (StringUtil::EmptyOrSpaces(content)) {
      LOGI << "[" << session_id << "]: Empty content is get from redis!";
      return 0;
    }
  } else if (mode_ == "cluster" && cluster_) {
    auto value = cluster_->get(key);
    content = *value;
    if (StringUtil::EmptyOrSpaces(content)) {
      LOGI << "[" << session_id << "]: Empty content is get from redis!";
      return 0;
    }
  } else {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid redis connection!";
    return -1;
  }

  auto list = JsonHelper::ParseJsonFromString(content);
  for (auto item : list) {
    Turn* turn = new Turn;
    if (turn != nullptr && turn->Deserialize(item) >= 0) {
      session->push_back(turn);
    } else {
      delete turn;
      LOG(ERROR) << "Failed to deserialize object from: "
                 << JsonHelper::ToString(item);
      return -1;
    }
  }

  return 0;
}

int RedisContextManager::Put(const string& session_id,
                             const vector<Turn*>& session) {
  Json::Value list(Json::ValueType::arrayValue);
  for (const auto& turn : session) {
    if (turn != nullptr) {
      list.append(turn->Serialize());
    }
  }

  auto content = JsonHelper::ToString(list);
  string key;
  if (BuildKey(session_id, &key) < 0) {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid session id: " << session_id;
    return -1;
  }
  auto expire_time = GetExpireTime(expire_map_, ContextType::kUserSession);
  if (mode_ == "single" && redis_) {
    if (!redis_->set(key, content, std::chrono::seconds(expire_time))) {
      LOG(ERROR) << "[" << session_id << "]: Failed to write the context to redis!";
      return -1;
    }
  } else if (mode_ == "cluster" && cluster_) {
    if (!cluster_->set(key, content, std::chrono::seconds(expire_time))) {
      LOG(ERROR) << "[" << session_id << "]: Failed to write the context to redis!";
      return -1;
    }
  } else {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid redis connection!";
    return -1;
  }

  return 0;
}

int RedisContextManager::Get(const string& session_id,
                             std::string* value) const {
  assert(value);
  value->clear();
  string key;
  if (BuildKey(session_id, &key) < 0) {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid session id: " << session_id;
    return -1;
  }
  if (mode_ == "single" && redis_) {
    *value = *(redis_->get(key));
    if (StringUtil::EmptyOrSpaces(*value)) {
      LOGI << "[" << session_id << "]: Empty content is get from redis!";
      return 0;
    }
  } else if (mode_ == "cluster" && cluster_) {
    *value = *(cluster_->get(key));
    if (StringUtil::EmptyOrSpaces(*value)) {
      LOGI << "[" << session_id << "]: Empty content is get from redis!";
      return 0;
    }
  } else {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid redis connection!";
    return -1;
  }
  return 0;
}

int RedisContextManager::Put(const string& session_id, const std::string& value,
                             const ContextType& type) {
  string key;
  if (BuildKey(session_id, &key) < 0) {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid session id: " << session_id;
    return -1;
  }
  if (expire_map_.find(type) != expire_map_.end() && expire_map_[type] < 0) {
    LOGI << "[" << session_id << "]: The ContentType:" << type
              << " is expired rigth now, so do not save it to redis";
    return 0;
  }
  auto expire_time = GetExpireTime(expire_map_, type);
  if (mode_ == "single" && redis_) {
    if (!redis_->set(key, value, std::chrono::seconds(expire_time))) {
      LOG(ERROR) << "[" << session_id << "]: Failed to write the context to redis!";
      return -1;
    }
  } else if (mode_ == "cluster" && cluster_) {
    if (!cluster_->set(key, value, std::chrono::seconds(expire_time))) {
      LOG(ERROR) << "[" << session_id << "]: Failed to write the context to redis!";
      return -1;
    }
  } else {
    LOG(ERROR) << "[" << session_id << "]: Skip due to invalid redis connection!";
    return -1;
  }
  return 0;
}

int RedisContextManager::BuildKey(const string session_id, string* key) const {
  assert(key);
  if (!StringUtil::EmptyOrSpaces(session_id)) {
    key->assign(kContextHeader);
    *key += session_id;
    return 0;
  }
  return -1;
}

int RedisContextManager::ZGet(const std::string& key, int zrange,
                              std::vector<std::string>* values) const {
  assert(values);
  values->clear();
  string build_key;
  if (BuildKey(key, &build_key) < 0) {
    LOG(ERROR) << "Skip due to invalid session id: " << key;
    return -1;
  }
  if (mode_ == "single" && redis_) {
    redis_->zrevrange(build_key, 0, zrange, std::back_inserter(*values));
    if (values->empty()) {
      LOG(WARNING) << "Empty content is get from redis!";
      return 0;
    }
  } else if (mode_ == "cluster" && cluster_) {
    cluster_->zrevrange(build_key, 0, zrange, std::back_inserter(*values));
    if (values->empty()) {
      LOG(WARNING) << "Empty content is get from redis!";
      return 0;
    }
  } else {
    LOG(ERROR) << "Skip due to invalid redis connection!";
    return -1;
  }
  return 0;
}

int RedisContextManager::ZAdd(const std::string& key, const std::string& value,
                              double score, const ContextType& type) {
  string build_key;
  if (BuildKey(key, &build_key) < 0) {
    LOG(ERROR) << "Skip due to invalid session id: " << key;
    return -1;
  }
  if (expire_map_.find(type) != expire_map_.end() && expire_map_[type] < 0) {
    LOGI << "The ContentType:" << type
              << " is expired rigth now, so do not save it to redis";
    return 0;
  }
  auto expire_time = GetExpireTime(expire_map_, type);
  auto update_type = sw::redis::UpdateType::ALWAYS;
  bool changed = false;  //
  try {
    if (mode_ == "single" && redis_) {
      if (redis_->zadd(build_key, value, score, update_type, changed) == 0) {
        LOG(ERROR) << "Failed to write the context to redis!";
        return -1;
      }
      redis_->expire(build_key, expire_time);
    } else if (mode_ == "cluster" && cluster_) {
      if (!cluster_->zadd(build_key, value, score, update_type, changed) == 0) {
        LOG(ERROR) << "Failed to write the context to redis!";
        return -1;
      }
      redis_->expire(build_key, expire_time);
    } else {
      LOG(ERROR) << "Skip due to invalid redis connection!";
      return -1;
    }
  } catch (const sw::redis::Error& e) {
    LOG(ERROR) << "Failed to write the context to redis: " << e.what();
  }
  return 0;
}

int RedisContextManager::HGet(const std::string& key,
                              std::vector<std::string>* values) const {
  assert(values);
  values->clear();
  string build_key;
  if (BuildKey(key, &build_key) < 0) {
    LOG(ERROR) << "[" << key << "]: Skip due to invalid session id: " << key;
    return -1;
  }
  std::vector<std::pair<std::string, std::string>> result;
  try {
    if (mode_ == "single" && redis_) {
      redis_->hgetall(build_key, std::back_inserter(result));
      if (result.empty()) {
        LOGI << "[" << key << "]: Empty content is get from redis!";
        return 0;
      }
    } else if (mode_ == "cluster" && cluster_) {
      cluster_->hgetall(build_key, std::back_inserter(result));
      if (result.empty()) {
        LOGI << "[" << key << "]: Empty content is get from redis!";
        return 0;
      }
    } else {
      LOG(ERROR) << "[" << key << "]: Skip due to invalid redis connection!";
      return -1;
    }
  } catch (const sw::redis::Error& e) {
    LOG(ERROR) << "[" << key << "]: Failed to write the context to redis: " << e.what();
  }
  for (auto& item : result) {
    values->push_back(item.second);
  }
  return 0;
}

int RedisContextManager::HSet(const std::string& key, const std::string& field,
                              const std::string& value,
                              const ContextType& type) {
  string build_key;
  if (BuildKey(key, &build_key) < 0) {
    LOG(ERROR) << "[" << key << "]: Skip due to invalid session id: " << key;
    return -1;
  }
  if (expire_map_.find(type) != expire_map_.end() && expire_map_[type] < 0) {
    LOGI << "[" << key << "]: The ContentType:" << type
              << " is expired rigth now, so do not save it to redis";
    return 0;
  }
  auto expire_time = GetExpireTime(expire_map_, type);
  try {
    if (mode_ == "single" && redis_) {
      redis_->hset(build_key, field, value);
      redis_->expire(build_key, expire_time);
    } else if (mode_ == "cluster" && cluster_) {
      cluster_->hset(build_key, field, value);
      cluster_->expire(build_key, expire_time);
    } else {
      LOG(ERROR) << "[" << key << "]: Skip due to invalid redis connection!";
      return -1;
    }
  } catch (const sw::redis::Error& e) {
    LOG(ERROR) << "[" << key << "]: Failed to write the context to redis: " << e.what();
  }
  return 0;
}

int RedisContextManager::HDel(const std::string& key,
                              const std::string& field) {
  string build_key;
  if (BuildKey(key, &build_key) < 0) {
    LOG(ERROR) << "[" << key << "]: Skip due to invalid session id: " << key;
    return -1;
  }
  try {
    if (mode_ == "single" && redis_) {
      redis_->hdel(build_key, field);
    } else if (mode_ == "cluster" && cluster_) {
      cluster_->hdel(build_key, field);
    } else {
      LOG(ERROR) << "[" << key << "]: Skip due to invalid redis connection!";
      return -1;
    }
  } catch (const sw::redis::Error& e) {
    LOG(ERROR) << "[" << key << "]: Failed to delete the context from redis: " << e.what();
  }
  return 0;
}

int RedisContextManager::Del(const std::string& key) {
  string build_key;
  if (BuildKey(key, &build_key) < 0) {
    LOG(ERROR) << "[" << key << "]: Skip due to invalid session id: " << key;
    return -1;
  }
  try {
    if (mode_ == "single" && redis_) {
      redis_->del(build_key);
    } else if (mode_ == "cluster" && cluster_) {
      cluster_->del(build_key);
    } else {
      LOG(ERROR) << "[" << key << "]: Skip due to invalid redis connection!";
      return -1;
    }
  } catch (const sw::redis::Error& e) {
    LOG(ERROR) << "[" << key << "]: Failed to delete the context from redis: " << e.what();
  }
  return 0;
}

}  // namespace dialog
}  // namespace nlptk
