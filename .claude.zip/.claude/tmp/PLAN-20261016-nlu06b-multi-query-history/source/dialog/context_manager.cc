// Copyright 2022 the project authors. All Rights Reserved.

#include "dialog/context_manager.h"

#include "base/json_helper.h"
#include "dialog/local_context_manager.h"
#include "dialog/redis_context_manager.h"
#include "common/utils.h"

namespace nlptk {
namespace dialog {

using std::string;

ContextManager* ContextManager::Create(const string& type) {
  ContextManager* manager = nullptr;
  auto active_type = type;
  if (active_type.find("$") != std::string::npos) {
    active_type = clu::GetEnv(active_type, LocalContextManager::kType);
  }
  if (active_type == LocalContextManager::kType) {
    manager = new LocalContextManager;
    LOGI << "Using local context manager.";
  } else if (active_type == RedisContextManager::kType) {
    manager = new RedisContextManager;
    LOGI << "Using redis context manager.";
  }
  return manager;
}

ContextManager* ContextManager::Create(const string& type,
                                       const Json::Value& config) {
  ContextManager* manager = ContextManager::Create(type);
  if (manager) {
    if (manager->Initialize(config) < 0) {
      LOG(ERROR) << "Failed to load context manager from: "
                 << JsonHelper::ToString(config);
      delete manager;
      manager = nullptr;
    }
  }

  return manager;
}

ContextManager* ContextManager::Create(const string& type,
                                       const string& config_file) {
  ContextManager* manager = ContextManager::Create(type);
  if (manager) {
    if (manager->Initialize(config_file) < 0) {
      LOG(ERROR) << "Failed to load context manager from file: "
                 << config_file;
      delete manager;
      manager = nullptr;
    }
  }

  return manager;
}

ContextManager::~ContextManager() = default;

}  // namespace dialog
}  // namespace nlptk
