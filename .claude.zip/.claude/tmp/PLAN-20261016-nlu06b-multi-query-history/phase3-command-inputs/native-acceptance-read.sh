set -euo pipefail
log=/home/daigd/wtp184-validation-logs/PLAN-20261016-nlu06b-multi-query-history-v2-native.log
printf 'V10 AND RETAIN5 TEST EXECUTION\n'
grep -nE '^\[ (RUN|      OK) +\].*(V10|v10|Retain|retai|Keep|Five|History|history)' "$log" | tail -n 72
printf '\nNATIVE LOG SIZE\n'
stat -c 'bytes=%s' "$log"
