set -euo pipefail
log=/home/daigd/packages/logs/cu-dev-pipeline-android-v3-debug-20261016-143445.log
artifact=/home/daigd/packages/android-lib/libdialogue_api-android-v3-debug-arm64-v8a-api21.20261016-143458-3f086385.so
printf 'AUTHORITATIVE_ANDROID_LOG=%s\n' "$log"
printf 'ANDROID METADATA\n'
cat "$artifact.meta"
printf '\nPACKAGE INTEGRITY\n'
sha256sum "$artifact"
stat -c 'size=%s' "$artifact"
file "$artifact"
printf '\nV3 DEBUG POINTER\n'
cat /home/daigd/packages/android-lib/LATEST-v3-debug
printf '\nPIPELINE BUILD SELECTION\n'
grep -nE 'action=|project=|PROJECT_DIR|third_party|local_log=|Bazel |define|compilation|strip|cxxopt|target=|build_log|local build|WORKSPACE|Temporary|temporary|restor|SUCCESS|Build completed|processes|ERROR|FAILED' "$log" | tail -n 70
printf '\nLOG SIZE\n'; stat -c 'bytes=%s' "$log"
