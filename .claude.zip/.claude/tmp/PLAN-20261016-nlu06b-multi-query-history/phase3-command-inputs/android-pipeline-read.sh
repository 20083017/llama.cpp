set -euo pipefail
grep -nE 'LOG_FILE=|LOG_DIR=|tee |exec |artifact|metadata|LATEST|PACKAGE_DIR=|ANDROID_PACKAGE|sha256|dialogue_pipeline_v3|BAZEL_TARGET=' /home/daigd/cu-dev-pipeline-v18-android-dialogue-api.sh | sed -n '1,130p'
