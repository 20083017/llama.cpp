set -euo pipefail
sed -n '85,118p;1000,1058p;1183,1226p' /home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh
printf '\nBAZEL RC\n'
sed -n '1,160p' /home/daigd/dialogue/.bazelrc
printf '\nWRAPPERS\n'
for f in /home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc /home/daigd/tools/wtp184-gcc493-sysroot/bin/g++; do readlink -f "$f"; sed -n '1,100p' "$f"; done
printf '\nDEFAULT BAZEL\n'
command -v bazel
