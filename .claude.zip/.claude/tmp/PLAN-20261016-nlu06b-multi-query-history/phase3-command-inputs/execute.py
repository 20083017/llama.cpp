import os,sys,pathlib,subprocess,shlex,json
def emit(s): print(s,flush=True)
def need(ok,msg):
 if not ok: raise RuntimeError(msg)
def run(args,**kw): return subprocess.run(args,capture_output=True,timeout=kw.pop("timeout",15),**kw)
ssh=os.environ['PHASE2_SSH_EXE'];keygen=os.environ['PHASE2_KEYGEN_EXE'];cygpath=os.environ['PHASE2_CYGPATH_EXE']
alias='new2_wtp184-server'
files=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc','cu/v3_linux_offline_test.cc']
try:
 need(not any(os.environ.get(k) for k in ['WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS']),'Explicit override present; no alias fallback')
 r=run([ssh,'-G',alias]);emit('ssh -G new2_wtp184-server EXIT '+str(r.returncode));need(r.returncode==0,'Alias resolution failed')
 wanted=['hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','hostkeyalias','proxyjump','proxycommand','canonicalizehostname']
 cfg={}
 for line in r.stdout.decode().splitlines():
  k,_,v=line.partition(' ')
  if k in wanted:cfg.setdefault(k,[]).append(v)
 for k,v in [('hostname','10.1.120.40'),('user','daigd'),('port','22'),('identitiesonly','yes')]:need(cfg.get(k)==[v],'Alias mismatch: '+k)
 for k in ['proxyjump','proxycommand','hostkeyalias']:need(cfg.get(k,['none'])==['none'],'Unexpected '+k)
 need(cfg.get('canonicalizehostname',['false'])[0] in ['false','no'],'Hostname canonicalization enabled')
 def paths(v):
  lexer=shlex.shlex(v,posix=True);lexer.whitespace_split=True;lexer.commenters='';lexer.escape=''
  return list(lexer)
 identities=[]
 for v in cfg.get('identityfile',[]):
  # Each IdentityFile line is one path; preserve embedded spaces.
  if len(v)>=2 and v[0]==v[-1] and v[0] in ['"', "'"]:v=v[1:-1]
  identities.append(v)
 known=[(kind,i,p) for kind in ['userknownhostsfile','globalknownhostsfile'] for i,p in enumerate([p for v in cfg.get(kind,[]) for p in paths(v)],1) if p!='none']
 need(identities and known,'Missing configured identity/trust mechanisms')
 def native(p,category):
  if p=='~' or p.startswith('~/'):
   home=os.environ.get('HOME');need(bool(home),category+' tilde expansion: HOME absent')
   p=home.rstrip('/')+p[1:]
  need(not p.startswith('~') and '%' not in p,category+' unresolved path expansion')
  r=run([cygpath,'-w',p]);need(r.returncode==0,category+' cygpath conversion failed exit='+str(r.returncode))
  n=r.stdout.decode().strip();need(bool(n),category+' empty converted path')
  return n
 for i,p in enumerate(identities,1):
  category='identity['+str(i)+']';n=native(p,category)
  exists=pathlib.Path(n).is_file();readable=exists and os.access(n,os.R_OK)
  emit(category+' native_file='+str(exists)+' readable='+str(readable)+' conversion=cygpath-w')
  need(readable,category+' required configured identity absent/nonregular/unreadable')
 count=0;readable_known=0
 for kind,i,p in known:
  category=kind+'['+str(i)+']';n=native(p,category)
  exists=pathlib.Path(n).exists();regular=pathlib.Path(n).is_file();readable=regular and os.access(n,os.R_OK)
  emit(category+' basename='+pathlib.Path(n).name+' native_exists='+str(exists)+' readable='+str(readable)+' conversion=cygpath-w')
  if not exists:
   emit(category+' OPTIONAL_ABSENT skipped; no trust/config mutation');continue
  need(readable,category+' existing configured trust file nonregular/unreadable')
  readable_known+=1
  r=run([keygen,'-F','10.1.120.40','-f',n]);need(r.returncode in [0,1],category+' known-host lookup failed exit='+str(r.returncode))
  lines=[x for x in r.stdout.decode().splitlines() if x and not x.startswith('#')]
  need(not any(x.startswith('@revoked') for x in lines),category+' revoked destination key')
  matches=[x for x in lines if not x.startswith('@')]
  count+=len(matches);emit(category+' bare_HostName_trusted_matches='+str(len(matches)))
 need(readable_known>0 and count==2,'Pinned trust mismatch: expected two existing bare-HostName matches; found='+str(count))
 emit('CONTRACT PASS Ubuntu new2_wtp184-server -> daigd@10.1.120.40:22; configured readable identities; existing trust matches=2; no HostKeyAlias/proxy; no trust/config mutation')
 opts=['-T']
 for option in ['BatchMode=yes','StrictHostKeyChecking=yes','UpdateHostKeys=no','IdentitiesOnly=yes','IdentityAgent=none','PasswordAuthentication=no','KbdInteractiveAuthentication=no','PreferredAuthentications=publickey','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=10','ConnectionAttempts=1','ServerAliveInterval=10','ServerAliveCountMax=2','ProxyJump=none','ProxyCommand=none','CanonicalizeHostname=no']:opts+=['-o',option]
 code=pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
 bound=int(sys.argv[2])
 cmd='timeout --kill-after=20s '+str(bound)+'s /bin/bash --noprofile --norc -s'
 r=subprocess.run([ssh]+opts+[alias,cmd],input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=bound+45)
 print(r.stdout.decode(errors='replace'),end='')
 print(r.stderr.decode(errors='replace'),end='',file=sys.stderr)
 print('SSH_REMOTE_EXIT='+str(r.returncode),flush=True)
 sys.exit(r.returncode)
except Exception as e:
 print('EXECUTOR_FAIL '+str(e),file=sys.stderr);sys.exit(1)
