set -euo pipefail
sed -n '55,68p;135,154p;1736,1754p;2135,2170p;2198,2220p;2222,2238p;2260,2299p' /home/daigd/cu-dev-pipeline-v18-android-dialogue-api.sh
