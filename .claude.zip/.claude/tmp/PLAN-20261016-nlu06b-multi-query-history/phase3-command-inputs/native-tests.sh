set -euo pipefail
umask 077
cd /home/daigd/dialogue
export LC_ALL=C
export CC=/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc
export CXX=/home/daigd/tools/wtp184-gcc493-sysroot/bin/g++
export PATH="/home/daigd/tools/wtp184-gcc493-sysroot/bin:/home/daigd/tools/gcc-4.9.3-centos7/bin:$PATH"
logdir=/home/daigd/wtp184-validation-logs
mkdir -p "$logdir"
log="$logdir/PLAN-20261016-nlu06b-multi-query-history-v2-native.log"
if [[ -e "$log" ]]; then
  log="$logdir/PLAN-20261016-nlu06b-multi-query-history-v2-native-$(date -u +%Y%m%dT%H%M%SZ).log"
  printf 'Original native log exists; preserving it. Distinct run log=%s\n' "$log"
fi
(set -o noclobber; : > "$log")
printf 'NATIVE_LOG=%s\n' "$log"
set +e
(
 set -euo pipefail
 printf 'PLAN=PLAN-20261016-nlu06b-multi-query-history VERSION=2 PHASE=3 START=%s\n' "$(date -u +%FT%TZ)"
 printf 'PROJECT=%s CC=%s CXX=%s\n' "$PWD" "$CC" "$CXX"
 printf 'GCC_DUMPVERSION='; "$CC" -dumpversion
 printf 'GXX_DUMPVERSION='; "$CXX" -dumpversion
 printf 'SYSROOT='; "$CC" -print-sysroot
 [[ "$("$CC" -dumpversion)" == 4.9.3 ]]
 [[ "$("$CXX" -dumpversion)" == 4.9.3 ]]
 printf 'COMPILER WRAPPER CONTENTS\n'; cat "$CC" "$CXX"
 for target in //cu:nlu_0_6b_http_backend_test //cu:v3_query_history_policy_test //cu:v3_linux_offline_test; do
  cmd=(timeout --kill-after=15s 580s bazel test --cpu=k8 --host_cpu=k8 --define=dialogue_pipeline_v3=true --test_output=all --subcommands --cache_test_results=no "--action_env=CC=$CC" "--action_env=CXX=$CXX" "--action_env=PATH=$PATH" "$target")
  printf '\nTARGET_START=%s TIME=%s\nCOMMAND=' "$target" "$(date -u +%FT%TZ)"; printf '%q ' "${cmd[@]}"; printf '\n'
  set +e
  "${cmd[@]}"
  status=$?
  set -e
  printf 'TARGET_EXIT=%s STATUS=%s TIME=%s\n' "$target" "$status" "$(date -u +%FT%TZ)"
  if [[ "$status" != 0 ]]; then exit "$status"; fi
 done
 printf 'NATIVE_TESTS_COMPLETE=PASS TIME=%s\n' "$(date -u +%FT%TZ)"
) >> "$log" 2>&1
status=$?
set -e
printf 'NATIVE_EXIT=%s\nNATIVE_LOG=%s\n' "$status" "$log"
printf 'COMPACT_NATIVE_SUMMARY\n'
grep -nE 'TARGET_START|TARGET_EXIT|GCC_DUMPVERSION|GXX_DUMPVERSION|SYSROOT=|NATIVE_TESTS_COMPLETE|ERROR:|error:|FAILED|\[==========\]|\[  PASSED  \]|\[  FAILED  \]|Executed [0-9]|//cu:.*(PASSED|FAILED)' "$log" | tail -n 65 || :
if [[ "$status" != 0 ]]; then tail -n 45 "$log"; fi
exit "$status"
