// Copyright 2026 the project authors. All Rights Reserved.

#ifndef CU_STREAMING_COMPLETION_H_
#define CU_STREAMING_COMPLETION_H_

#include <exception>
#include <future>
#include <memory>
#include <utility>
#include <vector>

namespace nlptk {
namespace streaming_internal {

// Private StreamSegmentQuery outcome, not an enclosing request return code.
// Only a fully completed cache miss may finalize the segmentation cache.
const int kSegmentCacheMissComplete = 1;

// DialogueResponse copies borrow the singleton timeline AND its request entry.
// Install this deleter when constructing shared ownership, so allocation of the
// control block and all later preparation/insertion failures are covered too.
template <class Response>
struct BorrowedTimelineDeleter {
  void operator()(Response *response) const noexcept {
    response->timeline = nullptr;
    delete response;
  }
};

template <class Response>
std::shared_ptr<Response> CopyBorrowingTimeline(const Response &response) {
  return std::shared_ptr<Response>(new Response(response),
                                   BorrowedTimelineDeleter<Response>());
}

// The request thread alone changes records. Workers borrow their pointees,
// never entries in the vector. Register ownership BEFORE Submit, then assign
// the returned future immediately (future move assignment does not allocate).
template <class Turn, class Response>
struct QueryTask {
  QueryTask(const std::shared_ptr<Turn> &turn_owner,
            const std::shared_ptr<Response> &response_owner)
      : turn(turn_owner), response(response_owner) {}
  QueryTask(QueryTask &&) noexcept = default;
  QueryTask &operator=(QueryTask &&) noexcept = default;
  QueryTask(const QueryTask &) = delete;
  QueryTask &operator=(const QueryTask &) = delete;

  std::future<int> result;
  std::shared_ptr<Turn> turn;
  std::shared_ptr<Response> response;
};

template <class Queue>
void CloseQueueNoThrow(Queue &queue) noexcept {
  try {
    queue.WaitForStop();
  } catch (...) {
    // No diagnostics, business work or allocations during fallback cleanup.
  }
}

template <class Queue>
class CloseInputOnExit {
 public:
  explicit CloseInputOnExit(Queue &queue) noexcept : queue_(queue) {}
  ~CloseInputOnExit() noexcept { CloseQueueNoThrow(queue_); }
  CloseInputOnExit(const CloseInputOnExit &) = delete;
  CloseInputOnExit &operator=(const CloseInputOnExit &) = delete;

 private:
  Queue &queue_;
};

inline void WaitNoThrow(std::future<int> &result) noexcept {
  if (result.valid()) {
    try {
      result.wait();
    } catch (...) {
      // A valid pool future's wait does not rethrow the task's exception.
    }
  }
}

// All referenced state must be declared before this guard. Destruction only
// closes/wakes input, joins accepted bodies and then closes output. It never
// gets/merges results, caches or persists, and introduces no cleanup allocation.
// Queue closure is not cancellation; dependency timeouts remain unchanged.
template <class InputQueue, class OutputQueue, class Task>
class RequestCompletion {
 public:
  RequestCompletion(InputQueue &input, OutputQueue &output,
                    std::future<int> &producer, std::vector<Task> &tasks) noexcept
      : input_(input), output_(output), producer_(producer), tasks_(tasks) {}
  ~RequestCompletion() noexcept {
    CloseQueueNoThrow(input_);
    WaitNoThrow(producer_);
    for (auto &task : tasks_) {
      WaitNoThrow(task.result);
    }
    CloseQueueNoThrow(output_);
  }
  RequestCompletion(const RequestCompletion &) = delete;
  RequestCompletion &operator=(const RequestCompletion &) = delete;

 private:
  InputQueue &input_;
  OutputQueue &output_;
  std::future<int> &producer_;
  std::vector<Task> &tasks_;
};

struct Outcome {
  Outcome() : code(0) {}
  bool ok() const { return code >= 0 && !error; }

  int code;
  std::exception_ptr error;
};

inline Outcome ObserveProducer(std::future<int> &producer) {
  Outcome outcome;
  try {
    outcome.code = producer.get();
  } catch (...) {
    outcome.error = std::current_exception();
  }
  return outcome;
}

// Finish EVERY submitted task in order, including after a negative result or a
// get/merge exception. Only the successful prefix is merged. A later exception
// must not replace an earlier ordered negative (or an earlier exception).
// Propagation/mapping and all cache/persistence policy belong to the caller.
template <class Task, class Merge>
Outcome DrainQueries(std::vector<Task> &tasks, const Merge &merge) {
  Outcome outcome;
  for (auto &task : tasks) {
    try {
      const int code = task.result.get();
      if (outcome.ok()) {
        if (code < 0) {
          outcome.code = code;
        } else {
          merge(task);
        }
      }
    } catch (...) {
      if (outcome.ok()) {
        outcome.error = std::current_exception();
      }
    }
  }
  return outcome;
}

}  // namespace streaming_internal
}  // namespace nlptk

#endif  // CU_STREAMING_COMPLETION_H_
