// Copyright 2026 the project authors. All Rights Reserved.

#include "cu/streaming_completion.h"

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdlib>
#include <fstream>
#include <future>
#include <initializer_list>
#include <iterator>
#include <memory>
#include <mutex>
#include <new>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <vector>

#include "common/message_queue.h"
#include "common/sub_query.h"
#include "gtest/gtest.h"
#include "utils/simple_thread_pool.h"

namespace nlptk {
namespace {

namespace streaming = streaming_internal;
typedef clu::MessageQueue<std::shared_ptr<clu::SubQuery>> InputQueue;
typedef clu::MessageQueue<std::string> OutputQueue;
const std::chrono::seconds kWait(5);
const std::chrono::milliseconds kBlockedCheck(50);

// No sleeps: every worker gate has a bounded wait and every assertion exit
// releases gates/closes input before destroying a joining async future.
class Gate {
 public:
  Gate() : open_(false) {}
  bool Wait() {
    std::unique_lock<std::mutex> lock(mutex_);
    return cv_.wait_for(lock, kWait, [this] { return open_; });
  }
  void Release() {
    std::lock_guard<std::mutex> lock(mutex_);
    open_ = true;
    cv_.notify_all();
  }
 private:
  std::mutex mutex_;
  std::condition_variable cv_;
  bool open_;
};

class ReleaseOnExit {
 public:
  ReleaseOnExit(InputQueue &input, std::initializer_list<Gate *> gates)
      : input_(input), gates_(gates) {}
  ~ReleaseOnExit() {
    for (auto gate : gates_) {
      gate->Release();
    }
    input_.WaitForStop();
  }
 private:
  InputQueue &input_;
  std::vector<Gate *> gates_;
};

struct TimelineState {
  TimelineState() : removals(0), copies_destroyed(0) {}
  std::atomic<int> removals;
  std::atomic<int> copies_destroyed;
};

// Light owners model only the local ownership contract, NOT DialogueResponse
// payload/copy or cache semantics. Wiring checks below inspect actual V2 source
// without linking/loading the model stack.
struct LightResponse {
  explicit LightResponse(TimelineState *state)
      : semantic(0), state(state), timeline(state) {}
  LightResponse(const LightResponse &other)
      : semantic(other.semantic), state(other.state), timeline(other.timeline) {}
  ~LightResponse() {
    ++state->copies_destroyed;
    if (timeline) {
      ++timeline->removals;
    }
  }
  int semantic;
  TimelineState *state;
  TimelineState *timeline;
};

struct LightTurn {
  explicit LightTurn(int value = 0) : value(value) {}
  int value;
};

typedef streaming::QueryTask<LightTurn, LightResponse> Task;
typedef streaming::RequestCompletion<InputQueue, OutputQueue, Task> Completion;
static_assert(std::is_nothrow_move_constructible<Task>::value,
              "Record relocation must not strand an accepted future");

void AddRecord(std::vector<Task> *tasks, const LightResponse &original,
               int value = 0) {
  auto turn = std::make_shared<LightTurn>(value);
  auto response = streaming::CopyBorrowingTimeline(original);
  tasks->emplace_back(turn, response);
}

TEST(StreamingLifetime, ProducerAfterStopStillAllowsQueryOverlapButNotReturn) {
  ASSERT_GE(std::thread::hardware_concurrency(), 2u);
  utils::SimpleThreadPool pool(2);
  InputQueue input;
  OutputQueue output;
  TimelineState timeline;
  LightResponse original(&timeline);
  Gate release_producer;
  std::promise<void> producer_stopped, query_ran, observing;
  auto stopped = producer_stopped.get_future();
  auto ran = query_ran.get_future();
  auto observing_future = observing.get_future();
  std::atomic<bool> producer_done(false);
  auto request = std::async(std::launch::async, [&] {
    std::future<int> producer;
    streaming::Outcome producer_outcome;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    producer = pool.Submit([&] {
      streaming::CloseInputOnExit<InputQueue> close(input);
      input.ProduceMessage(std::make_shared<clu::SubQuery>("synthetic"));
      input.WaitForStop();
      producer_stopped.set_value();
      EXPECT_TRUE(release_producer.Wait());
      producer_done = true;
      return streaming::kSegmentCacheMissComplete;
    });
    auto message = input.ConsumeMessage();
    EXPECT_EQ("synthetic", message->generate_text);
    AddRecord(&tasks, original);
    tasks.back().result = pool.Submit([&] {
      EXPECT_FALSE(producer_done.load());
      query_ran.set_value();
      return 0;
    });
    observing.set_value();
    producer_outcome = streaming::ObserveProducer(producer);
    auto outcome = streaming::DrainQueries(tasks, [](Task &) {});
    EXPECT_TRUE(outcome.ok());
    EXPECT_TRUE(producer_done.load());
    return producer_outcome.code;
  });
  ReleaseOnExit cleanup(input, {&release_producer});
  ASSERT_EQ(std::future_status::ready, stopped.wait_for(kWait));
  ASSERT_EQ(std::future_status::ready, ran.wait_for(kWait));
  ASSERT_EQ(std::future_status::ready, observing_future.wait_for(kWait));
  EXPECT_EQ(std::future_status::timeout, request.wait_for(kBlockedCheck));
  EXPECT_EQ(0, timeline.copies_destroyed.load());
  release_producer.Release();
  ASSERT_EQ(std::future_status::ready, request.wait_for(kWait));
  EXPECT_EQ(streaming::kSegmentCacheMissComplete, request.get());
  EXPECT_EQ(1, timeline.copies_destroyed.load());
  EXPECT_EQ(0, timeline.removals.load());
  EXPECT_TRUE(output.IsStop());
}

TEST(StreamingLifetime, UnwindingAlsoWaitsForProducerAfterQueueStop) {
  ASSERT_GT(std::thread::hardware_concurrency(), 0u);
  utils::SimpleThreadPool pool(1);
  InputQueue input;
  OutputQueue output;
  Gate release_producer;
  std::promise<void> stopped, leaving;
  auto stopped_future = stopped.get_future();
  auto leaving_future = leaving.get_future();
  std::atomic<bool> done(false);
  auto request = std::async(std::launch::async, [&] {
    std::future<int> producer;
    streaming::Outcome producer_outcome;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    producer = pool.Submit([&] {
      streaming::CloseInputOnExit<InputQueue> close(input);
      input.WaitForStop();
      stopped.set_value();
      EXPECT_TRUE(release_producer.Wait());
      done = true;
      return 0;
    });
    EXPECT_EQ(std::future_status::ready, stopped_future.wait_for(kWait));
    leaving.set_value();
    throw std::runtime_error("preparation");
  });
  ReleaseOnExit cleanup(input, {&release_producer});
  ASSERT_EQ(std::future_status::ready, leaving_future.wait_for(kWait));
  EXPECT_EQ(std::future_status::timeout, request.wait_for(kBlockedCheck));
  EXPECT_FALSE(done.load());
  release_producer.Release();
  ASSERT_EQ(std::future_status::ready, request.wait_for(kWait));
  EXPECT_THROW(request.get(), std::runtime_error);
  EXPECT_TRUE(done.load());
  EXPECT_TRUE(output.IsStop());
}

// Use the production DrainQueries, not a duplicate test implementation. The
// later throwing task stays blocked until draining begins; no early failure
// may abandon its handle or replace the first ordered failure.
void CheckOrderedFailure(int failure_kind) {
  ASSERT_GE(std::thread::hardware_concurrency(), 2u);
  utils::SimpleThreadPool pool(2);
  InputQueue input;
  OutputQueue output;
  TimelineState timeline;
  LightResponse original(&timeline);
  Gate release_later;
  std::promise<void> later_started, draining;
  auto started = later_started.get_future();
  auto draining_future = draining.get_future();
  std::vector<int> merged;
  std::atomic<bool> later_done(false);
  auto request = std::async(std::launch::async, [&] {
    std::future<int> producer;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    AddRecord(&tasks, original, 1);
    tasks.back().result = pool.Submit([failure_kind] {
      if (failure_kind == 1) {
        throw std::runtime_error("first-query");
      }
      return failure_kind == 0 ? -7 : 0;
    });
    AddRecord(&tasks, original, 2);
    tasks.back().result = pool.Submit([&]() -> int {
      later_started.set_value();
      EXPECT_TRUE(release_later.Wait());
      later_done = true;
      throw std::runtime_error("later-query");
    });
    draining.set_value();
    return streaming::DrainQueries(tasks, [&](Task &task) {
      if (failure_kind == 2) {
        throw std::runtime_error("first-merge");
      }
      merged.push_back(task.turn->value);
    });
  });
  ReleaseOnExit cleanup(input, {&release_later});
  ASSERT_EQ(std::future_status::ready, started.wait_for(kWait));
  ASSERT_EQ(std::future_status::ready, draining_future.wait_for(kWait));
  EXPECT_EQ(std::future_status::timeout, request.wait_for(kBlockedCheck));
  EXPECT_EQ(0, timeline.copies_destroyed.load());
  release_later.Release();
  ASSERT_EQ(std::future_status::ready, request.wait_for(kWait));
  const auto outcome = request.get();
  EXPECT_TRUE(later_done.load());
  EXPECT_TRUE(merged.empty());
  if (failure_kind == 0) {
    EXPECT_EQ(-7, outcome.code);
    EXPECT_FALSE(static_cast<bool>(outcome.error));
  } else {
    ASSERT_TRUE(static_cast<bool>(outcome.error));
    try {
      std::rethrow_exception(outcome.error);
    } catch (const std::runtime_error &error) {
      EXPECT_EQ(failure_kind == 1 ? "first-query" : "first-merge",
                std::string(error.what()));
    }
  }
  EXPECT_EQ(2, timeline.copies_destroyed.load());
  EXPECT_EQ(0, timeline.removals.load());
  EXPECT_TRUE(output.IsStop());
}

TEST(StreamingLifetime, FirstNegativeDrainsLaterExceptionWithoutReplacingIt) {
  CheckOrderedFailure(0);
}
TEST(StreamingLifetime, FirstQueryExceptionDrainsLaterException) {
  CheckOrderedFailure(1);
}
TEST(StreamingLifetime, MergeExceptionDrainsLaterException) {
  CheckOrderedFailure(2);
}

TEST(StreamingLifetime, SuccessfulPrefixMergesInSubmissionNotFinishOrder) {
  ASSERT_GE(std::thread::hardware_concurrency(), 2u);
  utils::SimpleThreadPool pool(2);
  InputQueue input;
  OutputQueue output;
  TimelineState timeline;
  LightResponse original(&timeline);
  Gate release_first;
  std::promise<void> first_started, last_finished, draining;
  auto first = first_started.get_future();
  auto last = last_finished.get_future();
  auto draining_future = draining.get_future();
  std::vector<int> merged;
  auto request = std::async(std::launch::async, [&] {
    std::future<int> producer;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    AddRecord(&tasks, original, 1);
    tasks.back().result = pool.Submit([&] {
      first_started.set_value();
      EXPECT_TRUE(release_first.Wait());
      return 0;
    });
    AddRecord(&tasks, original, 2);
    tasks.back().result = pool.Submit([] { return 0; });
    AddRecord(&tasks, original, 3);
    tasks.back().result = pool.Submit([&] {
      last_finished.set_value();
      return 0;
    });
    // Submission may relocate records while task 1 borrows its pointees.
    draining.set_value();
    return streaming::DrainQueries(tasks, [&](Task &task) {
      merged.push_back(task.turn->value);
    });
  });
  ReleaseOnExit cleanup(input, {&release_first});
  ASSERT_EQ(std::future_status::ready, first.wait_for(kWait));
  ASSERT_EQ(std::future_status::ready, last.wait_for(kWait));
  ASSERT_EQ(std::future_status::ready, draining_future.wait_for(kWait));
  EXPECT_EQ(std::future_status::timeout, request.wait_for(kBlockedCheck));
  release_first.Release();
  ASSERT_EQ(std::future_status::ready, request.wait_for(kWait));
  EXPECT_TRUE(request.get().ok());
  EXPECT_EQ((std::vector<int>{1, 2, 3}), merged);
  EXPECT_EQ(0, timeline.removals.load());
}

void CheckProducerFailure(bool publish, bool throws) {
  ASSERT_GT(std::thread::hardware_concurrency(), 0u);
  utils::SimpleThreadPool pool(1);
  InputQueue input;
  OutputQueue output;
  {
    std::future<int> producer;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    std::promise<void> consuming;
    auto consuming_future = consuming.get_future();
    auto consumer = std::async(std::launch::async, [&] {
      consuming.set_value();
      int count = 0;
      try {
        for (;;) {
          input.ConsumeMessage();
          ++count;
        }
      } catch (const std::runtime_error &) {
        return count;
      }
    });
    ReleaseOnExit cleanup(input, {});
    ASSERT_EQ(std::future_status::ready, consuming_future.wait_for(kWait));
    producer = pool.Submit([&] {
      streaming::CloseInputOnExit<InputQueue> close(input);
      if (publish) {
        input.ProduceMessage(std::make_shared<clu::SubQuery>("synthetic"));
      }
      if (throws) {
        throw std::runtime_error("producer");
      }
      return -1;
    });
    ASSERT_EQ(std::future_status::ready, consumer.wait_for(kWait));
    EXPECT_EQ(publish ? 1 : 0, consumer.get());
    const auto outcome = streaming::ObserveProducer(producer);
    EXPECT_FALSE(outcome.ok());
    EXPECT_EQ(throws, static_cast<bool>(outcome.error));
    if (!throws) {
      EXPECT_EQ(-1, outcome.code);
    }
    EXPECT_TRUE(input.IsStop());
  }
  EXPECT_TRUE(output.IsStop());
}

TEST(StreamingLifetime, ProducerNegativeBeforePublicationWakesConsumer) {
  CheckProducerFailure(false, false);
}
TEST(StreamingLifetime, ProducerNegativeAfterPublicationWakesConsumer) {
  CheckProducerFailure(true, false);
}
TEST(StreamingLifetime, ProducerExceptionBeforePublicationWakesConsumer) {
  CheckProducerFailure(false, true);
}
TEST(StreamingLifetime, ProducerExceptionAfterPublicationWakesConsumer) {
  CheckProducerFailure(true, true);
}

std::future<int> RejectBeforeAcceptance() {
  throw std::bad_alloc();
}

void CheckConsumerFailure(bool submission) {
  ASSERT_GT(std::thread::hardware_concurrency(), 0u);
  utils::SimpleThreadPool pool(1);
  InputQueue input;
  OutputQueue output;
  TimelineState timeline;
  LightResponse original(&timeline);
  Gate release_worker;
  std::promise<void> started, leaving;
  auto started_future = started.get_future();
  auto leaving_future = leaving.get_future();
  std::atomic<bool> done(false);
  auto request = std::async(std::launch::async, [&] {
    std::future<int> producer;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    AddRecord(&tasks, original);
    tasks.back().result = pool.Submit([&] {
      started.set_value();
      EXPECT_TRUE(release_worker.Wait());
      EXPECT_EQ(0, output.ProduceMessage("synthetic-chunk"));
      done = true;
      return 0;
    });
    auto next = streaming::CopyBorrowingTimeline(original);
    if (!submission) {
      leaving.set_value();
      // Models an allocating subquery assignment after response construction.
      throw std::bad_alloc();
    }
    tasks.emplace_back(std::make_shared<LightTurn>(), next);
    leaving.set_value();
    tasks.back().result = RejectBeforeAcceptance();
  });
  ReleaseOnExit cleanup(input, {&release_worker});
  ASSERT_EQ(std::future_status::ready, started_future.wait_for(kWait));
  ASSERT_EQ(std::future_status::ready, leaving_future.wait_for(kWait));
  EXPECT_EQ(std::future_status::timeout, request.wait_for(kBlockedCheck));
  EXPECT_FALSE(done.load());
  EXPECT_FALSE(output.IsStop());  // Fallback must close only AFTER writers.
  EXPECT_EQ(0, timeline.removals.load());
  release_worker.Release();
  ASSERT_EQ(std::future_status::ready, request.wait_for(kWait));
  EXPECT_THROW(request.get(), std::bad_alloc);
  EXPECT_TRUE(done.load());
  EXPECT_EQ(2, timeline.copies_destroyed.load());
  EXPECT_EQ(0, timeline.removals.load());
  EXPECT_EQ("synthetic-chunk", output.ConsumeMessage());
  EXPECT_TRUE(output.IsStop());
}

TEST(StreamingLifetime, PreparationFailureWaitsForPreviouslyAcceptedWorker) {
  CheckConsumerFailure(false);
}
TEST(StreamingLifetime, SubmissionFailureKeepsRegisteredOwnersAndPriorHandle) {
  CheckConsumerFailure(true);
}

// Standard allocator fault injection, not an executor or production adapter.
template <class T>
struct FailingAllocator {
  typedef T value_type;
  FailingAllocator() noexcept {}
  template <class U>
  FailingAllocator(const FailingAllocator<U> &) noexcept {}
  template <class U>
  struct rebind { typedef FailingAllocator<U> other; };
  T *allocate(std::size_t) { throw std::bad_alloc(); }
  void deallocate(T *p, std::size_t n) { std::allocator<T>().deallocate(p, n); }
};
template <class T, class U>
bool operator==(const FailingAllocator<T> &, const FailingAllocator<U> &) {
  return true;
}
template <class T, class U>
bool operator!=(const FailingAllocator<T> &, const FailingAllocator<U> &) {
  return false;
}

TEST(StreamingLifetime, BorrowedTimelineSurvivesControlBlockAllocationFailure) {
  TimelineState timeline;
  LightResponse original(&timeline);
  auto fail_control_block = [&] {
    // Same construction-installed production deleter; force only the standard
    // shared_ptr control-block allocation to fail (no global new override).
    std::shared_ptr<LightResponse> copy(
        new LightResponse(original),
        streaming::BorrowedTimelineDeleter<LightResponse>(),
        FailingAllocator<LightResponse>());
  };
  EXPECT_THROW(fail_control_block(), std::bad_alloc);
  EXPECT_EQ(1, timeline.copies_destroyed.load());
  EXPECT_EQ(0, timeline.removals.load());
}

TEST(StreamingLifetime, BorrowedTimelineSurvivesActualRecordInsertionFailure) {
  TimelineState timeline;
  LightResponse original(&timeline);
  auto fail_insert = [&] {
    auto copy = streaming::CopyBorrowingTimeline(original);
    std::vector<Task, FailingAllocator<Task>> records;
    records.emplace_back(std::make_shared<LightTurn>(), copy);
  };
  EXPECT_THROW(fail_insert(), std::bad_alloc);
  EXPECT_EQ(1, timeline.copies_destroyed.load());
  EXPECT_EQ(0, timeline.removals.load());
}

struct ThrowingCopyResponse {
  explicit ThrowingCopyResponse(TimelineState *state)
      : state(state), fail_copy(true), timeline(state) {}
  ThrowingCopyResponse(const ThrowingCopyResponse &other)
      : state(other.state), fail_copy(other.fail_copy) {
    if (fail_copy) {
      throw std::bad_alloc();
    }
    timeline = other.timeline;  // Like the real response: borrowed field LAST.
  }
  ~ThrowingCopyResponse() {
    ++state->copies_destroyed;
    if (timeline) {
      ++timeline->removals;
    }
  }
  TimelineState *state;
  bool fail_copy;
  TimelineState *timeline;
};

TEST(StreamingLifetime, IncompleteCopyDoesNotRunResponseDestructor) {
  TimelineState timeline;
  ThrowingCopyResponse original(&timeline);
  EXPECT_THROW(streaming::CopyBorrowingTimeline(original), std::bad_alloc);
  EXPECT_EQ(0, timeline.copies_destroyed.load());
  EXPECT_EQ(0, timeline.removals.load());
}

std::future<int> ReadyResult(int code) {
  std::promise<int> result;
  auto future = result.get_future();
  result.set_value(code);
  return future;
}

TEST(StreamingLifetime, NegativePreservesOnlySuccessfulPrefixAndDrainsAll) {
  TimelineState timeline;
  LightResponse original(&timeline);
  std::vector<Task> tasks;
  for (int i = 1; i <= 3; ++i) {
    AddRecord(&tasks, original, i);
    tasks.back().result = ReadyResult(i == 2 ? -9 : 0);
  }
  std::vector<int> merged;
  const auto outcome = streaming::DrainQueries(tasks, [&](Task &task) {
    merged.push_back(task.turn->value);
  });
  EXPECT_EQ(-9, outcome.code);
  EXPECT_FALSE(static_cast<bool>(outcome.error));
  EXPECT_EQ((std::vector<int>{1}), merged);
  for (auto &task : tasks) {
    EXPECT_FALSE(task.result.valid());
  }
}

TEST(StreamingLifetime, CacheStoreAndFinalizationFailuresLeaveNoBorrowedOwners) {
  ASSERT_GT(std::thread::hardware_concurrency(), 0u);
  utils::SimpleThreadPool pool(1);
  // These fault points test the shared lifetime boundary, NOT real Redis or
  // serialization. The source-wiring cases below tie their ordering to V2.
  for (int fault = 0; fault < 4; ++fault) {
    SCOPED_TRACE(fault);
    TimelineState timeline;
    LightResponse original(&timeline);
    InputQueue input;
    OutputQueue output;
    std::weak_ptr<LightResponse> borrowed;
    std::atomic<bool> writer_done(false);
    auto request_body = [&] {
      std::future<int> producer;
      std::vector<Task> tasks;
      Completion completion(input, output, producer, tasks);
      producer = ReadyResult(streaming::kSegmentCacheMissComplete);
      AddRecord(&tasks, original);
      borrowed = tasks.back().response;
      tasks.back().result = pool.Submit([&] {
        // Nobody consumes output: queue closure must not require HTTP drain.
        output.ProduceMessage("synthetic-chunk");
        writer_done = true;
        return 0;
      });
      const auto producer_outcome = streaming::ObserveProducer(producer);
      EXPECT_EQ(streaming::kSegmentCacheMissComplete, producer_outcome.code);
      const auto query_outcome = streaming::DrainQueries(tasks, [](Task &) {});
      EXPECT_TRUE(query_outcome.ok());
      EXPECT_TRUE(writer_done.load());
      if (fault == 0) {
        throw std::runtime_error("cache");
      }
      output.WaitForStop();
      if (fault == 1) {
        throw std::runtime_error("store");
      }
      if (fault == 2) {
        throw std::runtime_error("semantic-finalization");
      }
      return -1;  // The existing StoreQueries negative-return path.
    };
    if (fault == 3) {
      EXPECT_EQ(-1, request_body());
    } else {
      EXPECT_THROW(request_body(), std::runtime_error);
    }
    EXPECT_TRUE(writer_done.load());
    EXPECT_TRUE(borrowed.expired());
    EXPECT_EQ(1, timeline.copies_destroyed.load());
    EXPECT_EQ(0, timeline.removals.load());
    EXPECT_EQ("synthetic-chunk", output.ConsumeMessage());
    EXPECT_TRUE(output.IsStop());
  }
}

TEST(StreamingLifetime, ClosedUnwritableOutputDoesNotReleaseBlockedWriter) {
  ASSERT_GT(std::thread::hardware_concurrency(), 0u);
  utils::SimpleThreadPool pool(1);
  InputQueue input;
  OutputQueue output;
  output.WaitForStop();  // No HTTP/provider required, writes are rejected.
  Gate release_worker;
  TimelineState timeline;
  LightResponse original(&timeline);
  std::promise<void> started, leaving;
  auto started_future = started.get_future();
  auto leaving_future = leaving.get_future();
  std::atomic<bool> done(false);
  auto request = std::async(std::launch::async, [&] {
    std::future<int> producer;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    AddRecord(&tasks, original);
    tasks.back().result = pool.Submit([&] {
      started.set_value();
      EXPECT_TRUE(release_worker.Wait());
      EXPECT_EQ(-1, output.ProduceMessage("synthetic-chunk"));
      done = true;
      return 0;
    });
    leaving.set_value();
    return -1;  // Fallback destructor still owns the accepted writer.
  });
  ReleaseOnExit cleanup(input, {&release_worker});
  ASSERT_EQ(std::future_status::ready, started_future.wait_for(kWait));
  ASSERT_EQ(std::future_status::ready, leaving_future.wait_for(kWait));
  EXPECT_EQ(std::future_status::timeout, request.wait_for(kBlockedCheck));
  EXPECT_EQ(0, timeline.copies_destroyed.load());
  release_worker.Release();
  ASSERT_EQ(std::future_status::ready, request.wait_for(kWait));
  EXPECT_EQ(-1, request.get());
  EXPECT_TRUE(done.load());
  EXPECT_EQ(0, timeline.removals.load());
}

TEST(StreamingLifetime, CacheHitSnapshotKeepsOriginalEntriesAndConsumerAppends) {
  ASSERT_GT(std::thread::hardware_concurrency(), 0u);
  utils::SimpleThreadPool pool(1);
  InputQueue input;
  OutputQueue output;
  std::vector<std::shared_ptr<clu::SubQuery>> accumulated;
  accumulated.push_back(std::make_shared<clu::SubQuery>("first"));
  accumulated.push_back(std::make_shared<clu::SubQuery>("second"));
  Gate release_producer;
  std::promise<void> published;
  auto published_future = published.get_future();
  std::future<int> producer;
  std::vector<Task> tasks;
  Completion completion(input, output, producer, tasks);
  producer = pool.Submit([&] {
    streaming::CloseInputOnExit<InputQueue> close(input);
    const auto cached_sub_queries = accumulated;
    input.ProduceMessages(cached_sub_queries);
    input.WaitForStop();
    published.set_value();
    EXPECT_TRUE(release_producer.Wait());
    EXPECT_EQ(2u, cached_sub_queries.size());
    return 0;
  });
  ReleaseOnExit cleanup(input, {&release_producer});
  ASSERT_EQ(std::future_status::ready, published_future.wait_for(kWait));
  accumulated.push_back(input.ConsumeMessage());
  accumulated.push_back(input.ConsumeMessage());
  EXPECT_EQ(4u, accumulated.size());
  EXPECT_EQ(accumulated[0], accumulated[2]);
  EXPECT_EQ(accumulated[1], accumulated[3]);
  EXPECT_TRUE(input.IsStop());
  release_producer.Release();
  EXPECT_EQ(0, streaming::ObserveProducer(producer).code);
}

TEST(StreamingLifetime, EmptyAndRejectedBeforeSubmissionCloseBothQueues) {
  for (int rejected = 0; rejected < 2; ++rejected) {
    SCOPED_TRACE(rejected);
    InputQueue input;
    OutputQueue output;
    auto request_body = [&] {
      std::future<int> producer;
      streaming::Outcome producer_outcome;
      std::vector<Task> tasks;
      Completion completion(input, output, producer, tasks);
      if (rejected) {
        return -1;
      }
      producer = ReadyResult(0);  // Completed producer with no publication.
      producer_outcome = streaming::ObserveProducer(producer);
      EXPECT_TRUE(producer_outcome.ok());
      EXPECT_TRUE(streaming::DrainQueries(tasks, [](Task &) {}).ok());
      return 0;
    };
    EXPECT_EQ(rejected ? -1 : 0, request_body());
    EXPECT_TRUE(input.IsStop());
    EXPECT_TRUE(output.IsStop());
    EXPECT_THROW(input.ConsumeMessage(), std::runtime_error);
  }
}

TEST(StreamingLifetime, ClosedEmptyInputCanSubmitTheExistingSingleFallback) {
  ASSERT_GT(std::thread::hardware_concurrency(), 0u);
  utils::SimpleThreadPool pool(1);
  InputQueue input;
  OutputQueue output;
  TimelineState timeline;
  LightResponse original(&timeline);
  {
    std::future<int> producer;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    producer = pool.Submit([&] {
      streaming::CloseInputOnExit<InputQueue> close(input);
      return -1;
    });
    ASSERT_EQ(std::future_status::ready, producer.wait_for(kWait));
    ASSERT_TRUE(input.IsStop());
    std::shared_ptr<clu::SubQuery> fallback;
    try {
      input.ConsumeMessage();
    } catch (const std::runtime_error &) {
      fallback = std::make_shared<clu::SubQuery>("synthetic-fallback");
      fallback->index = 1;
      fallback->is_last = true;
    }
    ASSERT_TRUE(static_cast<bool>(fallback));
    EXPECT_EQ(1u, fallback->index);
    EXPECT_TRUE(fallback->is_last);
    AddRecord(&tasks, original);
    tasks.back().result = pool.Submit([] { return 0; });
    EXPECT_EQ(-1, streaming::ObserveProducer(producer).code);
    EXPECT_TRUE(streaming::DrainQueries(tasks, [](Task &) {}).ok());
  }
  EXPECT_EQ(0, timeline.removals.load());
  EXPECT_TRUE(output.IsStop());
}

TEST(StreamingLifetime, ProducerSubmissionFailureClosesWithoutAValidHandle) {
  InputQueue input;
  OutputQueue output;
  auto request_body = [&] {
    std::future<int> producer;
    std::vector<Task> tasks;
    Completion completion(input, output, producer, tasks);
    producer = RejectBeforeAcceptance();
  };
  EXPECT_THROW(request_body(), std::bad_alloc);
  EXPECT_TRUE(input.IsStop());
  EXPECT_TRUE(output.IsStop());
}

TEST(StreamingLifetime, OnlyOriginalResponseRemovesBorrowedTimelineEntry) {
  TimelineState timeline;
  {
    LightResponse original(&timeline);
    {
      auto first = streaming::CopyBorrowingTimeline(original);
      auto second = streaming::CopyBorrowingTimeline(original);
      EXPECT_EQ(original.timeline, first->timeline);
      EXPECT_EQ(original.timeline, second->timeline);
    }
    EXPECT_EQ(0, timeline.removals.load());
    EXPECT_EQ(2, timeline.copies_destroyed.load());
  }
  EXPECT_EQ(1, timeline.removals.load());
}

std::string ReadSource(const std::string &relative) {
  std::ifstream input(relative.c_str());
  if (!input.is_open()) {
    const char *root = std::getenv("TEST_SRCDIR");
    const char *workspace = std::getenv("TEST_WORKSPACE");
    if (!root || !workspace) {
      throw std::runtime_error("Source runfiles unavailable");
    }
    input.clear();
    input.open((std::string(root) + "/" + workspace + "/" + relative).c_str());
  }
  if (!input.is_open()) {
    throw std::runtime_error("Cannot read source runfile");
  }
  return std::string(std::istreambuf_iterator<char>(input),
                     std::istreambuf_iterator<char>());
}

std::string Section(const std::string &source, const std::string &begin,
                    const std::string &end) {
  const auto first = source.find(begin);
  if (first == std::string::npos) {
    throw std::runtime_error("Source section start missing");
  }
  const auto last = source.find(end, first + begin.size());
  if (last == std::string::npos) {
    throw std::runtime_error("Source section end missing");
  }
  return source.substr(first, last - first);
}

void ExpectBefore(const std::string &source, const std::string &first,
                  const std::string &last) {
  const auto a = source.find(first);
  const auto b = source.find(last);
  ASSERT_NE(std::string::npos, a) << first;
  ASSERT_NE(std::string::npos, b) << last;
  EXPECT_LT(a, b) << first << " must precede " << last;
}

// These are executable SOURCE assertions, not end-to-end payload/cache tests.
// In particular they prevent light-owner tests from passing while V2 bypasses
// the tested primitive or uses a nonvirtual fake subclass as "injection".
TEST(StreamingWiring, V2RegistersBeforeSubmitAndFinalizesAfterEveryWriter) {
  const auto source = ReadSource("cu/dialogue.cc");
  const auto conversion = Section(source, "int Dialogue::StreamConversion(",
                                   "int Dialogue::SynchronousConversation(");
  ExpectBefore(conversion, "std::future<int> qs_code;", "completion(query_queue");
  ExpectBefore(conversion, "Outcome producer_outcome;", "completion(query_queue");
  ExpectBefore(conversion, "std::vector<QueryTask> results;", "completion(query_queue");
  ExpectBefore(conversion, "completion(query_queue", "QueryRejection(response)");
  ExpectBefore(conversion, "completion(query_queue", "qs_code = thread_pool_->Submit(");
  EXPECT_NE(std::string::npos, conversion.find(
      "auto new_response = streaming_internal::CopyBorrowingTimeline(*response);"));
  ExpectBefore(conversion, "results.emplace_back(new_turn, new_response);",
               "task.result = thread_pool_->Submit(");
  EXPECT_NE(std::string::npos, conversion.find(
      "auto &task = results.back();\n    task.result = thread_pool_->Submit("));
  EXPECT_NE(std::string::npos, conversion.find(
      "task.turn.get(), task.response.get()"));
  EXPECT_EQ(std::string::npos, conversion.find("make_pair"));
  EXPECT_EQ(std::string::npos, conversion.find("response_list"));
  ExpectBefore(conversion, "query_queue.ConsumeMessage()", "ObserveProducer(qs_code)");
  ExpectBefore(conversion, "ObserveProducer(qs_code)", "streaming_internal::DrainQueries(");
  ExpectBefore(conversion, "streaming_internal::DrainQueries(", "CacheQuerySegment(");
  ExpectBefore(conversion, "CacheQuerySegment(", "response->stream_content->WaitForStop()");
  ExpectBefore(conversion, "response->stream_content->WaitForStop()", "StoreSubQueries(");
  ExpectBefore(conversion, "StoreSubQueries(", "semantic_results.append(task.response->semantic_json)");
  ExpectBefore(conversion, "semantic_results.append(task.response->semantic_json)", "StoreQueries(");
  EXPECT_NE(std::string::npos, conversion.find("MergeTurns(task.turn, cur_turn)"));
  // The legacy negative-query path logs but does not become a new return code.
  const auto negative = Section(conversion, "if (query_outcome.code < 0)",
                                "response->stream_content->WaitForStop()");
  EXPECT_EQ(std::string::npos, negative.find("return"));
  EXPECT_NE(std::string::npos, conversion.find("std::rethrow_exception(query_outcome.error)"));
  EXPECT_NE(std::string::npos, conversion.find(
      "if (StoreQueries(query_history_size_, context_manager_, response) < 0)"));
  EXPECT_NE(std::string::npos, conversion.find("if (results.empty())"));
  EXPECT_NE(std::string::npos, conversion.find("sub_query->index = 1;"));
  EXPECT_NE(std::string::npos, conversion.find("sub_query->is_last = true;"));
}

TEST(StreamingWiring, SnapshotAndSuccessfulMissOnlyRetainTheExistingCachePolicy) {
  const auto source = ReadSource("cu/dialogue.cc");
  const auto producer = Section(source, "int Dialogue::StreamSegmentQuery(",
                                "int Dialogue::ProcessQueries(");
  ExpectBefore(producer, "CloseInputOnExit<", "clu::CreMatcher::CreQuery");
  ExpectBefore(producer, "qs_manager_->Process(", "return streaming_internal::kSegmentCacheMissComplete;");
  ExpectBefore(producer, "return DialogueCode::E_Error;",
               "return streaming_internal::kSegmentCacheMissComplete;");
  ExpectBefore(producer, "const auto cached_sub_queries = response->sub_queries;",
               "query_queue->ProduceMessages(cached_sub_queries);");
  EXPECT_EQ(std::string::npos, producer.find("CacheQuerySegment("));
  EXPECT_EQ(std::string::npos, producer.find("ProduceMessages(response->sub_queries)"));
  const auto conversion = Section(source, "int Dialogue::StreamConversion(",
                                   "int Dialogue::SynchronousConversation(");
  const auto cache_branch = Section(conversion, "if (producer_outcome.ok() &&",
                                    "if (producer_outcome.error)");
  EXPECT_NE(std::string::npos, cache_branch.find(
      "producer_outcome.code == streaming_internal::kSegmentCacheMissComplete"));
  EXPECT_NE(std::string::npos, cache_branch.find("CacheQuerySegment("));
  // Query failure must not disable a complete eligible segmentation miss.
  EXPECT_EQ(std::string::npos, cache_branch.find("query_outcome"));
  EXPECT_NE(std::string::npos, cache_branch.find("catch (...)"));
  EXPECT_NE(std::string::npos, cache_branch.find("std::current_exception()"));
  ExpectBefore(conversion, "CacheQuerySegment(", "std::rethrow_exception(query_outcome.error)");
  const auto cache = Section(source, "int CacheQuerySegment(", "void MergeTurns(");
  EXPECT_NE(std::string::npos, cache.find("sub_queries.size() == 1"));
  EXPECT_NE(std::string::npos, cache.find("sub_queries[0]->generate_text == raw_query"));
  EXPECT_NE(std::string::npos, cache.find("sub_queries[0]->handler == \"llm\""));
  EXPECT_NE(std::string::npos, cache.find(
      "value.append(q->generate_text).append(\"\\n\")"));
  EXPECT_NE(std::string::npos, cache.find(
      "ctx->Put(raw_query, value, ContextManager::ContextType::kLLMSimpleCache);"));
}

TEST(StreamingWiring, RealResponseBorrowsTimelineLastAndRemovesRatherThanDeletes) {
  const auto source = ReadSource("cu/dialogue_response.cc");
  const auto copy = Section(source,
      "DialogueResponse::DialogueResponse(const DialogueResponse &other)",
      "Json::Value DialogueResponse::ToJson()");
  EXPECT_NE(std::string::npos, copy.find("timeline = other.timeline;\n}\n"));
  ExpectBefore(copy, "context_variables = other.context_variables;",
               "timeline = other.timeline;");
  const auto destructor = Section(source, "DialogueResponse::~DialogueResponse()",
                                  "}  // namespace nlptk");
  EXPECT_NE(std::string::npos, destructor.find("timeline->remove(request_id)"));
  EXPECT_EQ(std::string::npos, destructor.find("delete"));
}

}  // namespace
}  // namespace nlptk
