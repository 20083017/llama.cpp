// Copyright 2026 the nlptk project authors. All Rights Reserved.
// Author: daigd

#pragma once

#include <chrono>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace nlptk {

namespace clu {

// 记录单个时间点的信息
struct TimePoint {
  std::string event_name;
  std::string desc;
  std::chrono::steady_clock::time_point timestamp;
};

// 存储一个请求的完整时间线
struct RequestTimeline {
  std::vector<TimePoint> events;
  mutable std::mutex mtx; // 保护单个请求内部事件列表的线程安全
};

class Timeline {
public:
  // 获取单例实例
  static Timeline &getInstance();

  // 注册一个时间节点
  void record(const std::string &request_id, const std::string &event_name, const std::string &desc = "");

  void remove(const std::string &request_id);

  // 获取一个请求的完整时间线
  std::vector<TimePoint> getTimeline(const std::string &request_id) const;

  std::string toString(const std::string &request_id) const;

private:
  Timeline() = default;                           // 私有构造函数
  ~Timeline() = default;                          // 私有析构函数
  Timeline(const Timeline &) = delete;            // 禁止拷贝
  Timeline &operator=(const Timeline &) = delete; // 禁止赋值

  mutable std::mutex global_mtx_; // 保护 map 的线程安全
  std::unordered_map<std::string, std::unique_ptr<RequestTimeline>> timelines_;
};

} // namespace clu
} // namespace nlptk