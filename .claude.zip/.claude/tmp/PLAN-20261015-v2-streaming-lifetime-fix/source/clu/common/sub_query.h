// Copyright 2024 the nlptk project authors. All Rights Reserved.
// Author: daigd

#ifndef CLU_COMMON_SUB_QUERY_H_
#define CLU_COMMON_SUB_QUERY_H_

#include <string>
#include "json/json.h"

namespace nlptk {
namespace clu {

class SubQuery {
 public:
  SubQuery();
  SubQuery(const std::string &text);
  ~SubQuery();

  Json::Value ToJson() const;

 public:
  std::string request_id;
  std::string generate_text;
  std::string orginal_text;
  std::string category;
  bool        is_nlu_domain;
  bool        is_rejected;
  bool        rule_matched;
  std::string matched_rule;
  std::string handler;
  uint32_t    index;             // query的编号
  bool        is_last;
  bool        is_first_rejected;
  std::string history_categories;
  bool        is_sensitive;
  std::vector<std::pair<std::string, std::string>> extra_slots;
};

}  // namespace clu
}  // namespace nlptk

#endif  // CLU_COMMON_SUB_QUERY_H_
