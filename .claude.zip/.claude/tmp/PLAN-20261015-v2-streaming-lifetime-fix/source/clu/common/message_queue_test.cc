
// Copyright 2023 the NLPTK project authors. All Rights Reserved.
// Author: daigd
#include "common/message_queue.h"

#include <chrono>
#include <future>
#include <string>
#include <thread>

#include "base/logging.h"
#include "gtest/gtest.h"

namespace nlptk {
namespace clu {

int produce(const std::string &msg, MessageQueue<std::string> *queue) {
  LOG(INFO) << "Start produce...";
  std::this_thread::sleep_for(std::chrono::seconds(1));
  return queue->ProduceMessage(msg);
}

int consume(MessageQueue<std::string> *queue) {
  LOG(INFO) << "Start Consume...";
  int count = 0;
  while (true) {
    try {
      auto msg = queue->ConsumeMessage();
      if (!msg.empty()) {
        LOG(INFO) << "Consume message:" << msg;
        count++;
      }
      if (queue->IsStop()) {
        LOG(INFO) << "Stoped";
        break;
      }
    } catch (const std::exception &e) {
      LOG(ERROR) << "Error:" << e.what();
      break;
    }
  }
  return count;
}

TEST(MessageQueue, PoduceAndConsume) {
  MessageQueue<std::string> message;
  auto code3 = std::async(std::launch::async, consume, &message);
  auto code1 =
      std::async(std::launch::async, produce, "hello world1", &message);
  auto code2 =
      std::async(std::launch::async, produce, "hello world2", &message);

  std::this_thread::sleep_for(std::chrono::seconds(2));
  message.WaitForStop();
  ASSERT_EQ(code1.get(), 0);
  ASSERT_EQ(code2.get(), 0);
  ASSERT_EQ(code3.get(), 2);
}

} // namespace clu
} // namespace nlptk
