// Copyright 2023 the NLPTK project authors. All Rights Reserved.
// Author: daigd

#ifndef CLU_COMMON_MESSAGE_QUEUE_H_
#define CLU_COMMON_MESSAGE_QUEUE_H_

#include <condition_variable>
#include <map>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <vector>
#include <atomic>

namespace nlptk {
namespace clu {

template <typename T>
class MessageQueue {
 public:
  MessageQueue();
  ~MessageQueue();
  int ProduceMessage(const T &msg);
  int ProduceMessages(const std::vector<T> &msgs);
  T ConsumeMessage();
  void WaitForStop();
  bool IsStop();
  int SetExtraData(const std::string &key, const std::string &value,
                   bool force = true, bool append = false);
  int GetExtraData(const std::string &key, std::string *value);

  int SetExtraData(const std::string &key, uint32_t value);
  uint32_t GetExtraData(const std::string &key);
  inline uint32_t GetCount() const { return count_; }

 protected:
  std::mutex msg_mtx_;
  std::mutex data_mtx_;
  std::atomic<bool> stoped_;
  std::queue<T> msgs_;
  std::condition_variable cv_;
  std::map<std::string, std::string> extra_data_s_;
  std::map<std::string, uint32_t> extra_data_n_;
  uint32_t count_;
};

}  // namespace clu
}  // namespace nlptk

#endif  // CLU_COMMON_MESSAGE_QUEUE_H_
