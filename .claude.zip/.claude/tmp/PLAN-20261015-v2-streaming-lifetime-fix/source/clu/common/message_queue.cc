// Copyright 2023 the NLPTK project authors. All Rights Reserved.
// Author: daigd

#include "common/message_queue.h"

#include <cassert>
#include <memory>
#include <mutex>
#include <utility>
#include <thread>

#include "common/sub_query.h"

#include "base/logging.h"

namespace nlptk {
namespace clu {

template <typename T>
MessageQueue<T>::MessageQueue() : stoped_(false), count_(0) {}

template <typename T>
MessageQueue<T>::~MessageQueue() {
  WaitForStop();
}

template <typename T>
int MessageQueue<T>::ProduceMessage(const T &msg) {
  if (IsStop()) {
    return -1;
  }
  std::lock_guard<std::mutex> lock(msg_mtx_);
  msgs_.push(msg);
  cv_.notify_one();
  count_++;
  return 0;
}

template <typename T>
int MessageQueue<T>::ProduceMessages(const std::vector<T> &msgs) {
  std::lock_guard<std::mutex> lock(msg_mtx_);
  if (IsStop()) {
    return -1;
  }
  for (auto &msg : msgs) {
    msgs_.emplace(std::move(msg));
  }
  cv_.notify_all();
  count_ += msgs.size();
  return msgs.size();
}

template <typename T>
T MessageQueue<T>::ConsumeMessage() {
  std::unique_lock<std::mutex> lock(msg_mtx_);
  cv_.wait(lock, [this] { return !msgs_.empty() || stoped_.load();});
  if (IsStop() && msgs_.empty()) {
    throw std::runtime_error("Queue is stopped and empty.");
  }
  T msg = msgs_.front();
  msgs_.pop();
  return std::move(msg);
}

template <typename T>
bool MessageQueue<T>::IsStop() {
  return stoped_.load() && msgs_.empty();
}

template <typename T>
void MessageQueue<T>::WaitForStop() {
  if (stoped_.load()) {
    return;
  }
  LOGI << "Wait for stop ...";
  // std::thread t([this]() { 
  // while (!IsStop()) {
  //   if (!msgs_.empty()) {
  //     std::this_thread::sleep_for(std::chrono::milliseconds(10));
  //     continue;
  //   }
  //   std::lock_guard<std::mutex> lock(msg_mtx_);
  //   stoped_.store(true);
  //   cv_.notify_all();
  //   LOGI << "All messages was consumed, queue was stoped.";
  //   return;
  // }
  // LOGI << "Queue was already stoped.";
  // });
  // t.detach();
  std::lock_guard<std::mutex> lock(msg_mtx_);
  stoped_.store(true);
  cv_.notify_all();
}

template <typename T>
int MessageQueue<T>::SetExtraData(const std::string &key,
                                  const std::string &value, bool force,
                                  bool append) {
  std::lock_guard<std::mutex> lock(data_mtx_);
  auto iter = extra_data_s_.find(key);
  if (iter != extra_data_s_.end()) {
    if (append) {
      extra_data_s_[key].append(value);
    } else if (force) {
      extra_data_s_[key] = value;
    } else {
      return -1;
    }
  } else {
    extra_data_s_[key] = value;
  }
  return 0;
}

template <typename T>
int MessageQueue<T>::GetExtraData(const std::string &key, std::string *value) {
  assert(value);
  std::lock_guard<std::mutex> lock(data_mtx_);
  auto iter = extra_data_s_.find(key);
  if (iter == extra_data_s_.end()) {
    return -1;
  }
  *value = iter->second;
  return 0;
}
template <typename T>
int MessageQueue<T>::SetExtraData(const std::string &key, uint32_t value) {
  std::lock_guard<std::mutex> lock(data_mtx_);
  extra_data_n_[key] = value;
  return 0;
}
template <typename T>
uint32_t MessageQueue<T>::GetExtraData(const std::string &key) {
  std::lock_guard<std::mutex> lock(data_mtx_);
  auto iter = extra_data_n_.find(key);
  if (iter == extra_data_n_.end()) {
    return 0;
  }
  return iter->second;
}

template class MessageQueue<std::string>;
template class MessageQueue<std::shared_ptr<SubQuery>>;

}  // namespace clu
}  // namespace nlptk
