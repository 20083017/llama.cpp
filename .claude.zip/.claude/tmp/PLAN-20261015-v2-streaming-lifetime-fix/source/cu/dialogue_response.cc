// Copyright 2022 the project authors. All Rights Reserved.

#include "cu/dialogue_response.h"

#include "base/string_util.h"
#include "common/utils.h"

namespace nlptk {

LgResponse::LgResponse() : auto_listening(false) {}

Json::Value LgResponse::ToJson(bool ignore_empty) const {
  Json::Value lg(Json::ValueType::objectValue);
  lg["auto_listening"] = auto_listening;

  if (!ignore_empty || !StringUtil::EmptyOrSpaces(display_text)) {
    lg["display_text"] = display_text;
  }

  if (!ignore_empty || !StringUtil::EmptyOrSpaces(spoken_text)) {
    lg["spoken_text"] = spoken_text;
  }

  if (!ignore_empty || !StringUtil::EmptyOrSpaces(spoken_ssml)) {
    lg["spoken_ssml"] = spoken_ssml;
  }

  if (!ignore_empty || tips.empty()) {
    for (auto tip : tips) {
      lg["tips"].append(tip);
    }
  }

  if (lg.empty()) {
    lg["display_text"] = "";
  }

  return lg;
}

Json::Value Action::ToJson(bool ignore_empty) const {
  Json::Value action(Json::ValueType::objectValue);
  if (!ignore_empty || !StringUtil::EmptyOrSpaces(name)) {
    action["name"] = name;
  }

  if (!ignore_empty || !StringUtil::EmptyOrSpaces(cmd)) {
    action["command"] = cmd;
  }

  if (!ignore_empty || !StringUtil::EmptyOrSpaces(version)) {
    action["version"] = version;
  }

  if (!ignore_empty || !args.empty()) {
    for (auto arg : args) {
      Json::Value obj;
      obj[arg.first] = arg.second;
      action["parameters"].append(obj);
    }
  }

  Json::Value text_objs(Json::arrayValue);
  if (!ignore_empty || !text_list.empty()) {
    for (auto &reply : text_list) {
      Json::Value obj;
      obj["status"] = reply.status;
      obj["text"] = reply.text;
      Json::Value list(Json::arrayValue);
      for (auto &v : reply.place_holder_list) {
        list.append(v);
      }
      obj["place_holder_list"] = list;
      text_objs.append(obj);
    }
  }
  action["text_list"] = text_objs;
  return action;
}

DialogueResponse::DialogueResponse(): timeline(&nlptk::clu::Timeline::getInstance()) {
  start_t = nlptk::clu::Datetime::GetDatetime();
  stream_content =
      std::make_shared<nlptk::clu::MessageQueue<std::string>>();
}

DialogueResponse::DialogueResponse(const DialogueResponse &other) {
  code = 0;
  error_msg = "ok";
  normalized_query = other.normalized_query;
  original_query = other.original_query;
  debug_info = DebugInfo();
  debug = other.debug;
  request_id = other.request_id;
  semantic_json = Json::Value();
  query_histories = other.query_histories;
  stream = other.stream;
  rejection_result = other.rejection_result;
  sub_queries = other.sub_queries;
  session_id = other.session_id;
  start_t = other.start_t;
  end_t = other.end_t;
  for (auto &item: other.history_semantics) {
    history_semantics.emplace_back(item);
  }
  stream_content = other.stream_content;
  is_multi_intent = other.is_multi_intent;
  version = other.version;
  context_variables = other.context_variables;
  timeline = other.timeline;
}

Json::Value DialogueResponse::ToJson() const {
  Json::Value body;
  Json::Value header;
  Json::Value payload;
  header["Code"] = code;
  header["RequestId"] = request_id;
  header["SessionId"] = session_id;
  header["Message"] = error_msg;
  header["Debug"] = debug;
  header["Stream"] = stream;
  header["StartTime"] = start_t;
  if (!end_t.empty()) {
    header["EndTime"] = end_t;
  } else {
    header["EndTime"] = nlptk::clu::Datetime::GetDatetime();
  }
  header["Version"] = version;
  if (stream) {
    header["IsEnd"] = sub_queries.empty() || sub_queries.back()->is_last;
  }
  payload["Semantic"] = semantic_json;
  if (debug) {
    Json::Value info;
    Json::Value segment_info(Json::arrayValue);
    for (auto &sub_query : sub_queries) {
      segment_info.append(sub_query->ToJson());
    }
    Json::Value hot_query_info;
    hot_query_info["rule_matched"] = debug_info.hot_query_info.rule_matched;
    hot_query_info["matched_rule"] = debug_info.hot_query_info.matched_rule;
    hot_query_info["enable"] = debug_info.hot_query_info.enable;
    info["HotQueryCache"] = hot_query_info;
    info["RejectionInfo"] = rejection_result.ToJson();
    info["SegementInfo"] = segment_info;
    info["DispatchInfo"] = debug_info.dispatch_info;
    info["NluInfo"] = debug_info.nlu_info;
    info["DMInfo"] = debug_info.dm_info;
    Json::Value q_histories(Json::arrayValue);
    for (auto &q : query_histories) {
      auto llm_res = q->GetResponse();
      if (!llm_res.empty()) {
        q_histories.append(q->GetQuery() + " => " + llm_res);
      } else {
        q_histories.append(q->GetQuery());
      }
    }
    info["QueryHistories"] = q_histories;
    Json::Value ctx_vars(Json::objectValue);
    for (auto &item: context_variables) {
      ctx_vars[item.first] = item.second;
    }
    info["ContextVariables"] = ctx_vars;
    info["TimeLine"] = JsonHelper::ParseJsonFromString(timeline->toString(request_id));
    body["debug"] = info;
  }
  body["Header"] = header;
  body["Payload"] = payload;
  return body;
}

DialogueResponse::~DialogueResponse() {
  if (timeline != nullptr) {
    timeline->remove(request_id);
  }
}

}  // namespace nlptk
