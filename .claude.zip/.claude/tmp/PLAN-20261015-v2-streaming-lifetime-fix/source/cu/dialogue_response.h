// Copyright 2022 the project authors. All Rights Reserved.

#ifndef CU_DIALOGUE_RESPONSE_H_
#define CU_DIALOGUE_RESPONSE_H_

#include <string>
#include <vector>
#include <utility>
#include <memory>
#include <map>

#include "base/basictypes.h"
#include "json/json.h"
#include "common/query.h"
#include "qr/query_classifition.h"
#include "common/sub_query.h"
#include "common/message_queue.h"
#include "common/simple_semantic.h"
#include "dialog/flow_task_context.h"
#include "timeline/time_line.h"


namespace Json {

class Value;

}  // namespace Json

namespace nlptk {

struct LgResponse {
  bool                     auto_listening;
  std::string              display_text;
  std::string              spoken_text;
  std::string              spoken_ssml;
  std::vector<std::string> tips;

 public:
  LgResponse();
  Json::Value ToJson(bool ignore_empty = true) const;
};

struct PresetReply {
  std::string              status;
  std::string              text;
  std::vector<std::string> place_holder_list;
};

struct Action {
  std::string                                      name;
  std::string                                      cmd;
  std::string                                      version;
  std::vector<std::pair<std::string, std::string>> args;
  std::vector<PresetReply>                         text_list;

 public:
  Json::Value ToJson(bool ignore_empty = true) const;
};

struct HotQueryInfo {
  bool enable {true};
  bool rule_matched {false};
  std::string matched_rule;
};

struct DebugInfo {
  Json::Value rejection_info;
  Json::Value segment_info;
  Json::Value dispatch_info;
  Json::Value nlu_info;
  Json::Value dm_info;
  HotQueryInfo hot_query_info;
};

typedef void (*StreamingProcessCallback)(const char *content, void *custom_ptr);

struct DialogueResponse {
  uint32_t                                          code {0};
  std::string                                       error_msg {"ok"};
  std::string                                       normalized_query;
  std::string                                       original_query;
  DebugInfo                                         debug_info;
  bool                                              debug {false};
  std::string                                       request_id;
  Json::Value                                       semantic_json;
  std::vector<std::shared_ptr<clu::Query>>          query_histories;
  bool                                              stream {false};
  std::shared_ptr<clu::MessageQueue<std::string>>   stream_content{nullptr};
  clu::MultiClassQueryResult                        rejection_result{""};
  std::vector<std::shared_ptr<clu::SubQuery>>       sub_queries;
  std::string                                       session_id;
  std::string                                       start_t;
  std::string                                       end_t;
  std::map<std::string, std::string>                context_variables;
  bool                                              is_multi_intent {false};
  std::vector<std::shared_ptr<clu::SimpleSemantic>> history_semantics;
  std::string                                       version;
  clu::Timeline*                                    timeline;

  DialogueResponse();
  DialogueResponse(const DialogueResponse &other);
  Json::Value ToJson() const;
  ~DialogueResponse();
};

}  // namespace nlptk

#endif  // CU_DIALOGUE_RESPONSE_H_
