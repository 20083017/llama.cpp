// Copyright 2023 the project authors. All Rights Reserved.

#include "cu/dialogue_system.h"

#include <string>

#include "glog/logging.h"
#include "gtest/gtest.h"

TEST(DialogueSystem, Init_Process_Release) {
  auto code = Initialize(
      "/mnt/d/car_20240710-cui/dialog_configure.json");
  EXPECT_EQ(1, code);
  auto query_templete = R"(
    {
      "first_wakeup": false,
      "histories": [
        {
          "query": "周杰伦有哪些歌曲",
          "response": "周杰伦有《稻香》《青花瓷》等歌曲"
        }
      ],
      "input_data": [],
      "query": "QUERY",
      "request_id": "REQUEST_ID",
      "session_id": "wgw000c9aaf",
      "stream": false
    }
  )";
  std::string query_str = query_templete;
  query_str = query_str.replace(query_str.find("QUERY"), 5, "氛围灯暗一点");
  query_str = query_str.replace(query_str.find("REQUEST_ID"), 10, "1234567890");
  auto result = Process(query_str.c_str());
  // code = result.find("turn_on_device");
  // EXPECT_TRUE(code < result.size());
  LOG(INFO) << "Response:" <<result;

  std::string query_str2 = query_templete;
  query_str2 = query_str2.replace(query_str2.find("QUERY"), 5,"再暗一点");
  query_str2 = query_str2.replace(query_str2.find("REQUEST_ID"), 10, "0987654321");
  result = Process(query_str2.c_str());
  LOG(INFO) << "Response:" <<result;
  Release();
}

void ReceivedChunk(const char *content, void *custom_ptr) {
  LOG(INFO) <<"Received response: "<< content;
  std::string s_content = std::string(content);
  auto index = s_content.find("Domain");
  EXPECT_TRUE(index != std::string::npos);
}

TEST(DialogueSystem, StreamingProcess) {
  // 测试流式
  auto code = Initialize(
      "/mnt/d/car_20240710-cui/dialog_configure.json");
  EXPECT_EQ(1, code);
  auto query_templete = R"(
    {
      "first_wakeup": false,
      "histories": [
        {
          "query": "周杰伦有哪些歌曲",
          "response": "周杰伦有《稻香》《青花瓷》等歌曲"
        }
      ],
      "input_data": [],
      "query": "QUERY",
      "request_id": "REQUEST_ID",
      "session_id": "wgw000c9aaf",
      "stream": false
    }
  )";
  std::string query_str = query_templete;
  query_str = query_str.replace(query_str.find("QUERY"), 5, "打开车窗打开空调");
  query_str = query_str.replace(query_str.find("REQUEST_ID"), 10, "1234567890");
  void *custom_ptr = nullptr;
  auto succ = StreamingProcess(query_str.c_str(), custom_ptr, ReceivedChunk);
  // code = result.find("turn_on_device");
  EXPECT_TRUE(succ);
  Release();
}


TEST(DialogueSystem, MultiTurnProcess) {
  // 测试电话多轮
  auto code = Initialize(
      "/mnt/d/car_20240710-cui/dialog_configure.json");
  EXPECT_EQ(1, code);
  auto query_templete = R"(
  {
      "first_wakeup": false,
      "histories": [
          {
              "query": "给杨慧打电话",
              "response": "找到多个相似联系人，请告诉我选择第几个"
          }
      ],
      "input_data": [
          {
              "telephone::default": {
                  "activeStatus": "fg",
                  "sceneStatus": "moreContact",
                  "datatime": 1742475495167
              }
          }
      ],
      "query": "QUERY",
      "request_id": "REQUEST_ID",
      "session_id": "wgw000c9aaf",
      "stream": false
  }
  )";
  std::string query_str = query_templete;
  query_str = query_str.replace(query_str.find("QUERY"), 5, "给杨慧打电话");
  query_str = query_str.replace(query_str.find("REQUEST_ID"), 10, "1234567890");
  auto result = Process(query_str.c_str());
  LOG(INFO) << "Response:" <<result;
  std::string res(result);
  code = res.find("phone_call");
  EXPECT_TRUE(code != std::string::npos);

  std::string query_str2 = query_templete;
  query_str2 = query_str2.replace(query_str2.find("QUERY"), 5,"第一个");
  query_str2 = query_str2.replace(query_str2.find("REQUEST_ID"), 10, "0987654321");
  result = Process(query_str2.c_str());
  LOG(INFO) << "Response:" <<result;
  res = result;
  code = res.find("phone_call");
  EXPECT_TRUE(code != std::string::npos);
  
  std::string query_str3 = R"(
    {
        "first_wakeup": true,
        "histories": [],
        "input_data": [
            "{\"telephone::default\":{\"activeStatus\":\"fg\",\"sceneStatus\":\"moreContact\",\"datatime\":1742475495167}}"
        ],
        "query": "QUERY",
        "request_id": "REQUEST_ID",
        "session_id": "wgw000c9aaf",
        "stream": false
    }
  )";
  query_str3 = query_str3.replace(query_str3.find("QUERY"), 5,"第一个");
  query_str3 = query_str3.replace(query_str3.find("REQUEST_ID"), 10, "0987654321");
  result = Process(query_str3.c_str());
  LOG(INFO) << "Response:" <<result;
  res = result;
  code = res.find("phone_call");
  EXPECT_TRUE(code != std::string::npos);
  Release();
}