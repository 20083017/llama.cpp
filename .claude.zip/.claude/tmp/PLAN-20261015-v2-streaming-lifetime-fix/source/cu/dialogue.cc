// Copyright 2022 the project authors. All Rights Reserved.

#include "cu/dialogue.h"

#include <algorithm>
#include <cassert>
#include <future>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <utility>
#include <vector>

#include "base/guid.h"
#include "base/json_helper.h"
#include "base/logging.h"
#include "base/path.h"
#include "base/rtti.h"
#include "base/string_util.h"
#include "common/query.h"
#include "common/slot_utils.h"
#include "common/sub_queries.h"
#include "curl/curl.h"
#include "dialog/context_manager.h"
#include "dialog/dialogue_utils.h"
#include "dialog/flow_task.h"
#include "dialog/flow_task_def.h"
#include "dialog/form_task_def.h"
#include "dialog/input.h"
#include "dialog/lang_gen_result.h"
#include "dialog/task_base.h"
#include "dialog/task_manager.h"
#include "dialog/turn.h"
#include "dialog/user_info.h"
#include "dispatch/dispatch_manager.h"
#include "dst/dst_manager.h"
#include "eu/event_processor.h"
#include "json/json.h"
#include "nlu/semantic_frame.h"
#include "nlu/semantic_frames.h"
#include "nlu/timex.h"
#include "qr/qr_manager.h"
#include "qs/qs_manager.h"
#include "qts/nlu.h"
#include "rule/cre_matcher.h"
#include "semantic_modifier/modifier_factory.h"
#include "semantics_processor/multi_semantic_processor.h"

namespace nlptk {

using std::map;
using std::shared_ptr;
using std::string;
using std::vector;

using dialog::ClientContent;
using dialog::ContextManager;
using dialog::DialogueManager;
using dialog::DialogueUtils;
using dialog::EventInput;
using dialog::LangGenResult;
using dialog::LocInfo;
using dialog::SpeechInput;
using dialog::TextInput;
using dialog::Turn;
using dialog::UserInfo;

using nlu::SemanticFrames;

namespace {

const char kDelimiter[] = "|";
const char kVAD[] = "VAD";
const char kInactiveVad[] = "inactive";
const char kSessionPrefixOfCommand[] = "Query:";
const char kSessionPrefixOfSubQuery[] = "SubQuery:";
const char kValidSlotName[] = "NULL";
const std::string kEndEventSymbol = "[DONE]";
const std::string kCurQuery = "cur_query";
const std::string kRejected = "kRejected";
const std::string kSensitiveMsg = "我们换个话题聊聊";
const std::string kDomainOther = "other";
const std::string kDomainChat = "chat";
const std::string kDomainSensitive = "sensitive";
const std::string kWakeUp = "isWakeUp";

int HandleEventMode(const std::string &input_data, Turn *turn) {
  assert(turn);
  auto obj = JsonHelper::ParseJsonFromString(input_data);
  if (obj.isNull() || obj.empty()) {
    LOGW << "No input data ";
    return 0;
  }
  auto event_objs = JsonHelper::ParseJsonFromString(input_data);
  if (event_objs.isNull()) {
    LOGW << "Invalid input data:" << input_data;
    return 0;
  }
  eu::EventProcessor event_processor(input_data);
  if (event_processor.PreProcess() < 0) {
    LOGE << "Failed to pre-process event";
    return -1;
  }
  Json::Value input_events;
  if (event_processor.Build(&input_events) < 0) {
    LOGE << "Failed to build input_event json object";
    return -1;
  }
  if (input_events.isArray()) {
    for (auto &event_value : input_events) {
      auto input = std::make_shared<EventInput>();
      if (input->Load(event_value) < 0) {
        LOGE << "Failed to load EventInput from json string:"
                   << JsonHelper::ToString(event_value);
        return -1;
      }
      turn->inputs.push_back(input);
    }
  }
  auto query_input = std::make_shared<EventInput>();
  query_input->SetName("cur_query");
  query_input->SetValue(turn->query);
  turn->inputs.emplace_back(std::move(query_input));
  return 0;
}

int BuildInput(const DialogueRequest &request, Turn *turn) {
  assert(turn);
  auto event_objs = JsonHelper::ParseJsonFromString(request.input_data);
  if (event_objs.isNull() || event_objs.empty()) {
    LOGI << "[" << turn->turn_uid << "]: No input data.";
    auto query_input = std::make_shared<EventInput>();
    query_input->SetName(kCurQuery);
    query_input->SetValue(turn->query);
    turn->inputs.emplace_back(std::move(query_input));
    return 0;
  }
  auto sss = JsonHelper::ToString(event_objs);
  eu::EventProcessor event_processor(event_objs);
  if (event_processor.PreProcess() < 0) {
    LOGE << "[" << turn->turn_uid << "]: Failed to pre-process event";
    return -1;
  }
  Json::Value input_events;
  if (event_processor.Build(&input_events) < 0) {
    LOGE << "[" << turn->turn_uid
               << "]: Failed to build input_event json object";
    return -1;
  }
  if (input_events.isArray()) {
    for (auto &event_value : input_events) {
      auto input = std::make_shared<EventInput>();
      if (input->Load(event_value) < 0) {
        LOGE << "[" << turn->turn_uid
                   << "]: Failed to load EventInput from json string:"
                   << JsonHelper::ToString(event_value);
        continue;
      }
      turn->inputs.push_back(input);
    }
  }
  bool found_cur_query = false;
  bool found_first_wakeup = false;
  for (auto &input : turn->inputs) {
    if (input->InputMode() == EventInput::Mode::kEvent) {
      auto event_input = std::static_pointer_cast<EventInput>(input);
      if (event_input->GetName() == kCurQuery) {
        event_input->SetValue(turn->query);
        found_cur_query = true;
      }
      if (event_input->GetName() == "first_wakeup") {
        found_first_wakeup = true;
        event_input->SetValue(request.first_wakeup);
      }
    }
  }
  if (!found_cur_query) {
    auto query_input = std::make_shared<EventInput>();
    query_input->SetName(kCurQuery);
    query_input->SetValue(turn->query);
    turn->inputs.emplace_back(std::move(query_input));
  }
  if (!found_first_wakeup) {
    auto wakeup_input = std::make_shared<EventInput>();
    wakeup_input->SetName("first_wakeup");
    std::string first_wakeup_str = "false";
    if (request.first_wakeup) {
      first_wakeup_str = "true";
    }
    wakeup_input->SetValue(first_wakeup_str);
    turn->inputs.emplace_back(std::move(wakeup_input));
  }
  return 0;
}

int BuildClientContent(const DialogueRequest &request, ClientContent *content) {
  assert(content);

  LocInfo loc_info;
  loc_info.latitude = request.latitude;
  loc_info.longitude = request.longitude;
  loc_info.valid = true;
  content->loc_info = loc_info;

  UserInfo user_info;
  user_info.user_id = request.user_id;
  content->user_info = user_info;

  content->extra_data = request.extra_data;
  return 0;
}

int BuildLgResponse(const LangGenResult &lang_gen_result, LgResponse *lg) {
  assert(lg);

  lg->auto_listening = lang_gen_result.auto_listening;
  lg->display_text = lang_gen_result.display;
  lg->spoken_text = lang_gen_result.spoken;
  lg->spoken_ssml = lang_gen_result.spoken_ssml;
  lg->tips.assign(lang_gen_result.tips.begin(), lang_gen_result.tips.end());
  return 0;
}

int BuildAction(const dialog::Action &action, Action *response) {
  assert(response);

  response->name = action.name;
  response->cmd = action.cmd;
  response->version = action.version;

  for (const auto &arg : action.args) {
    response->args.push_back(std::make_pair(arg.first, arg.second));
  }

  for (auto &reply : action.text_list) {
    PresetReply preset_reply;
    preset_reply.status = reply->status;
    preset_reply.text = reply->text;
    preset_reply.place_holder_list = reply->place_holders;
    response->text_list.push_back(preset_reply);
  }
  return 0;
}

int UpdateTurn(const string &tid, vector<Turn *> *history, Turn *cur_turn,
               const string &id) {
  assert(cur_turn);
  assert(history);

  if (history->empty()) {
    cur_turn->turn_id = 0;
    cur_turn->turn_uid = tid;
  } else {
    auto iter = tid.empty() ? history->end() : history->begin();
    while (iter != history->end()) {
      if (tid == (*iter)->turn_uid) {
        break;
      } else {
        ++iter;
      }
    }

    if (iter != history->end()) {
      for (auto it = history->begin(); it != iter; ++it) {
        delete *it;
      }

      cur_turn->turn_id = (*iter)->turn_id;
      cur_turn->turn_uid = tid;
      cur_turn->active_tasks = (*iter)->active_tasks;
      delete *iter;
      history->erase(history->begin(), iter + 1);
    } else {
      cur_turn->turn_id = history->at(0)->turn_id + 1;
      cur_turn->turn_uid = tid;
      for (const auto &task : history->at(0)->active_tasks) {
        cur_turn->active_tasks.push_back(task);
      }
      for (const auto &task : history->at(0)->completed_tasks) {
        cur_turn->completed_tasks.push_back(task);
      }
    }
  }
  return 0;
}

int UpdateTurn(int tid, vector<Turn *> *history, Turn *cur_turn,
               const string &id) {
  assert(history);
  assert(cur_turn);
  if (tid == 0) {
    DialogueUtils::FreePointers(history);
  }

  if (history->empty()) {
    cur_turn->turn_id = 0;
  } else {
    if (tid >= 0) {
      cur_turn->turn_id = tid;
      if (cur_turn->turn_id <= history->at(0)->turn_id + 1 &&
          cur_turn->turn_id > history->back()->turn_id) {
        while (history->at(0)->turn_id >= cur_turn->turn_id) {
          delete history->at(0);
          history->erase(history->begin());
        }
      } else {
        LOGW << "Request [" << id << " ] : ignore turn id: " << tid
                     << " out of [" << history->back()->turn_id << ","
                     << history->at(0)->turn_id << "]";
      }
    }

    cur_turn->turn_id = history->at(0)->turn_id + 1;
    for (const auto &task : history->at(0)->active_tasks) {
      cur_turn->active_tasks.push_back(task);
    }
    for (const auto &task : history->at(0)->completed_tasks) {
      cur_turn->completed_tasks.push_back(task);
    }
  }

  return 0;
}

Json::Value GetDMJson(const Turn *cur_turn) {
  assert(cur_turn);

  return cur_turn->Serialize();
}

bool IsSlotInAction(const nlu::Slot &slot,
                    const std::vector<shared_ptr<dialog::Action>> &actions) {
  for (auto &action : actions) {
    for (auto &arg : action->args) {
      if (slot.name == arg.first && slot.value == arg.second) {
        return true;
      }
    }
  }
  return false;
}

struct zp_entity {
  std::string name;
  std::string type;
  std::string normal;
  std::string value;
};

void BuildSemanticJson(const Json::Value &results, const std::string &text,
                       const std::string &vad_status, bool is_multi_intent,
                       Json::Value *semantic) {
  assert(semantic);
  (*semantic)["Query"] = text;
  (*semantic)["Results"] = results;
  (*semantic)["SessionStatus"] = 0;
  (*semantic)["VadStatus"] = vad_status;
  (*semantic)["IsMultiIntent"] = is_multi_intent;
}

bool IsValueExist(const std::string &src, const std::string &value) {
  return src == value || src.find(kDelimiter + value) < src.length() ||
         src.find(value + kDelimiter) == 0;
}

void BuildStatus(const clu::SubQuery &sub_query, Json::Value *status) {
  assert(status);
  if (sub_query.is_sensitive) {
    (*status)["Msg"] = kSensitiveMsg;
    (*status)["Code"] = 10019;
  } else {
    (*status)["Msg"] = "";
    (*status)["Code"] = 0;
  }
}

Json::Value GetDispatchJsonResult(const Turn &cur_turn,
                                  const clu::SubQuery &dispatch_info) {
  Json::Value result_obj;
  Json::Value nlu_obj;
  std::string domain = dispatch_info.category;
  std::string intent = "";
  bool is_rejected = dispatch_info.is_rejected;
  auto slot_objs = JsonHelper::MakeJsonArray();
  if (!cur_turn.frames.empty() && cur_turn.frames.front()) {
    domain = cur_turn.frames.front()->domain.value;
    if (dispatch_info.is_first_rejected || domain != kDomainOther) {
      is_rejected = false;
    }
    if (!cur_turn.frames.front()->intents.empty() && cur_turn.frames.front()->intents.front().value != "other") {
      intent = cur_turn.frames.front()->intents.front().value;
    }
    std::vector<nlu::Slot*> slot_list;
    cur_turn.frames.front()->slots.List("", &slot_list);
    for (auto &slot : slot_list) {
      Json::Value slot_obj;
      slot_obj["Name"] = slot->name;
      slot_obj["Value"] = slot->value;
      slot_obj["RawValue"] = slot->value;
      slot_obj["Type"] = "entity";
      slot_objs.append(slot_obj);
    }
  }
  nlu_obj["Domain"] = domain;
  nlu_obj["Confidence"] = 1.0f;
  nlu_obj["Intent"] = intent.empty() ? domain: intent;
  for(auto &slot : dispatch_info.extra_slots) {
    Json::Value slot_obj;
    slot_obj["Name"] = slot.first;
    slot_obj["Value"] = slot.second;
    slot_obj["RawValue"] = slot.second;
    if (dispatch_info.is_sensitive) {
      slot_obj["Type"] = "sensitive_words";
    } else {
      slot_obj["Type"] = "extra_info";
    }
    slot_objs.append(slot_obj);
  }
  nlu_obj["Slots"] = slot_objs;
  Json::Value dm_obj;
  dm_obj["SessionID"] = cur_turn.session_id;
  dm_obj["Text"] = cur_turn.text;
  Json::Value skill_obj;
  Json::Value command_obj;
  Json::Value text_list(Json::arrayValue);
  command_obj["TextList"] = text_list;
  skill_obj["Command"] = command_obj;
  dm_obj["Skill"] = skill_obj;
  dm_obj["IsLocalEntity"] = 0;
  dm_obj["SessionComplete"] = cur_turn.session_complete;
  result_obj["Nlu"] = nlu_obj;
  result_obj["Dm"] = dm_obj;
  result_obj["IsRejected"] = is_rejected;
  Json::Value status_obj;
  BuildStatus(dispatch_info, &status_obj);
  result_obj["Status"] = status_obj;
  result_obj["SubQuery"] = dispatch_info.generate_text;
  result_obj["Index"] = dispatch_info.index;
  return result_obj;
}

Json::Value GetResultJsonForZP(const Turn &cur_turn,
                               const clu::SubQuery &dispatch_info,
                               std::string *vad_status) {
  assert(vad_status);
  bool is_rejected = dispatch_info.is_rejected;
  std::string query = cur_turn.query;
  if (!dispatch_info.is_nlu_domain) {
    return GetDispatchJsonResult(cur_turn, dispatch_info);
  }
  Json::Value result_obj;
  Json::Value nlu_obj;
  std::string domain;
  float domain_confidence;
  std::string intent;
  auto slot_objs = JsonHelper::MakeJsonArray();
  auto active_task = cur_turn.selected_task;
  if (active_task->type == dialog::FlowTaskDef::kType) {
    auto flow_task = std::dynamic_pointer_cast<dialog::FlowTask>(active_task);
    if (*vad_status == kInactiveVad) {
      for (auto &var : flow_task->variables) {
        if (var->GetName() == kVAD) {
          *vad_status = var->AsString();
        }
      }
    }

    if (!flow_task->related_domain.empty()) {
      domain = flow_task->related_domain;
      domain_confidence = 1.0f;
      if (domain == kRejected) {
        is_rejected = true;
        domain = kDomainOther;
        intent = kDomainOther;
      }
    }
  }
  auto active_frame = active_task->GetActiveFrame();
  if (active_frame) {
    if (domain.empty()) {
      domain = active_frame->domain.value;
      domain_confidence = active_frame->domain.score;
    }
    if (intent.empty() && (active_task->type == dialog::FormTaskDef::kType ||
                           active_task->type == dialog::FlowTaskDef::kType)) {
      auto form_task = std::dynamic_pointer_cast<dialog::FormTask>(active_task);
      intent = form_task->focus;
      std::map<std::string, zp_entity> slot_map;
      for (auto &nlu_slots : form_task->slots) {
        if (!nlu_slots->required || domain == kDomainOther) {
          continue;
        }
        for (auto &slot : nlu_slots->slot_values) {
          std::string normal;
          if (slot->properties.size() > 0) {
            for (auto &prop : slot->properties) {
              if (prop->Type() == typeid(nlu::CanonicalString)) {
                auto p_prop = static_cast<nlu::CanonicalString *>(prop);
                normal = p_prop->Value();
                break;
              } else if (prop->Type() == typeid(nlu::TimeX)) {
                auto p_prop = static_cast<nlu::TimeX *>(prop);
                normal = p_prop->value;
                break;
              } else {
                LOGE << "Not implement property type";
              }
            }
          } else {
            normal = slot->value;
          }
          auto found = slot_map.find(slot->name);
          if (found != slot_map.end()) {
            // found->second.value =
            //     found->second.value + kDelimiter + slot->value;
            // if (!IsValueExist(found->second.normal, normal)) {
            //   found->second.normal = found->second.normal + kDelimiter +
            //   normal;
            // }
            // 此处需求变更，出现同名槽不同值的情况，则下发other
            if (found->second.normal == normal) {
              continue;
            } else {
              LOGI << "Change Doamin to 'other' because the slot '"
                        << slot->name
                        << "' has two different values:" << found->second.value
                        << " and " << slot->value;
              slot_map.clear();
              domain = kDomainOther;
              intent = kDomainOther;
              break;
            }
          } else {
            slot_map[slot->name] = {slot->name, "entity", normal, slot->value};
          }
        }
      }
      for (auto &item : slot_map) {
        if (item.second.name == kValidSlotName) {
          continue;
        }
        Json::Value slot_obj;
        slot_obj["Name"] = item.second.name;
        slot_obj["Value"] = item.second.normal;
        slot_obj["RawValue"] = item.second.value;
        slot_obj["Type"] = item.second.type;
        slot_objs.append(slot_obj);
      }
    } else if (intent.empty() && active_frame->intents.size() > 0) {
      intent = active_frame->intents[0].value;
      std::vector<nlu::Slot *> list;
      if (active_frame->slots.List("", &list) > 0) {
        for (auto &slot : list) {
          if (!IsSlotInAction(*slot, cur_turn.actions)) {
            continue;
          }
          Json::Value slot_obj;
          slot_obj["Name"] = slot->name;
          std::string normal;
          if (slot->properties.size() > 0) {
            auto prop =
                static_cast<nlu::CanonicalString *>(slot->properties[0]);
            normal = prop->Value();
          } else {
            normal = slot->value;
          }
          slot_obj["Value"] = normal;
          slot_obj["RawValue"] = slot->value;
          slot_obj["Type"] = "entity";
          slot_objs.append(slot_obj);
        }
      }
    }
    nlu_obj["Domain"] = domain;
    nlu_obj["Confidence"] = domain_confidence;
    nlu_obj["Intent"] = intent;
    nlu_obj["Slots"] = slot_objs;
  } else {
    nlu_obj["Domain"] = kDomainOther;
    nlu_obj["Confidence"] = 1.0f;
    nlu_obj["Intent"] = kDomainOther;
    nlu_obj["Slots"] = JsonHelper::MakeJsonArray();
  }
  result_obj["Nlu"] = nlu_obj;
  Json::Value dm_obj;
  dm_obj["SessionID"] = cur_turn.session_id;
  dm_obj["Text"] = cur_turn.text;
  Json::Value skill_obj;
  Json::Value command_obj;
  Json::Value text_list(Json::arrayValue);
  for (auto &action : cur_turn.actions) {
    for (auto &text_obj : action->text_list) {
      Json::Value text_json;
      text_json["Status"] = text_obj->status;
      text_json["Text"] = text_obj->text;
      Json::Value holders(Json::arrayValue);
      for (auto &holder : text_obj->place_holders) {
        holders.append(holder);
      }
      text_json["PlaceHolderList"] = holders;
      text_list.append(text_json);
    }
  }
  command_obj["TextList"] = text_list;
  skill_obj["Command"] = command_obj;
  dm_obj["Skill"] = skill_obj;
  dm_obj["IsLocalEntity"] = 0;
  dm_obj["SessionComplete"] = cur_turn.session_complete;
  result_obj["Dm"] = dm_obj;
  result_obj["IsRejected"] = is_rejected;
  Json::Value status_obj;
  BuildStatus(dispatch_info, &status_obj);
  result_obj["Status"] = status_obj;
  result_obj["SubQuery"] = query;
  result_obj["Index"] = dispatch_info.index;
  return result_obj;
}

Json::Value BuildNluResToJson(const std::shared_ptr<dialog::TaskBase> task,
                              const nlu::SemanticFrame &frame,
                              const std::vector<Action> &actions) {
  Json::Value obj;

  if (task->type == dialog::FormTaskDef::kType ||
      task->type == dialog::FlowTaskDef::kType) {
    auto form_task = std::dynamic_pointer_cast<dialog::FormTask>(task);
    Json::Value domain;
    Json::Value intent;
    Json::Value intents = JsonHelper::MakeJsonArray();
    Json::Value slot_obj;
    domain["value"] = frame.domain.value;
    domain["score"] = frame.domain.score;
    obj["domain"] = domain;
    intent["value"] = form_task->focus;
    intent["score"] = form_task->focus_score;
    intents.append(intent);
    obj["intents"] = intents;
    Json::Value slot_arr(Json::arrayValue);
    for (auto &nlu_slots : form_task->slots) {
      for (auto &slot : nlu_slots->slot_values) {
        slot_arr.append(slot->ToJson());
      }
    }
    slot_obj["relation"] = "NONE";
    slot_obj["slots"] = slot_arr;
    obj["slots"] = slot_obj;
  } else {
    obj = frame.ToJson();
  }
  return obj;
}

Json::Value GetDefaultSemanticJson(const Turn &cur_turn,
                                   const std::vector<Action> &actions) {
  Json::Value result_json = Json::objectValue;

  Json::Value dm_json;
  auto frame = cur_turn.selected_task->GetActiveFrame();
  if (frame) {
    result_json["nlu"] =
        BuildNluResToJson(cur_turn.selected_task, *frame, actions);
  } else if (cur_turn.frames.size() > 0) {
    result_json["nlu"] = cur_turn.frames[0]->ToJson();
  } else {
    result_json["nlu"] = Json::objectValue;
  }

  Json::Value actions_array = Json::arrayValue;
  for (const auto &action : actions) {
    actions_array.append(action.ToJson());
  }
  dm_json["actions"] = actions_array;
  dm_json["text"] = cur_turn.text;
  dm_json["session_complete"] = cur_turn.session_complete;
  result_json["dm"] = dm_json;
  return result_json;
}

void CleanFrames(nlu::SemanticFrames *frames) {
  assert(frames);
  for (size_t i = 0; i < frames->size(); ++i) {
    frames->at(i) = nullptr;
  }
  frames->clear();
}

int ApplySemanticsModifiers(
    const std::vector<clu::SemanticModifier *> &modifiers, Turn *cur_turn) {
  assert(cur_turn);
  if (!cur_turn->selected_task) {
    return 0;
  }
  auto active_frame = cur_turn->selected_task->GetActiveFrame();
  if (!active_frame) {
    return 0;
  }
  LOGI << "Start to process semantic modifier after DM.";
  std::vector<nlu::Slot *> slots;
  auto form_task =
      std::dynamic_pointer_cast<dialog::FormTask>(cur_turn->selected_task);
  if (form_task) {
    for (auto &nlu_slots : form_task->slots) {
      slots.insert(slots.end(), nlu_slots->slot_values.begin(),
                   nlu_slots->slot_values.end());
    }
  }

  for (auto &modifier : modifiers) {
    if (modifier->IsWorksAfterDm() &&
        modifier->Process(&active_frame->domain.value, &form_task->focus,
                          &slots) < 0) {
      LOGE << "Failed to process semantic modifier: " << modifier->type;
      return -1;
    }
  }
  LOGI << "SemanticMapper process frames after DM successfully!";
  return 0;
}

int FilterSubQuery(const std::string &query, SemanticFrames *frames) {
  assert(frames);
  std::vector<nlu::Slot *> temp_slots;
  for (auto iter = frames->begin(); iter != frames->end();) {
    temp_slots.clear();
    (*iter)->slots.List("", &temp_slots);
    bool found = false;
    for (auto &slot : temp_slots) {
      if (static_cast<int>(query.find(slot->value)) < 0) {
        LOGI << "Not found slot value '" << slot->value
                  << "' in query:" << query;
        delete *iter;
        auto p = frames->erase(iter);
        found = true;
        break;
      }
    }
    if (!found) {
      ++iter;
    }
  }
  return 0;
}

int RestoreQueries(const DialogueRequest &request,
                   const uint32_t max_query_size, ContextManager &ctx,
                   std::vector<std::shared_ptr<clu::Query>> *queries) {
  assert(queries);
  auto key = kSessionPrefixOfCommand + request.session_id;
  if (request.first_wakeup) {
    ctx.Del(key);
    auto query = std::make_shared<clu::Query>(request.query);
    query->SetFirstWakeUp(request.first_wakeup);
    query->SetRequestId(request.id);
    queries->emplace_back(std::move(query));
    LOGI << "[" << request.id << "]: First wakeup, no query history.";
    return 0;
  }
  std::vector<std::string> query_str_list;
  if (ctx.HGet(key, &query_str_list) < 0) {
    LOGE << "[" << request.id << "] Failed to get dialogue context for "
               << key;
    return -1;
  }
  for (auto &query_str : query_str_list) {
    auto query_obj = JsonHelper::ParseJsonFromString(query_str);
    auto query = std::make_shared<clu::Query>("");
    if (query->Deserialize(query_obj) < 0) {
      LOGE << "[" << request.id
                 << "] Failed to deserialize query from json: " << query_str;
      return -1;
    } else {
      queries->push_back(query);
    }
  }
  std::sort(queries->begin(), queries->end(),
            [](const std::shared_ptr<clu::Query> &a,
               const std::shared_ptr<clu::Query> &b) {
              return a->GetTimeStamp() < b->GetTimeStamp();
            });
  if (queries->size() > max_query_size) {
    auto count = queries->size() - max_query_size;
    for (auto iter = queries->begin(); iter < queries->end();) {
      std::string q_id = (*iter)->GetRequestId();
      LOGI << "[" << request.id
                << "]: Remove expired query: " << (*iter)->GetQuery() << "("
                << q_id << ").";
      ctx.HDel(key, q_id);
      queries->erase(iter);
      if (--count == 0) {
        break;
      }
    }
  }

  key = kSessionPrefixOfSubQuery + request.session_id;
  std::string kv_value;
  if (ctx.Get(key, &kv_value) < 0) {
    LOGE << "[" << request.id << "] Failed to get dialogue context for "
               << key;
    return -1;
  }
  std::string last_query;
  std::string last_sub_queries;
  if (!kv_value.empty()) {
    auto index = kv_value.find("->");
    if (index != std::string::npos) {
      last_query = kv_value.substr(0, index);
      last_sub_queries = kv_value.substr(index + 2);
    } else {
      LOGW << "[" << request.id << "] Invalid sub-query context value '"
                   << kv_value << "' for key'" << key << "'";
    }
  }
  for (auto &his_response : request.histories) {
    
    for (auto iter = queries->rbegin(); iter != queries->rend(); ++iter) {
      if (!his_response.request_id.empty()) {
        if ((*iter)->GetRequestId() == his_response.request_id) {
          (*iter)->SetResponse(his_response.response);
          break;
      }
    } else if ((*iter)->GetQuery() == his_response.query) {
        LOGI << "[" << request.id
                  << "] set query response: " << his_response.query << " -> "
                  << his_response.response;
        (*iter)->SetResponse(his_response.response);
        break;
      }
      if ((*iter)->GetQuery() == last_query &&
          last_sub_queries.find("|" + his_response.query + "|") !=
              std::string::npos) {
        LOGI << "[" << request.id
                  << "] set sub-query response: " << his_response.query
                  << " -> " << his_response.response;
        (*iter)->SetResponse(his_response.response, true);
        break;
      }
    }
  }
  Json::Value query_objs(Json::arrayValue);
  for (auto &q : *queries) {
    Json::Value query_obj;
    query_obj["id"] = q->GetRequestId();
    query_obj["query"] = q->GetQuery();
    query_obj["response"] = q->GetResponse();
    query_objs.append(query_obj);
  }
  LOGI << "[" << request.id << "] restore query histories: "
            << JsonHelper::ToString(query_objs);
  if (!request.query.empty()) {
    auto query = std::make_shared<clu::Query>(request.query);
    query->SetFirstWakeUp(request.first_wakeup);
    query->SetRequestId(request.id);
    queries->emplace_back(std::move(query));
  }
  return 0;
}

int StoreQueries(const uint32_t max_query_size,
                 std::shared_ptr<dialog::ContextManager> ctx,
                 DialogueResponse *response) {
  assert(ctx);
  assert(response);
  response->timeline->record(response->request_id, "store-queries", "存储query上下文");
  auto key = kSessionPrefixOfCommand + response->session_id;
  std::string request_id = response->request_id;
  if (response->query_histories.empty()) {
    LOGW << "[" << request_id << "]: no queries to store";
    return 0;
  }
  auto cur_query = response->query_histories.back();
  for (auto &sub_query: response->sub_queries) {
    std::string llm_command = sub_query->generate_text + ":" + sub_query->category;
    cur_query->AppendLLMCommand(llm_command);
  }
  if (response->query_histories.size() >= 2) {
    auto last_query =
        response->query_histories[response->query_histories.size() - 2];
    if (last_query->IsChanged()) {
      LOGI << "[" << request_id << "]: store last query response: "
                << last_query->GetResponse();
      auto query_str = JsonHelper::ToString(last_query->Serialize());
      ctx->HSet(key, last_query->GetRequestId(), query_str,
                ContextManager::ContextType::KQueryRecords);
    }
  }
  cur_query->SetMultiIntents(response->sub_queries.size() > 1);
  auto query_str = JsonHelper::ToString(cur_query->Serialize());
  if (ctx->HSet(key, cur_query->GetRequestId(), query_str,
                ContextManager::ContextType::KQueryRecords) < 0) {
    LOGE << "[" << request_id
               << "]: Failed to put dialogue context for: " << key;
    return -1;
  }
  LOGI << "[" << request_id << "]: stored current query:" << query_str;
  return 0;
}

int StoreSubQueries(const DialogueResponse &response,
                    std::shared_ptr<dialog::ContextManager> ctx) {
  response.timeline->record(response.request_id, "store-subquery", "存储子句");
  if (response.sub_queries.empty()) {
    LOGW << "[" << response.request_id << "]: no sub queries to store";
    return 0;
  }
  if (response.sub_queries.size() == 1 &&
      response.sub_queries[0]->generate_text == response.normalized_query) {
    LOGI << "[" << response.request_id
              << "]: sub query is the same as raw query, so there is no need "
                 "to store the sub-query results";
    return 0;
  }
  std::string key = kSessionPrefixOfSubQuery + response.session_id;
  std::string value = response.normalized_query + "->|";
  for (auto &sub_query : response.sub_queries) {
    value += sub_query->generate_text + "|";
  }
  if (ctx->Put(key, value, ContextManager::ContextType::KQueryRecords) < 0) {
    LOGE << "[" << response.request_id
               << "]: Failed to put dialogue context for: " << key;
  }
  LOGI << "[" << response.request_id << "]: stored sub queries:" << value;
  return 0;
}

int GetQuerySegmentCache(
    const std::string &request_id,
    const std::shared_ptr<dialog::ContextManager> ctx, const std::string &query,
    std::vector<std::shared_ptr<clu::SubQuery>> *sub_queries) {
  assert(sub_queries);
  std::string value;
  ctx->Get(query, &value);
  if (!value.empty()) {
    std::vector<std::string> list;
    StringUtil::Split(value, &list, "\n", true);
    uint32_t i = 1;
    for (auto &q : list) {
      auto sub_query = std::make_shared<clu::SubQuery>(q);
      sub_query->request_id = request_id;
      sub_query->index = i++;
      if (i == list.size() + 1) {
        sub_query->is_last = true;
      }
      sub_queries->push_back(sub_query);
    }
    LOGI << "[" << request_id << "]: Get query segment cache for key: '"
              << query << "' value: '" << value << "'";
  } else {
    LOGI << "[" << request_id << "]: No query segment cache for key '"
              << query << "'";
    return 1;
  }
  return 0;
}

int CacheQuerySegment(
    std::shared_ptr<dialog::ContextManager> ctx, const std::string &raw_query,
    const std::vector<std::shared_ptr<clu::SubQuery>> &sub_queries) {
  if (sub_queries.size() == 1 && sub_queries[0]->generate_text == raw_query &&
      sub_queries[0]->handler == "llm") {
    // 1. 缓存的策略：改写query等于原query
    std::string value;
    for (auto &q : sub_queries) {
      value.append(q->generate_text).append("\n");
    }
    value.pop_back();
    ctx->Put(raw_query, value, ContextManager::ContextType::kLLMSimpleCache);
    LOGI << "[" << sub_queries[0]->request_id
              << "]: Cache query segment for key: '" << raw_query
              << "' value: '" << value << "'";
  }
  return 0;
}

void MergeTurns(const std::shared_ptr<dialog::Turn> turn,
                dialog::Turn *cur_turn) {
  assert(cur_turn);
  for (auto &input : turn->inputs) {
    if (input->InputMode() == dialog::Input::Mode::kReference) {
      cur_turn->inputs.push_back(input);
    }
  }
  for (auto &task : turn->active_tasks) {
    bool found = false;
    for (auto &t : cur_turn->active_tasks) {
      if (t->guid == task->guid) {
        found = true;
        break;
      }
    }
    if (!found) {
      cur_turn->active_tasks.push_back(task);
    }
  }
  cur_turn->selected_task = turn->selected_task;
  cur_turn->frames = turn->frames;
  turn->frames = {};
}

void GetTurnSoundPosition(const dialog::Turn &turn, std::string *position) {
  for (auto &input : turn.inputs) {
    if (input->InputMode() == dialog::Input::Mode::kEvent) {
      auto p_input = std::dynamic_pointer_cast<dialog::EventInput>(input);
      if (p_input->GetName() == "microphone") {
        auto p_postion = p_input->GetChildByName("position");
        if (p_postion) {
          *position = p_postion->AsString();
        }
        return;
      }
    }
  }
  LOGI << "[" << turn.turn_uid << "]: no microphone position info";
}

void SetHistorySemantics(const dialog::Turn &cur_turn,
                         const std::vector<dialog::Turn *> &history,
                         DialogueResponse *response) {
  if (!history.empty()) {
    // 只要最后一条query的语义信息
    auto &turn = history.front();
    if (turn->selected_task && turn->selected_task->GetActiveFrame()) {
      auto frame = turn->selected_task->GetActiveFrame();
      auto semantic = std::make_shared<clu::SimpleSemantic>();
      semantic->domain = frame->domain.value;
      if (!frame->intents.empty()) {
        semantic->intent = frame->intents.front().value;
      } else {
        semantic->intent = semantic->domain;
      }
      if (turn->selected_task->type == dialog::FlowTaskDef::kType ||
          turn->selected_task->type == dialog::FormTaskDef::kType) {
        auto form_task =
            std::dynamic_pointer_cast<dialog::FormTask>(turn->selected_task);
        for (auto &dl_slot : form_task->slots) {
          for (auto &slot : dl_slot->slot_values) {
            semantic->slots.emplace_back(
                slot->name, clu::SlotUtils::GetSlotNormalValue(*slot));
          }
        }
      }
      semantic->query = turn->query;
      response->history_semantics.emplace_back(semantic);
      LOGI << "[" << response->request_id << "]: Last history semantics: "
                << response->history_semantics.back()->ToString();
    } else {
      for (auto &frame : turn->frames) {
        auto semantic = std::make_shared<clu::SimpleSemantic>();
        semantic->domain = frame->domain.value;
        if (!frame->intents.empty()) {
          semantic->intent = frame->intents.front().value;
        } else {
          semantic->intent = semantic->domain;
        }
        semantic->query = turn->query;
        response->history_semantics.emplace_back(semantic);
        LOGI << "[" << response->request_id
                  << "]: Last history semantics: "
                  << response->history_semantics.back()->ToString();
      }
    }
    if (!response->history_semantics.empty()) {
      response->query_histories.back()->SetLastSemantic(
          response->history_semantics.back());
      LOGI
          << "[" << response->request_id
          << "]: set query Last history semantics: "
          << response->query_histories.back()->GetLastSemantic()->ToString();
    }
    // 为当前轮设置最近一轮非拒识的语义
    if (!response->query_histories.empty() &&
        !response->query_histories.back()->GetLastSemantic()) {
      std::shared_ptr<clu::SimpleSemantic> last_semantic = nullptr;
      for (auto it = response->query_histories.rbegin() + 1;
           it != response->query_histories.rend(); ++it) {
        if ((*it)->GetLastSemantic()) {
          last_semantic = (*it)->GetLastSemantic();
          break;
        }
      }
      if (last_semantic) {
        response->query_histories.back()->SetLastSemantic(last_semantic);
      }
    }
  }
}

void SetResponseRejectionInfo(const DialogueRequest &request,
                              DialogueResponse *response) {
  if (response->query_histories.empty()) {
    return;
  }
  auto query = response->query_histories.back();
  response->rejection_result.SetQuery(query->GetQuery());
  response->rejection_result.SetFirstWakeup(request.first_wakeup);
  response->rejection_result.SetRepeatQuery(
      response->query_histories.size() >= 2 &&
      query->GetQuery() ==
          response->query_histories[response->query_histories.size() - 2]
              ->GetQuery());
  response->context_variables["is_repeat_query"] = std::to_string(response->rejection_result.IsRepeatQuery());
  auto iter = response->context_variables.find(kWakeUp);
  if (iter != response->context_variables.end() && iter->second == "1") {
    response->rejection_result.SetWakeUp(true);
  }
}

void SetQuerySoundPosition(const dialog::Turn &cur_turn,
                           DialogueResponse *response) {
  if (response->query_histories.empty()) {
    return;
  }
  std::string position;
  GetTurnSoundPosition(cur_turn, &position);
  response->query_histories.back()->SetSoundPosition(position);
}

void GetLastNotOtherCategory(const std::vector<dialog::Turn *> &history,
                             std::string *category) {
  if (!history.empty()) {
    for (auto &frame : history.back()->frames) {
      if (frame->domain.value != kDomainOther) {
        *category = frame->domain.value;
        LOGI << "Set last not other category: " << *category;
        break;
      }
    }
  }
}

void FilterContext(const std::shared_ptr<clu::CtxFilter> filter,
                   const std::vector<dialog::Turn *> &history,
                   dialog::Turn *cur_turn, DialogueResponse *response) {
  assert(cur_turn);
  assert(response);
  if (response->query_histories.empty()) {
    LOGI << "[" << cur_turn->turn_uid << "]: no query histories.";
    return;
  }
  std::set<std::string> query_ids;
  for (auto &query : response->query_histories) {
    if (query_ids.find(query->GetRequestId()) != query_ids.end()) {
      LOGW << "[" << cur_turn->turn_uid
                   << "]: duplicated query id: " << query->GetRequestId();
      continue;
    }
    query_ids.insert(query->GetRequestId());
  }
  auto &query = response->query_histories.back();
  query->SetQueryContext(query_ids);
  if (!filter) {
    LOGI << "[" << cur_turn->turn_uid << "]: ContextFilter is disabled.";
    return;
  }
  if (filter->Filter(response->query_histories, &query_ids) < 0) {
    LOGE << "[" << cur_turn->turn_uid << "]：Failed to filter context";
    return;
  }
  query->SetQueryContext(query_ids);
  for (auto &task : cur_turn->active_tasks) {
    if (query_ids.find(task->request_id) != query_ids.end()) {
      cur_turn->executable_tasks.insert(task->request_id);
    } else {
      LOGI << "[" << cur_turn->turn_uid
                << "]：not executable task: " << task->guid;
    }
  }
}

void FlatEventInput(const std::shared_ptr<dialog::EventInput> &input,
                    const std::string &base_name,
                    std::map<std::string, std::string> *vars) {
  assert(vars);
  if (input->GetType() == EventInput::DataType::kObject ||
      input->GetType() == EventInput::DataType::kArray) {
    for (auto &child : input->GetChildren()) {
      auto new_base_name = input->GetName();
      if (!base_name.empty()) {
        new_base_name = base_name + new_base_name;
      }
      new_base_name.push_back('.');
      FlatEventInput(child, new_base_name, vars);
    }
  } else {
    vars->insert({base_name + input->GetName(), input->AsString()});
  }
}

void UpdateContextVariables(const dialog::Turn &cur_turn,
                            const DialogueRequest &request,
                            DialogueResponse *response) {
  assert(response);
  for (auto &input : cur_turn.inputs) {
    if (input->InputMode() == EventInput::Mode::kEvent ||
        input->InputMode() == EventInput::Mode::kReference) {
      auto p_input = std::dynamic_pointer_cast<dialog::EventInput>(input);
      FlatEventInput(p_input, "", &response->context_variables);
    }
  }
  std::string first_wakeup_str = "false";
  if (request.first_wakeup) {
    first_wakeup_str = "true";
  }
  response->context_variables.insert({"first_wakeup", first_wakeup_str});
  if (!response->history_semantics.empty()) {
    auto semantic = response->history_semantics.back();
    response->context_variables.insert({"last_domain", semantic->domain});
    response->context_variables.insert({"last_intent", semantic->intent});
    for (auto &slot : semantic->slots) {
      response->context_variables.insert(
          {"last_slot_" + slot.first, slot.second});
    }
    response->context_variables.insert(
        {"last_slots_size", std::to_string(semantic->slots.size())});
  }
  if (response->query_histories.size() >= 2) {
    auto last_query =
        response->query_histories.at(response->query_histories.size() - 2);
    if (!last_query->GetResponse().empty()) {
      response->context_variables.insert(
          {"last_response", last_query->GetResponse()});
    }
    response->context_variables.insert(
      {"last_query", last_query->GetQuery()});
    response->context_variables.insert(
      {"last_query.microphone.position", last_query->GetSoundPosition()});
  }
}

}  // namespace

void Dialogue::Initialize() { nlptk::dialog::BindBuildinTasks(); }

Dialogue::Dialogue()
    : valid_(false),
      turn_history_size_(2u),
      qs_manager_(nullptr),
      qr_manager_(nullptr),
      dst_manager_(nullptr),
      semantics_processor_(nullptr),
      semantic_processor_(nullptr),
      normalizer_(nullptr),
      plugin_manager_(nullptr),
      dispatch_manager_(nullptr),
      thread_pool_(nullptr),
      hot_queries_cache_(nullptr),
      query_normalizer_(nullptr),
      ctx_filter_(nullptr),
      query_guard_(nullptr) {}

Dialogue::~Dialogue() {
  Destruction();
  LOGI << "Dialogue destroyed.";
}

int Dialogue::Initialize(const string &config_path) {
  curl_global_init(CURL_GLOBAL_ALL);
  config_file_ = config_path;
  Path path(config_path);
  path = path.AbsolutePath();
  if (!path.IsExisted()) {
    LOGE << "Configure file not existed: " << config_path;
    return -1;
  }

  Json::Value config = JsonHelper::ParseJsonFromFile(path.ToString());
  Path base_path = path.Directory();

  if (config.isNull()) {
    LOGE << "Failed to parse config from: " << path.ToString();
    return -1;
  }

  if (config.empty()) {
    LOGE << "Empty configure is parse from: " << path.ToString();
    return -1;
  }

  auto ds = JsonHelper::ResolveJPath<string>(config, ".DefaultScenario", "");
  if (StringUtil::EmptyOrSpaces(ds)) {
    LOGE << "Failed to load CU config due to missed default scenario!";
    return -1;
  } else {
    ds = StringUtil::Trim(ds);
    ds = StringUtil::ToLower(ds);
  }
  auto nlu_config = JsonHelper::ResolveJPath(config, "LanguageUnderstanding");
  if (nlu_config.isNull() || nlu_config.empty()) {
    LOGE << "Failed to load nlu config due to empty json!";
    return -1;
  }
#ifdef ENABLE_SIMPLIFIED_NLU
  auto nlu_config_file =
      JsonHelper::ResolveJPath<std::string>(nlu_config, "NluConfig", "");
  if (nlu_config_file.empty()) {
    LOGE << "Failed to load nlu config due to empty json!";
    return -1;
  }
  auto nlu_path = base_path.Append(nlu_config_file);
  if (!nlu_path.IsFile()) {
    LOGE << "Failed to load nlu config due to file "
               << nlu_path.ToString() << " is not exist!";
    return -1;
  }
  auto nlu_obj = JsonHelper::ParseJsonFromFile(nlu_path.ToString());
  nlu_manager_.reset(new clu::NluManager());
  if (nlu_manager_->Initialize(nlu_obj, base_path.ToString(), ds) < 0) {
    LOGE << "Failed to initialize NLU manager!";
    return -1;
  }
  LOGI << "NLU manager initialized!";
#else
  nlu_manager_.reset(new nlu::NLUManager());
  if (nlu_manager_->Initialize(nlu_config, base_path.ToString(), ds) < 0) {
    LOGE << "Failed to initialize NLU manager!";
    return -1;
  }

  if (!nlu_manager_->IsSupportedScenario(ds)) {
    LOGE << "Unregistered scenario for NLU!" << ds;
    return -1;
  }
#endif

  auto query_normalizer_cmd =
      JsonHelper::ResolveJPath<std::string>(nlu_config, "QueryNormalizer", "");
  if (!query_normalizer_cmd.empty()) {
    query_normalizer_ = std::make_shared<clu::QueryProcessor>();
    if (query_normalizer_->Initialize(query_normalizer_cmd) < 0) {
      LOGE << "Failed to initialize query normalizer!";
      return -1;
    }
  }
  qs_manager_ = std::make_shared<clu::QsManager>();
  auto qs_config = JsonHelper::ResolveJPath<std::string>(
      nlu_config, "QuerySegmentionConfig", "");
  if (qs_config.empty()) {
    LOGE << "Failed to load config: QuerySegmentionConfig is empty.";
    return -1;
  }
  Path qs_path(base_path);
  qs_path = qs_path.Append(qs_config);
  if (!qs_path.IsFile()) {
    LOGE << "file " << qs_path.ToString() << " is not exist!";
    return -1;
  }
  Json::Value qs_obj = JsonHelper::ParseJsonFromFile(qs_path.ToString());
  if (qs_manager_->Initialize(qs_obj, base_path.ToString()) < 0) {
    LOGE << "Failed to init 'QuerySegmentionConfig':"
               << JsonHelper::ToString(qs_config);
    return -1;
  }

  auto process_config =
      JsonHelper::ResolveJPath(nlu_config, "SemanticsProcessConfig");
  if (!process_config.isNull()) {
    semantics_processor_ = std::make_shared<clu::MultiSemanticProcessor>();
    Path process_path(base_path);
    process_path = process_path.Append(process_config.asString());
    if (!process_path.IsFile()) {
      LOGE << "file " << process_path.ToString() << " is not exist!";
      return -1;
    }
    Json::Value process_obj =
        JsonHelper::ParseJsonFromFile(process_path.ToString());
    if (semantics_processor_->Initialize(process_obj) < 0) {
      LOGE << "Failed to init 'MultiSemanticProcessor':"
                 << JsonHelper::ToString(qs_config);
      return -1;
    }
    LOGI << "Load " << process_path.ToString() << " successfully!";
  }

  process_config =
      JsonHelper::ResolveJPath(nlu_config, "SemanticProcessConfig");
  if (!process_config.isNull()) {
    semantic_processor_ = std::make_shared<clu::SingleSemanticProcessor>();
    Path process_path(base_path);
    process_path = process_path.Append(process_config.asString());
    if (!process_path.IsFile()) {
      LOGE << "file " << process_path.ToString() << " is not exist!";
      return -1;
    }
    Json::Value process_obj =
        JsonHelper::ParseJsonFromFile(process_path.ToString());
    if (semantic_processor_->Initialize(process_obj) < 0) {
      LOGE << "Failed to init 'MultiSemanticProcessor':"
                 << JsonHelper::ToString(qs_config);
      return -1;
    }
  }

  auto modifier_configs =
      JsonHelper::ResolveJPath(nlu_config, "SemanticModifierConfigs");
  if (!modifier_configs.isNull()) {
    if (!modifier_configs.isArray()) {
      LOGE
          << "Failed to load 'SemanticModifierConfigs': expect array type";
      return -1;
    }
    for (auto &modifier_config : modifier_configs) {
      Path modifier_path(base_path);
      modifier_path = modifier_path.Append(modifier_config.asString());
      if (!modifier_path.IsFile()) {
        LOGE << "File " << modifier_path.ToString() << " is not exist!";
        return -1;
      }
      Json::Value modifier_obj =
          JsonHelper::ParseJsonFromFile(modifier_path.ToString());
      if (modifier_obj.isArray()) {
        for (auto &item : modifier_obj) {
          auto type = JsonHelper::ResolveJPath<std::string>(item, "type", "");
          auto modifier = clu::ModifierFactory::Get(type);
          if (modifier) {
            if (modifier->Load(item) < 0) {
              LOGE << "Failed to load json file: "
                         << modifier_path.ToString()
                         << ", failed to load json '"
                         << JsonHelper::ToString(item) << "'";
              delete modifier;
              return -1;
            }
            semantic_modifiers_.push_back(modifier);
          } else {
            LOGE << "Failed to load json file: "
                       << modifier_path.ToString() << ": unrecognized type:'"
                       << type << "'";
            return -1;
          }
        }
        LOGI << "Load " << modifier_path.ToString() << " successfully!";
      } else {
        LOGI << "Failed to load json file: " << modifier_path.ToString()
                  << ": expect array value.";
      }
    }
  }

  auto normalizer_obj =
      JsonHelper::ResolveJPath(nlu_config, "SlotNormalizerConfig");
  if (!normalizer_obj.isNull()) {
    normalizer_ = new clu::SlotNormalizer();
    if (normalizer_->Initialize(normalizer_obj, base_path.ToString()) < 0) {
      LOGE << "Failed to load 'SlotNormalizerConfig'";
      return -1;
    }
  }

  qr_manager_ = std::make_shared<clu::QrManager>();
  auto qr_config = JsonHelper::ResolveJPath<std::string>(
      nlu_config, "QueryRejectionConfig", "");
  if (qr_config.empty()) {
    LOGW << "Not config 'QueryRejectionConfig'.";
  } else {
    Path dispath_config(base_path);
    dispath_config = dispath_config.Append(qr_config);
    if (!dispath_config.IsFile()) {
      LOGE << "File " << dispath_config.ToString() << " is not exist!";
      return -1;
    }
    auto dispatch_obj =
        JsonHelper::ParseJsonFromFile(dispath_config.ToString());

    if (qr_manager_->Initialize(dispatch_obj, base_path.ToString()) < 0) {
      LOGE << "Failed to init 'QueryRejection':"
                 << JsonHelper::ToString(qr_config);
      return -1;
    }
  }

  plugin_manager_ = std::make_shared<clu::PluginManager>();
  auto plugins_config =
      JsonHelper::ResolveJPath<std::string>(nlu_config, "PluginsConfig", "");
  if (!plugins_config.empty()) {
    auto plugin_path = base_path.Append(plugins_config);
    if (!plugin_path.IsFile()) {
      LOGE << "File " << plugin_path.ToString() << " is not exist!";
      return -1;
    }
    auto plugin_config = JsonHelper::ParseJsonFromFile(plugin_path.ToString());
    if (plugin_manager_->Initialize(plugin_config, base_path.ToString()) < 0) {
      LOGE << "Failed to init 'Plugins':"
                 << JsonHelper::ToString(plugin_config);
      return -1;
    }
  }

  dispatch_manager_ = std::make_shared<clu::DispatchManager>();
  auto dispatch_config = JsonHelper::ResolveJPath<std::string>(
      nlu_config, "QueryDispatchConfig", "");
  if (dispatch_config.empty()) {
    LOGE << "Not config 'QueryDispatchConfig'.";
    return -1;
  }
  Path dispath_config(base_path);
  dispath_config = dispath_config.Append(dispatch_config);
  if (!dispath_config.IsExisted()) {
    LOGE << "File " << dispath_config.ToString() << " is not exist!";
    return -1;
  }
  auto dispath_config_obj =
      JsonHelper::ParseJsonFromFile(dispath_config.ToString());
  if (dispatch_manager_->Initialize(dispath_config_obj, base_path.ToString()) <
      0) {
    LOGE << "Failed to init 'QueryDispatchConfig':"
               << JsonHelper::ToString(dispatch_config);
    return -1;
  }
  dst_manager_ = std::make_shared<clu::DstManager>();
  auto dst_config =
      JsonHelper::ResolveJPath(nlu_config, "DialogueStateTracking");
  if (dst_manager_->Initialize(dst_config, base_path.ToString()) < 0) {
    LOGE << "Failed to init 'DialogueStateTracking':"
               << JsonHelper::ToString(dst_config);
    return -1;
  }

  turn_history_size_ = JsonHelper::ResolveJPath<size_t>(
      config, "ContextManager.max_turn_size", 2);
  query_history_size_ = JsonHelper::ResolveJPath<size_t>(
      config, "ContextManager.max_query_records", 4);
  auto cm_type =
      JsonHelper::ResolveJPath<string>(config, "ContextManager.Type", "local");
  auto cm = ContextManager::Create(cm_type, config["ContextManager"]);
  if (cm == nullptr) {
    LOGE << "Failed to create context manager from: "
               << JsonHelper::ToString(config["ContextManager"]);
    return -1;
  }

  context_manager_.reset(cm);
  personalized_dict_manager_ = std::make_shared<dialog::PersonalizedDictManager>(context_manager_);
  auto dm_config = JsonHelper::ResolveJPath(config, "DialogueManager");
  if (dm_config.isNull() || dm_config.empty()) {
    LOGE << "Failed to load dm config due to empty json!";
    return -1;
  }

  dialogue_manager_.reset(new DialogueManager());
  if (dialogue_manager_->Initialize(dm_config, context_manager_,
                                    base_path.ToString(), ds) < 0) {
    dialogue_manager_.reset();
    LOGE << "Failed to initialize dialogue manager!";
    return -1;
  }

  if (!dialogue_manager_->IsSupportedScenario(ds)) {
    LOGE << "Unregistered scenario for DM!" << ds;
    return -1;
  }
  dialogue_manager_->SetDefaultScenario(ds);
  auto pool_size =
      JsonHelper::ResolveJPath<size_t>(config, "ThreadPoolSize", 5);
  thread_pool_.reset(new utils::SimpleThreadPool(pool_size));

  auto hot_rule_config =
      JsonHelper::ResolveJPath(config, "HotQueriesCacheRules");
  hot_queries_cache_.reset(new HotQueriesCache());
  if (hot_queries_cache_->Initialize(hot_rule_config, base_path.ToString()) <
      0) {
    LOGE << "Failed to init 'HotQueriesCacheRules':"
               << JsonHelper::ToString(hot_rule_config);
    return -1;
  }
  auto filter_obj = JsonHelper::ResolveJPath(config, "ContextFilter");
  if (filter_obj.isObject()) {
    ctx_filter_ = std::make_shared<clu::CtxFilter>();
    if (ctx_filter_->Initialize(filter_obj, base_path.ToString()) < 0) {
      LOGE << "CtxFilter initialize failed.";
      return -1;
    }
  }
  auto query_guard_obj = JsonHelper::ResolveJPath(config, "QueryGuard");
  if (!query_guard_obj.isNull()) {
    query_guard_ = std::make_shared<clu::QueryGuard>();
    if (query_guard_->Initialize(query_guard_obj, base_path.ToString()) < 0) {
      LOGE << "QueryGuard initialize failed.";
      return -1;
    }
  }
  version = JsonHelper::ResolveJPath<std::string>(config, "version", "null");
  valid_.store(context_manager_ && nlu_manager_ && dialogue_manager_);
  return valid_.load() ? 0 : -1;
}

int Dialogue::Process(const DialogueRequest &request,
                      DialogueResponse *response) const {
  assert(response);
  if (!valid_.load()) {
    LOGE << "Invalid dialogue is invoked!";
    response->code = 503;
    response->error_msg = "Service is unavailable: Failed to initialize!";
    return 503;
  }
  vector<Turn *> history;
  Turn *cur_turn = new Turn();
  response->timeline->record(response->request_id, "pre-request", "参数和上下文预处理");
  auto code = BeforeProcess(request, cur_turn, &history, response);
  if (code != DialogueCode::Success) {
    LOGE << "[" << request.id << "]: Failed to invoke BeforeProcess.";
    delete cur_turn;
    DialogueUtils::FreePointers(&history);
    return code;
  }
  response->timeline->record(response->request_id, "hot-query", "hot-query模块规则匹配");
  if (GetHotQueryCache(response, cur_turn) <= 0) {
    if (request.stream) {
      code = StreamConversion(history, cur_turn, response);
    } else {
      code = SynchronousConversation(history, cur_turn, response);
    }
  }
  response->timeline->record(response->request_id, "after-request", "上下文回存");
  if (AfterProcess(request.session_id, cur_turn, &history) != 0) {
    LOGE << "[" << request.id << "]: Failed to invoke AfterProcess.";
    DialogueUtils::FreePointers(&history);
    return -1;
  }
  DialogueUtils::FreePointers(&history);
  return code;
}

int Dialogue::BeforeProcess(const DialogueRequest &request,
                            dialog::Turn *cur_turn,
                            std::vector<dialog::Turn *> *history,
                            DialogueResponse *response) const {
  assert(cur_turn);
  assert(history);
  assert(response);
  response->request_id = request.id;
  response->original_query = request.query;
  response->normalized_query = request.query;
  response->version = version;
  if (query_normalizer_) {
    query_normalizer_->Process(&response->normalized_query);
    LOG_IF(INFO, response->original_query != response->normalized_query)
        << "[" << request.id
        << "]: Normalized query to: " << response->normalized_query;
  }
  response->debug = request.enable_debug;
  response->stream = request.stream;
  cur_turn->session_id = request.session_id;
  response->session_id = request.session_id;
  cur_turn->turn_uid = request.id;
  response->debug_info.hot_query_info.enable = request.enable_cache;
  response->rejection_result.SetContextVariables(&response->context_variables);
  if (request.enable_hotfix) {
    cur_turn->cache_code += (1 << 1);
  }
  cur_turn->query = request.query;
  if (BuildInput(request, cur_turn) < 0) {
    LOGE << "[" << request.id << "]: Failed to build input!";
    return DialogueCode::E_EmptyQuery;
  }
  if (!request.app_id.empty() && !request.uid.empty()) {
    auto code = personalized_dict_manager_->Get(request.app_id, request.uid, &cur_turn->inputs);
    if (code < 0) {
      LOGE << "[" << request.id << "]: Failed to get personalized dict for "
                 << request.app_id << ":" << request.uid;
    }
  }
  if (BuildClientContent(request, &(cur_turn->client_content)) < 0) {
    LOGE << "[" << request.id << "]: Failed to build client content!";
  }
  if (!request.first_wakeup &&
      context_manager_->Get(request.session_id, history) < 0) {
    LOGE << "[" << request.id << "]: Failed to get dialogue context for "
               << request.session_id;
    DialogueUtils::FreePointers(history);
    return DialogueCode::E_Invalid;
  }

  if (!request.turn_uid.empty()) {
    UpdateTurn(request.turn_uid, history, cur_turn, request.id);
  } else {
    UpdateTurn(request.turn_id, history, cur_turn, request.id);
  }

  // if (!StringUtil::EmptyOrSpaces(request.scenario) &&
  //     !nlu_manager_->IsSupportedScenario(request.scenario)) {
  //   LOGE << "Unregistered scenario: " << request.scenario;
  //   DialogueUtils::FreePointer(&cur_turn);
  //   return DialogueCode::E_UnregistedScenario;
  // }
  if (RestoreQueries(request, query_history_size_, *context_manager_,
                     &response->query_histories) < 0) {
    LOGE << "[" << request.id << "]: Failed to get query history.";
    return DialogueCode::E_Error;
  }
  if (!response->query_histories.empty()) {
    response->query_histories.back()->SetNormalizedQuery(
        response->normalized_query);
    response->query_histories.back()->SetEnableLLM(request.enable_llm);
  }
  for (auto &q : response->query_histories) {
    q->SetContextVariables(&response->context_variables);
  }
  SetHistorySemantics(*cur_turn, *history, response);
  SetQuerySoundPosition(*cur_turn, response);
  FilterContext(ctx_filter_, *history, cur_turn, response);
  UpdateContextVariables(*cur_turn, request, response);
  SetResponseRejectionInfo(request, response);
  return DialogueCode::Success;
}

int Dialogue::AfterProcess(const std::string &session_id,
                           dialog::Turn *cur_turn,
                           std::vector<dialog::Turn *> *history) const {
  assert(cur_turn);
  assert(history);
  history->insert(history->begin(), cur_turn);
  while (history->size() > turn_history_size_) {
    delete history->back();
    history->pop_back();
  }

  if (!session_id.empty() && context_manager_->Put(session_id, *history) < 0) {
    LOGE << "[" << cur_turn->turn_uid
               << "]: Failed to put conversation context for " << session_id;
    return DialogueCode::E_ContextManager;
  }
  return DialogueCode::Success;
}

int Dialogue::QueryRejection(DialogueResponse *response) const {
  assert(response);
  auto query = response->query_histories.back();
  response->timeline->record(response->request_id, "rejection", "调用拒识模块");
  if (qr_manager_->Process(response->query_histories, &response->rejection_result) < 0) {
    LOGE << "[" << response->request_id
               << "]: Failed to process query-rejection.";
    return DialogueCode::E_Error;
  }
  if (response->debug) {
    response->debug_info.rejection_info = response->rejection_result.ToJson();
  }
  if (response->rejection_result.isRjected()) {
    query->UpdateStatus(clu::Query::Status::kRejected);
  }
  return 0;
}

int Dialogue::StreamSegmentQuery(
    DialogueResponse *response,
    clu::MessageQueue<std::shared_ptr<clu::SubQuery>> *query_queue) const {
  assert(response);
  assert(query_queue);
  clu::CreMatcher::CreQuery cre_query{response->request_id,
                                      response->original_query};
                                auto sub_query =
        std::make_shared<clu::SubQuery>(response->normalized_query);
  if (query_guard_ && !response->rejection_result.isRjected() &&
      query_guard_->IsOk(cre_query, &sub_query->extra_slots)) {
    sub_query->request_id = response->request_id;
    sub_query->is_sensitive = true;
    sub_query->is_last = true;
    sub_query->category = kDomainSensitive;
    // response->sub_queries.push_back(std::move(sub_query));
    query_queue->ProduceMessage(sub_query);
    LOGI << "[" << response->request_id
              << "]: detected query is sensitive, category changed to "
                 "sensitive.";
  } else if (!response->rejection_result.isRjected() &&
             !response->rejection_result.isSemanticClear()) {
    if (GetQuerySegmentCache(response->request_id, context_manager_,
                             response->normalized_query,
                             &response->sub_queries) > 0) {
      // 此处选择调用流式接口
      response->timeline->record(response->request_id, "rewrite", "调用分句改写模块");
      auto code = qs_manager_->Process(response->query_histories, query_queue);
      if (code < 0) {
        LOGE << "[" << response->request_id
                   << "]: Failed to process query-segmentation in clu.";
        return DialogueCode::E_Error;
      }
      CacheQuerySegment(context_manager_, response->normalized_query,
                        response->sub_queries);
    } else {
      query_queue->ProduceMessages(response->sub_queries);
    }
  } else {
    sub_query->request_id = response->request_id;
    sub_query->is_last = true;
    sub_query->is_rejected = response->rejection_result.isRjected();
    query_queue->ProduceMessage(sub_query);
  }
  query_queue->WaitForStop();
  return 0;
}

int Dialogue::ProcessQueries(const std::vector<dialog::Turn *> &turn_history,
                             dialog::Turn *cur_turn,
                             DialogueResponse *response) const {
  assert(response);
  std::map<nlu::SemanticFrame *, std::shared_ptr<clu::SubQuery>> semantic_map;
  nlu::SemanticFrames frames;
  int index = 0;
  bool exist_rejected = false;
  Json::Value debug_dispatch_info(Json::arrayValue);
  for (auto &sub_query : response->sub_queries) {
    cur_turn->query = sub_query->generate_text;
    const auto cur_query = response->query_histories.back();
    // 小模型拒识或者大模型拒识
    if (response->rejection_result.isRjected() || sub_query->is_rejected) {
      if (response->rejection_result.GetVersion() == "v1.0" && response->rejection_result.isFirstWakeup()) {
        // 此处兼容旧版本，首轮不拒识
        sub_query->is_rejected = false;
        LOGI << "[" << response->request_id
                  << "]: First wakeup, set is_rejected to false.";
        if (sub_query->handler == "llm") {
          sub_query->category = "unknown";
        }
      } else if (response->rejection_result.IsRepeatQuery()) {
        sub_query->is_rejected = false;
        LOGI << "[" << response->request_id
                  << "]: Repeat query, set is_rejected to false";
        if (sub_query->handler == "llm") {
          sub_query->category = "unknown";
        }
      } else {
        auto p_frame = new nlu::SemanticFrame();
        std::string domain = kDomainOther;
        sub_query->is_rejected = true;
        // 如果拒识，则将当前query的status设为kRejected，不会对真实的query状态产生影响，只会对插件中闲聊相关性中判断是否拒识有影响
        response->query_histories.back()->UpdateStatus(
            clu::Query::Status::kRejected);
        sub_query->category = domain;
        p_frame->domain.value = domain;
        p_frame->domain.score = 1.0f;
        frames.push_back(p_frame);
        semantic_map[frames.back()] = sub_query;
        continue;
      }
    }
    // 分发
    clu::DispatchResult dispatch_result(sub_query->generate_text);
    dispatch_result.SetCategory(sub_query->category);
    dispatch_result.SetVariables(&response->context_variables);
    GetLastNotOtherCategory(turn_history, &sub_query->history_categories);
    response->timeline->record(response->request_id, "handle-dispatch", "处理分发");
    if (dispatch_manager_->Dispatch(*sub_query, &dispatch_result) < 0) {
      LOGE << "[" << response->request_id
                 << "]: Failed to dispatch query:" << cur_query->GetQuery();
      return DialogueCode::E_Error;
    }
    if (response->debug) {
      debug_dispatch_info.append(dispatch_result.ToJson());
    }
    if (dispatch_result.GetCategory() == kDomainOther &&
        !dispatch_result.IsRuleMatched()) {
      // 分发标签为other, 如果是首次唤醒或者重复query，则转成chat
      if (response->rejection_result.isFirstWakeup()) {
        dispatch_result.SetCategory(kDomainChat);
        LOGI << "[" << response->request_id
                  << "]: First wakeup, set category to 'chat'.";
        // query拒识状态改为不拒识
        cur_query->SetStatus(clu::Query::Status::kOk);
      } else if (response->rejection_result.IsRepeatQuery()) {
        dispatch_result.SetCategory(kDomainChat);
        LOGI << "[" << response->request_id
                  << "]: Repeat query, set category to 'chat'.";
        // query拒识状态改为不拒识
        cur_query->SetStatus(clu::Query::Status::kOk);
      }
    }
    sub_query->is_nlu_domain = dispatch_result.IsNluDomain();
    sub_query->category = dispatch_result.GetCategory();
    if (!dispatch_result.IsNluDomain()) {
      auto p_frame = new nlu::SemanticFrame();
      p_frame->domain.value = dispatch_result.GetCategory();
      p_frame->domain.score = 1.0f;
      frames.push_back(p_frame);
      semantic_map[frames.back()] = sub_query;
      continue;
    }
#ifdef ENABLE_SIMPLIFIED_NLU
    // 走简化版nlu时，可以将domain分类传入，减少一次领域分类调用
    auto p_frame = new nlu::SemanticFrame();
    p_frame->domain.value = dispatch_result.GetCategory();
    p_frame->domain.score = 0.99f;
    cur_turn->frames.push_back(p_frame);
#endif
    clu::NluContext nlu_ctx;
    nlu_ctx.var_ctx = &response->context_variables;
    response->timeline->record(response->request_id, "nlu", "调用nlu");
    if (nlu_manager_->Process(cur_turn, turn_history, &nlu_ctx) < 0) {
      LOGE << "[" << response->request_id
                 << "]: Failed to understanding query: "
                 << response->normalized_query;
      return DialogueCode::E_Error;
    }
    if (response->debug) {
      if (!cur_turn->frames.empty()) {
        auto nlu_info = cur_turn->frames[0]->ToJson();
        nlu_info["processor"] = nlu_ctx.processor;
        nlu_info["matched_rule"] = nlu_ctx.matched_rule;
        response->debug_info.nlu_info.append(nlu_info);
      } else {
        response->debug_info.nlu_info.append(JsonHelper::MakeJsonObject());
      }
    }
    LOGI << "[" << response->request_id << "]:NLU process '"
              << cur_turn->query << "' completed.";
    // 归一化
    response->timeline->record(response->request_id, "normalize", "调用归一化");
    if (normalizer_ && !cur_turn->is_slot_immutable &&
        normalizer_->Process(&cur_turn->frames) < 0) {
      LOGE << "[" << response->request_id
                 << "]: Failed to process SlotNormalizer";
    }
    if (!cur_turn->frames.empty()) {
      LOGI << "[" << response->request_id
                << "]: NLU domain:" << cur_turn->frames[0]->domain.value;
      if (!cur_turn->frames[0]->intents.empty()) {
        LOGI << "[" << response->request_id
                  << "]: NLU intent:" << cur_turn->frames[0]->intents[0].value;
      } else {
        cur_turn->frames[0]->intents.emplace_back(kDomainOther, 1.0f);
        LOGI << "[" << response->request_id
                  << "]: NLU intent is empty set to 'other'";
      }
    }
    if (!cur_turn->frames.empty()) {
      frames.emplace_back(std::move(cur_turn->frames.front()));
      semantic_map[frames.back()] = sub_query;
      cur_turn->frames.front() = nullptr;
      cur_turn->frames.clear();
    }
  }
  // nlu语义修改器
  response->timeline->record(response->request_id, "modifier-nlu", "nlu之后调用语义修改器");
  LOGI << "[" << response->request_id << "]: "
            << "Start to apply semantic modifiers after nlu.";
  for (auto &modifier : semantic_modifiers_) {
    if (modifier->IsWorksAfterNlu() && modifier->Process(&frames) < 0) {
      LOGE << "[" << response->request_id
                 << "]: Failed to process semantic modifier: "
                 << modifier->type;
    }
  }
  LOGI << "[" << response->request_id
            << "]:SemanticMapper process frames after NLU successfully!";
  // 归一化
  response->timeline->record(response->request_id, "renormalize", "再归一化");
  if (normalizer_ && !cur_turn->is_slot_immutable &&
      normalizer_->Process(&frames) < 0) {
    LOGE << "[" << response->request_id
               << "]: Failed to process SlotNormalizer";
  }
  // 多意图后处理
  if (semantics_processor_) {
    response->timeline->record(response->request_id, "multi-intents", "多意图后处理");
    auto code = semantics_processor_->Process(&frames);
    if (code < 0) {
      LOGE
          << "[" << response->request_id
          << "]: Failed to invoke MultiSemanticProcessor::Process in clu.";
    }
  }
  // 单意图后处理
  if (semantic_processor_ && frames.size() == 1) {
    response->timeline->record(response->request_id, "single-intent", "单意图拦截器");
    auto code =
        semantic_processor_->Process(response->request_id, frames.front());
    if (code < 0) {
      LOGE
          << "[" << response->request_id
          << "]: Failed to invoke SingleSemanticProcessor::Process in clu.";
    }
  }
  LOGI << "[" << response->request_id
            << "]: Start to process semantic modifier after NLU.";

  // 插件处理
  response->timeline->record(response->request_id, "plugins", "插件调用");
  if (plugin_manager_->Process(response->query_histories, response->sub_queries,
                               &frames) < 0) {
    LOGE << "[" << response->request_id
               << "]:Failed to process plugin manager in clu.";
  }
  Json::Value results(Json::arrayValue);
  std::string vad_status = kInactiveVad;
  Json::Value semantic_obj = JsonHelper::MakeJsonObject();
  for (auto &frame : frames) {
    CleanFrames(&cur_turn->frames);
    cur_turn->frames.push_back(frame);
    if (semantic_map.find(frame) == semantic_map.end()) {
      cur_turn->query = response->normalized_query;
      auto sub_query =
          std::make_shared<clu::SubQuery>(response->normalized_query);
      sub_query->category = frame->domain.value;
      semantic_map[frame] = sub_query;
    } else {
      cur_turn->query = semantic_map[frame]->generate_text;
    }
    // 对话管理
    response->timeline->record(response->request_id, "dm", "对话管理");
    if (dialogue_manager_->Process(cur_turn, turn_history, "default") < 0) {
      LOGE << "[" << response->request_id
                 << "]: Failed to manage dialog for query: "
                 << response->normalized_query;
      return DialogueCode::E_Error;
    }
    // dm 语义修改器
    response->timeline->record(response->request_id, "modifier-dm", "dm之后调用语义修改器");
    if (ApplySemanticsModifiers(semantic_modifiers_, cur_turn) < 0) {
      LOGE << "[" << response->request_id
                 << "]: Failed to apply modifiers";
    }
    auto result =
        GetResultJsonForZP(*cur_turn, *semantic_map[frame], &vad_status);
    results.append(result);
  }
  CleanFrames(&cur_turn->frames);
  cur_turn->frames.insert(cur_turn->frames.begin(), frames.begin(),
                          frames.end());
  if (response->debug) {
    response->debug_info.dm_info = cur_turn->Serialize();
    response->debug_info.dispatch_info = debug_dispatch_info;
  }
  if (!response->stream) {
    response->is_multi_intent = frames.size() > 1;
    if (results.size() == 1 &&
        results[0]["Nlu"]["Domain"].asString() == kDomainOther) {
      response->is_multi_intent = false;
      results[0]["SubQuery"] = response->normalized_query;
    }
  }
  response->timeline->record(response->request_id, "build-result-json", "构造最终的json结果");
  BuildSemanticJson(results, response->original_query, vad_status,
                    response->is_multi_intent, &response->semantic_json);
  CleanFrames(&frames);
  if (response->stream) {
    auto content = JsonHelper::ToString(response->ToJson());
    response->stream_content->ProduceMessage(content);
    if (response->debug) {
      response->debug = false;
      content = JsonHelper::ToString(response->ToJson());
      LOGI << "[" << response->request_id << "]: Send chunk: " << content;
      response->debug = true;
    } else {
      LOGI << "[" << response->request_id << "]: Send chunk: " << content;
    }
  }
  return 0;
}

int Dialogue::StreamConversion(const std::vector<dialog::Turn *> &history,
                               dialog::Turn *cur_turn,
                               DialogueResponse *response) const {
  assert(response);
  assert(cur_turn);
  if (QueryRejection(response) < 0) {
    return -1;
  }
  clu::MessageQueue<std::shared_ptr<clu::SubQuery>> query_queue;
  auto qs_code = thread_pool_->Submit(
      std::bind(&Dialogue::StreamSegmentQuery, this, response, &query_queue));
  std::vector<std::pair<std::future<int>, std::shared_ptr<dialog::Turn>>>
      results;
  std::vector<std::shared_ptr<DialogueResponse>> response_list;
  std::mutex mutex;
  bool is_breaked = false;
  while (!query_queue.IsStop()) {
    std::shared_ptr<clu::SubQuery> sub_query = nullptr;
    try {
      sub_query = query_queue.ConsumeMessage();
    } catch (std::runtime_error) {
      if (response_list.empty()) {
        // 分句报错，返回拒识
        sub_query = std::make_shared<clu::SubQuery>(response->normalized_query);
        sub_query->index = 1;
        sub_query->is_last = true;
        is_breaked = true;
      } else {
        break;
      }
    }
    std::lock_guard<std::mutex> lock(mutex);
    auto new_turn = std::make_shared<dialog::Turn>(*cur_turn);
    new_turn->query = sub_query->generate_text;
    response->sub_queries.push_back(sub_query);
    response->is_multi_intent = !(sub_query->index == 1 && sub_query->is_last);
    auto new_response = std::make_shared<DialogueResponse>(*response);
    new_response->sub_queries = {sub_query};
    response_list.push_back(new_response);
    auto pq_code =
        thread_pool_->Submit(std::bind(&Dialogue::ProcessQueries, this, history,
                                       new_turn.get(), new_response.get()));
    results.emplace_back(
        std::make_pair(std::move(pq_code), std::move(new_turn)));
    if (is_breaked) {
      break;
    }
  }

  cur_turn->active_tasks.clear();
  for (auto &item : results) {
    if (item.first.get() < 0) {
      LOGE << "[" << response->request_id
                 << "]: Failed to invoke ProcessQueries.";
      break;
    }
    MergeTurns(item.second, cur_turn);
  }
  response->stream_content->WaitForStop();
  StoreSubQueries(*response, context_manager_);
  LOGI << "[" << response->request_id
            << "]: Active task size: " << cur_turn->active_tasks.size();
  Json::Value semantic_results(Json::arrayValue);
  for (auto &res : response_list) {
    semantic_results.append(res->semantic_json);
  }
  response->semantic_json = semantic_results;
  if (StoreQueries(query_history_size_, context_manager_, response) < 0) {
    LOGE << "[" << response->request_id << "] Failed to store queries.";
    return -1;
  }
  // 保证最后一次response销毁才删除request_id
  for (auto &res : response_list) {
    res->timeline = nullptr;
  }
  return 0;
}

int Dialogue::SynchronousConversation(
    const std::vector<dialog::Turn *> &history, dialog::Turn *cur_turn,
    DialogueResponse *response) const {
  assert(response);
  assert(cur_turn);
  if (QueryRejection(response) < 0) {
    return -1;
  }
  clu::CreMatcher::CreQuery cre_query{response->request_id,
                                      response->original_query};
  auto sub_query =
        std::make_shared<clu::SubQuery>(response->normalized_query);
  if (query_guard_ && !response->rejection_result.isRjected() &&
      query_guard_->IsOk(cre_query, &sub_query->extra_slots)) {
    sub_query->request_id = response->request_id;
    sub_query->is_sensitive = true;
    sub_query->is_last = true;
    sub_query->category = kDomainSensitive;
    response->sub_queries.push_back(std::move(sub_query));
    LOGI << "[" << response->request_id
              << "]: detected query is sensitive, category changed to "
                 "sensitive.";
  } else if (!response->rejection_result.isRjected() &&
             !response->rejection_result.isSemanticClear()) {
    if (GetQuerySegmentCache(response->request_id, context_manager_,
                             response->normalized_query,
                             &response->sub_queries) > 0) {
      // 大模型分句
      response->timeline->record(response->request_id, "rewrite", "调用分句改写模块");
      auto qs_code = qs_manager_->Process(response->query_histories,
                                          &response->sub_queries);
      if (qs_code < 0) {
        LOGE << "[" << response->request_id
                   << "]: Failed to process query-segmentation in clu.";
        return DialogueCode::E_Error;
      }
      CacheQuerySegment(context_manager_, response->normalized_query,
                        response->sub_queries);
      for (auto &sub_q : response->sub_queries) {
        // 拒识后将query改成原始query
        if (sub_q->is_rejected) {
          sub_q->generate_text = response->normalized_query;
        }
      }
    }
  } else {
    sub_query->request_id = response->request_id;
    sub_query->is_rejected = response->rejection_result.isRjected();
    sub_query->is_last = true;
    response->sub_queries.push_back(std::move(sub_query));
  }
  if (ProcessQueries(history, cur_turn, response) < 0) {
    LOGE << "[" << response->request_id
               << "]: Failed to process queries.";
    return DialogueCode::E_Error;
  }
  StoreSubQueries(*response, context_manager_);
  if (StoreQueries(query_history_size_, context_manager_, response) < 0) {
    LOGE << "[" << response->request_id << "] Failed to store queries.";
    return -1;
  }
  return DialogueCode::Success;
}

int Dialogue::GetHotQueryCache(DialogueResponse *response,
                               dialog::Turn *turn) const {
  assert(response);
  if (hot_queries_cache_->GetCache(response) <= 0) {
    LOGI << "[" << response->request_id
              << "]: Failed to get hot query cache.";
    return 0;
  }
  auto results = JsonHelper::ResolveJPath(response->semantic_json, "Results");
  for (auto &item : results) {
    auto p_frame = new nlu::SemanticFrame();
    auto domain = JsonHelper::ResolveJPath<std::string>(item, "Nlu.Domain", "");
    p_frame->domain = {domain, 1.0f};
    auto intent = JsonHelper::ResolveJPath<std::string>(item, "Nlu.Intent", "");
    p_frame->intents.emplace_back(intent, 1.0f);
    auto slot_objs = JsonHelper::ResolveJPath(item, "Nlu.Slots");
    for (auto &slot_obj : slot_objs) {
      auto slot_name =
          JsonHelper::ResolveJPath<std::string>(slot_obj, "Name", "");
      auto slot_value =
          JsonHelper::ResolveJPath<std::string>(slot_obj, "Value", "");
      auto p_slot = new nlu::Slot(slot_name, slot_value);
      p_frame->slots.Add(p_slot);
    }
    turn->frames.push_back(p_frame);
  }
  LOGI << "[" << response->request_id << "]: Get hot query cache.";
  if (response->stream) {
    std::string chunk = JsonHelper::ToString(response->ToJson());
    response->stream_content->ProduceMessage(chunk);
    LOGI << "[" << response->request_id << "]: send chunk: " << chunk;
    response->stream_content->WaitForStop();
  }
  if (StoreQueries(query_history_size_, context_manager_, response) < 0) {
    LOGE << "[" << response->request_id << "]: Failed to store queries.";
    return -1;
  }
  return 1;
}

int Dialogue::ReInitialize() {
  Destruction();
  return Initialize(config_file_);
}

void Dialogue::Destruction() {
  valid_.store(false);
  for (auto &p : semantic_modifiers_) {
    delete p;
  }
  semantic_modifiers_.clear();
  delete normalizer_;
}

Dialogue DialogueInstance::instance_;

bool DialogueInstance::Initialize(const std::string &config) {
  Dialogue::Initialize();
  instance_.Initialize(config);

  return instance_.Valid();
}

const Dialogue &DialogueInstance::Get() { return instance_; }

}  // namespace nlptk
