// Copyright 2023 the NLPTK project authors. All Rights Reserved.
// Author: daigd

#include "simple_thread_pool.h"

#include <future>
#include <utility>

#include "base/logging.h"

namespace nlptk {
namespace utils {

SimpleThreadPool::SimpleThreadPool(uint pool_size) : pool_size_(pool_size), stop_(false) {
  static const size_t max_count = std::thread::hardware_concurrency();
  if (pool_size_ >= max_count) {
    pool_size_ = max_count;
  }
  for (auto i = 0; i < pool_size_; ++i) {
    threads_.emplace_back([this] {
      for (;;) {
        std::function<void()> task;
        {
          std::unique_lock<std::mutex> lock(this->mutex_);
          this->cv_.wait(
              lock, [this] { return this->stop_ || !this->tasks_.empty(); });
          if (this->stop_ && this->tasks_.empty()) {
            return;
          }
          task = std::move(this->tasks_.front());
          this->tasks_.pop();
        }
        task();
      }
    });
  }
}

SimpleThreadPool::~SimpleThreadPool() {
  {
    std::unique_lock<std::mutex> lock(mutex_);
    stop_ = true;
  }
  cv_.notify_all();
  for (std::thread &worker : threads_) {
    worker.join();
  }
}

}  // namespace utils
}  // namespace nlptk
