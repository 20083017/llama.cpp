// Copyright 2023 the NLPTK project authors. All Rights Reserved.
// Author: daigd

#ifndef UTILS_SIMPLE_THREAD_POOL_H_
#define UTILS_SIMPLE_THREAD_POOL_H_

#include <functional>
#include <atomic>
#include <condition_variable>
#include <future>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>
#include <utility>
#include <memory>

namespace nlptk {
namespace utils {

class SimpleThreadPool {
 public:
  explicit SimpleThreadPool(uint pool_size);
  SimpleThreadPool(const SimpleThreadPool &) = delete;
  SimpleThreadPool(SimpleThreadPool &&) = delete;
  SimpleThreadPool &operator=(const SimpleThreadPool &) = delete;
  SimpleThreadPool &operator=(SimpleThreadPool &&) = delete;
  ~SimpleThreadPool();
  inline size_t ActiveTaskSize() const { return tasks_.size(); }

 public:
  template <class F, class... Args>
  auto Submit(F &&f, Args &&...args) -> std::future<decltype(f(args...))> {
    using return_type = decltype(f(args...));
    auto task = std::make_shared<std::packaged_task<return_type()>>(
        std::bind(std::forward<F>(f), std::forward<Args>(args)...));
    {
      std::unique_lock<std::mutex> lock(mutex_);
      tasks_.emplace([task]() { (*task)(); });
    }
    cv_.notify_one();
    return task->get_future();
  }

 private:
  uint                              pool_size_;
  std::mutex                        mutex_;
  std::condition_variable           cv_;
  std::queue<std::function<void()>> tasks_;
  std::vector<std::thread>          threads_;
  std::atomic<bool>                 stop_;
};

}  // namespace utils
}  // namespace nlptk

#endif  // UTILS_SIMPLE_THREAD_POOL_H_
