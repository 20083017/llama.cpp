import os, sys, pathlib, subprocess, shlex, json, base64, datetime, hashlib
root=pathlib.Path('D:/project/new_wtp184_dialogue/.claude/tmp/PLAN-20261016-nlu06b-config-driven-syntax')
packet=root/('v2-phase1-'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S'))
packet.mkdir(exist_ok=False)
log=(packet/'operation.log').open('w',encoding='utf-8')
def emit(s):
 print(s,flush=True);log.write(s+'\n');log.flush()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def run(args,**kw):return subprocess.run(args,capture_output=True,timeout=kw.pop('timeout',15),**kw)
ssh=os.environ['PHASE1_SSH_EXE'];keygen=os.environ['PHASE1_KEYGEN_EXE'];cygpath=os.environ['PHASE1_CYGPATH_EXE']
alias='new2_wtp184-server'
files=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc']
try:
 need(not any(os.environ.get(k) for k in ['WTP184_SSH_HOST','WTP184_SSH_USER','WTP184_SSH_KEY','WTP184_SSH_KNOWN_HOSTS']),'Explicit override present; no alias fallback')
 r=run([ssh,'-G',alias]);emit('ssh -G new2_wtp184-server EXIT '+str(r.returncode));need(r.returncode==0,'Alias resolution failed')
 wanted=['hostname','user','port','identitiesonly','identityfile','userknownhostsfile','globalknownhostsfile','hostkeyalias','proxyjump','proxycommand','canonicalizehostname']
 cfg={}
 for line in r.stdout.decode().splitlines():
  k,_,v=line.partition(' ')
  if k in wanted:cfg.setdefault(k,[]).append(v)
 for k,v in [('hostname','10.1.120.40'),('user','daigd'),('port','22'),('identitiesonly','yes')]:need(cfg.get(k)==[v],'Alias mismatch: '+k)
 for k in ['proxyjump','proxycommand','hostkeyalias']:need(cfg.get(k,['none'])==['none'],'Unexpected '+k)
 need(cfg.get('canonicalizehostname',['false'])[0] in ['false','no'],'Hostname canonicalization enabled')
 def paths(v):
  lexer=shlex.shlex(v,posix=True);lexer.whitespace_split=True;lexer.commenters='';lexer.escape=''
  return list(lexer)
 identities=[]
 for v in cfg.get('identityfile',[]):
  # Each IdentityFile line is one path; preserve embedded spaces.
  if len(v)>=2 and v[0]==v[-1] and v[0] in ['"', "'"]:v=v[1:-1]
  identities.append(v)
 known=[(kind,i,p) for kind in ['userknownhostsfile','globalknownhostsfile'] for i,p in enumerate([p for v in cfg.get(kind,[]) for p in paths(v)],1) if p!='none']
 need(identities and known,'Missing configured identity/trust mechanisms')
 def native(p,category):
  if p=='~' or p.startswith('~/'):
   home=os.environ.get('HOME');need(bool(home),category+' tilde expansion: HOME absent')
   p=home.rstrip('/')+p[1:]
  need(not p.startswith('~') and '%' not in p,category+' unresolved path expansion')
  r=run([cygpath,'-w',p]);need(r.returncode==0,category+' cygpath conversion failed exit='+str(r.returncode))
  n=r.stdout.decode().strip();need(bool(n),category+' empty converted path')
  return n
 for i,p in enumerate(identities,1):
  category='identity['+str(i)+']';n=native(p,category)
  exists=pathlib.Path(n).is_file();readable=exists and os.access(n,os.R_OK)
  emit(category+' native_file='+str(exists)+' readable='+str(readable)+' conversion=cygpath-w')
  need(readable,category+' required configured identity absent/nonregular/unreadable')
 count=0;readable_known=0
 for kind,i,p in known:
  category=kind+'['+str(i)+']';n=native(p,category)
  exists=pathlib.Path(n).exists();regular=pathlib.Path(n).is_file();readable=regular and os.access(n,os.R_OK)
  emit(category+' basename='+pathlib.Path(n).name+' native_exists='+str(exists)+' readable='+str(readable)+' conversion=cygpath-w')
  if not exists:
   emit(category+' OPTIONAL_ABSENT skipped; no trust/config mutation');continue
  need(readable,category+' existing configured trust file nonregular/unreadable')
  readable_known+=1
  r=run([keygen,'-F','10.1.120.40','-f',n]);need(r.returncode in [0,1],category+' known-host lookup failed exit='+str(r.returncode))
  lines=[x for x in r.stdout.decode().splitlines() if x and not x.startswith('#')]
  need(not any(x.startswith('@revoked') for x in lines),category+' revoked destination key')
  matches=[x for x in lines if not x.startswith('@')]
  count+=len(matches);emit(category+' bare_HostName_trusted_matches='+str(len(matches)))
 need(readable_known>0 and count==2,'Pinned trust mismatch: expected two existing bare-HostName matches; found='+str(count))
 emit('CONTRACT PASS Ubuntu new2_wtp184-server -> daigd@10.1.120.40:22; configured readable identities; existing trust matches=2; no HostKeyAlias/proxy; no trust/config mutation')
 opts=['-T']
 for option in ['BatchMode=yes','StrictHostKeyChecking=yes','UpdateHostKeys=no','IdentitiesOnly=yes','IdentityAgent=none','PasswordAuthentication=no','KbdInteractiveAuthentication=no','PreferredAuthentications=publickey','ForwardAgent=no','ForwardX11=no','ClearAllForwardings=yes','RequestTTY=no','ControlMaster=no','ControlPath=none','ControlPersist=no','ConnectTimeout=10','ConnectionAttempts=1','ServerAliveInterval=10','ServerAliveCountMax=2','ProxyJump=none','ProxyCommand=none','CanonicalizeHostname=no']:opts+=['-o',option]
 def remote(label,code,payload=b'',bound=60):
  compile(code,'<'+label+'>','exec')
  (packet/(label+'-command.py')).write_text(code,encoding='utf-8')
  cmd='timeout --kill-after=5s '+str(bound)+'s python3 -I -c '+shlex.quote(code)
  r=run([ssh]+opts+[alias,cmd],input=payload,timeout=bound+25)
  emit(label+' SSH/REMOTE EXIT '+str(r.returncode))
  if r.stderr:emit(r.stderr.decode(errors='replace')[:3000])
  if r.returncode:emit(r.stdout.decode(errors='replace')[-3000:])
  need(r.returncode==0,label+' failed; see retained packet');return r.stdout
 prior=root.parent/'PLAN-20261016-nlu06b-multi-query-history'/'v2-work'
 observer='cu/v3_linux_offline_test.cc'
 patch=(root/'syntax-v2.patch').read_bytes()
 need(len(patch)==50835 and len(patch.splitlines())==1021,'Owner patch size/line drift')
 need([x[4:].decode() for x in patch.splitlines() if x.startswith(b'--- ')]==['a/'+f for f in files],'Old patch scope mismatch')
 need([x[4:].decode() for x in patch.splitlines() if x.startswith(b'+++ ')]==['b/'+f for f in files],'New patch scope mismatch')
 tx='/home/daigd/.wtp184-transactions/PLAN-20261016-nlu06b-config-driven-syntax-v2-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 emit('TRANSACTION '+tx)
 common=r'''import os,sys,json,base64,pathlib,subprocess,stat,shutil,hashlib
P=pathlib.Path('/home/daigd/dialogue')
F=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc']
O='cu/v3_linux_offline_test.cc'
H='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert P.resolve(strict=True)==P, 'Project path mismatch'
for f in F+[O]:
 p=P/f
 assert not p.is_symlink() and p.resolve(strict=True)==p and p.is_file(), 'Product path escape/nonregular'
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_EXTERNAL_DIFF='')
G=['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-C',str(P)]
def git(args):
 r=subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==0, r.stderr.decode(errors='replace')
 assert len(r.stdout)<=1048576, 'Scoped output bound exceeded'
 return r.stdout
assert git(['rev-parse','HEAD']).decode().strip()==H, 'HEAD drift'
assert git(['symbolic-ref','--short','HEAD']).decode().strip()=='feat/v3-nlu-linux', 'Branch drift'
def metadata(p):
 s=p.stat();return [s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
'''
 common+='T=pathlib.Path('+repr(tx)+')\n'
 stagecode=common+'PATCH_SHA='+repr(hashlib.sha256(patch).hexdigest())+'\n'+r'''assert T.parent==pathlib.Path('/home/daigd/.wtp184-transactions')
assert T.name.startswith('PLAN-20261016-nlu06b-config-driven-syntax-v2-') and len(T.name)==len('PLAN-20261016-nlu06b-config-driven-syntax-v2-20261016T000000Z')
S=git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()
assert S==''.join(' M '+f+'\n' for f in F+[O]), 'Scoped baseline drift: '+S
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O]), 'Unexpected staged baseline'
b=sys.stdin.buffer.read(50836);assert len(b)==50835 and len(b.splitlines())==1021, 'Patch size mismatch'
assert hashlib.sha256(b).hexdigest()==PATCH_SHA, 'Patch transfer integrity mismatch'
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'--- ')]==['a/'+f for f in F]
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'+++ ')]==['b/'+f for f in F]
os.umask(0o077)
T.parent.mkdir(mode=0o700,exist_ok=True)
assert T.parent.resolve(strict=True)==T.parent and not T.exists(), 'Transaction escape/collision'
T.mkdir(mode=0o700);assert T.resolve(strict=True)==T
(T/'syntax-v2.patch').write_bytes(b)
D={};M={}
for f in F:
 p=P/f;original=p.read_bytes();M[f]=metadata(p)
 q=T/'preimages'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(p),str(q))
 assert q.read_bytes()==original and metadata(q)==M[f], 'Backup bytes/metadata mismatch'
 D[f]=base64.b64encode(original).decode()
M[O]=metadata(P/O)
(T/'preimage-metadata.json').write_text(json.dumps(M))
print(json.dumps({'head':H,'branch':'feat/v3-nlu-linux','preimages':D,'observer':base64.b64encode((P/O).read_bytes()).decode(),'metadata':M,'status':S,'numstat':git(['diff','--no-ext-diff','--no-textconv','--numstat','--']+F+[O]).decode(),'patch_sha256':PATCH_SHA}))
'''
 pre=json.loads(remote('01-stage-and-preimage',stagecode,patch,60))
 emit('BASELINE '+pre['branch']+' HEAD '+pre['head'])
 emit('BASELINE SCOPED STATUS\n'+pre['status'].rstrip())
 emit('BASELINE NUMSTAT (relative to HEAD)\n'+pre['numstat'].rstrip())
 emit('PATCH TRANSFER SHA256 MATCH '+pre['patch_sha256'])
 for f in files:
  need(base64.b64decode(pre['preimages'][f])==(prior/f).read_bytes(),'Current authoritative preimage differs from prior applied postimage: '+f)
  emit('PREIMAGE BYTE EQUALITY PASS prior APPLIED v2-work '+f)
 need(base64.b64decode(pre['observer'])==(prior/observer).read_bytes(),'Prior offline-test delta mismatch; preserve and return to owner')
 emit('PRIOR OFFLINE TEST BYTE EQUALITY PASS; read-only observer')
 applycode=common+r'''assert T.resolve(strict=True)==T, 'Transaction escape'
M=json.loads((T/'preimage-metadata.json').read_text())
assert git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()==''.join(' M '+f+'\n' for f in F+[O]), 'Scoped status drift before apply'
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O]), 'Staged drift before apply'
for f in F:
 assert (P/f).read_bytes()==(T/'preimages'/f).read_bytes(), 'Immediate preimage byte drift: '+f
 assert metadata(P/f)==M[f] and metadata(T/'preimages'/f)==M[f], 'Immediate metadata drift'
print('IMMEDIATE TWO-FILE PREIMAGE BYTE EQUALITY PASS against reconciled backups')
assert metadata(P/O)==M[O], 'Observer metadata drift'
offline_before=(P/O).read_bytes()
patch=T/'syntax-v2.patch'
def patchrun(dry):
 args=['patch','--batch','--forward','--fuzz=0','--no-backup-if-mismatch','--reject-file='+str(T/'patch-rejects.txt'),'-p1','-i',str(patch)]
 if dry:args.insert(1,'--dry-run')
 r=subprocess.run(args,cwd=str(P),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 text=r.stdout.decode(errors='replace');name='dry-run' if dry else 'apply'
 print(name+' EXIT '+str(r.returncode));print(text,end='')
 assert r.returncode==0, name+' failed; content correction belongs to owner'
 assert 'offset' not in text.lower() and 'fuzz' not in text.lower(), 'Nonexact patch locations; return to owner'
patchrun(True)
for f in F:assert (P/f).read_bytes()==(T/'preimages'/f).read_bytes(), 'Preimage drift after dry-run'
patchrun(False)
for f in F:assert metadata(P/f)==M[f], 'Product metadata changed'
assert (P/O).read_bytes()==offline_before and metadata(P/O)==M[O], 'Prior offline-test edit changed'
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O]), 'Unexpected staged delta'
S=git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()
assert S==''.join(' M '+f+'\n' for f in F+[O]), 'Unexpected scoped status'
ws=subprocess.run(G+['diff','--no-ext-diff','--no-textconv','--check','--']+F,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
print('WHITESPACE AUDIT VS HEAD EXIT '+str(ws.returncode));print(ws.stdout.decode(errors='replace'),end='')
assert ws.returncode==0, 'Whitespace audit failed; owner correction required'
for f in F:
 r=subprocess.run(['git','--no-pager','-c','core.fsmonitor=false','-c','core.pager=cat','diff','--no-index','--no-ext-diff','--no-textconv','--check','--',str(T/'preimages'/f),str(P/f)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
 print('NEW DELTA WHITESPACE '+f+' EXIT '+str(r.returncode));print(r.stdout.decode(errors='replace'),end='')
 assert r.returncode in [0,1] and not r.stdout, 'New delta whitespace audit failed; owner correction required'
print('FINAL SCOPED STATUS\n'+S,end='')
for label,args in [('CUMULATIVE STAT VS HEAD',['diff','--no-ext-diff','--no-textconv','--stat','--']+F+[O]),('CUMULATIVE NUMSTAT VS HEAD',['diff','--no-ext-diff','--no-textconv','--numstat','--']+F+[O])]:
 print(label+'\n'+git(args).decode(),end='')
print('PRIOR OFFLINE TEST BYTES/METADATA PRESERVED; TWO PRODUCT METADATA PRESERVED; SCOPED STAGED DIFF EMPTY; HEAD/BRANCH UNCHANGED')
'''
 emit(remote('02-apply-and-audit',applycode,b'',90).decode(errors='replace'))
 postcode=common+r'''assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O])
D={};N={}
for f in F:
 D[f]=base64.b64encode((P/f).read_bytes()).decode()
 r=subprocess.run(['git','--no-pager','-c','core.fsmonitor=false','-c','core.pager=cat','diff','--no-index','--no-ext-diff','--no-textconv','--numstat','--',str(T/'preimages'/f),str(P/f)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==1, 'Expected scoped content delta absent/diff error'
 N[f]=r.stdout.decode().split('\t',2)[:2]
print(json.dumps({'head':H,'branch':'feat/v3-nlu-linux','postimages':D,'observer':base64.b64encode((P/O).read_bytes()).decode(),'metadata':{f:metadata(P/f) for f in F+[O]},'new_delta_numstat':N,'status':git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()}))
'''
 post=json.loads(remote('03-postimage',postcode))
 for f,stats,size in zip(files,[['102','71'],['629','22']],[83204,207622]):
  b=base64.b64decode(post['postimages'][f])
  need(b==(root/'v2-work'/f).read_bytes(),'Applied postimage differs from sole content owner: '+f)
  need(len(b)==size,'Postimage size drift: '+f)
  need(post['new_delta_numstat'][f]==stats,'New delta stats mismatch: '+f)
  need(post['metadata'][f]==pre['metadata'][f],'File metadata changed: '+f)
  emit('POSTIMAGE BYTE EQUALITY PASS '+f+' bytes='+str(len(b))+' new_delta=+'+stats[0]+'/-'+stats[1])
 need(post['observer']==pre['observer'] and post['metadata'][observer]==pre['metadata'][observer],'Prior offline-test bytes/metadata changed')
 need(post['status']==pre['status'],'Scoped status changed unexpectedly')
 emit('PRIOR THREE-FILE INTENTIONAL DIRTY DELTA RETAINED; OFFLINE TEST EXACT BYTES/METADATA UNCHANGED')
 emit('PASS Phase1 exact two-file owner patch applied; no builds/tests/Git mutation/runtime/config/deployment actions')
except Exception as e:
 emit('FAIL '+str(e));sys.exit(1)
finally:
 emit('LOCAL EVIDENCE PACKET '+str(packet));log.close()
