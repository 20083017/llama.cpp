set -euo pipefail
log=/home/daigd/wtp184-validation-logs/PLAN-20261016-nlu06b-config-driven-syntax-v2-native.log
python3 -I - "$log" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); lines=p.read_text(errors='replace').splitlines()
print('FIRST FAILED ASSERTIONS (at most 20 log lines)')
count=0
for i,l in enumerate(lines):
 if ': Failure' in l or ': error: Failure' in l:
  start=i
  for j in range(i,min(i+12,len(lines))):
   if j>i and (lines[j].startswith('E2026') or lines[j].startswith('[  FAILED  ]') or lines[j].startswith('[ RUN') or ': Failure' in lines[j]):break
   if count>=20:break
   print(str(j+1)+':'+lines[j]);count+=1
 if count>=20:break
print('AUTHORITATIVE_LOG_BYTES='+str(p.stat().st_size))
PY
