set -euo pipefail
python3 -I - <<'PY'
from pathlib import Path
p=Path('/home/daigd/wtp184-validation-logs/PLAN-20261016-nlu06b-config-driven-syntax-v2-native.log')
a=p.read_text(errors='replace').splitlines()
active=False
for i,l in enumerate(a):
 if l.startswith('[ RUN') and 'ProfileV10MalformedContentNeverReturnsPartialFrames' in l:active=True
 if active and ':3874:' in l:print('FIRST_TEST_TRACE '+str(i+1)+':'+l)
 if active and l.startswith('[  FAILED'):active=False
start=next(i for i,l in enumerate(a) if l.startswith('[ RUN') and 'SelectedProtocolFilenameDoesNotSelectLayout' in l)
block=a[start:next(i+1 for i in range(start,len(a)) if a[i].startswith('[  FAILED'))]
fails=[start+j for j,l in enumerate(block) if ': Failure' in l]
print('SECOND_TEST_ASSERTIONS')
printed=0
for i in fails:
 for j in range(i,min(i+11,len(a))):
  if j>i and (a[j].startswith('E2026') or a[j].startswith('[  FAILED') or ': Failure' in a[j]):break
  if printed>=20:break
  print(str(j+1)+':'+a[j]);printed+=1
 if printed>=20:break
PY
