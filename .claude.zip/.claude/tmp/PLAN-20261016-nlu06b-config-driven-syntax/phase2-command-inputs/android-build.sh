set -euo pipefail
printf 'ACTION=android_v3_debug_build ROLE=Ubuntu-build/package-only\n'
printf 'COMMAND=LC_ALL=C PROJECT_DIR=$HOME/dialogue THIRD_PARTY_DIR=$HOME/dialogue/third_party timeout --kill-after=15s 1800s /bin/bash --noprofile --norc $HOME/cu-dev-pipeline-v18-android-dialogue-api.sh android_v3_debug_build --android-ndk $HOME/workspaces/android-ndk-r20b --android-abi arm64-v8a --android-api 21 --message "PLAN-20261016 config-driven syntax Android V3 validation"\n'
set +e
LC_ALL=C PROJECT_DIR="$HOME/dialogue" THIRD_PARTY_DIR="$HOME/dialogue/third_party" timeout --kill-after=15s 1800s /bin/bash --noprofile --norc "$HOME/cu-dev-pipeline-v18-android-dialogue-api.sh" android_v3_debug_build --android-ndk "$HOME/workspaces/android-ndk-r20b" --android-abi arm64-v8a --android-api 21 --message 'PLAN-20261016 config-driven syntax Android V3 validation' 2>&1 | awk '
 /LOG_FILE=|log_file=|log=|build_log=|BUILD_LOG|ANDROID_|artifact=|metadata=|sha256=|size=|latest=|latest_pointer=|dialogue_pipeline_v3|ERROR|error:|FAILED|Build completed|Elapsed time|^Target |^INFO: [0-9]+ processes/ { if (n++<180) print; fflush(); }
'
status=${PIPESTATUS[0]}
set -e
printf 'ANDROID_PIPELINE_EXIT=%s\n' "$status"
exit "$status"
