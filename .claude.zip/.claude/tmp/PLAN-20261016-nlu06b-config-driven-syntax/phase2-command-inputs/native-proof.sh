set -euo pipefail
log=/home/daigd/wtp184-validation-logs/PLAN-20261016-nlu06b-config-driven-syntax-v2-native.log
printf 'ACTUAL COMPILE ACTIONS (bounded excerpts)\n'
python3 -I - "$log" <<'PY'
import sys,re
from pathlib import Path
s=Path(sys.argv[1]).read_text(errors='replace')
lines=s.splitlines()
for source in ['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc']:
    print('SOURCE='+source)
    matches=[]
    for i,line in enumerate(lines):
        if source in line and ' -c ' in line:
            matches.append((i,line))
    if not matches:
        raise SystemExit('MISSING_ACTION '+source)
    for i,line in matches[:1]:
        print('ACTION_LOG_LINE='+str(i+1))
        print('\n'.join(lines[max(0,i-7):i]))
        for pattern in [r'/[^\s\x27]*gcc[^\s\x27]*',r'-std=[^\s\x27]+',r'-D[^\s\x27]*DIALOGUE_PIPELINE_V3[^\s\x27]*',r'[^\s\x27]*'+re.escape(source)]:
            print('ACTION_EXTRACT '+ ' '.join(re.findall(pattern,line)))
        if '/home/daigd/tools/wtp184-gcc493-sysroot/bin/gcc' not in line or '-std=c++11' not in line:
            raise SystemExit('ACTION_COMPILER_OR_CXX11_MISMATCH '+source)
print('COMPILE_ACTION_PROOF=PASS')
PY
