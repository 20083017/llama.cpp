import os,sys,json,base64,pathlib,subprocess,stat,shutil,hashlib
P=pathlib.Path('/home/daigd/dialogue')
F=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc']
O='cu/v3_linux_offline_test.cc'
H='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert P.resolve(strict=True)==P, 'Project path mismatch'
for f in F+[O]:
 p=P/f
 assert not p.is_symlink() and p.resolve(strict=True)==p and p.is_file(), 'Product path escape/nonregular'
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_EXTERNAL_DIFF='')
G=['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-C',str(P)]
def git(args):
 r=subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==0, r.stderr.decode(errors='replace')
 assert len(r.stdout)<=1048576, 'Scoped output bound exceeded'
 return r.stdout
assert git(['rev-parse','HEAD']).decode().strip()==H, 'HEAD drift'
assert git(['symbolic-ref','--short','HEAD']).decode().strip()=='feat/v3-nlu-linux', 'Branch drift'
def metadata(p):
 s=p.stat();return [s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
T=pathlib.Path('/home/daigd/.wtp184-transactions/PLAN-20261016-nlu06b-config-driven-syntax-v2-20261016T074742Z')
assert T.resolve(strict=True)==T, 'Transaction escape'
M=json.loads((T/'preimage-metadata.json').read_text())
assert git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()==''.join(' M '+f+'\n' for f in F+[O]), 'Scoped status drift before apply'
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O]), 'Staged drift before apply'
for f in F:
 assert (P/f).read_bytes()==(T/'preimages'/f).read_bytes(), 'Immediate preimage byte drift: '+f
 assert metadata(P/f)==M[f] and metadata(T/'preimages'/f)==M[f], 'Immediate metadata drift'
print('IMMEDIATE TWO-FILE PREIMAGE BYTE EQUALITY PASS against reconciled backups')
assert metadata(P/O)==M[O], 'Observer metadata drift'
offline_before=(P/O).read_bytes()
patch=T/'syntax-v2.patch'
def patchrun(dry):
 args=['patch','--batch','--forward','--fuzz=0','--no-backup-if-mismatch','--reject-file='+str(T/'patch-rejects.txt'),'-p1','-i',str(patch)]
 if dry:args.insert(1,'--dry-run')
 r=subprocess.run(args,cwd=str(P),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 text=r.stdout.decode(errors='replace');name='dry-run' if dry else 'apply'
 print(name+' EXIT '+str(r.returncode));print(text,end='')
 assert r.returncode==0, name+' failed; content correction belongs to owner'
 assert 'offset' not in text.lower() and 'fuzz' not in text.lower(), 'Nonexact patch locations; return to owner'
patchrun(True)
for f in F:assert (P/f).read_bytes()==(T/'preimages'/f).read_bytes(), 'Preimage drift after dry-run'
patchrun(False)
for f in F:assert metadata(P/f)==M[f], 'Product metadata changed'
assert (P/O).read_bytes()==offline_before and metadata(P/O)==M[O], 'Prior offline-test edit changed'
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O]), 'Unexpected staged delta'
S=git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()
assert S==''.join(' M '+f+'\n' for f in F+[O]), 'Unexpected scoped status'
ws=subprocess.run(G+['diff','--no-ext-diff','--no-textconv','--check','--']+F,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
print('WHITESPACE AUDIT VS HEAD EXIT '+str(ws.returncode));print(ws.stdout.decode(errors='replace'),end='')
assert ws.returncode==0, 'Whitespace audit failed; owner correction required'
for f in F:
 r=subprocess.run(['git','--no-pager','-c','core.fsmonitor=false','-c','core.pager=cat','diff','--no-index','--no-ext-diff','--no-textconv','--check','--',str(T/'preimages'/f),str(P/f)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
 print('NEW DELTA WHITESPACE '+f+' EXIT '+str(r.returncode));print(r.stdout.decode(errors='replace'),end='')
 assert r.returncode in [0,1] and not r.stdout, 'New delta whitespace audit failed; owner correction required'
print('FINAL SCOPED STATUS\n'+S,end='')
for label,args in [('CUMULATIVE STAT VS HEAD',['diff','--no-ext-diff','--no-textconv','--stat','--']+F+[O]),('CUMULATIVE NUMSTAT VS HEAD',['diff','--no-ext-diff','--no-textconv','--numstat','--']+F+[O])]:
 print(label+'\n'+git(args).decode(),end='')
print('PRIOR OFFLINE TEST BYTES/METADATA PRESERVED; TWO PRODUCT METADATA PRESERVED; SCOPED STAGED DIFF EMPTY; HEAD/BRANCH UNCHANGED')
