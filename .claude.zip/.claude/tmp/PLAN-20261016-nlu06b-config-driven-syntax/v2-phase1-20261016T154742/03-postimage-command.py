import os,sys,json,base64,pathlib,subprocess,stat,shutil,hashlib
P=pathlib.Path('/home/daigd/dialogue')
F=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc']
O='cu/v3_linux_offline_test.cc'
H='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert P.resolve(strict=True)==P, 'Project path mismatch'
for f in F+[O]:
 p=P/f
 assert not p.is_symlink() and p.resolve(strict=True)==p and p.is_file(), 'Product path escape/nonregular'
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_EXTERNAL_DIFF='')
G=['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-C',str(P)]
def git(args):
 r=subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==0, r.stderr.decode(errors='replace')
 assert len(r.stdout)<=1048576, 'Scoped output bound exceeded'
 return r.stdout
assert git(['rev-parse','HEAD']).decode().strip()==H, 'HEAD drift'
assert git(['symbolic-ref','--short','HEAD']).decode().strip()=='feat/v3-nlu-linux', 'Branch drift'
def metadata(p):
 s=p.stat();return [s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
T=pathlib.Path('/home/daigd/.wtp184-transactions/PLAN-20261016-nlu06b-config-driven-syntax-v2-20261016T074742Z')
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O])
D={};N={}
for f in F:
 D[f]=base64.b64encode((P/f).read_bytes()).decode()
 r=subprocess.run(['git','--no-pager','-c','core.fsmonitor=false','-c','core.pager=cat','diff','--no-index','--no-ext-diff','--no-textconv','--numstat','--',str(T/'preimages'/f),str(P/f)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==1, 'Expected scoped content delta absent/diff error'
 N[f]=r.stdout.decode().split('\t',2)[:2]
print(json.dumps({'head':H,'branch':'feat/v3-nlu-linux','postimages':D,'observer':base64.b64encode((P/O).read_bytes()).decode(),'metadata':{f:metadata(P/f) for f in F+[O]},'new_delta_numstat':N,'status':git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()}))
