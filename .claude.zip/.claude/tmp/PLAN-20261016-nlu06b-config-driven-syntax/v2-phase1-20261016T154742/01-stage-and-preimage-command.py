import os,sys,json,base64,pathlib,subprocess,stat,shutil,hashlib
P=pathlib.Path('/home/daigd/dialogue')
F=['cu/nlu_0_6b_http_backend.cc','cu/nlu_0_6b_http_backend_test.cc']
O='cu/v3_linux_offline_test.cc'
H='3f086385c81509d40ccb82813758dd1d6d24c0f3'
assert P.resolve(strict=True)==P, 'Project path mismatch'
for f in F+[O]:
 p=P/f
 assert not p.is_symlink() and p.resolve(strict=True)==p and p.is_file(), 'Product path escape/nonregular'
env=os.environ.copy();env.update(GIT_OPTIONAL_LOCKS='0',GIT_PAGER='cat',PAGER='cat',GIT_EXTERNAL_DIFF='')
G=['git','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.pager=cat','-C',str(P)]
def git(args):
 r=subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 assert r.returncode==0, r.stderr.decode(errors='replace')
 assert len(r.stdout)<=1048576, 'Scoped output bound exceeded'
 return r.stdout
assert git(['rev-parse','HEAD']).decode().strip()==H, 'HEAD drift'
assert git(['symbolic-ref','--short','HEAD']).decode().strip()=='feat/v3-nlu-linux', 'Branch drift'
def metadata(p):
 s=p.stat();return [s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
T=pathlib.Path('/home/daigd/.wtp184-transactions/PLAN-20261016-nlu06b-config-driven-syntax-v2-20261016T074742Z')
PATCH_SHA='5e61a92824ea9ef056e30d2b80cf61654a018e966f716e1c4dd2648b6e077b90'
assert T.parent==pathlib.Path('/home/daigd/.wtp184-transactions')
assert T.name.startswith('PLAN-20261016-nlu06b-config-driven-syntax-v2-') and len(T.name)==len('PLAN-20261016-nlu06b-config-driven-syntax-v2-20261016T000000Z')
S=git(['status','--porcelain=v1','--untracked-files=all','--']+F+[O]).decode()
assert S==''.join(' M '+f+'\n' for f in F+[O]), 'Scoped baseline drift: '+S
assert not git(['diff','--cached','--no-ext-diff','--no-textconv','--']+F+[O]), 'Unexpected staged baseline'
b=sys.stdin.buffer.read(50836);assert len(b)==50835 and len(b.splitlines())==1021, 'Patch size mismatch'
assert hashlib.sha256(b).hexdigest()==PATCH_SHA, 'Patch transfer integrity mismatch'
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'--- ')]==['a/'+f for f in F]
assert [x[4:].decode() for x in b.splitlines() if x.startswith(b'+++ ')]==['b/'+f for f in F]
os.umask(0o077)
T.parent.mkdir(mode=0o700,exist_ok=True)
assert T.parent.resolve(strict=True)==T.parent and not T.exists(), 'Transaction escape/collision'
T.mkdir(mode=0o700);assert T.resolve(strict=True)==T
(T/'syntax-v2.patch').write_bytes(b)
D={};M={}
for f in F:
 p=P/f;original=p.read_bytes();M[f]=metadata(p)
 q=T/'preimages'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(p),str(q))
 assert q.read_bytes()==original and metadata(q)==M[f], 'Backup bytes/metadata mismatch'
 D[f]=base64.b64encode(original).decode()
M[O]=metadata(P/O)
(T/'preimage-metadata.json').write_text(json.dumps(M))
print(json.dumps({'head':H,'branch':'feat/v3-nlu-linux','preimages':D,'observer':base64.b64encode((P/O).read_bytes()).decode(),'metadata':M,'status':S,'numstat':git(['diff','--no-ext-diff','--no-textconv','--numstat','--']+F+[O]).decode(),'patch_sha256':PATCH_SHA}))
