#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compare histories replay cases against 9999 and 9530.

Compatibility:
  - Python 3.6+
  - Standard library only
  - No dataclasses, no walrus operator, no future annotations, no match/case

Replay contract:
  1. One case is replayed round-by-round in source order.
  2. A fresh session_id is generated for each case/environment run.
  3. By default ONLY payload.session_id is replaced.
  4. request_id, histories, histories[*].id, query, input_data, app_id, uid,
     sid and other source payload fields are preserved exactly.
  5. histories are NOT synthesized from the new runtime response. The script
     replays the source histories already recorded in the case JSON.
  6. 9999 and 9530 are executed independently so one environment cannot
     contaminate the other environment's session state.

Default endpoints:
  http://127.0.0.1:9999/zp/update
  http://127.0.0.1:9530/zp/update

Typical usage:
  python3 compare_histories_9999_9530_py36.py \\
    --cases history_replay_cases_c012_c015_completed.json \\
    --force-stream-false

Outputs under --out-dir:
  rounds.csv       one row per case/round with 9999 + 9530 side by side
  cases.csv        one row per case, focused on the target round
  result.json      complete structured comparison result (no raw payload body)
  raw/             only created when --save-raw is specified

Exit code:
  0 = all requests parsed and every round is core-equal between 9999/9530
  1 = at least one semantic difference or expected mismatch
  2 = input/CLI error
  3 = at least one transport/parse failure
"""

import argparse
import copy
import csv
import datetime
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid


def now_run_id():
    return "%s_%s" % (
        datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
        uuid.uuid4().hex[:6],
    )


def safe_text(value):
    if value is None:
        return ""
    return str(value)


def sanitize_filename(value, max_len=80):
    text = re.sub(r"[^0-9A-Za-z_.-]+", "_", safe_text(value))
    text = text.strip("._") or "item"
    return text[:max_len]


def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def load_cases(path, selected_case_ids):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    cases = data.get("cases") if isinstance(data, dict) else None
    if not isinstance(cases, list):
        raise ValueError("cases JSON must contain a top-level 'cases' list")

    if not selected_case_ids:
        return data, cases

    wanted = set(selected_case_ids)
    selected = []
    for case in cases:
        if case.get("case_id") in wanted:
            selected.append(case)

    missing = []
    found = set([c.get("case_id") for c in selected])
    for case_id in selected_case_ids:
        if case_id not in found:
            missing.append(case_id)
    if missing:
        raise ValueError("case_id not found: %s" % ", ".join(missing))
    return data, selected


def make_session_id(run_id, case_index, env_tag, same_session_id):
    if same_session_id:
        return "hr_%s_c%03d" % (run_id, case_index)
    return "hr_%s_c%03d_%s" % (run_id, case_index, env_tag)


def prepare_payload(round_obj, new_session_id, force_stream_false):
    payload = copy.deepcopy(round_obj.get("request_payload") or {})
    payload["session_id"] = new_session_id
    if force_stream_false:
        payload["stream"] = False
    return payload


def iter_dicts(obj):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            for child in iter_dicts(value):
                yield child
    elif isinstance(obj, list):
        for value in obj:
            for child in iter_dicts(value):
                yield child


def is_dialogue_response(obj):
    if not isinstance(obj, dict):
        return False
    header = obj.get("Header")
    payload = obj.get("Payload")
    return isinstance(header, dict) and isinstance(payload, dict) and "Semantic" in payload


def pick_dialogue_response(candidates):
    dialogue = []
    for obj in candidates:
        if is_dialogue_response(obj):
            dialogue.append(obj)
    if not dialogue:
        return None

    # Prefer an explicit stream end response when one exists.
    for obj in reversed(dialogue):
        header = obj.get("Header") or {}
        if header.get("IsEnd") is True:
            return obj
    return dialogue[-1]


def parse_json_fragment(text):
    if not isinstance(text, str):
        return None
    text = text.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass
    try:
        decoded = urllib.parse.unquote(text)
        if decoded != text:
            return json.loads(decoded)
    except Exception:
        pass
    return None


def add_candidate(obj, candidates):
    if isinstance(obj, dict):
        for item in iter_dicts(obj):
            candidates.append(item)
    elif isinstance(obj, list):
        for item in obj:
            add_candidate(item, candidates)
    elif isinstance(obj, str):
        nested = parse_json_fragment(obj)
        if nested is not None:
            add_candidate(nested, candidates)


def scan_embedded_json(text):
    decoder = json.JSONDecoder()
    candidates = []
    pos = 0
    length = len(text)
    while pos < length:
        p_obj = text.find("{", pos)
        p_arr = text.find("[", pos)
        starts = []
        if p_obj >= 0:
            starts.append(p_obj)
        if p_arr >= 0:
            starts.append(p_arr)
        if not starts:
            break
        start = min(starts)
        try:
            obj, consumed = decoder.raw_decode(text[start:])
            add_candidate(obj, candidates)
            pos = start + max(consumed, 1)
        except Exception:
            pos = start + 1
    return candidates


def parse_response_text(text):
    if text is None or not text.strip():
        return None, "empty_response"

    stripped = text.strip()
    candidates = []

    obj = parse_json_fragment(stripped)
    if obj is not None:
        add_candidate(obj, candidates)
        picked = pick_dialogue_response(candidates)
        if picked is not None:
            return picked, None
        if isinstance(obj, dict):
            return obj, None

    # SSE / NDJSON / line-framed response.
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith("data:"):
            line = line[5:].strip()
        elif lower.startswith("message:"):
            line = line[8:].strip()
        elif lower.startswith("response="):
            line = line[9:].strip()
        elif lower.startswith("response:"):
            line = line[9:].strip()
        elif lower.startswith("event:") or lower.startswith("id:") or lower.startswith("retry:"):
            continue
        if not line or line in ("[DONE]", "DONE"):
            continue
        obj = parse_json_fragment(line)
        if obj is not None:
            add_candidate(obj, candidates)

    picked = pick_dialogue_response(candidates)
    if picked is not None:
        return picked, None

    embedded = scan_embedded_json(text)
    picked = pick_dialogue_response(embedded)
    if picked is not None:
        return picked, None

    return None, "response_not_json"


def post_json(url, payload, timeout):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json, text/event-stream, */*",
        },
    )
    start = time.time()
    try:
        response = urllib.request.urlopen(request, timeout=timeout)
        try:
            status = int(response.getcode())
            raw = response.read()
            content_type = response.headers.get("Content-Type", "")
        finally:
            response.close()
    except urllib.error.HTTPError as exc:
        status = int(exc.code)
        content_type = exc.headers.get("Content-Type", "") if exc.headers else ""
        raw = exc.read()
    except Exception as exc:
        latency_ms = (time.time() - start) * 1000.0
        return {
            "http_status": 0,
            "latency_ms": latency_ms,
            "content_type": "",
            "response": None,
            "raw_text": "",
            "error": repr(exc),
        }

    latency_ms = (time.time() - start) * 1000.0
    text = raw.decode("utf-8", errors="replace")
    parsed, parse_error = parse_response_text(text)
    return {
        "http_status": status,
        "latency_ms": latency_ms,
        "content_type": content_type,
        "response": parsed,
        "raw_text": text,
        "error": parse_error,
    }


def first_semantic_obj(response_obj):
    if not isinstance(response_obj, dict):
        return {}, {}, {}, {}
    header = response_obj.get("Header") or {}
    payload = response_obj.get("Payload") or {}
    semantic = payload.get("Semantic")
    if isinstance(semantic, list):
        semantic_obj = semantic[0] if semantic and isinstance(semantic[0], dict) else {}
    elif isinstance(semantic, dict):
        semantic_obj = semantic
    else:
        semantic_obj = {}
    results = semantic_obj.get("Results") or []
    result = results[0] if results and isinstance(results[0], dict) else {}
    nlu = result.get("Nlu") or {}
    dm = result.get("Dm") or {}
    return header, semantic_obj, result, nlu if isinstance(nlu, dict) else {}


def normalize_slots(slots):
    normalized = []
    if not isinstance(slots, list):
        return normalized
    for slot in slots:
        if not isinstance(slot, dict):
            continue
        normalized.append({
            "Name": slot.get("Name"),
            "RawValue": slot.get("RawValue"),
            "Type": slot.get("Type"),
            "Value": slot.get("Value"),
        })
    normalized.sort(key=lambda x: (
        safe_text(x.get("Name")),
        safe_text(x.get("Value")),
        safe_text(x.get("RawValue")),
        safe_text(x.get("Type")),
    ))
    return normalized


def extract_semantic(response_obj):
    header, semantic, result, nlu = first_semantic_obj(response_obj)
    dm = result.get("Dm") or {}
    return {
        "header_code": header.get("Code"),
        "header_message": header.get("Message"),
        "query": semantic.get("Query"),
        "sub_query": result.get("SubQuery"),
        "domain": nlu.get("Domain"),
        "intent": nlu.get("Intent"),
        "slots": normalize_slots(nlu.get("Slots") or []),
        "is_rejected": result.get("IsRejected"),
        "dm_text": dm.get("Text") if isinstance(dm, dict) else None,
    }


def core_signature(actual):
    return (
        actual.get("domain"),
        actual.get("intent"),
    )


def semantic_signature(actual):
    return (
        actual.get("query"),
        actual.get("sub_query"),
        actual.get("domain"),
        actual.get("intent"),
        json.dumps(actual.get("slots") or [], ensure_ascii=False, sort_keys=True),
        actual.get("is_rejected"),
        actual.get("header_code"),
    )


def expected_core_match(actual, expected):
    if not isinstance(expected, dict) or not expected:
        return True
    if expected.get("domain") is not None and actual.get("domain") != expected.get("domain"):
        return False
    if expected.get("intent") is not None and actual.get("intent") != expected.get("intent"):
        return False
    return True


def expected_semantic_match(actual, expected):
    if not expected_core_match(actual, expected):
        return False
    if not isinstance(expected, dict) or not expected:
        return True

    fields = ["query", "sub_query", "is_rejected", "header_code"]
    for key in fields:
        if key in expected and expected.get(key) is not None:
            if actual.get(key) != expected.get(key):
                return False

    if "slots" in expected and expected.get("slots") is not None:
        if actual.get("slots") != normalize_slots(expected.get("slots") or []):
            return False
    return True


def run_round(url, payload, expected, timeout, expected_available=True):
    transport = post_json(url, payload, timeout)
    actual = extract_semantic(transport.get("response")) if transport.get("response") else {}
    transport_ok = (
        transport.get("error") is None
        and int(transport.get("http_status") or 0) > 0
        and isinstance(transport.get("response"), dict)
    )
    return {
        "transport_ok": transport_ok,
        "http_status": transport.get("http_status"),
        "latency_ms": round(float(transport.get("latency_ms") or 0.0), 3),
        "content_type": transport.get("content_type"),
        "error": transport.get("error"),
        "actual": actual,
        "expected_available": bool(expected_available),
        "expected_core_match": (expected_core_match(actual, expected) if transport_ok else False) if expected_available else None,
        "expected_semantic_match": (expected_semantic_match(actual, expected) if transport_ok else False) if expected_available else None,
        "raw_text": transport.get("raw_text") or "",
    }


def is_target_round(case, round_obj, round_no, round_count):
    target_request_id = case.get("target_request_id")
    source_request_id = round_obj.get("source_request_id")
    if target_request_id:
        return source_request_id == target_request_id
    return round_no == round_count


def write_csv(path, fieldnames, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def bool_text(value):
    if value is None:
        return "N/A"
    return "YES" if value else "NO"


def match_text(value):
    if value is None:
        return "N/A"
    return "OK" if value else "DIFF"


def env_csv(prefix, result):
    actual = result.get("actual") or {}
    return {
        prefix + "_http": result.get("http_status"),
        prefix + "_latency_ms": result.get("latency_ms"),
        prefix + "_transport_ok": bool_text(result.get("transport_ok")),
        prefix + "_domain": actual.get("domain"),
        prefix + "_intent": actual.get("intent"),
        prefix + "_sub_query": actual.get("sub_query"),
        prefix + "_slots": json.dumps(actual.get("slots") or [], ensure_ascii=False, sort_keys=True),
        prefix + "_rejected": actual.get("is_rejected"),
        prefix + "_expected_core": bool_text(result.get("expected_core_match")),
        prefix + "_expected_semantic": bool_text(result.get("expected_semantic_match")),
        prefix + "_error": result.get("error") or "",
    }


def save_raw(raw_dir, case_id, round_no, env_tag, raw_text):
    ensure_dir(raw_dir)
    name = "%s_r%03d_%s.txt" % (sanitize_filename(case_id), round_no, env_tag)
    path = os.path.join(raw_dir, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(raw_text or "")
    return path


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Replay histories cases and compare 9999 versus 9530 (Python 3.6 compatible)."
    )
    parser.add_argument("--cases", required=True, help="Path to history replay cases JSON")
    parser.add_argument("--url-9999", default="http://127.0.0.1:9999/zp/update")
    parser.add_argument("--url-9530", default="http://127.0.0.1:9530/zp/update")
    parser.add_argument("--case-id", action="append", help="Run only one case_id; can be repeated")
    parser.add_argument("--timeout", type=float, default=15.0, help="Per request timeout seconds; default 15")
    parser.add_argument("--sleep-ms", type=int, default=50, help="Sleep between rounds; default 50ms")
    parser.add_argument("--case-sleep-ms", type=int, default=100, help="Sleep between cases; default 100ms")
    parser.add_argument(
        "--force-stream-false",
        action="store_true",
        help="Set payload.stream=false before send; useful for deterministic single-JSON replies",
    )
    parser.add_argument(
        "--same-session-id-across-envs",
        action="store_true",
        help="Use the same generated session_id string for 9999 and 9530",
    )
    parser.add_argument("--save-raw", action="store_true", help="Save complete raw HTTP responses under out-dir/raw")
    parser.add_argument("--out-dir", default=None, help="Output directory; default histories_compare_<run_id>")
    parser.add_argument("--stop-on-transport-error", action="store_true")
    args = parser.parse_args(argv)

    try:
        source_data, cases = load_cases(args.cases, args.case_id)
    except Exception as exc:
        print("[ERROR] failed to load cases: %s" % exc, file=sys.stderr)
        return 2

    run_id = now_run_id()
    out_dir = args.out_dir or ("histories_compare_%s" % run_id)
    ensure_dir(out_dir)
    raw_dir = os.path.join(out_dir, "raw")

    round_rows = []
    case_rows = []
    result_cases = []

    total_rounds = 0
    transport_failures = 0
    cross_core_diffs = 0
    cross_semantic_diffs = 0
    expected_9999_core_diffs = 0
    expected_9530_core_diffs = 0

    print("[RUN] id=%s cases=%d" % (run_id, len(cases)))
    print("[RUN] 9999=%s" % args.url_9999)
    print("[RUN] 9530=%s" % args.url_9530)
    print("[RUN] session_policy=fresh-per-case-per-env; payload_policy=replace-session-id-only")
    print("[RUN] force_stream_false=%s" % bool(args.force_stream_false))

    for case_index, case in enumerate(cases, start=1):
        case_id = safe_text(case.get("case_id"))
        rounds = case.get("rounds") or []
        if not isinstance(rounds, list) or not rounds:
            print("[WARN] case=%s has no rounds; skipped" % case_id)
            continue

        sid_9999 = make_session_id(run_id, case_index, "9999", args.same_session_id_across_envs)
        sid_9530 = make_session_id(run_id, case_index, "9530", args.same_session_id_across_envs)
        print("\n[CASE %02d/%02d] %s rounds=%d" % (case_index, len(cases), case_id, len(rounds)))

        case_result = {
            "case_id": case_id,
            "case_type": case.get("case_type"),
            "target_request_id": case.get("target_request_id"),
            "target_domain": case.get("target_domain"),
            "target_intent": case.get("target_intent"),
            "session_9999": sid_9999,
            "session_9530": sid_9530,
            "rounds": [],
        }
        target_record = None

        # Important: complete the whole case on 9999 and 9530 independently.
        # We send the same round number to both environments before moving on,
        # but session IDs are separate, so state does not cross environments.
        for round_no, round_obj in enumerate(rounds, start=1):
            total_rounds += 1
            expected = round_obj.get("expected") or {}
            expected_available = bool(round_obj.get("expected_available", True))
            payload_9999 = prepare_payload(round_obj, sid_9999, args.force_stream_false)
            payload_9530 = prepare_payload(round_obj, sid_9530, args.force_stream_false)

            result_9999 = run_round(args.url_9999, payload_9999, expected, args.timeout, expected_available)
            result_9530 = run_round(args.url_9530, payload_9530, expected, args.timeout, expected_available)

            if not result_9999.get("transport_ok"):
                transport_failures += 1
            if not result_9530.get("transport_ok"):
                transport_failures += 1

            actual_9999 = result_9999.get("actual") or {}
            actual_9530 = result_9530.get("actual") or {}
            cross_core_equal = (
                result_9999.get("transport_ok")
                and result_9530.get("transport_ok")
                and core_signature(actual_9999) == core_signature(actual_9530)
            )
            cross_semantic_equal = (
                result_9999.get("transport_ok")
                and result_9530.get("transport_ok")
                and semantic_signature(actual_9999) == semantic_signature(actual_9530)
            )

            if not cross_core_equal:
                cross_core_diffs += 1
            if not cross_semantic_equal:
                cross_semantic_diffs += 1
            if result_9999.get("expected_core_match") is False:
                expected_9999_core_diffs += 1
            if result_9530.get("expected_core_match") is False:
                expected_9530_core_diffs += 1

            is_target = is_target_round(case, round_obj, round_no, len(rounds))
            histories = payload_9999.get("histories")
            history_count = len(histories) if isinstance(histories, list) else 0

            record = {
                "round_no": round_no,
                "is_target": is_target,
                "source_request_id": round_obj.get("source_request_id"),
                "query": payload_9999.get("query"),
                "first_wakeup": payload_9999.get("first_wakeup"),
                "has_histories": "histories" in payload_9999,
                "history_count": history_count,
                "expected": expected,
                "expected_available": expected_available,
                "result_9999": dict(result_9999),
                "result_9530": dict(result_9530),
                "cross_core_equal": cross_core_equal,
                "cross_semantic_equal": cross_semantic_equal,
            }
            # Never duplicate raw response bodies in result.json by default.
            record["result_9999"].pop("raw_text", None)
            record["result_9530"].pop("raw_text", None)

            if args.save_raw:
                record["raw_9999_file"] = save_raw(raw_dir, case_id, round_no, "9999", result_9999.get("raw_text"))
                record["raw_9530_file"] = save_raw(raw_dir, case_id, round_no, "9530", result_9530.get("raw_text"))

            case_result["rounds"].append(record)
            if is_target:
                target_record = record

            csv_row = {
                "case_id": case_id,
                "case_type": case.get("case_type"),
                "round_no": round_no,
                "is_target": bool_text(is_target),
                "source_request_id": round_obj.get("source_request_id"),
                "query": payload_9999.get("query"),
                "first_wakeup": payload_9999.get("first_wakeup"),
                "has_histories": bool_text("histories" in payload_9999),
                "history_count": history_count,
                "expected_domain": expected.get("domain"),
                "expected_intent": expected.get("intent"),
                "expected_sub_query": expected.get("sub_query"),
                "expected_available": bool_text(expected_available),
                "cross_core_equal": bool_text(cross_core_equal),
                "cross_semantic_equal": bool_text(cross_semantic_equal),
            }
            csv_row.update(env_csv("p9999", result_9999))
            csv_row.update(env_csv("p9530", result_9530))
            round_rows.append(csv_row)

            a9999 = "%s/%s" % (safe_text(actual_9999.get("domain")), safe_text(actual_9999.get("intent")))
            a9530 = "%s/%s" % (safe_text(actual_9530.get("domain")), safe_text(actual_9530.get("intent")))
            print(
                "  R%02d%s hist=%d q=%s | 9999=%s %.1fms | 9530=%s %.1fms | CORE=%s | EXP=%s/%s"
                % (
                    round_no,
                    "*" if is_target else " ",
                    history_count,
                    safe_text(payload_9999.get("query")),
                    a9999,
                    float(result_9999.get("latency_ms") or 0.0),
                    a9530,
                    float(result_9530.get("latency_ms") or 0.0),
                    "SAME" if cross_core_equal else "DIFF",
                    match_text(result_9999.get("expected_core_match")),
                    match_text(result_9530.get("expected_core_match")),
                )
            )

            if args.stop_on_transport_error and (
                not result_9999.get("transport_ok") or not result_9530.get("transport_ok")
            ):
                print("[STOP] transport/parse failure", file=sys.stderr)
                return 3

            if args.sleep_ms > 0 and round_no < len(rounds):
                time.sleep(args.sleep_ms / 1000.0)

        if target_record is None:
            target_record = case_result["rounds"][-1]

        target_9999 = target_record.get("result_9999") or {}
        target_9530 = target_record.get("result_9530") or {}
        target_a9999 = target_9999.get("actual") or {}
        target_a9530 = target_9530.get("actual") or {}

        all_cross_core = True
        all_cross_semantic = True
        all_9999_expected_core = True
        all_9530_expected_core = True
        all_transport_ok = True
        for item in case_result["rounds"]:
            all_cross_core = all_cross_core and bool(item.get("cross_core_equal"))
            all_cross_semantic = all_cross_semantic and bool(item.get("cross_semantic_equal"))
            r9999_expected = (item.get("result_9999") or {}).get("expected_core_match")
            r9530_expected = (item.get("result_9530") or {}).get("expected_core_match")
            if r9999_expected is not None:
                all_9999_expected_core = all_9999_expected_core and bool(r9999_expected)
            if r9530_expected is not None:
                all_9530_expected_core = all_9530_expected_core and bool(r9530_expected)
            all_transport_ok = all_transport_ok and bool((item.get("result_9999") or {}).get("transport_ok"))
            all_transport_ok = all_transport_ok and bool((item.get("result_9530") or {}).get("transport_ok"))

        case_result["summary"] = {
            "round_count": len(rounds),
            "all_transport_ok": all_transport_ok,
            "all_cross_core_equal": all_cross_core,
            "all_cross_semantic_equal": all_cross_semantic,
            "all_9999_expected_core_match": all_9999_expected_core,
            "all_9530_expected_core_match": all_9530_expected_core,
            "target_cross_core_equal": target_record.get("cross_core_equal"),
            "target_cross_semantic_equal": target_record.get("cross_semantic_equal"),
        }
        result_cases.append(case_result)

        case_rows.append({
            "case_id": case_id,
            "case_type": case.get("case_type"),
            "round_count": len(rounds),
            "target_request_id": case.get("target_request_id"),
            "target_query": case.get("target_query"),
            "expected_domain": case.get("target_domain"),
            "expected_intent": case.get("target_intent"),
            "p9999_domain": target_a9999.get("domain"),
            "p9999_intent": target_a9999.get("intent"),
            "p9530_domain": target_a9530.get("domain"),
            "p9530_intent": target_a9530.get("intent"),
            "target_cross_core_equal": bool_text(target_record.get("cross_core_equal")),
            "target_cross_semantic_equal": bool_text(target_record.get("cross_semantic_equal")),
            "all_cross_core_equal": bool_text(all_cross_core),
            "all_cross_semantic_equal": bool_text(all_cross_semantic),
            "all_9999_expected_core": bool_text(all_9999_expected_core),
            "all_9530_expected_core": bool_text(all_9530_expected_core),
            "all_transport_ok": bool_text(all_transport_ok),
        })

        if args.case_sleep_ms > 0 and case_index < len(cases):
            time.sleep(args.case_sleep_ms / 1000.0)

    round_fields = [
        "case_id", "case_type", "round_no", "is_target", "source_request_id", "query",
        "first_wakeup", "has_histories", "history_count",
        "expected_domain", "expected_intent", "expected_sub_query", "expected_available",
        "p9999_http", "p9999_latency_ms", "p9999_transport_ok", "p9999_domain", "p9999_intent",
        "p9999_sub_query", "p9999_slots", "p9999_rejected", "p9999_expected_core",
        "p9999_expected_semantic", "p9999_error",
        "p9530_http", "p9530_latency_ms", "p9530_transport_ok", "p9530_domain", "p9530_intent",
        "p9530_sub_query", "p9530_slots", "p9530_rejected", "p9530_expected_core",
        "p9530_expected_semantic", "p9530_error",
        "cross_core_equal", "cross_semantic_equal",
    ]
    case_fields = [
        "case_id", "case_type", "round_count", "target_request_id", "target_query",
        "expected_domain", "expected_intent",
        "p9999_domain", "p9999_intent", "p9530_domain", "p9530_intent",
        "target_cross_core_equal", "target_cross_semantic_equal",
        "all_cross_core_equal", "all_cross_semantic_equal",
        "all_9999_expected_core", "all_9530_expected_core", "all_transport_ok",
    ]

    rounds_csv = os.path.join(out_dir, "rounds.csv")
    cases_csv = os.path.join(out_dir, "cases.csv")
    result_json = os.path.join(out_dir, "result.json")
    write_csv(rounds_csv, round_fields, round_rows)
    write_csv(cases_csv, case_fields, case_rows)

    result_doc = {
        "run_id": run_id,
        "source_cases_file": os.path.abspath(args.cases),
        "source_case_version": source_data.get("version") if isinstance(source_data, dict) else None,
        "url_9999": args.url_9999,
        "url_9530": args.url_9530,
        "force_stream_false": bool(args.force_stream_false),
        "same_session_id_across_envs": bool(args.same_session_id_across_envs),
        "summary": {
            "case_count": len(result_cases),
            "round_count": total_rounds,
            "transport_failures": transport_failures,
            "cross_core_diffs": cross_core_diffs,
            "cross_semantic_diffs": cross_semantic_diffs,
            "expected_9999_core_diffs": expected_9999_core_diffs,
            "expected_9530_core_diffs": expected_9530_core_diffs,
        },
        "cases": result_cases,
    }
    with open(result_json, "w", encoding="utf-8") as f:
        json.dump(result_doc, f, ensure_ascii=False, indent=2, sort_keys=False)

    print("\n[SUMMARY] cases=%d rounds=%d" % (len(result_cases), total_rounds))
    print("[SUMMARY] transport_failures=%d" % transport_failures)
    print("[SUMMARY] cross_core_diffs=%d" % cross_core_diffs)
    print("[SUMMARY] cross_semantic_diffs=%d" % cross_semantic_diffs)
    print("[SUMMARY] 9999_expected_core_diffs=%d" % expected_9999_core_diffs)
    print("[SUMMARY] 9530_expected_core_diffs=%d" % expected_9530_core_diffs)
    print("[OUTPUT] %s" % rounds_csv)
    print("[OUTPUT] %s" % cases_csv)
    print("[OUTPUT] %s" % result_json)

    if transport_failures > 0:
        return 3
    if cross_core_diffs > 0 or expected_9999_core_diffs > 0 or expected_9530_core_diffs > 0:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
