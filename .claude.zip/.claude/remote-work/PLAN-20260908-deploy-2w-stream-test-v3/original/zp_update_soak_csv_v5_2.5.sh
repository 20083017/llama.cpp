#!/usr/bin/env bash
set -uo pipefail
umask 077

# ==============================================================================
# Entry point name: basename "$0".
#
# Modes:
#
#   single
#     Exact single-case repeat test.
#     - one persistent HTTP connection
#     - one worker
#     - exact repeat count
#     - HTTP 200 + Header.Code=0 + Payload.Semantic exists
#     - container/PID stability check
#     - core readiness gate
#     - new-core fingerprint check
#
#   stress
#     Reuses validated v5.2 load engine.
#     Supports:
#       FULL_DATASET
#       TARGETED_RESUME
#       TARGETED_WINDOW
#
# Dataset numbering:
#   dataset_row   : 1-based valid CSV record number after header
#   csv_line_hint : dataset_row + 1 for the current one-record-per-line dataset
#
# ==============================================================================

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SELF_NAME="$(basename "$0")"
BASE_RUNNER="${BASE_RUNNER:-$SELF_DIR/zp_update_soak_csv_v5_2.sh}"

MODE="stress"

URL="http://10.1.122.21:9530/zp/update"
CSV_FILE="./2w_data.csv"

CONCURRENCY=4
DURATION_SECONDS=60
RAMP_TIME_SECONDS=1
REPORT_INTERVAL=10
CONNECT_TIMEOUT=3
RESPONSE_TIMEOUT=10
# Conservative 1 MiB bound for every HTTP response body.
MAX_RESPONSE_BYTES=1048576
MAX_CONSECUTIVE_TRANSPORT_ERRORS=20
TRANSPORT_ERROR_BACKOFF_MS=200

MONITOR_SSH=""
DOCKER_HOST_PORT=9530
PROCESS_PATTERN="cu-server"

START_DATASET_ROW=""
ANCHOR_REPORT=""
ANCHOR_LOOKBACK=50
WINDOW_AFTER=""
SINGLE_OFFSET=0
SINGLE_REPEAT=100

usage() {
  cat <<EOF
Usage:
  ./${SELF_NAME} --mode single|stress [options]

Common:
  --mode MODE       single | stress
  -u URL
  -f CSV
  -m USER@HOST
  -P PORT

Anchor / replay:
  -A REPORT_DIR     Previous report used to resolve failure anchor
  -S ROW            Manual original dataset row
  -K N              Look back N cases before anchor, default 50
  -W N              Stress only: targeted window, N cases after anchor
  -O N              Single only: offset from anchor/manual row

Single:
  -n N              Exact repeat count, default 100

Stress:
  -c N              Workers, default 4
  -d SEC            Duration, default 60
  -R SEC            Ramp-up, default 1
  -r SEC            Resource/report interval, default 10
  -C SEC            Connect timeout, default 3
  -T SEC            Response timeout, default 10
  --max-response-bytes N
                    Maximum response body, default 1048576 bytes (1 MiB)
  -E N              Consecutive transport breaker, default 20
  -B MS             Transport backoff, default 200

Examples:

  # Single case, manual row
  ./${SELF_NAME} \
    --mode single \
    -f ./2w_data.csv \
    -S 5600 \
    -n 100 \
    -m daigd@10.1.122.21 \
    -P 9530

  # Single case, automatically use old failure anchor
  ./${SELF_NAME} \
    --mode single \
    -A soak_report_csv_20260824_115608 \
    -f ./2w_data.csv \
    -n 100 \
    -m daigd@10.1.122.21 \
    -P 9530

  # Test anchor -3
  ./${SELF_NAME} \
    --mode single \
    -A soak_report_csv_20260824_115608 \
    -O -3 \
    -f ./2w_data.csv \
    -n 100 \
    -m daigd@10.1.122.21 \
    -P 9530

  # Full stress
  ./${SELF_NAME} \
    --mode stress \
    -f ./2w_data.csv \
    -c 4 \
    -d 1200 \
    -r 30 \
    -m daigd@10.1.122.21 \
    -P 9530

  # Failure-window stress:
  # anchor-50 .. anchor+50, recycle this window
  ./${SELF_NAME} \
    --mode stress \
    -A soak_report_csv_20260824_115608 \
    -K 50 \
    -W 50 \
    -f ./2w_data.csv \
    -c 4 \
    -d 120 \
    -r 10 \
    -m daigd@10.1.122.21 \
    -P 9530
EOF
}

die() {
  echo "[V5.3][ERROR] $*" >&2
  exit 2
}

need_arg() {
  [[ $# -ge 2 ]] || die "$1 requires an argument"
}

while (($#)); do
  case "$1" in
    --mode)
      need_arg "$@"
      MODE="$2"
      shift 2
      ;;

    -u)
      need_arg "$@"
      URL="$2"
      shift 2
      ;;

    -f)
      need_arg "$@"
      CSV_FILE="$2"
      shift 2
      ;;

    -c)
      need_arg "$@"
      CONCURRENCY="$2"
      shift 2
      ;;

    -d)
      need_arg "$@"
      DURATION_SECONDS="$2"
      shift 2
      ;;

    -R)
      need_arg "$@"
      RAMP_TIME_SECONDS="$2"
      shift 2
      ;;

    -r)
      need_arg "$@"
      REPORT_INTERVAL="$2"
      shift 2
      ;;

    -C)
      need_arg "$@"
      CONNECT_TIMEOUT="$2"
      shift 2
      ;;

    -T)
      need_arg "$@"
      RESPONSE_TIMEOUT="$2"
      shift 2
      ;;

    --max-response-bytes)
      need_arg "$@"
      MAX_RESPONSE_BYTES="$2"
      shift 2
      ;;

    -E)
      need_arg "$@"
      MAX_CONSECUTIVE_TRANSPORT_ERRORS="$2"
      shift 2
      ;;

    -B)
      need_arg "$@"
      TRANSPORT_ERROR_BACKOFF_MS="$2"
      shift 2
      ;;

    -m)
      need_arg "$@"
      MONITOR_SSH="$2"
      shift 2
      ;;

    -P)
      need_arg "$@"
      DOCKER_HOST_PORT="$2"
      shift 2
      ;;

    -p)
      need_arg "$@"
      PROCESS_PATTERN="$2"
      shift 2
      ;;

    -A)
      need_arg "$@"
      ANCHOR_REPORT="$2"
      shift 2
      ;;

    -S)
      need_arg "$@"
      START_DATASET_ROW="$2"
      shift 2
      ;;

    -K)
      need_arg "$@"
      ANCHOR_LOOKBACK="$2"
      shift 2
      ;;

    -W)
      need_arg "$@"
      WINDOW_AFTER="$2"
      shift 2
      ;;

    -O)
      need_arg "$@"
      SINGLE_OFFSET="$2"
      shift 2
      ;;

    -n)
      need_arg "$@"
      SINGLE_REPEAT="$2"
      shift 2
      ;;

    -h|--help)
      usage
      exit 0
      ;;

    *)
      die "unknown argument: $1"
      ;;
  esac
done

[[ "$MODE" == "single" || "$MODE" == "stress" ]] || \
  die "--mode must be single or stress"

command -v python3 >/dev/null 2>&1 || die "python3 is required"

[[ "$MAX_RESPONSE_BYTES" =~ ^[0-9]+$ ]] || \
  die "MAX_RESPONSE_BYTES must be a non-negative integer: $MAX_RESPONSE_BYTES"
(( MAX_RESPONSE_BYTES >= 1 )) || \
  die "MAX_RESPONSE_BYTES must be at least 1: $MAX_RESPONSE_BYTES"

[[ -f "$CSV_FILE" ]] || die "CSV not found: $CSV_FILE"

CSV_FILE="$(
python3 - "$CSV_FILE" <<'PY'
import os, sys
print(os.path.abspath(sys.argv[1]))
PY
)"

for v in \
  CONCURRENCY \
  DURATION_SECONDS \
  RAMP_TIME_SECONDS \
  REPORT_INTERVAL \
  CONNECT_TIMEOUT \
  RESPONSE_TIMEOUT \
  MAX_CONSECUTIVE_TRANSPORT_ERRORS \
  TRANSPORT_ERROR_BACKOFF_MS \
  DOCKER_HOST_PORT \
  ANCHOR_LOOKBACK \
  SINGLE_REPEAT
do
  val="${!v}"
  [[ "$val" =~ ^[0-9]+$ ]] || die "$v must be a non-negative integer: $val"
done

(( SINGLE_REPEAT >= 1 )) || die "SINGLE_REPEAT must be at least 1: $SINGLE_REPEAT"

[[ "$SINGLE_OFFSET" =~ ^-?[0-9]+$ ]] || \
  die "SINGLE_OFFSET must be integer"

if [[ -n "$WINDOW_AFTER" ]]; then
  [[ "$WINDOW_AFTER" =~ ^[0-9]+$ ]] || \
    die "WINDOW_AFTER must be non-negative integer"
fi

TOTAL_DATASET_ROWS="$(
python3 - "$CSV_FILE" <<'PY'
import csv, sys

n = 0
with open(sys.argv[1], 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    next(r, None)
    for row in r:
        if row and row[0] != '':
            n += 1

print(n)
PY
)"

(( TOTAL_DATASET_ROWS > 0 )) || die "CSV contains no usable query"

# ==============================================================================
# Anchor
# ==============================================================================

resolve_anchor() {
  local report="$1"

  [[ -d "$report" ]] || return 2

  python3 - "$report" <<'PY'
import csv
import os
import sys

report = sys.argv[1]
anchor_path = os.path.join(report, 'failure_anchor.tsv')
errors_path = os.path.join(report, 'request_errors.tsv')

def integer(v):
    try:
        return int(v)
    except Exception:
        return None

# Native v5.3 report.
if os.path.isfile(anchor_path):
    with open(anchor_path, 'r', encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))

    for row in rows:
        if row.get('anchor_role') == 'selected':
            n = integer(
                row.get('original_dataset_row')
                or row.get('dataset_row')
            )
            if n is not None:
                print('%d\t%s' % (
                    n,
                    row.get('anchor_type', 'failure')
                ))
                raise SystemExit(0)

# v5.1/v5.2 fallback.
if not os.path.isfile(errors_path):
    raise SystemExit(3)

first_any = None
first_transport = None

with open(errors_path, 'r', encoding='utf-8', newline='') as f:
    r = csv.DictReader(f, delimiter='\t')

    for row in r:
        seq = integer(row.get('request_seq'))
        dataset = integer(row.get('dataset_row'))

        if seq is None or dataset is None:
            continue

        if first_any is None or seq < first_any[0]:
            first_any = (seq, dataset)

        if 'transport' in row.get('error_types', ''):
            if first_transport is None or seq < first_transport[0]:
                first_transport = (seq, dataset)

if first_transport:
    print('%d\tfirst_transport_error' % first_transport[1])
elif first_any:
    print('%d\tfirst_failure' % first_any[1])
else:
    raise SystemExit(4)
PY
}

ANCHOR_ROW=""
ANCHOR_TYPE="NONE"

if [[ -n "$ANCHOR_REPORT" ]]; then
  ANCHOR_RESULT="$(resolve_anchor "$ANCHOR_REPORT")" || \
    die "cannot resolve anchor from: $ANCHOR_REPORT"

  IFS=$'\t' read -r ANCHOR_ROW ANCHOR_TYPE <<< "$ANCHOR_RESULT"
fi

# ==============================================================================
# Remote Docker/core snapshot
# ==============================================================================

remote_snapshot() {
  [[ -n "$MONITOR_SSH" ]] || return 1

  ssh \
    -o BatchMode=yes \
    -o ConnectTimeout=5 \
    "$MONITOR_SSH" \
    "PORT=$(printf '%q' "$DOCKER_HOST_PORT") PROCESS_PATTERN=$(printf '%q' "$PROCESS_PATTERN") bash -s" <<'REMOTE'
set -u

cid="$(
  docker ps \
    --filter "publish=${PORT}" \
    --format '{{.ID}}' \
    2>/dev/null |
  head -n 1
)"

if [[ -z "$cid" ]]; then
  cid="$(
    docker ps -a \
      --filter "publish=${PORT}" \
      --format '{{.ID}}' \
      2>/dev/null |
    head -n 1
  )"
fi

echo "container_id=$cid"

if [[ -z "$cid" ]]; then
  echo "container_state=NOT_FOUND"
  echo "core_ready=NO"
  exit 0
fi

state="$(docker inspect -f '{{.State.Status}}' "$cid" 2>/dev/null || echo UNKNOWN)"
started="$(docker inspect -f '{{.State.StartedAt}}' "$cid" 2>/dev/null || true)"
ulimits="$(docker inspect -f '{{json .HostConfig.Ulimits}}' "$cid" 2>/dev/null || true)"

echo "container_state=$state"
echo "container_started_at=$started"
echo "docker_ulimits=$ulimits"

if [[ "$state" != "running" ]]; then
  echo "cu_pid="
  echo "core_ready=NO"
  exit 0
fi

pid="$(
  docker exec "$cid" sh -c '
    pidof cu-server 2>/dev/null |
    awk "{print \$1}"
  ' 2>/dev/null
)"

if [[ -z "$pid" ]]; then
  pid="$(
    docker exec "$cid" sh -c '
      ps -eo pid,args 2>/dev/null |
      awk "/[c]u-server/ {print \$1; exit}"
    ' 2>/dev/null
  )"
fi

echo "cu_pid=$pid"

if [[ -z "$pid" ]]; then
  echo "core_ready=NO"
  exit 0
fi

limits="$(
  docker exec "$cid" sh -c '
    p="$1"
    grep -i "Max core file size" /proc/"$p"/limits 2>/dev/null || true
  ' sh "$pid"
)"

echo "core_limit=$limits"

if echo "$limits" | grep -qE 'unlimited[[:space:]]+unlimited'; then
  limit_ok=YES
else
  limit_ok=NO
fi

echo "core_limit_ok=$limit_ok"

pattern="$(
  docker exec "$cid" sh -c '
    cat /proc/sys/kernel/core_pattern 2>/dev/null
  ' 2>/dev/null
)"

echo "core_pattern=$pattern"

if [[ "$pattern" == \|* ]]; then
  echo "core_mode=PIPE"
  echo "core_target_dir="
  echo "core_target_exists=UNKNOWN"
  echo "core_target_writable=UNKNOWN"
  echo "core_fingerprint=UNSUPPORTED_PIPE"
  echo "core_ready=NO"
  exit 0
fi

if [[ "$pattern" == /* ]]; then
  core_dir="${pattern%/*}"
  [[ "$core_dir" == "$pattern" ]] && core_dir="/"
else
  core_dir="$(
    docker exec "$cid" sh -c '
      p="$1"
      readlink -f /proc/"$p"/cwd 2>/dev/null
    ' sh "$pid"
  )"
fi

echo "core_mode=FILE"
echo "core_target_dir=$core_dir"

if docker exec "$cid" sh -c 'test -d "$1"' sh "$core_dir" 2>/dev/null; then
  exists=YES
else
  exists=NO
fi

if docker exec "$cid" sh -c 'test -d "$1" && test -w "$1"' sh "$core_dir" 2>/dev/null; then
  writable=YES
else
  writable=NO
fi

echo "core_target_exists=$exists"
echo "core_target_writable=$writable"

fingerprint="$(
  docker exec "$cid" sh -c '
    d="$1"
    find "$d" \
      -maxdepth 1 \
      -type f \
      \( -name "core*" -o -name "*core*" \) \
      -printf "%f|%s|%T@\n" \
      2>/dev/null |
    sort
  ' sh "$core_dir" |
  sha256sum |
  awk '{print $1}'
)"

echo "core_fingerprint=$fingerprint"

if [[ "$limit_ok" == YES && "$exists" == YES && "$writable" == YES ]]; then
  echo "core_ready=YES"
else
  echo "core_ready=NO"
fi
REMOTE
}

get_field() {
  local file="$1"
  local key="$2"

  awk -F= -v k="$key" '
    $1 == k {
      sub(/^[^=]*=/, "")
      print
      exit
    }
  ' "$file"
}

# ==============================================================================
# SINGLE CASE MODE
# ==============================================================================

run_single() {
  [[ -n "$MONITOR_SSH" ]] || \
    die "single mode requires -m USER@HOST because PID/core verification is mandatory"

  local base_row

  if [[ -n "$ANCHOR_ROW" ]]; then
    base_row="$ANCHOR_ROW"
  elif [[ -n "$START_DATASET_ROW" ]]; then
    base_row="$START_DATASET_ROW"
  else
    die "single mode requires -S ROW or -A REPORT"
  fi

  [[ "$base_row" =~ ^[0-9]+$ ]] || die "invalid single dataset row"

  local selected_row=$(( base_row + SINGLE_OFFSET ))

  (( selected_row >= 1 && selected_row <= TOTAL_DATASET_ROWS )) || \
    die "single row outside dataset: $selected_row"

  local ts
  ts="$(date '+%Y%m%d_%H%M%S')"

  local run_dir="single_case_report_${ts}"
  mkdir -p "$run_dir"

  local before="$run_dir/core_before.txt"
  local after="$run_dir/core_after.txt"
  local results="$run_dir/results.tsv"
  local engine_summary="$run_dir/engine_summary.env"
  local summary="$run_dir/summary.txt"

  echo "============================================================"
  echo " SINGLE CASE TEST v5.3"
  echo "============================================================"
  echo "dataset row      : $selected_row"
  echo "csv line hint    : $((selected_row + 1))"
  echo "repeat           : $SINGLE_REPEAT"
  echo "URL              : $URL"
  echo "SSH              : $MONITOR_SSH"
  echo "Docker port      : $DOCKER_HOST_PORT"
  echo "============================================================"

  echo
  echo "[CORE GATE] before test..."

  remote_snapshot > "$before" || die "remote snapshot failed"

  cat "$before"

  local core_ready
  core_ready="$(get_field "$before" core_ready)"

  if [[ "$core_ready" != "YES" ]]; then
    echo
    echo "[CORE GATE][FAIL] core capture is not ready."
    echo
    echo "Inspect:"
    echo "  $before"
    echo
    echo "Most important fields:"
    echo "  core_limit_ok"
    echo "  core_pattern"
    echo "  core_target_dir"
    echo "  core_target_exists"
    echo "  core_target_writable"
    exit 20
  fi

  local before_cid before_pid before_fp
  before_cid="$(get_field "$before" container_id)"
  before_pid="$(get_field "$before" cu_pid)"
  before_fp="$(get_field "$before" core_fingerprint)"

  if [[ -z "$before_cid" || ! "$before_pid" =~ ^[0-9]+$ || \
    ! "$before_fp" =~ ^[0-9a-f]{64}$ ]]; then
    die "incomplete pre-dispatch runtime snapshot contract"
  fi

  echo
  echo "[RUN] single case exact repeat..."

  set +e

  python3 - \
    "$URL" \
    "$CSV_FILE" \
    "$selected_row" \
    "$SINGLE_REPEAT" \
    "$CONNECT_TIMEOUT" \
    "$RESPONSE_TIMEOUT" \
    "$MAX_RESPONSE_BYTES" \
    "$results" \
    "$engine_summary" <<'PY'

import csv
import http.client
import json
import sys
import time
from urllib.parse import urlparse

(
    url,
    csv_path,
    dataset_row,
    repeat,
    connect_timeout,
    response_timeout,
    max_response_bytes,
    results_path,
    summary_path,
) = sys.argv[1:]

dataset_row = int(dataset_row)
repeat = int(repeat)
connect_timeout = int(connect_timeout)
response_timeout = int(response_timeout)
max_response_bytes = int(max_response_bytes)

query = None
n = 0

with open(csv_path, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    next(r, None)

    for row in r:
        if not row or row[0] == '':
            continue

        n += 1

        if n == dataset_row:
            query = row[0]
            break

if query is None:
    raise SystemExit('dataset row not found: %d' % dataset_row)

u = urlparse(url)

if u.scheme not in ('http', 'https') or not u.hostname:
    raise SystemExit('invalid URL: %s' % url)

host = u.hostname
port = u.port or (443 if u.scheme == 'https' else 80)
path = u.path or '/'

if u.query:
    path += '?' + u.query

conn = None

def close_conn():
    global conn
    if conn is not None:
        try:
            conn.close()
        except Exception:
            pass
    conn = None

def open_conn():
    global conn

    if u.scheme == 'https':
        conn = http.client.HTTPSConnection(
            host,
            port,
            timeout=connect_timeout,
        )
    else:
        conn = http.client.HTTPConnection(
            host,
            port,
            timeout=connect_timeout,
        )

    conn.connect()

    if conn.sock is not None:
        conn.sock.settimeout(response_timeout)

ok_count = 0
business_fail = 0
transport_fail = 0
oversized_responses = 0

with open(results_path, 'w', encoding='utf-8') as out:

    out.write(
        'iteration\telapsed_ms\thttp_status\t'
        'header_code\tsemantic_exists\t'
        'transport_error\tsuccess\terror\n'
    )

    for i in range(1, repeat + 1):

        started = time.monotonic()

        status = None
        header_code = ''
        semantic_exists = False
        transport_error = False
        success = False
        err = ''

        try:

            if conn is None:
                open_conn()

            body = json.dumps(
                {'query': query},
                ensure_ascii=False,
                separators=(',', ':'),
            ).encode('utf-8')

            headers = {
                'Content-Type': 'application/json',
                'Connection': 'keep-alive',
                'Content-Length': str(len(body)),
                'Accept': '*/*',
            }

            conn.request(
                'POST',
                path,
                body=body,
                headers=headers,
            )

            response = conn.getresponse()

            status = response.status
            raw = response.read(max_response_bytes + 1)
            oversized_response = len(raw) > max_response_bytes

            if oversized_response:
                oversized_responses += 1
                err = 'response_too_large'
                close_conn()

            if (
                (response.getheader('Connection') or '').lower() == 'close'
                or getattr(response, 'will_close', False)
            ):
                close_conn()

            if oversized_response:
                data = None
            else:
                try:
                    data = json.loads(
                        raw.decode('utf-8', 'replace')
                    )
                except Exception as e:
                    data = None
                    err = 'invalid_json:%s' % e

            if isinstance(data, dict):
                header = data.get('Header', {})
                payload = data.get('Payload', {})

                if isinstance(header, dict):
                    header_code = header.get('Code', '')

                semantic_exists = (
                    isinstance(payload, dict)
                    and 'Semantic' in payload
                    and payload.get('Semantic') is not None
                )

            success = (
                status == 200
                and str(header_code) == '0'
                and semantic_exists
                and not oversized_response
            )

            if not success:
                business_fail += 1

        except Exception as e:

            transport_error = True
            transport_fail += 1
            err = '%s:%s' % (
                type(e).__name__,
                e,
            )

            close_conn()

        elapsed_ms = (
            time.monotonic() - started
        ) * 1000.0

        if success:
            ok_count += 1

        out.write(
            '%d\t%.3f\t%s\t%s\t%s\t%s\t%s\t%s\n'
            % (
                i,
                elapsed_ms,
                '' if status is None else status,
                str(header_code).replace('\t', ' '),
                str(bool(semantic_exists)),
                str(bool(transport_error)),
                str(bool(success)),
                err.replace('\t', ' ').replace('\n', ' '),
            )
        )

        # A transport failure can be the observable edge of a crash.
        # Stop immediately instead of contaminating the result.
        if transport_error:
            break

close_conn()

with open(summary_path, 'w', encoding='utf-8') as f:
    f.write('dataset_row=%d\n' % dataset_row)
    f.write('query=%s\n' % query.replace('\n', '\\n'))
    f.write('configured_repeat=%d\n' % repeat)
    f.write('success=%d\n' % ok_count)
    f.write('business_failures=%d\n' % business_fail)
    f.write('transport_failures=%d\n' % transport_fail)
    f.write('max_response_bytes=%d\n' % max_response_bytes)
    f.write('oversized_responses=%d\n' % oversized_responses)

print('dataset_row        : %d' % dataset_row)
print('query              : %s' % query)
print('configured_repeat  : %d' % repeat)
print('success            : %d' % ok_count)
print('business_failures  : %d' % business_fail)
print('transport_failures : %d' % transport_fail)
print('max_response_bytes   : %d' % max_response_bytes)
print('oversized_responses  : %d' % oversized_responses)

raise SystemExit(
    0
    if (
        ok_count == repeat
        and business_fail == 0
        and transport_fail == 0
    )
    else 3
)
PY

  local engine_rc=$?

  set -e

  echo
  echo "[CORE GATE] after test..."

  remote_snapshot > "$after" || true
  cat "$after"

  local after_cid after_pid after_state after_fp
  after_cid="$(get_field "$after" container_id)"
  after_pid="$(get_field "$after" cu_pid)"
  after_state="$(get_field "$after" container_state)"
  after_fp="$(get_field "$after" core_fingerprint)"

  local business_fail transport_fail oversized_responses
  business_fail="$(get_field "$engine_summary" business_failures)"
  transport_fail="$(get_field "$engine_summary" transport_failures)"
  oversized_responses="$(get_field "$engine_summary" oversized_responses)"

  local result="PASS"

  if [[ "$after_state" != "running" ]]; then
    result="CRASH_OR_EXIT"

  elif [[ "$before_cid" != "$after_cid" ]]; then
    result="CONTAINER_CHANGED"

  elif [[ "$before_pid" != "$after_pid" ]]; then
    result="PID_CHANGED"

  elif [[ -n "$before_fp" && -n "$after_fp" && "$before_fp" != "$after_fp" ]]; then
    result="NEW_CORE_DETECTED"

  elif (( transport_fail > 0 )); then
    result="TRANSPORT_FAIL"

  elif (( business_fail > 0 )); then
    result="BUSINESS_FAIL"

  elif (( engine_rc != 0 )); then
    result="ENGINE_FAIL"
  fi

  {
    echo "============================================================"
    echo " SINGLE CASE SUMMARY"
    echo "============================================================"
    echo "dataset_row          : $selected_row"
    echo "csv_line_hint        : $((selected_row + 1))"
    echo "anchor_row           : $ANCHOR_ROW"
    echo "anchor_type          : $ANCHOR_TYPE"
    echo "single_offset        : $SINGLE_OFFSET"
    echo "repeat               : $SINGLE_REPEAT"
    echo "engine_rc            : $engine_rc"
    echo "before_container     : $before_cid"
    echo "after_container      : $after_cid"
    echo "before_pid           : $before_pid"
    echo "after_pid            : $after_pid"
    echo "after_state          : $after_state"
    echo "core_before          : $before_fp"
    echo "core_after           : $after_fp"
    echo "business_failures    : $business_fail"
    echo "transport_failures   : $transport_fail"
    echo "max_response_bytes   : $MAX_RESPONSE_BYTES"
    echo "oversized_responses  : $oversized_responses"
    echo "result               : $result"
    echo
    echo "results_tsv          : $results"
    echo "core_before_file     : $before"
    echo "core_after_file      : $after"
  } | tee "$summary"

  echo
  echo "[DONE] single report: $run_dir"

  [[ "$result" == "PASS" ]]
}

# ==============================================================================
# STRESS CSV preparation
# ==============================================================================

prepare_stress_csv() {
  local work_dir="$1"

  STRESS_CSV="$CSV_FILE"
  TEST_SCOPE="FULL_DATASET"
  ORIGINAL_START_ROW=1
  WINDOW_START=""
  WINDOW_END=""

  CASE_MAP="$work_dir/case_map.tsv"

  if [[ -n "$ANCHOR_ROW" && -n "$WINDOW_AFTER" ]]; then

    TEST_SCOPE="TARGETED_WINDOW"

    WINDOW_START=$(( ANCHOR_ROW - ANCHOR_LOOKBACK ))
    (( WINDOW_START < 1 )) && WINDOW_START=1

    WINDOW_END=$(( ANCHOR_ROW + WINDOW_AFTER ))
    (( WINDOW_END > TOTAL_DATASET_ROWS )) && \
      WINDOW_END="$TOTAL_DATASET_ROWS"

    STRESS_CSV="$work_dir/window.csv"

    python3 - \
      "$CSV_FILE" \
      "$WINDOW_START" \
      "$WINDOW_END" \
      "$STRESS_CSV" \
      "$CASE_MAP" <<'PY'

import csv
import sys

src, start, end, dst, map_file = sys.argv[1:]
start = int(start)
end = int(end)

with open(src, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    header = next(r, None)

    rows = [
        row
        for row in r
        if row and row[0] != ''
    ]

selected = rows[start-1:end]

with open(dst, 'w', encoding='utf-8', newline='') as f:
    w = csv.writer(f, lineterminator='\n')
    if header is not None:
        w.writerow(header)
    w.writerows(selected)

with open(map_file, 'w', encoding='utf-8') as f:
    f.write('replay_dataset_row\toriginal_dataset_row\tcsv_line_hint\tquery\n')

    for replay_row, original_row in enumerate(range(start, end + 1), 1):
        query = rows[original_row - 1][0]
        query = query.replace('\t', ' ').replace('\n', '\\n').replace('\r', '\\r')

        f.write(
            '%d\t%d\t%d\t%s\n'
            % (
                replay_row,
                original_row,
                original_row + 1,
                query,
            )
        )
PY

    return
  fi

  local start=""

  if [[ -n "$ANCHOR_ROW" ]]; then
    start=$(( ANCHOR_ROW - ANCHOR_LOOKBACK ))
    (( start < 1 )) && start=1

  elif [[ -n "$START_DATASET_ROW" ]]; then
    start="$START_DATASET_ROW"
  fi

  if [[ -n "$start" && "$start" != "1" ]]; then

    TEST_SCOPE="TARGETED_RESUME"
    ORIGINAL_START_ROW="$start"
    STRESS_CSV="$work_dir/rotated.csv"

    python3 - \
      "$CSV_FILE" \
      "$start" \
      "$STRESS_CSV" \
      "$CASE_MAP" <<'PY'

import csv
import sys

src, start, dst, map_file = sys.argv[1:]
start = int(start)

with open(src, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    header = next(r, None)
    rows = [row for row in r if row and row[0] != '']

idx = start - 1

ordered = (
    list(enumerate(rows[idx:], idx))
    +
    list(enumerate(rows[:idx], 0))
)

with open(dst, 'w', encoding='utf-8', newline='') as f:
    w = csv.writer(f, lineterminator='\n')
    if header is not None:
        w.writerow(header)

    for _, row in ordered:
        w.writerow(row)

with open(map_file, 'w', encoding='utf-8') as f:
    f.write('replay_dataset_row\toriginal_dataset_row\tcsv_line_hint\tquery\n')

    for replay_row, (original_idx, row) in enumerate(ordered, 1):
        original_row = original_idx + 1
        query = row[0].replace('\t', ' ').replace('\n', '\\n').replace('\r', '\\r')

        f.write(
            '%d\t%d\t%d\t%s\n'
            % (
                replay_row,
                original_row,
                original_row + 1,
                query,
            )
        )
PY

    return
  fi

  # Identity mapping.
  python3 - "$CSV_FILE" "$CASE_MAP" <<'PY'
import csv
import sys

src, map_file = sys.argv[1:]

with open(src, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f)
    next(r, None)

    rows = [
        row
        for row in r
        if row and row[0] != ''
    ]

with open(map_file, 'w', encoding='utf-8') as f:
    f.write('replay_dataset_row\toriginal_dataset_row\tcsv_line_hint\tquery\n')

    for i, row in enumerate(rows, 1):
        query = row[0].replace('\t', ' ').replace('\n', '\\n').replace('\r', '\\r')
        f.write('%d\t%d\t%d\t%s\n' % (i, i, i + 1, query))
PY
}

# ==============================================================================
# STRESS postprocess anchor
# ==============================================================================

postprocess_stress() {
  local report="$1"
  local case_map="$2"

  python3 - \
    "$report" \
    "$case_map" \
    "$CSV_FILE" \
    "$TEST_SCOPE" \
    "$ANCHOR_LOOKBACK" <<'PY'

import csv
import os
import sys

report, map_file, csv_file, scope, lookback = sys.argv[1:]
lookback = int(lookback)

errors_file = os.path.join(report, 'request_errors.tsv')
anchor_file = os.path.join(report, 'failure_anchor.tsv')
context_file = os.path.join(report, 'failure_context.tsv')
resume_file = os.path.join(report, 'resume_plan.txt')
summary_file = os.path.join(report, 'summary.txt')

mapping = {}

with open(map_file, 'r', encoding='utf-8', newline='') as f:
    for row in csv.DictReader(f, delimiter='\t'):
        mapping[int(row['replay_dataset_row'])] = int(row['original_dataset_row'])

queries = []

with open(csv_file, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f)
    next(r, None)

    for row in r:
        if row and row[0] != '':
            queries.append(row[0])

errors = []

if os.path.isfile(errors_file):

    with open(errors_file, 'r', encoding='utf-8', newline='') as f:

        for row in csv.DictReader(f, delimiter='\t'):

            try:
                seq = int(row['request_seq'])
                replay = int(row['dataset_row'])
                original = mapping[replay]
            except Exception:
                continue

            row['_seq'] = seq
            row['_original'] = original
            errors.append(row)

errors.sort(key=lambda x: x['_seq'])

transport = [
    x for x in errors
    if 'transport' in x.get('error_types', '')
]

selected = transport[0] if transport else (errors[0] if errors else None)

selected_type = (
    'first_transport_error'
    if transport
    else ('first_failure' if selected else 'NONE')
)

header = (
    'anchor_role\tanchor_type\ttimestamp\tworker\trequest_seq\tcycle\t'
    'original_dataset_row\tcsv_line_hint\thttp_status\theader_code\t'
    'error_types\terror\tquery\n'
)

with open(anchor_file, 'w', encoding='utf-8') as f:
    f.write(header)

    if selected:
        original = selected['_original']

        vals = [
            'selected',
            selected_type,
            selected.get('timestamp', ''),
            selected.get('worker', ''),
            selected.get('request_seq', ''),
            selected.get('cycle', ''),
            original,
            original + 1,
            selected.get('http_status', ''),
            selected.get('header_code', ''),
            selected.get('error_types', ''),
            selected.get('error', ''),
            selected.get('query', ''),
        ]

        f.write(
            '\t'.join(
                str(v)
                .replace('\t', ' ')
                .replace('\n', '\\n')
                .replace('\r', '\\r')
                for v in vals
            )
            + '\n'
        )

with open(context_file, 'w', encoding='utf-8') as f:

    f.write(
        'offset\trelation\toriginal_dataset_row\tcsv_line_hint\tquery\n'
    )

    if selected:

        anchor = selected['_original']

        lo = max(1, anchor - lookback)
        hi = min(len(queries), anchor + 20)

        for original in range(lo, hi + 1):

            offset = original - anchor

            relation = (
                'ANCHOR'
                if offset == 0
                else ('BEFORE' if offset < 0 else 'AFTER')
            )

            q = (
                queries[original - 1]
                .replace('\t', ' ')
                .replace('\n', '\\n')
                .replace('\r', '\\r')
            )

            f.write(
                '%d\t%s\t%d\t%d\t%s\n'
                % (
                    offset,
                    relation,
                    original,
                    original + 1,
                    q,
                )
            )

with open(resume_file, 'w', encoding='utf-8') as f:

    f.write('test_scope=%s\n' % scope)

    if selected:
        anchor = selected['_original']

        f.write('anchor_type=%s\n' % selected_type)
        f.write('anchor_dataset_row=%d\n' % anchor)
        f.write(
            'next_replay_start=%d\n'
            % max(1, anchor - lookback)
        )
    else:
        f.write('anchor_type=NONE\n')

summary = ''

if os.path.isfile(summary_file):
    with open(summary_file, 'r', encoding='utf-8') as f:
        summary = f.read()

base = {}

for line in summary.splitlines():
    if ':' in line:
        k, v = line.split(':', 1)
        base[k.strip()] = v.strip()

if scope == 'FULL_DATASET':
    effective = base.get('dataset_validation', 'UNKNOWN')
    targeted = 'NOT_APPLICABLE'
else:
    effective = 'NOT_APPLICABLE'

    if base.get('run_status') == 'INFRA_ABORTED':
        targeted = 'INFRA_ABORTED'
    elif int(base.get('transport_errors', '0') or 0) > 0:
        targeted = 'INFRA_FAIL'
    elif int(base.get('jmeter_failures', '0') or 0) > 0:
        targeted = 'BUSINESS_FAIL'
    else:
        targeted = 'PASS'

with open(summary_file, 'a', encoding='utf-8') as f:

    f.write('\n# ===== v5.3 =====\n')
    f.write('test_mode             : STRESS\n')
    f.write('test_scope            : %s\n' % scope)
    f.write('effective_dataset_validation: %s\n' % effective)
    f.write('targeted_validation   : %s\n' % targeted)
    f.write('failure_anchor_type   : %s\n' % selected_type)

    if selected:
        f.write(
            'failure_anchor_dataset_row: %d\n'
            % selected['_original']
        )

print()
print('===== V5.3 STRESS SUMMARY =====')
print('test_scope            : %s' % scope)
print('effective_dataset     : %s' % effective)
print('targeted_validation   : %s' % targeted)
print('failure_anchor_type   : %s' % selected_type)

if selected:
    print(
        'failure_anchor_row    : %d'
        % selected['_original']
    )
PY
}

# ==============================================================================
# STRESS MODE
# ==============================================================================

run_stress() {
  [[ -f "$BASE_RUNNER" ]] || \
    die "v5.2 runner not found: $BASE_RUNNER"

  local work
  work="$(mktemp -d "${TMPDIR:-/tmp}/zp_v53.XXXXXX")"

  trap 'rm -rf "$work" 2>/dev/null || true' RETURN

  prepare_stress_csv "$work"

  echo "============================================================"
  echo " STRESS TEST v5.3"
  echo "============================================================"
  echo "scope             : $TEST_SCOPE"
  echo "original csv      : $CSV_FILE"
  echo "stress csv        : $STRESS_CSV"
  echo "anchor row        : $ANCHOR_ROW"
  echo "anchor type       : $ANCHOR_TYPE"

  if [[ "$TEST_SCOPE" == "TARGETED_WINDOW" ]]; then
    echo "window start      : $WINDOW_START"
    echo "window end        : $WINDOW_END"
    echo "window cases      : $((WINDOW_END - WINDOW_START + 1))"
  elif [[ "$TEST_SCOPE" == "TARGETED_RESUME" ]]; then
    echo "start row         : $ORIGINAL_START_ROW"
  fi

  echo "workers           : $CONCURRENCY"
  echo "duration          : $DURATION_SECONDS"
  echo "============================================================"

  local core_before="$work/core_before.txt"

  if [[ -n "$MONITOR_SSH" ]]; then
    remote_snapshot > "$core_before" || true

    if [[ -s "$core_before" ]]; then
      echo
      echo "[CORE STATUS]"
      cat "$core_before"

      if [[ "$(get_field "$core_before" core_ready)" != "YES" ]]; then
        echo
        echo "[WARN] core capture is not ready."
        echo "[WARN] Stress can continue, but a crash may not leave a usable core."
      fi
    fi
  fi

  set +e

  bash "$BASE_RUNNER" \
    -u "$URL" \
    -f "$STRESS_CSV" \
    -c "$CONCURRENCY" \
    -d "$DURATION_SECONDS" \
    -R "$RAMP_TIME_SECONDS" \
    -r "$REPORT_INTERVAL" \
    -C "$CONNECT_TIMEOUT" \
    -T "$RESPONSE_TIMEOUT" \
    --max-response-bytes "$MAX_RESPONSE_BYTES" \
    -E "$MAX_CONSECUTIVE_TRANSPORT_ERRORS" \
    -B "$TRANSPORT_ERROR_BACKOFF_MS" \
    ${MONITOR_SSH:+-m "$MONITOR_SSH"} \
    -P "$DOCKER_HOST_PORT" \
    -p "$PROCESS_PATTERN" \
    2>&1 | tee "$work/base.log"

  local base_rc=${PIPESTATUS[0]}

  set -e

  local report
  report="$(
    sed -n \
      's/^\[DONE\] report directory : //p' \
      "$work/base.log" |
    tail -n 1
  )"

  if [[ -z "$report" ]]; then
    echo "[V5.3][WARN] unable to discover report directory"
    return "$base_rc"
  fi

  [[ "$report" == /* ]] || report="$(pwd)/$report"

  cp -f "$CASE_MAP" "$report/case_map.tsv"

  if [[ -s "$core_before" ]]; then
    cp -f "$core_before" "$report/core_before.txt"
  fi

  if [[ -n "$MONITOR_SSH" ]]; then
    remote_snapshot > "$report/core_after.txt" || true
  fi

  {
    echo
    echo "# v5.3 stress controller"
    echo "v5_3_mode=stress"
    echo "v5_3_scope=$TEST_SCOPE"
    echo "v5_3_original_csv=$CSV_FILE"
    echo "v5_3_anchor_report=$ANCHOR_REPORT"
    echo "v5_3_anchor_row=$ANCHOR_ROW"
    echo "v5_3_anchor_type=$ANCHOR_TYPE"
    echo "v5_3_lookback=$ANCHOR_LOOKBACK"
    echo "v5_3_window_after=$WINDOW_AFTER"
    echo "v5_3_max_response_bytes=$MAX_RESPONSE_BYTES"
  } >> "$report/config.txt"

  postprocess_stress "$report" "$report/case_map.tsv"

  echo
  echo "[DONE] stress report: $report"

  return "$base_rc"
}

case "$MODE" in
  single)
    run_single
    ;;
  stress)
    run_stress
    ;;
esac
