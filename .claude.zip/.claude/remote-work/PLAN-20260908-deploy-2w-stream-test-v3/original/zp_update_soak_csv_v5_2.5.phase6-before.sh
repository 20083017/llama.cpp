#!/usr/bin/env bash
set -uo pipefail
umask 077

# ==============================================================================
# Entry point name: basename "$0".
#
# Modes:
#
#   single
#     Exact single-case repeat test.
#     - one persistent HTTP connection
#     - one worker
#     - exact repeat count
#     - HTTP 200 + Header.Code=0 + Payload.Semantic exists
#     - container/PID stability check
#     - core readiness gate
#     - new-core fingerprint check
#
#   stress
#     Self-contained bounded Python worker engine.
#     Supports:
#       DURATION
#       EXACT_ONCE
#       FULL_DATASET
#       TARGETED_RESUME
#       TARGETED_WINDOW
#
#   histories
#     Delegates directly to the existing multi-round comparator.
#
# Dataset numbering:
#   dataset_row   : 1-based valid CSV record number after header
#   csv_line_hint : dataset_row + 1 for the current one-record-per-line dataset
#
# ==============================================================================

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SELF_NAME="$(basename "$0")"
HISTORY_COMPARATOR="$SELF_DIR/compare_histories_9999_9530_py36_full.py"
HISTORY_CASES="$SELF_DIR/history_replay_cases_verified_full.json"
HISTORY_CASE_ID="C005_case1_car_info_tire_pressure"
HISTORY_URL_9999="http://10.1.122.21:9999/zp/update"
HISTORY_URL_9530="http://10.1.122.21:9530/zp/update"
HISTORY_FORCE_STREAM_FALSE=0

MODE="stress"

URL="http://10.1.122.21:9530/zp/update"
CSV_FILE="./2w_data.csv"

CONCURRENCY=4
DURATION_SECONDS=60
RAMP_TIME_SECONDS=1
REPORT_INTERVAL=10
CONNECT_TIMEOUT=3
RESPONSE_TIMEOUT=10
# Conservative 1 MiB bound for every HTTP response body.
MAX_RESPONSE_BYTES=1048576
MAX_CONSECUTIVE_TRANSPORT_ERRORS=20
TRANSPORT_ERROR_BACKOFF_MS=200

MONITOR_SSH=""
DOCKER_HOST_PORT=9530
PROCESS_PATTERN="cu-server"

START_DATASET_ROW=""
ANCHOR_REPORT=""
ANCHOR_LOOKBACK=50
WINDOW_AFTER=""
SINGLE_OFFSET=0
SINGLE_REPEAT=100
STREAM_MODE="false"
EXACT_ONCE=0
APP_ID="10241"
SESSION_PREFIX="wtp184_$(date '+%Y%m%d_%H%M%S')_$$"

usage() {
  cat <<EOF
Usage:
  ./${SELF_NAME} --mode single|stress|histories [options]

Common single/stress:
  --stream BOOL     true | false, default false
  --session-prefix PREFIX
                    Synthetic session prefix; default generated per run
  -u URL
  -f CSV
  -m USER@HOST
  -P PORT

Anchor / replay:
  -A REPORT_DIR     Previous report used to resolve failure anchor
  -S ROW            Manual original dataset row
  -K N              Look back N cases before anchor, default 50
  -W N              Stress only: targeted window, N cases after anchor
  -O N              Single only: offset from anchor/manual row

Single:
  -n N              Exact repeat count, default 100

Stress:
  --exact-once      Dispatch every selected CSV row exactly once
  -c N              Workers, default 4
  -d SEC            Duration mode, default 60
  -R SEC            Ramp-up, default 1
  -r SEC            Progress interval, default 10
  -C SEC            Connect timeout, default 3
  -T SEC            Response timeout, default 10
  --max-response-bytes N
                    Maximum response body, default 1048576 bytes (1 MiB)
  -E N              Consecutive transport breaker per worker, default 20
  -B MS             Transport backoff, default 200

Histories (delegates existing comparator):
  --case-id ID
  --cases PATH
  --url-9999 URL
  --url-9530 URL
  --force-stream-false

Examples:
  ./${SELF_NAME} --mode single --stream true -f ./2w_data.csv -S 1 -n 1 -m daigd@10.1.122.21 -P 9530
  ./${SELF_NAME} --mode stress --exact-once --stream true -f ./2w_data.csv -c 4 -r 30 -m daigd@10.1.122.21 -P 9530
  ./${SELF_NAME} --mode histories --case-id C005_case1_car_info_tire_pressure --cases ./history_replay_cases_verified_full.json --url-9999 http://10.1.122.21:9999/zp/update --url-9530 http://10.1.122.21:9530/zp/update --force-stream-false
EOF
}

die() {
  echo "[V5.3][ERROR] $*" >&2
  exit 2
}

need_arg() {
  [[ $# -ge 2 ]] || die "$1 requires an argument"
}

while (($#)); do
  case "$1" in
    --mode)
      need_arg "$@"
      MODE="$2"
      shift 2
      ;;

    --stream)
      need_arg "$@"
      STREAM_MODE="$2"
      shift 2
      ;;

    --session-prefix)
      need_arg "$@"
      SESSION_PREFIX="$2"
      shift 2
      ;;

    --exact-once)
      EXACT_ONCE=1
      shift
      ;;

    --case-id)
      need_arg "$@"
      HISTORY_CASE_ID="$2"
      shift 2
      ;;

    --cases)
      need_arg "$@"
      HISTORY_CASES="$2"
      shift 2
      ;;

    --url-9999)
      need_arg "$@"
      HISTORY_URL_9999="$2"
      shift 2
      ;;

    --url-9530)
      need_arg "$@"
      HISTORY_URL_9530="$2"
      shift 2
      ;;

    --force-stream-false)
      HISTORY_FORCE_STREAM_FALSE=1
      shift
      ;;

    -u)
      need_arg "$@"
      URL="$2"
      shift 2
      ;;

    -f)
      need_arg "$@"
      CSV_FILE="$2"
      shift 2
      ;;

    -c)
      need_arg "$@"
      CONCURRENCY="$2"
      shift 2
      ;;

    -d)
      need_arg "$@"
      DURATION_SECONDS="$2"
      shift 2
      ;;

    -R)
      need_arg "$@"
      RAMP_TIME_SECONDS="$2"
      shift 2
      ;;

    -r)
      need_arg "$@"
      REPORT_INTERVAL="$2"
      shift 2
      ;;

    -C)
      need_arg "$@"
      CONNECT_TIMEOUT="$2"
      shift 2
      ;;

    -T)
      need_arg "$@"
      RESPONSE_TIMEOUT="$2"
      shift 2
      ;;

    --max-response-bytes)
      need_arg "$@"
      MAX_RESPONSE_BYTES="$2"
      shift 2
      ;;

    -E)
      need_arg "$@"
      MAX_CONSECUTIVE_TRANSPORT_ERRORS="$2"
      shift 2
      ;;

    -B)
      need_arg "$@"
      TRANSPORT_ERROR_BACKOFF_MS="$2"
      shift 2
      ;;

    -m)
      need_arg "$@"
      MONITOR_SSH="$2"
      shift 2
      ;;

    -P)
      need_arg "$@"
      DOCKER_HOST_PORT="$2"
      shift 2
      ;;

    -p)
      need_arg "$@"
      PROCESS_PATTERN="$2"
      shift 2
      ;;

    -A)
      need_arg "$@"
      ANCHOR_REPORT="$2"
      shift 2
      ;;

    -S)
      need_arg "$@"
      START_DATASET_ROW="$2"
      shift 2
      ;;

    -K)
      need_arg "$@"
      ANCHOR_LOOKBACK="$2"
      shift 2
      ;;

    -W)
      need_arg "$@"
      WINDOW_AFTER="$2"
      shift 2
      ;;

    -O)
      need_arg "$@"
      SINGLE_OFFSET="$2"
      shift 2
      ;;

    -n)
      need_arg "$@"
      SINGLE_REPEAT="$2"
      shift 2
      ;;

    -h|--help)
      usage
      exit 0
      ;;

    *)
      die "unknown argument: $1"
      ;;
  esac
done

[[ "$MODE" == "single" || "$MODE" == "stress" || "$MODE" == "histories" ]] || \
  die "--mode must be single, stress, or histories"

command -v python3 >/dev/null 2>&1 || die "python3 is required"

[[ "$STREAM_MODE" == "true" || "$STREAM_MODE" == "false" ]] || \
  die "--stream must be true or false"
[[ "$SESSION_PREFIX" =~ ^[A-Za-z0-9_.-]{1,96}$ ]] || \
  die "--session-prefix must use 1-96 letters, digits, dot, underscore, or hyphen"

if [[ "$MODE" != "stress" && "$EXACT_ONCE" == 1 ]]; then
  die "--exact-once requires --mode stress"
fi

if [[ "$MODE" == "histories" ]]; then
  [[ "$STREAM_MODE" == "false" ]] || \
    die "histories mode uses comparator stream options, not --stream"
  [[ "$HISTORY_CASE_ID" =~ ^[A-Za-z0-9_.-]{1,128}$ ]] || \
    die "--case-id contains unsupported characters"
fi

if [[ "$MODE" != "histories" ]]; then

[[ "$MAX_RESPONSE_BYTES" =~ ^[0-9]+$ ]] || \
  die "MAX_RESPONSE_BYTES must be a non-negative integer: $MAX_RESPONSE_BYTES"
(( MAX_RESPONSE_BYTES >= 1 )) || \
  die "MAX_RESPONSE_BYTES must be at least 1: $MAX_RESPONSE_BYTES"

[[ -f "$CSV_FILE" ]] || die "CSV not found: $CSV_FILE"

CSV_FILE="$(
python3 - "$CSV_FILE" <<'PY'
import os, sys
print(os.path.abspath(sys.argv[1]))
PY
)"

for v in \
  CONCURRENCY \
  DURATION_SECONDS \
  RAMP_TIME_SECONDS \
  REPORT_INTERVAL \
  CONNECT_TIMEOUT \
  RESPONSE_TIMEOUT \
  MAX_CONSECUTIVE_TRANSPORT_ERRORS \
  TRANSPORT_ERROR_BACKOFF_MS \
  DOCKER_HOST_PORT \
  ANCHOR_LOOKBACK \
  SINGLE_REPEAT
do
  val="${!v}"
  [[ "$val" =~ ^[0-9]+$ ]] || die "$v must be a non-negative integer: $val"
done

(( CONCURRENCY >= 1 )) || die "CONCURRENCY must be at least 1"
(( MAX_CONSECUTIVE_TRANSPORT_ERRORS >= 1 )) || \
  die "MAX_CONSECUTIVE_TRANSPORT_ERRORS must be at least 1"
if [[ "$MODE" == "stress" && "$EXACT_ONCE" == 0 ]]; then
  (( DURATION_SECONDS >= 1 )) || die "DURATION_SECONDS must be at least 1"
fi

(( SINGLE_REPEAT >= 1 )) || die "SINGLE_REPEAT must be at least 1: $SINGLE_REPEAT"

[[ "$SINGLE_OFFSET" =~ ^-?[0-9]+$ ]] || \
  die "SINGLE_OFFSET must be integer"

if [[ -n "$WINDOW_AFTER" ]]; then
  [[ "$WINDOW_AFTER" =~ ^[0-9]+$ ]] || \
    die "WINDOW_AFTER must be non-negative integer"
fi

TOTAL_DATASET_ROWS="$(
python3 - "$CSV_FILE" <<'PY'
import csv, sys

n = 0
with open(sys.argv[1], 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    next(r, None)
    for row in r:
        if row and row[0] != '':
            n += 1

print(n)
PY
)"

(( TOTAL_DATASET_ROWS > 0 )) || die "CSV contains no usable query"

# ==============================================================================
# Anchor
# ==============================================================================

resolve_anchor() {
  local report="$1"

  [[ -d "$report" ]] || return 2

  python3 - "$report" <<'PY'
import csv
import os
import sys

report = sys.argv[1]
anchor_path = os.path.join(report, 'failure_anchor.tsv')
errors_path = os.path.join(report, 'request_errors.tsv')

def integer(v):
    try:
        return int(v)
    except Exception:
        return None

# Native v5.3 report.
if os.path.isfile(anchor_path):
    with open(anchor_path, 'r', encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))

    for row in rows:
        if row.get('anchor_role') == 'selected':
            n = integer(
                row.get('original_dataset_row')
                or row.get('dataset_row')
            )
            if n is not None:
                print('%d\t%s' % (
                    n,
                    row.get('anchor_type', 'failure')
                ))
                raise SystemExit(0)

# v5.1/v5.2 fallback.
if not os.path.isfile(errors_path):
    raise SystemExit(3)

first_any = None
first_transport = None

with open(errors_path, 'r', encoding='utf-8', newline='') as f:
    r = csv.DictReader(f, delimiter='\t')

    for row in r:
        seq = integer(row.get('request_seq'))
        dataset = integer(row.get('dataset_row'))

        if seq is None or dataset is None:
            continue

        if first_any is None or seq < first_any[0]:
            first_any = (seq, dataset)

        if 'transport' in row.get('error_types', ''):
            if first_transport is None or seq < first_transport[0]:
                first_transport = (seq, dataset)

if first_transport:
    print('%d\tfirst_transport_error' % first_transport[1])
elif first_any:
    print('%d\tfirst_failure' % first_any[1])
else:
    raise SystemExit(4)
PY
}

ANCHOR_ROW=""
ANCHOR_TYPE="NONE"

if [[ -n "$ANCHOR_REPORT" ]]; then
  ANCHOR_RESULT="$(resolve_anchor "$ANCHOR_REPORT")" || \
    die "cannot resolve anchor from: $ANCHOR_REPORT"

  IFS=$'\t' read -r ANCHOR_ROW ANCHOR_TYPE <<< "$ANCHOR_RESULT"
fi

fi  # MODE != histories

# ==============================================================================
# Remote Docker/core snapshot
# ==============================================================================

remote_snapshot() {
  [[ -n "$MONITOR_SSH" ]] || return 1

  ssh \
    -o BatchMode=yes \
    -o ConnectTimeout=5 \
    "$MONITOR_SSH" \
    "PORT=$(printf '%q' "$DOCKER_HOST_PORT") PROCESS_PATTERN=$(printf '%q' "$PROCESS_PATTERN") bash -s" <<'REMOTE'
set -u

cid="$(
  docker ps \
    --filter "publish=${PORT}" \
    --format '{{.ID}}' \
    2>/dev/null |
  head -n 1
)"

if [[ -z "$cid" ]]; then
  cid="$(
    docker ps -a \
      --filter "publish=${PORT}" \
      --format '{{.ID}}' \
      2>/dev/null |
    head -n 1
  )"
fi

echo "container_id=$cid"

if [[ -z "$cid" ]]; then
  echo "container_state=NOT_FOUND"
  echo "core_ready=NO"
  exit 0
fi

state="$(docker inspect -f '{{.State.Status}}' "$cid" 2>/dev/null || echo UNKNOWN)"
started="$(docker inspect -f '{{.State.StartedAt}}' "$cid" 2>/dev/null || true)"
ulimits="$(docker inspect -f '{{json .HostConfig.Ulimits}}' "$cid" 2>/dev/null || true)"

echo "container_state=$state"
echo "container_started_at=$started"
echo "docker_ulimits=$ulimits"

if [[ "$state" != "running" ]]; then
  echo "cu_pid="
  echo "core_ready=NO"
  exit 0
fi

pid="$(
  docker exec "$cid" sh -c '
    pidof cu-server 2>/dev/null |
    awk "{print \$1}"
  ' 2>/dev/null
)"

if [[ -z "$pid" ]]; then
  pid="$(
    docker exec "$cid" sh -c '
      ps -eo pid,args 2>/dev/null |
      awk "/[c]u-server/ {print \$1; exit}"
    ' 2>/dev/null
  )"
fi

echo "cu_pid=$pid"

if [[ -z "$pid" ]]; then
  echo "core_ready=NO"
  exit 0
fi

limits="$(
  docker exec "$cid" sh -c '
    p="$1"
    grep -i "Max core file size" /proc/"$p"/limits 2>/dev/null || true
  ' sh "$pid"
)"

echo "core_limit=$limits"

if echo "$limits" | grep -qE 'unlimited[[:space:]]+unlimited'; then
  limit_ok=YES
else
  limit_ok=NO
fi

echo "core_limit_ok=$limit_ok"

pattern="$(
  docker exec "$cid" sh -c '
    cat /proc/sys/kernel/core_pattern 2>/dev/null
  ' 2>/dev/null
)"

echo "core_pattern=$pattern"

if [[ "$pattern" == \|* ]]; then
  echo "core_mode=PIPE"
  echo "core_target_dir="
  echo "core_target_exists=UNKNOWN"
  echo "core_target_writable=UNKNOWN"
  echo "core_fingerprint=UNSUPPORTED_PIPE"
  echo "core_ready=NO"
  exit 0
fi

if [[ "$pattern" == /* ]]; then
  core_dir="${pattern%/*}"
  [[ "$core_dir" == "$pattern" ]] && core_dir="/"
else
  core_dir="$(
    docker exec "$cid" sh -c '
      p="$1"
      readlink -f /proc/"$p"/cwd 2>/dev/null
    ' sh "$pid"
  )"
fi

echo "core_mode=FILE"
echo "core_target_dir=$core_dir"

if docker exec "$cid" sh -c 'test -d "$1"' sh "$core_dir" 2>/dev/null; then
  exists=YES
else
  exists=NO
fi

if docker exec "$cid" sh -c 'test -d "$1" && test -w "$1"' sh "$core_dir" 2>/dev/null; then
  writable=YES
else
  writable=NO
fi

echo "core_target_exists=$exists"
echo "core_target_writable=$writable"

fingerprint="$(
  docker exec "$cid" sh -c '
    d="$1"
    find "$d" \
      -maxdepth 1 \
      -type f \
      \( -name "core*" -o -name "*core*" \) \
      -printf "%f|%s|%T@\n" \
      2>/dev/null |
    sort
  ' sh "$core_dir" |
  sha256sum |
  awk '{print $1}'
)"

echo "core_fingerprint=$fingerprint"

if [[ "$limit_ok" == YES && "$exists" == YES && "$writable" == YES ]]; then
  echo "core_ready=YES"
else
  echo "core_ready=NO"
fi
REMOTE
}

get_field() {
  local file="$1"
  local key="$2"

  awk -F= -v k="$key" '
    $1 == k {
      sub(/^[^=]*=/, "")
      print
      exit
    }
  ' "$file"
}

# ==============================================================================
# SINGLE CASE MODE
# ==============================================================================

run_single() {
  [[ -n "$MONITOR_SSH" ]] || \
    die "single mode requires -m USER@HOST because PID/core verification is mandatory"

  local base_row

  if [[ -n "$ANCHOR_ROW" ]]; then
    base_row="$ANCHOR_ROW"
  elif [[ -n "$START_DATASET_ROW" ]]; then
    base_row="$START_DATASET_ROW"
  else
    die "single mode requires -S ROW or -A REPORT"
  fi

  [[ "$base_row" =~ ^[0-9]+$ ]] || die "invalid single dataset row"

  local selected_row=$(( base_row + SINGLE_OFFSET ))

  (( selected_row >= 1 && selected_row <= TOTAL_DATASET_ROWS )) || \
    die "single row outside dataset: $selected_row"

  local ts
  ts="$(date '+%Y%m%d_%H%M%S')"

  local run_dir="single_case_report_${ts}"
  mkdir -p "$run_dir"

  local before="$run_dir/core_before.txt"
  local after="$run_dir/core_after.txt"
  local results="$run_dir/results.tsv"
  local engine_summary="$run_dir/engine_summary.env"
  local summary="$run_dir/summary.txt"

  echo "============================================================"
  echo " SINGLE CASE TEST v5.3"
  echo "============================================================"
  echo "dataset row      : $selected_row"
  echo "csv line hint    : $((selected_row + 1))"
  echo "repeat           : $SINGLE_REPEAT"
  echo "URL              : $URL"
  echo "SSH              : $MONITOR_SSH"
  echo "Docker port      : $DOCKER_HOST_PORT"
  echo "============================================================"

  echo
  echo "[CORE GATE] before test..."

  remote_snapshot > "$before" || die "remote snapshot failed"

  cat "$before"

  local core_ready
  core_ready="$(get_field "$before" core_ready)"

  if [[ "$core_ready" != "YES" ]]; then
    echo
    echo "[CORE GATE][FAIL] core capture is not ready."
    echo
    echo "Inspect:"
    echo "  $before"
    echo
    echo "Most important fields:"
    echo "  core_limit_ok"
    echo "  core_pattern"
    echo "  core_target_dir"
    echo "  core_target_exists"
    echo "  core_target_writable"
    exit 20
  fi

  local before_cid before_pid before_fp
  before_cid="$(get_field "$before" container_id)"
  before_pid="$(get_field "$before" cu_pid)"
  before_fp="$(get_field "$before" core_fingerprint)"

  if [[ -z "$before_cid" || ! "$before_pid" =~ ^[0-9]+$ || \
    ! "$before_fp" =~ ^[0-9a-f]{64}$ ]]; then
    die "incomplete pre-dispatch runtime snapshot contract"
  fi

  echo
  echo "[RUN] single case exact repeat..."

  set +e

  python3 - \
    "$URL" \
    "$CSV_FILE" \
    "$selected_row" \
    "$SINGLE_REPEAT" \
    "$CONNECT_TIMEOUT" \
    "$RESPONSE_TIMEOUT" \
    "$MAX_RESPONSE_BYTES" \
    "$STREAM_MODE" \
    "$APP_ID" \
    "$SESSION_PREFIX" \
    "$results" \
    "$engine_summary" <<'PY'

import csv
import http.client
import json
import sys
import time
from urllib.parse import urlparse

(
    url,
    csv_path,
    dataset_row,
    repeat,
    connect_timeout,
    response_timeout,
    max_response_bytes,
    stream_text,
    app_id,
    session_prefix,
    results_path,
    summary_path,
) = sys.argv[1:]

dataset_row = int(dataset_row)
repeat = int(repeat)
connect_timeout = int(connect_timeout)
response_timeout = int(response_timeout)
max_response_bytes = int(max_response_bytes)
stream_mode = stream_text == 'true'

query = None
n = 0

with open(csv_path, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    next(r, None)

    for row in r:
        if not row or row[0] == '':
            continue

        n += 1

        if n == dataset_row:
            query = row[0]
            break

if query is None:
    raise SystemExit('dataset row not found: %d' % dataset_row)

u = urlparse(url)

if u.scheme not in ('http', 'https') or not u.hostname:
    raise SystemExit('invalid URL: %s' % url)

host = u.hostname
port = u.port or (443 if u.scheme == 'https' else 80)
path = u.path or '/'

if u.query:
    path += '?' + u.query

conn = None

def close_conn():
    global conn
    if conn is not None:
        try:
            conn.close()
        except Exception:
            pass
    conn = None

def open_conn():
    global conn

    if u.scheme == 'https':
        conn = http.client.HTTPSConnection(
            host,
            port,
            timeout=connect_timeout,
        )
    else:
        conn = http.client.HTTPConnection(
            host,
            port,
            timeout=connect_timeout,
        )

    conn.connect()

    if conn.sock is not None:
        conn.sock.settimeout(response_timeout)

def parse_sse(raw):
    events = []
    current = []
    unexpected = []
    for line in raw.decode('utf-8', 'replace').splitlines():
        if line == '':
            if current:
                events.append('\n'.join(current))
                current = []
        elif line.startswith('data:'):
            current.append(line[5:].lstrip())
        elif line.startswith(':') or line.startswith('event:') or \
                line.startswith('id:') or line.startswith('retry:'):
            continue
        else:
            unexpected.append(line[:120])
    if current:
        events.append('\n'.join(current))
    if unexpected:
        raise ValueError('unexpected_sse_line:%s' % unexpected[0])
    objects = []
    for event in events:
        if event.strip() == '[DONE]':
            continue
        objects.append(json.loads(event))
    return objects

def assess_response(raw, content_type):
    header_code = ''
    semantic_exists = False
    parser_error = ''
    incomplete_stream = False
    if stream_mode:
        if not (content_type or '').lower().startswith('text/event-stream'):
            return header_code, semantic_exists, \
                'invalid_content_type:%s' % content_type, True
        try:
            objects = parse_sse(raw)
        except Exception as exc:
            return header_code, semantic_exists, 'invalid_sse:%s' % exc, True
        if not objects:
            return header_code, semantic_exists, 'empty_sse', True
        terminal = False
        stream_seen = False
        codes = []
        for item in objects:
            if not isinstance(item, dict):
                parser_error = 'sse_event_not_object'
                continue
            header = item.get('Header', {})
            payload = item.get('Payload', {})
            if isinstance(header, dict):
                codes.append(str(header.get('Code', '')))
                header_code = header.get('Code', header_code)
                terminal = terminal or header.get('IsEnd') is True
                stream_seen = stream_seen or header.get('Stream') is True
            semantic_exists = semantic_exists or (
                isinstance(payload, dict) and payload.get('Semantic') is not None
            )
        if any(code != '0' for code in codes) or not codes:
            parser_error = parser_error or 'stream_header_code'
        incomplete_stream = not terminal or not stream_seen
        return header_code, semantic_exists, parser_error, incomplete_stream
    try:
        data = json.loads(raw.decode('utf-8', 'replace'))
    except Exception as exc:
        return header_code, semantic_exists, 'invalid_json:%s' % exc, False
    if isinstance(data, dict):
        header = data.get('Header', {})
        payload = data.get('Payload', {})
        if isinstance(header, dict):
            header_code = header.get('Code', '')
        semantic_exists = (
            isinstance(payload, dict) and payload.get('Semantic') is not None
        )
    return header_code, semantic_exists, parser_error, incomplete_stream

ok_count = 0
business_fail = 0
transport_fail = 0
parser_fail = 0
incomplete_streams = 0
oversized_responses = 0
session_id = '%s_single_%d' % (session_prefix, dataset_row)

with open(results_path, 'w', encoding='utf-8') as out:

    out.write(
        'iteration\telapsed_ms\thttp_status\t'
        'header_code\tsemantic_exists\tparser_error\t'
        'incomplete_stream\ttransport_error\tsuccess\terror\n'
    )

    for i in range(1, repeat + 1):

        started = time.monotonic()

        status = None
        header_code = ''
        semantic_exists = False
        parser_error = ''
        incomplete_stream = False
        transport_error = False
        success = False
        err = ''

        try:

            if conn is None:
                open_conn()

            body = json.dumps(
                {
                    'app_id': app_id,
                    'firstWakeUp': False,
                    'input_data': [{'microphone': {'position': 0}}],
                    'query': query,
                    'debug': True,
                    'stream': stream_mode,
                    'session_id': session_id,
                },
                ensure_ascii=False,
                separators=(',', ':'),
            ).encode('utf-8')

            headers = {
                'Content-Type': 'application/json',
                'Connection': 'keep-alive',
                'Content-Length': str(len(body)),
                'Accept': 'text/event-stream' if stream_mode else 'application/json',
            }

            conn.request(
                'POST',
                path,
                body=body,
                headers=headers,
            )

            response = conn.getresponse()

            status = response.status
            content_type = response.getheader('Content-Type') or ''
            raw = response.read(max_response_bytes + 1)
            oversized_response = len(raw) > max_response_bytes

            if oversized_response:
                oversized_responses += 1
                err = 'response_too_large'
                close_conn()
            else:
                header_code, semantic_exists, parser_error, incomplete_stream = \
                    assess_response(raw, content_type)
                if parser_error:
                    parser_fail += 1
                    err = parser_error
                if incomplete_stream:
                    incomplete_streams += 1
                    err = err or 'incomplete_stream'

            if (
                (response.getheader('Connection') or '').lower() == 'close'
                or getattr(response, 'will_close', False)
            ):
                close_conn()

            success = (
                status == 200
                and str(header_code) == '0'
                and semantic_exists
                and not oversized_response
                and not parser_error
                and not incomplete_stream
            )

            if not success and not oversized_response and \
                    not parser_error and not incomplete_stream:
                business_fail += 1

        except Exception as e:

            transport_error = True
            transport_fail += 1
            err = '%s:%s' % (
                type(e).__name__,
                e,
            )

            close_conn()

        elapsed_ms = (
            time.monotonic() - started
        ) * 1000.0

        if success:
            ok_count += 1

        out.write(
            '%d\t%.3f\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n'
            % (
                i,
                elapsed_ms,
                '' if status is None else status,
                str(header_code).replace('\t', ' '),
                str(bool(semantic_exists)),
                parser_error.replace('\t', ' '),
                str(bool(incomplete_stream)),
                str(bool(transport_error)),
                str(bool(success)),
                err.replace('\t', ' ').replace('\n', ' '),
            )
        )

        # A transport failure can be the observable edge of a crash.
        # Stop immediately instead of contaminating the result.
        if transport_error:
            break

close_conn()

with open(summary_path, 'w', encoding='utf-8') as f:
    f.write('dataset_row=%d\n' % dataset_row)
    f.write('query=%s\n' % query.replace('\n', '\\n'))
    f.write('configured_repeat=%d\n' % repeat)
    f.write('stream_mode=%s\n' % stream_text)
    f.write('session_id=%s\n' % session_id)
    f.write('success=%d\n' % ok_count)
    f.write('business_failures=%d\n' % business_fail)
    f.write('transport_failures=%d\n' % transport_fail)
    f.write('parser_failures=%d\n' % parser_fail)
    f.write('incomplete_streams=%d\n' % incomplete_streams)
    f.write('max_response_bytes=%d\n' % max_response_bytes)
    f.write('oversized_responses=%d\n' % oversized_responses)

print('dataset_row        : %d' % dataset_row)
print('query              : %s' % query)
print('configured_repeat  : %d' % repeat)
print('stream_mode        : %s' % stream_text)
print('success            : %d' % ok_count)
print('business_failures  : %d' % business_fail)
print('transport_failures : %d' % transport_fail)
print('parser_failures    : %d' % parser_fail)
print('incomplete_streams : %d' % incomplete_streams)
print('max_response_bytes : %d' % max_response_bytes)
print('oversized_responses  : %d' % oversized_responses)

raise SystemExit(
    0
    if (
        ok_count == repeat
        and business_fail == 0
        and transport_fail == 0
        and parser_fail == 0
        and incomplete_streams == 0
        and oversized_responses == 0
    )
    else 3
)
PY

  local engine_rc=$?

  set -e

  echo
  echo "[CORE GATE] after test..."

  remote_snapshot > "$after" || true
  cat "$after"

  local after_cid after_pid after_state after_fp
  after_cid="$(get_field "$after" container_id)"
  after_pid="$(get_field "$after" cu_pid)"
  after_state="$(get_field "$after" container_state)"
  after_fp="$(get_field "$after" core_fingerprint)"

  local business_fail transport_fail parser_fail incomplete_streams oversized_responses
  business_fail="$(get_field "$engine_summary" business_failures)"
  transport_fail="$(get_field "$engine_summary" transport_failures)"
  parser_fail="$(get_field "$engine_summary" parser_failures)"
  incomplete_streams="$(get_field "$engine_summary" incomplete_streams)"
  oversized_responses="$(get_field "$engine_summary" oversized_responses)"

  local result="PASS"

  if [[ "$after_state" != "running" ]]; then
    result="CRASH_OR_EXIT"

  elif [[ "$before_cid" != "$after_cid" ]]; then
    result="CONTAINER_CHANGED"

  elif [[ "$before_pid" != "$after_pid" ]]; then
    result="PID_CHANGED"

  elif [[ -n "$before_fp" && -n "$after_fp" && "$before_fp" != "$after_fp" ]]; then
    result="NEW_CORE_DETECTED"

  elif (( transport_fail > 0 )); then
    result="TRANSPORT_FAIL"

  elif (( parser_fail > 0 )); then
    result="PARSER_FAIL"

  elif (( incomplete_streams > 0 )); then
    result="INCOMPLETE_STREAM"

  elif (( business_fail > 0 )); then
    result="BUSINESS_FAIL"

  elif (( engine_rc != 0 )); then
    result="ENGINE_FAIL"
  fi

  {
    echo "============================================================"
    echo " SINGLE CASE SUMMARY"
    echo "============================================================"
    echo "dataset_row          : $selected_row"
    echo "csv_line_hint        : $((selected_row + 1))"
    echo "anchor_row           : $ANCHOR_ROW"
    echo "anchor_type          : $ANCHOR_TYPE"
    echo "single_offset        : $SINGLE_OFFSET"
    echo "repeat               : $SINGLE_REPEAT"
    echo "stream_mode          : $STREAM_MODE"
    echo "session_prefix       : $SESSION_PREFIX"
    echo "engine_rc            : $engine_rc"
    echo "before_container     : $before_cid"
    echo "after_container      : $after_cid"
    echo "before_pid           : $before_pid"
    echo "after_pid            : $after_pid"
    echo "after_state          : $after_state"
    echo "core_before          : $before_fp"
    echo "core_after           : $after_fp"
    echo "business_failures    : $business_fail"
    echo "transport_failures   : $transport_fail"
    echo "parser_failures      : $parser_fail"
    echo "incomplete_streams   : $incomplete_streams"
    echo "max_response_bytes   : $MAX_RESPONSE_BYTES"
    echo "oversized_responses  : $oversized_responses"
    echo "result               : $result"
    echo
    echo "results_tsv          : $results"
    echo "core_before_file     : $before"
    echo "core_after_file      : $after"
  } | tee "$summary"

  echo
  echo "[DONE] single report: $run_dir"

  [[ "$result" == "PASS" ]]
}

# ==============================================================================
# STRESS CSV preparation
# ==============================================================================

prepare_stress_csv() {
  local work_dir="$1"

  STRESS_CSV="$CSV_FILE"
  TEST_SCOPE="FULL_DATASET"
  ORIGINAL_START_ROW=1
  WINDOW_START=""
  WINDOW_END=""

  CASE_MAP="$work_dir/case_map.tsv"

  if [[ -n "$ANCHOR_ROW" && -n "$WINDOW_AFTER" ]]; then

    TEST_SCOPE="TARGETED_WINDOW"

    WINDOW_START=$(( ANCHOR_ROW - ANCHOR_LOOKBACK ))
    (( WINDOW_START < 1 )) && WINDOW_START=1

    WINDOW_END=$(( ANCHOR_ROW + WINDOW_AFTER ))
    (( WINDOW_END > TOTAL_DATASET_ROWS )) && \
      WINDOW_END="$TOTAL_DATASET_ROWS"

    STRESS_CSV="$work_dir/window.csv"

    python3 - \
      "$CSV_FILE" \
      "$WINDOW_START" \
      "$WINDOW_END" \
      "$STRESS_CSV" \
      "$CASE_MAP" <<'PY'

import csv
import sys

src, start, end, dst, map_file = sys.argv[1:]
start = int(start)
end = int(end)

with open(src, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    header = next(r, None)

    rows = [
        row
        for row in r
        if row and row[0] != ''
    ]

selected = rows[start-1:end]

with open(dst, 'w', encoding='utf-8', newline='') as f:
    w = csv.writer(f, lineterminator='\n')
    if header is not None:
        w.writerow(header)
    w.writerows(selected)

with open(map_file, 'w', encoding='utf-8') as f:
    f.write('replay_dataset_row\toriginal_dataset_row\tcsv_line_hint\tquery\n')

    for replay_row, original_row in enumerate(range(start, end + 1), 1):
        query = rows[original_row - 1][0]
        query = query.replace('\t', ' ').replace('\n', '\\n').replace('\r', '\\r')

        f.write(
            '%d\t%d\t%d\t%s\n'
            % (
                replay_row,
                original_row,
                original_row + 1,
                query,
            )
        )
PY

    return
  fi

  local start=""

  if [[ -n "$ANCHOR_ROW" ]]; then
    start=$(( ANCHOR_ROW - ANCHOR_LOOKBACK ))
    (( start < 1 )) && start=1

  elif [[ -n "$START_DATASET_ROW" ]]; then
    start="$START_DATASET_ROW"
  fi

  if [[ -n "$start" && "$start" != "1" ]]; then

    TEST_SCOPE="TARGETED_RESUME"
    ORIGINAL_START_ROW="$start"
    STRESS_CSV="$work_dir/rotated.csv"

    python3 - \
      "$CSV_FILE" \
      "$start" \
      "$STRESS_CSV" \
      "$CASE_MAP" <<'PY'

import csv
import sys

src, start, dst, map_file = sys.argv[1:]
start = int(start)

with open(src, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f, delimiter=',', quotechar='"')
    header = next(r, None)
    rows = [row for row in r if row and row[0] != '']

idx = start - 1

ordered = (
    list(enumerate(rows[idx:], idx))
    +
    list(enumerate(rows[:idx], 0))
)

with open(dst, 'w', encoding='utf-8', newline='') as f:
    w = csv.writer(f, lineterminator='\n')
    if header is not None:
        w.writerow(header)

    for _, row in ordered:
        w.writerow(row)

with open(map_file, 'w', encoding='utf-8') as f:
    f.write('replay_dataset_row\toriginal_dataset_row\tcsv_line_hint\tquery\n')

    for replay_row, (original_idx, row) in enumerate(ordered, 1):
        original_row = original_idx + 1
        query = row[0].replace('\t', ' ').replace('\n', '\\n').replace('\r', '\\r')

        f.write(
            '%d\t%d\t%d\t%s\n'
            % (
                replay_row,
                original_row,
                original_row + 1,
                query,
            )
        )
PY

    return
  fi

  # Identity mapping.
  python3 - "$CSV_FILE" "$CASE_MAP" <<'PY'
import csv
import sys

src, map_file = sys.argv[1:]

with open(src, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f)
    next(r, None)

    rows = [
        row
        for row in r
        if row and row[0] != ''
    ]

with open(map_file, 'w', encoding='utf-8') as f:
    f.write('replay_dataset_row\toriginal_dataset_row\tcsv_line_hint\tquery\n')

    for i, row in enumerate(rows, 1):
        query = row[0].replace('\t', ' ').replace('\n', '\\n').replace('\r', '\\r')
        f.write('%d\t%d\t%d\t%s\n' % (i, i, i + 1, query))
PY
}

# ==============================================================================
# STRESS postprocess anchor
# ==============================================================================

postprocess_stress() {
  local report="$1"
  local case_map="$2"

  python3 - \
    "$report" \
    "$case_map" \
    "$CSV_FILE" \
    "$TEST_SCOPE" \
    "$ANCHOR_LOOKBACK" <<'PY'

import csv
import os
import sys

report, map_file, csv_file, scope, lookback = sys.argv[1:]
lookback = int(lookback)

errors_file = os.path.join(report, 'request_errors.tsv')
anchor_file = os.path.join(report, 'failure_anchor.tsv')
context_file = os.path.join(report, 'failure_context.tsv')
resume_file = os.path.join(report, 'resume_plan.txt')
summary_file = os.path.join(report, 'summary.txt')

mapping = {}

with open(map_file, 'r', encoding='utf-8', newline='') as f:
    for row in csv.DictReader(f, delimiter='\t'):
        mapping[int(row['replay_dataset_row'])] = int(row['original_dataset_row'])

queries = []

with open(csv_file, 'r', encoding='utf-8-sig', newline='') as f:
    r = csv.reader(f)
    next(r, None)

    for row in r:
        if row and row[0] != '':
            queries.append(row[0])

errors = []

if os.path.isfile(errors_file):

    with open(errors_file, 'r', encoding='utf-8', newline='') as f:

        for row in csv.DictReader(f, delimiter='\t'):

            try:
                seq = int(row['request_seq'])
                replay = int(row['dataset_row'])
                original = mapping[replay]
            except Exception:
                continue

            row['_seq'] = seq
            row['_original'] = original
            errors.append(row)

errors.sort(key=lambda x: x['_seq'])

transport = [
    x for x in errors
    if 'transport' in x.get('error_types', '')
]

selected = transport[0] if transport else (errors[0] if errors else None)

selected_type = (
    'first_transport_error'
    if transport
    else ('first_failure' if selected else 'NONE')
)

header = (
    'anchor_role\tanchor_type\ttimestamp\tworker\trequest_seq\tcycle\t'
    'original_dataset_row\tcsv_line_hint\thttp_status\theader_code\t'
    'error_types\terror\tquery\n'
)

with open(anchor_file, 'w', encoding='utf-8') as f:
    f.write(header)

    if selected:
        original = selected['_original']

        vals = [
            'selected',
            selected_type,
            selected.get('timestamp', ''),
            selected.get('worker', ''),
            selected.get('request_seq', ''),
            selected.get('cycle', ''),
            original,
            original + 1,
            selected.get('http_status', ''),
            selected.get('header_code', ''),
            selected.get('error_types', ''),
            selected.get('error', ''),
            selected.get('query', ''),
        ]

        f.write(
            '\t'.join(
                str(v)
                .replace('\t', ' ')
                .replace('\n', '\\n')
                .replace('\r', '\\r')
                for v in vals
            )
            + '\n'
        )

with open(context_file, 'w', encoding='utf-8') as f:

    f.write(
        'offset\trelation\toriginal_dataset_row\tcsv_line_hint\tquery\n'
    )

    if selected:

        anchor = selected['_original']

        lo = max(1, anchor - lookback)
        hi = min(len(queries), anchor + 20)

        for original in range(lo, hi + 1):

            offset = original - anchor

            relation = (
                'ANCHOR'
                if offset == 0
                else ('BEFORE' if offset < 0 else 'AFTER')
            )

            q = (
                queries[original - 1]
                .replace('\t', ' ')
                .replace('\n', '\\n')
                .replace('\r', '\\r')
            )

            f.write(
                '%d\t%s\t%d\t%d\t%s\n'
                % (
                    offset,
                    relation,
                    original,
                    original + 1,
                    q,
                )
            )

with open(resume_file, 'w', encoding='utf-8') as f:

    f.write('test_scope=%s\n' % scope)

    if selected:
        anchor = selected['_original']

        f.write('anchor_type=%s\n' % selected_type)
        f.write('anchor_dataset_row=%d\n' % anchor)
        f.write(
            'next_replay_start=%d\n'
            % max(1, anchor - lookback)
        )
    else:
        f.write('anchor_type=NONE\n')

summary = ''

if os.path.isfile(summary_file):
    with open(summary_file, 'r', encoding='utf-8') as f:
        summary = f.read()

base = {}

for line in summary.splitlines():
    if ':' in line:
        k, v = line.split(':', 1)
        base[k.strip()] = v.strip()

if scope == 'FULL_DATASET':
    effective = base.get('dataset_validation', 'UNKNOWN')
    targeted = 'NOT_APPLICABLE'
else:
    effective = 'NOT_APPLICABLE'

    if base.get('run_status') == 'INFRA_ABORTED':
        targeted = 'INFRA_ABORTED'
    elif int(base.get('transport_errors', '0') or 0) > 0:
        targeted = 'INFRA_FAIL'
    elif int(base.get('jmeter_failures', '0') or 0) > 0:
        targeted = 'BUSINESS_FAIL'
    else:
        targeted = 'PASS'

with open(summary_file, 'a', encoding='utf-8') as f:

    f.write('\n# ===== v5.3 =====\n')
    f.write('test_mode             : STRESS\n')
    f.write('test_scope            : %s\n' % scope)
    f.write('effective_dataset_validation: %s\n' % effective)
    f.write('targeted_validation   : %s\n' % targeted)
    f.write('failure_anchor_type   : %s\n' % selected_type)

    if selected:
        f.write(
            'failure_anchor_dataset_row: %d\n'
            % selected['_original']
        )

print()
print('===== V5.3 STRESS SUMMARY =====')
print('test_scope            : %s' % scope)
print('effective_dataset     : %s' % effective)
print('targeted_validation   : %s' % targeted)
print('failure_anchor_type   : %s' % selected_type)

if selected:
    print(
        'failure_anchor_row    : %d'
        % selected['_original']
    )
PY
}

# ==============================================================================
# STRESS MODE
# ==============================================================================

run_stress() {
  local work report ts core_before core_after engine_summary
  work="$(mktemp -d "${TMPDIR:-/tmp}/zp_v54.XXXXXX")"
  trap 'rm -rf "$work" 2>/dev/null || true' RETURN
  prepare_stress_csv "$work"

  ts="$(date '+%Y%m%d_%H%M%S')"
  report="$(pwd)/soak_report_csv_${ts}_$$"
  mkdir -p "$report"
  cp -f "$CASE_MAP" "$report/case_map.tsv"
  core_before="$report/core_before.txt"
  core_after="$report/core_after.txt"
  engine_summary="$report/engine_summary.env"

  local before_cid="" before_pid="" before_fp=""
  if [[ -n "$MONITOR_SSH" ]]; then
    remote_snapshot > "$core_before" || die "remote snapshot failed"
    cat "$core_before"
    before_cid="$(get_field "$core_before" container_id)"
    before_pid="$(get_field "$core_before" cu_pid)"
    before_fp="$(get_field "$core_before" core_fingerprint)"
  fi

  echo "============================================================"
  echo " STRESS TEST v5.4"
  echo "============================================================"
  echo "scope             : $TEST_SCOPE"
  echo "stream            : $STREAM_MODE"
  echo "exact once        : $EXACT_ONCE"
  echo "workers           : $CONCURRENCY"
  echo "duration          : $DURATION_SECONDS"
  echo "session prefix    : $SESSION_PREFIX"
  echo "============================================================"

  set +e
  python3 - "$URL" "$STRESS_CSV" "$CONCURRENCY" "$DURATION_SECONDS" \
    "$RAMP_TIME_SECONDS" "$REPORT_INTERVAL" "$CONNECT_TIMEOUT" \
    "$RESPONSE_TIMEOUT" "$MAX_RESPONSE_BYTES" \
    "$MAX_CONSECUTIVE_TRANSPORT_ERRORS" "$TRANSPORT_ERROR_BACKOFF_MS" \
    "$STREAM_MODE" "$EXACT_ONCE" "$APP_ID" "$SESSION_PREFIX" \
    "$report" "$engine_summary" <<'PY'
import csv
import datetime
import http.client
import json
import os
import queue
import sys
import threading
import time
from urllib.parse import urlparse

(url, csv_path, concurrency, duration, ramp, report_interval,
 connect_timeout, response_timeout, max_response_bytes,
 max_transport, backoff_ms, stream_text, exact_once,
 app_id, session_prefix, report, summary_env) = sys.argv[1:]
concurrency = int(concurrency)
duration = int(duration)
ramp = int(ramp)
report_interval = max(1, int(report_interval))
connect_timeout = int(connect_timeout)
response_timeout = int(response_timeout)
max_response_bytes = int(max_response_bytes)
max_transport = int(max_transport)
backoff_ms = int(backoff_ms)
stream_mode = stream_text == 'true'
exact_once = int(exact_once) == 1
if concurrency < 1 or max_transport < 1 or (not exact_once and duration < 1):
    raise SystemExit('invalid positive stress bound')

rows = []
with open(csv_path, 'r', encoding='utf-8-sig', newline='') as handle:
    reader = csv.reader(handle)
    next(reader, None)
    for row in reader:
        if row and row[0]:
            rows.append(row[0])
if not rows:
    raise SystemExit('stress CSV has no queries')

parsed_url = urlparse(url)
if parsed_url.scheme not in ('http', 'https') or not parsed_url.hostname:
    raise SystemExit('invalid URL: %s' % url)
request_path = parsed_url.path or '/'
if parsed_url.query:
    request_path += '?' + parsed_url.query
port = parsed_url.port or (443 if parsed_url.scheme == 'https' else 80)

jobs = queue.Queue(maxsize=max(2, concurrency * 2))
results = []
lock = threading.Lock()
stop_event = threading.Event()
producer_done = threading.Event()
state = {'dispatched': 0, 'completed': 0}
deadline = time.monotonic() + duration

def parse_sse(raw):
    events = []
    current = []
    unexpected = []
    for line in raw.decode('utf-8', 'replace').splitlines():
        if line == '':
            if current:
                events.append('\n'.join(current))
                current = []
        elif line.startswith('data:'):
            current.append(line[5:].lstrip())
        elif line.startswith(':') or line.startswith('event:') or \
                line.startswith('id:') or line.startswith('retry:'):
            continue
        else:
            unexpected.append(line[:120])
    if current:
        events.append('\n'.join(current))
    if unexpected:
        raise ValueError('unexpected_sse_line:%s' % unexpected[0])
    objects = []
    for event in events:
        if event.strip() == '[DONE]':
            continue
        objects.append(json.loads(event))
    return objects

def assess_response(raw, content_type):
    header_code = ''
    semantic_exists = False
    parser_error = ''
    incomplete_stream = False
    if stream_mode:
        if not (content_type or '').lower().startswith('text/event-stream'):
            return header_code, semantic_exists, \
                'invalid_content_type:%s' % content_type, True
        try:
            objects = parse_sse(raw)
        except Exception as exc:
            return header_code, semantic_exists, 'invalid_sse:%s' % exc, True
        if not objects:
            return header_code, semantic_exists, 'empty_sse', True
        terminal = False
        stream_seen = False
        codes = []
        for item in objects:
            if not isinstance(item, dict):
                parser_error = 'sse_event_not_object'
                continue
            header = item.get('Header', {})
            payload = item.get('Payload', {})
            if isinstance(header, dict):
                codes.append(str(header.get('Code', '')))
                header_code = header.get('Code', header_code)
                terminal = terminal or header.get('IsEnd') is True
                stream_seen = stream_seen or header.get('Stream') is True
            semantic_exists = semantic_exists or (
                isinstance(payload, dict) and payload.get('Semantic') is not None
            )
        if any(code != '0' for code in codes) or not codes:
            parser_error = parser_error or 'stream_header_code'
        incomplete_stream = not terminal or not stream_seen
        return header_code, semantic_exists, parser_error, incomplete_stream
    try:
        item = json.loads(raw.decode('utf-8', 'replace'))
    except Exception as exc:
        return header_code, semantic_exists, 'invalid_json:%s' % exc, False
    if isinstance(item, dict):
        header = item.get('Header', {})
        payload = item.get('Payload', {})
        if isinstance(header, dict):
            header_code = header.get('Code', '')
        semantic_exists = isinstance(payload, dict) and payload.get('Semantic') is not None
    return header_code, semantic_exists, parser_error, incomplete_stream

def producer():
    sequence = 0
    cycle = 0
    try:
        while not stop_event.is_set():
            cycle += 1
            for dataset_row, query in enumerate(rows, 1):
                if stop_event.is_set() or (not exact_once and time.monotonic() >= deadline):
                    return
                sequence += 1
                while not stop_event.is_set():
                    try:
                        jobs.put((sequence, dataset_row, cycle, query), timeout=0.2)
                        with lock:
                            state['dispatched'] += 1
                        break
                    except queue.Full:
                        if not exact_once and time.monotonic() >= deadline:
                            return
            if exact_once:
                return
    finally:
        producer_done.set()

def worker(worker_id):
    connection = None
    consecutive_transport = 0
    session_id = '%s_w%02d' % (session_prefix, worker_id)

    def close_connection():
        nonlocal connection
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass
        connection = None

    def open_connection():
        nonlocal connection
        cls = http.client.HTTPSConnection if parsed_url.scheme == 'https' \
            else http.client.HTTPConnection
        connection = cls(parsed_url.hostname, port, timeout=connect_timeout)
        connection.connect()
        if connection.sock is not None:
            connection.sock.settimeout(response_timeout)

    try:
        while True:
            if stop_event.is_set():
                return
            try:
                sequence, dataset_row, cycle, query = jobs.get(timeout=0.2)
            except queue.Empty:
                if producer_done.is_set():
                    return
                continue
            begun = time.monotonic()
            item = {
                'timestamp': datetime.datetime.now().isoformat(),
                'worker': worker_id,
                'request_seq': sequence,
                'cycle': cycle,
                'dataset_row': dataset_row,
                'query': query,
                'http_status': '',
                'header_code': '',
                'semantic_exists': False,
                'parser_error': '',
                'incomplete_stream': False,
                'transport_error': False,
                'oversized_response': False,
                'success': False,
                'error_types': '',
                'error': '',
            }
            try:
                if connection is None:
                    open_connection()
                payload = {
                    'app_id': app_id,
                    'firstWakeUp': False,
                    'input_data': [{'microphone': {'position': 0}}],
                    'query': query,
                    'debug': True,
                    'stream': stream_mode,
                    'session_id': session_id,
                }
                body = json.dumps(
                    payload, ensure_ascii=False, separators=(',', ':')
                ).encode('utf-8')
                connection.request('POST', request_path, body=body, headers={
                    'Content-Type': 'application/json',
                    'Connection': 'keep-alive',
                    'Content-Length': str(len(body)),
                    'Accept': 'text/event-stream' if stream_mode else 'application/json',
                })
                response = connection.getresponse()
                item['http_status'] = response.status
                content_type = response.getheader('Content-Type') or ''
                raw = response.read(max_response_bytes + 1)
                item['oversized_response'] = len(raw) > max_response_bytes
                if item['oversized_response']:
                    item['error_types'] = 'oversized'
                    item['error'] = 'response_too_large'
                    close_connection()
                else:
                    code, semantic, parser_error, incomplete = \
                        assess_response(raw, content_type)
                    item['header_code'] = code
                    item['semantic_exists'] = semantic
                    item['parser_error'] = parser_error
                    item['incomplete_stream'] = incomplete
                    error_types = []
                    if parser_error:
                        error_types.append('parser')
                    if incomplete:
                        error_types.append('incomplete')
                    if not parser_error and not incomplete and (
                        response.status != 200 or str(code) != '0' or not semantic
                    ):
                        error_types.append('business')
                    item['error_types'] = ','.join(error_types)
                    item['error'] = parser_error or (
                        'incomplete_stream' if incomplete else ''
                    )
                    item['success'] = not error_types
                if (response.getheader('Connection') or '').lower() == 'close' or \
                        getattr(response, 'will_close', False):
                    close_connection()
                consecutive_transport = 0
            except Exception as exc:
                item['transport_error'] = True
                item['error_types'] = 'transport'
                item['error'] = '%s:%s' % (type(exc).__name__, exc)
                consecutive_transport += 1
                close_connection()
                if backoff_ms > 0:
                    time.sleep(backoff_ms / 1000.0)
                if consecutive_transport >= max_transport:
                    stop_event.set()
            item['elapsed_ms'] = (time.monotonic() - begun) * 1000.0
            with lock:
                results.append(item)
                state['completed'] += 1
            jobs.task_done()
    finally:
        close_connection()

producer_thread = threading.Thread(target=producer, name='producer')
workers = []
producer_thread.start()
for worker_id in range(1, concurrency + 1):
    thread = threading.Thread(
        target=worker, args=(worker_id,), name='worker-%d' % worker_id
    )
    workers.append(thread)
    thread.start()
    if ramp > 0 and worker_id < concurrency:
        time.sleep(float(ramp) / float(concurrency))

next_report = time.monotonic() + report_interval
while producer_thread.is_alive() or any(thread.is_alive() for thread in workers):
    time.sleep(0.2)
    now = time.monotonic()
    if now >= next_report:
        with lock:
            print('[PROGRESS] dispatched=%d completed=%d' % (
                state['dispatched'], state['completed']
            ))
        next_report = now + report_interval
producer_thread.join()
for thread in workers:
    thread.join()

results.sort(key=lambda item: item['request_seq'])
result_header = [
    'timestamp', 'worker', 'request_seq', 'cycle', 'dataset_row', 'elapsed_ms',
    'http_status', 'header_code', 'semantic_exists', 'parser_error',
    'incomplete_stream', 'transport_error', 'oversized_response', 'success',
    'error_types', 'error', 'query'
]

def clean(value):
    return str(value).replace('\t', ' ').replace('\n', '\\n').replace('\r', '\\r')

with open(os.path.join(report, 'results.tsv'), 'w', encoding='utf-8') as handle:
    handle.write('\t'.join(result_header) + '\n')
    for item in results:
        values = dict(item)
        values['elapsed_ms'] = '%.3f' % item['elapsed_ms']
        handle.write('\t'.join(clean(values.get(key, '')) for key in result_header) + '\n')
with open(os.path.join(report, 'request_errors.tsv'), 'w', encoding='utf-8') as handle:
    error_keys = (
        'timestamp', 'worker', 'request_seq', 'cycle', 'dataset_row',
        'http_status', 'header_code', 'error_types', 'error', 'query'
    )
    handle.write('\t'.join(error_keys) + '\n')
    for item in results:
        if not item['success']:
            handle.write('\t'.join(clean(item.get(key, '')) for key in error_keys) + '\n')

counts = {
    'success': sum(1 for item in results if item['success']),
    'business': sum(1 for item in results if 'business' in item['error_types']),
    'transport': sum(1 for item in results if item['transport_error']),
    'parser': sum(1 for item in results if item['parser_error']),
    'incomplete': sum(1 for item in results if item['incomplete_stream']),
    'oversized': sum(1 for item in results if item['oversized_response']),
}
expected = len(rows) if exact_once else 0
accounted = len(set(item['dataset_row'] for item in results)) if exact_once else 0
unaccounted = max(0, expected - accounted) if exact_once else 0
dataset_validation = 'NOT_APPLICABLE'
if exact_once:
    dataset_validation = 'PASS' if (
        state['dispatched'] == expected and state['completed'] == expected and
        accounted == expected and unaccounted == 0
    ) else 'FAIL'
all_pass = (
    counts['business'] == 0 and counts['transport'] == 0 and
    counts['parser'] == 0 and counts['incomplete'] == 0 and
    counts['oversized'] == 0 and not stop_event.is_set() and
    dataset_validation != 'FAIL'
)
run_status = 'PASS' if all_pass else (
    'INFRA_ABORTED' if stop_event.is_set() else 'FAIL'
)
with open(os.path.join(report, 'summary.txt'), 'w', encoding='utf-8') as handle:
    handle.write('run_status : %s\n' % run_status)
    handle.write('stream_mode : %s\n' % stream_text)
    handle.write('execution_mode : %s\n' % ('EXACT_ONCE' if exact_once else 'DURATION'))
    handle.write('dataset_rows : %d\n' % len(rows))
    handle.write('dispatched : %d\n' % state['dispatched'])
    handle.write('completed : %d\n' % state['completed'])
    handle.write('success : %d\n' % counts['success'])
    handle.write('business_failures : %d\n' % counts['business'])
    handle.write('transport_errors : %d\n' % counts['transport'])
    handle.write('parser_failures : %d\n' % counts['parser'])
    handle.write('incomplete_streams : %d\n' % counts['incomplete'])
    handle.write('oversized_responses : %d\n' % counts['oversized'])
    handle.write('accounted_rows : %d\n' % accounted)
    handle.write('unaccounted_rows : %d\n' % unaccounted)
    handle.write('dataset_validation : %s\n' % dataset_validation)
    handle.write('jmeter_failures : %d\n' % (
        counts['business'] + counts['parser'] +
        counts['incomplete'] + counts['oversized']
    ))
with open(summary_env, 'w', encoding='utf-8') as handle:
    handle.write('run_status=%s\n' % run_status)
    handle.write('dispatched=%d\n' % state['dispatched'])
    handle.write('completed=%d\n' % state['completed'])
    handle.write('success=%d\n' % counts['success'])
    handle.write('business_failures=%d\n' % counts['business'])
    handle.write('transport_failures=%d\n' % counts['transport'])
    handle.write('parser_failures=%d\n' % counts['parser'])
    handle.write('incomplete_streams=%d\n' % counts['incomplete'])
    handle.write('oversized_responses=%d\n' % counts['oversized'])
    handle.write('accounted_rows=%d\n' % accounted)
    handle.write('unaccounted_rows=%d\n' % unaccounted)
    handle.write('dataset_validation=%s\n' % dataset_validation)
print('dispatched=%d' % state['dispatched'])
print('completed=%d' % state['completed'])
for key in ('success', 'business', 'transport', 'parser', 'incomplete', 'oversized'):
    print('%s=%d' % (key, counts[key]))
print('dataset_validation=%s' % dataset_validation)
raise SystemExit(0 if run_status == 'PASS' else 3)
PY
  local engine_rc=$?
  set -e

  local after_cid="" after_pid="" after_state="" after_fp=""
  if [[ -n "$MONITOR_SSH" ]]; then
    remote_snapshot > "$core_after" || true
    cat "$core_after"
    after_cid="$(get_field "$core_after" container_id)"
    after_pid="$(get_field "$core_after" cu_pid)"
    after_state="$(get_field "$core_after" container_state)"
    after_fp="$(get_field "$core_after" core_fingerprint)"
  fi

  local run_status business_fail transport_fail parser_fail
  local incomplete_streams oversized_responses unaccounted
  run_status="$(get_field "$engine_summary" run_status)"
  business_fail="$(get_field "$engine_summary" business_failures)"
  transport_fail="$(get_field "$engine_summary" transport_failures)"
  parser_fail="$(get_field "$engine_summary" parser_failures)"
  incomplete_streams="$(get_field "$engine_summary" incomplete_streams)"
  oversized_responses="$(get_field "$engine_summary" oversized_responses)"
  unaccounted="$(get_field "$engine_summary" unaccounted_rows)"

  local result="PASS"
  if [[ -n "$MONITOR_SSH" && "$after_state" != "running" ]]; then
    result="CRASH_OR_EXIT"
  elif [[ -n "$MONITOR_SSH" && "$before_cid" != "$after_cid" ]]; then
    result="CONTAINER_CHANGED"
  elif [[ -n "$MONITOR_SSH" && "$before_pid" != "$after_pid" ]]; then
    result="PID_CHANGED"
  elif [[ -n "$before_fp" && -n "$after_fp" && "$before_fp" != "$after_fp" ]]; then
    result="NEW_CORE_DETECTED"
  elif (( transport_fail > 0 )); then result="TRANSPORT_FAIL"
  elif (( parser_fail > 0 )); then result="PARSER_FAIL"
  elif (( incomplete_streams > 0 )); then result="INCOMPLETE_STREAM"
  elif (( business_fail > 0 )); then result="BUSINESS_FAIL"
  elif (( oversized_responses > 0 )); then result="OVERSIZED_RESPONSE"
  elif (( EXACT_ONCE == 1 && unaccounted > 0 )); then result="UNACCOUNTED_ROWS"
  elif [[ "$run_status" != "PASS" || "$engine_rc" != 0 ]]; then result="ENGINE_FAIL"
  fi

  {
    echo "url=$URL"
    echo "csv=$CSV_FILE"
    echo "stream_mode=$STREAM_MODE"
    echo "exact_once=$EXACT_ONCE"
    echo "session_prefix=$SESSION_PREFIX"
    echo "workers=$CONCURRENCY"
    echo "duration=$DURATION_SECONDS"
    echo "connect_timeout=$CONNECT_TIMEOUT"
    echo "response_timeout=$RESPONSE_TIMEOUT"
    echo "max_response_bytes=$MAX_RESPONSE_BYTES"
    echo "test_scope=$TEST_SCOPE"
  } > "$report/config.txt"
  postprocess_stress "$report" "$report/case_map.tsv"
  {
    echo "runtime_result : $result"
    echo "before_container : $before_cid"
    echo "after_container : $after_cid"
    echo "before_pid : $before_pid"
    echo "after_pid : $after_pid"
    echo "core_before : $before_fp"
    echo "core_after : $after_fp"
  } >> "$report/summary.txt"

  echo "[DONE] report directory : $report"
  echo "[DONE] stress report: $report"
  [[ "$result" == "PASS" ]]
}

run_histories() {
  [[ -f "$HISTORY_COMPARATOR" && -r "$HISTORY_COMPARATOR" ]] || \
    die "histories comparator not found: $HISTORY_COMPARATOR"
  if [[ "$HISTORY_CASES" != /* ]]; then
    HISTORY_CASES="$SELF_DIR/$HISTORY_CASES"
  fi
  [[ -f "$HISTORY_CASES" && -r "$HISTORY_CASES" ]] || \
    die "histories cases not found: $HISTORY_CASES"

  local -a command=(
    python3 "$HISTORY_COMPARATOR"
    --case-id "$HISTORY_CASE_ID"
    --cases "$HISTORY_CASES"
    --url-9999 "$HISTORY_URL_9999"
    --url-9530 "$HISTORY_URL_9530"
  )
  if (( HISTORY_FORCE_STREAM_FALSE == 1 )); then
    command+=(--force-stream-false)
  fi
  echo "[HISTORIES] comparator=$HISTORY_COMPARATOR"
  echo "[HISTORIES] case_id=$HISTORY_CASE_ID"
  echo "[HISTORIES] cases=$HISTORY_CASES"
  (cd "$SELF_DIR" && "${command[@]}")
}

case "$MODE" in
  single)
    run_single
    ;;
  stress)
    run_stress
    ;;
  histories)
    run_histories
    ;;
esac
