# Dev Redis Context Operations

Run from the `wtp184-redis-context` Skill directory, or pass an absolute script/output path. Select the dev target explicitly.

## Environment

Bash:

```bash
export REDIS_HOST='<dev-redis-host>'
export REDIS_PORT='<dev-redis-port>'
```

PowerShell:

```powershell
$env:REDIS_HOST = '<dev-redis-host>'
$env:REDIS_PORT = '<dev-redis-port>'
```

`--host` and `--port` override the environment. The tool fails without a host selection.

## Inspect one replay session

```bash
python3 scripts/redis_context.py inspect \
  --session-id '<replay-session-id>' \
  --request-id '<request-id>'
```

## Save exact request fields

```bash
python3 scripts/redis_context.py snapshot \
  --session-id '<replay-session-id>' \
  --request-id '<round-1-request-id>' \
  --request-id '<round-2-request-id>' \
  --output '/protected/output/redis-snapshot.json'
```

## Watch briefly after a replay round

```bash
python3 scripts/redis_context.py watch \
  --session-id '<replay-session-id>' \
  --request-id '<round-1-request-id>' \
  --duration 5 \
  --interval 0.2
```

The command timeout, watch duration, and interval are bounded CLI values. Capture `AFTER_R1` before sending round 2 when a before/after comparison is required.

## Read-only redis-cli equivalents

```bash
SID='<session-id>'
QUERY_KEY="dialog_context_Query:${SID}"
TURN_KEY="dialog_context_${SID}"

redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" TYPE "$QUERY_KEY"
redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" TTL "$QUERY_KEY"
redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" HLEN "$QUERY_KEY"
redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" HKEYS "$QUERY_KEY"
redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" --raw HGET "$QUERY_KEY" '<request-id>'
```
