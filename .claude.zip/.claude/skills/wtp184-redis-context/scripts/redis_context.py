#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inspect WTP184 dev Redis dialogue context with read-only commands."""

from __future__ import print_function

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
import time


DEFAULT_HOST = os.environ.get("REDIS_HOST")
DEFAULT_PORT = os.environ.get("REDIS_PORT")
READ_ONLY_COMMANDS = frozenset((
    "GET", "HGET", "HKEYS", "HLEN", "TTL", "TYPE"
))


def eprint(*args):
    print(*args, file=sys.stderr)


def require_text(name, value):
    if value is None or not str(value).strip():
        raise ValueError("%s is required" % name)
    value = str(value).strip()
    if any(ord(char) < 32 for char in value):
        raise ValueError("%s contains a control character" % name)
    return value


def port_value(value):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise argparse.ArgumentTypeError("must be an integer")
    if parsed < 1 or parsed > 65535:
        raise argparse.ArgumentTypeError("must be between 1 and 65535")
    return parsed


def bounded_float(name, minimum, maximum):
    def parse(value):
        try:
            parsed = float(value)
        except (TypeError, ValueError):
            raise argparse.ArgumentTypeError("must be a number")
        if parsed < minimum or parsed > maximum:
            raise argparse.ArgumentTypeError(
                "%s must be between %s and %s" %
                (name, minimum, maximum)
            )
        return parsed
    return parse


def require_output_path(value):
    path = os.path.abspath(require_text("--output", value))
    parent = os.path.dirname(path) or os.getcwd()
    if not os.path.isdir(parent):
        raise ValueError("output directory does not exist: %s" % parent)
    if os.path.isdir(path):
        raise ValueError("output path is a directory: %s" % path)
    return path


def context_keys(session_id):
    return (
        "dialog_context_" + session_id,
        "dialog_context_Query:" + session_id
    )


def call_redis(host, port, timeout, *args):
    if not args:
        raise ValueError("Redis command is required")
    command = str(args[0]).upper()
    if command not in READ_ONLY_COMMANDS:
        raise ValueError("Redis command is not read-only: %s" % command)

    cmd = [
        "redis-cli", "-h", host, "-p", str(port), "--raw"
    ] + list(args)
    try:
        completed = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError(
            "redis-cli %s timed out after %.3f seconds" %
            (command, timeout)
        )
    except OSError as exc:
        raise RuntimeError("redis-cli unavailable: %s" % exc)

    stdout = completed.stdout.decode("utf-8", "replace")
    stderr = completed.stderr.decode("utf-8", "replace").strip()
    if completed.returncode != 0:
        raise RuntimeError(
            stderr or "redis-cli %s failed with exit %d" %
            (command, completed.returncode)
        )
    return stdout.rstrip("\r\n")


def parse_json(value):
    if not value:
        return None
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return None


def capture_field(host, port, timeout, query_key, request_id, known_fields):
    raw = call_redis(host, port, timeout, "HGET", query_key, request_id)
    return {
        "exists": request_id in known_fields,
        "raw": raw,
        "json": parse_json(raw)
    }


def capture(host, port, timeout, session_id, request_ids):
    turn_key, query_key = context_keys(session_id)
    raw_hkeys = call_redis(host, port, timeout, "HKEYS", query_key)
    query_hkeys = raw_hkeys.splitlines() if raw_hkeys else []
    known_fields = frozenset(query_hkeys)
    unique_request_ids = tuple(request_ids)
    fields = {
        request_id: capture_field(
            host, port, timeout, query_key, request_id, known_fields
        )
        for request_id in unique_request_ids
    }

    return {
        "captured_at": dt.datetime.now().isoformat(),
        "redis_host": host,
        "redis_port": port,
        "session_id": session_id,
        "turn_key": turn_key,
        "query_key": query_key,
        "turn_type": call_redis(host, port, timeout, "TYPE", turn_key),
        "turn_ttl": call_redis(host, port, timeout, "TTL", turn_key),
        "query_type": call_redis(host, port, timeout, "TYPE", query_key),
        "query_ttl": call_redis(host, port, timeout, "TTL", query_key),
        "query_hlen": call_redis(host, port, timeout, "HLEN", query_key),
        "query_hkeys": query_hkeys,
        "fields": fields
    }


def print_capture(obj):
    print(
        "TURN_KEY=%s TYPE=%s TTL=%s" %
        (obj["turn_key"], obj["turn_type"], obj["turn_ttl"])
    )
    print(
        "QUERY_KEY=%s TYPE=%s TTL=%s HLEN=%s" %
        (
            obj["query_key"], obj["query_type"],
            obj["query_ttl"], obj["query_hlen"]
        )
    )
    print("HKEYS=%s" % json.dumps(obj["query_hkeys"], ensure_ascii=False))
    for request_id, item in obj["fields"].items():
        if not item["exists"]:
            print("FIELD %s => <missing>" % request_id)
            continue
        value = item["json"]
        if isinstance(value, dict):
            print(
                "FIELD %s => response=%r status=%r text=%r "
                "normalized_query=%r" %
                (
                    request_id, value.get("response"), value.get("status"),
                    value.get("text"), value.get("normalized_query")
                )
            )
        else:
            print("FIELD %s => %s" % (request_id, item["raw"]))


def write_json(path, obj):
    temporary = "%s.tmp.%d" % (path, os.getpid())
    try:
        with open(temporary, "w", encoding="utf-8") as output_file:
            json.dump(obj, output_file, ensure_ascii=False, indent=2)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def add_common(parser):
    parser.add_argument(
        "--host",
        default=DEFAULT_HOST,
        help="Redis host; defaults to REDIS_HOST."
    )
    parser.add_argument(
        "--port",
        type=port_value,
        default=DEFAULT_PORT,
        help="Redis port; defaults to REDIS_PORT."
    )
    parser.add_argument("--session-id", required=True)
    parser.add_argument("--request-id", action="append", default=[])
    parser.add_argument(
        "--command-timeout",
        type=bounded_float("--command-timeout", 0.1, 60.0),
        default=5.0,
        help="Per-command timeout in seconds (0.1-60; default: 5)."
    )


def parse_args():
    parser = argparse.ArgumentParser(
        description="Inspect WTP184 dev Redis dialogue context."
    )
    subparsers = parser.add_subparsers(dest="command")

    inspect_parser = subparsers.add_parser("inspect")
    add_common(inspect_parser)

    snapshot_parser = subparsers.add_parser("snapshot")
    add_common(snapshot_parser)
    snapshot_parser.add_argument("--output", required=True)

    watch_parser = subparsers.add_parser("watch")
    add_common(watch_parser)
    watch_parser.add_argument(
        "--duration",
        type=bounded_float("--duration", 0.0, 300.0),
        default=5.0,
        help="Watch duration in seconds (0-300; default: 5)."
    )
    watch_parser.add_argument(
        "--interval",
        type=bounded_float("--interval", 0.05, 60.0),
        default=0.2,
        help="Watch interval in seconds (0.05-60; default: 0.2)."
    )
    return parser, parser.parse_args()


def validated_common(args):
    host = require_text("--host or REDIS_HOST", args.host)
    if args.port is None:
        raise ValueError("--port or REDIS_PORT is required")
    port = port_value(args.port)
    session_id = require_text("--session-id", args.session_id)
    request_ids = tuple(
        require_text("--request-id", request_id)
        for request_id in args.request_id
    )
    return host, port, session_id, request_ids


def main():
    parser, args = parse_args()
    if not args.command:
        parser.print_help()
        return 2

    host, port, session_id, request_ids = validated_common(args)

    if args.command in ("inspect", "snapshot"):
        obj = capture(
            host, port, args.command_timeout, session_id, request_ids
        )
        print_capture(obj)
        if args.command == "snapshot":
            output_path = require_output_path(args.output)
            write_json(output_path, obj)
            print("output=%s" % output_path)
        return 0

    deadline = time.monotonic() + args.duration
    last_signature = None
    while True:
        obj = capture(
            host, port, args.command_timeout, session_id, request_ids
        )
        signature = json.dumps(
            {
                "type": obj["query_type"],
                "ttl": obj["query_ttl"],
                "hlen": obj["query_hlen"],
                "fields": obj["fields"]
            },
            ensure_ascii=False,
            sort_keys=True
        )
        if signature != last_signature:
            print("\n=== %s ===" % dt.datetime.now().isoformat())
            print_capture(obj)
            last_signature = signature
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        time.sleep(min(args.interval, remaining))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError) as exc:
        eprint("ERROR: %s" % exc)
        sys.exit(1)
