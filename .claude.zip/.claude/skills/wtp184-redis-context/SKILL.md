---
name: wtp184-redis-context
description: Use for read-only inspection of WTP184 dev Redis dialogue context, Query history, TTL behavior, replay state, and correlation of Redis Query.response with dev HTTP or SSE evidence.
---

# WTP184 Redis Context

Read `.claude/workflows/wtp184-workflow.md` and use the current execution route and the existing `wtp184-server-operator` controls. This Skill supplies Redis-context-specific evidence rules; it does not create a separate approval, preflight, or validation path.

## Environment boundary

Operate on a user-selected dev Redis target unless another environment is explicitly in scope. Supply `REDIS_HOST` and `REDIS_PORT` or the corresponding CLI arguments at execution time. Do not embed credentials in Skill files or generated commands.

## Key model

`RedisContextManager::BuildKey` adds the physical prefix `dialog_context_`.

```text
Turn context:
  <session_id>
  -> dialog_context_<session_id>

Query history:
  Query:<session_id>
  -> dialog_context_Query:<session_id>
```

Expected storage shape:

- Turn key: normally a Redis `string`.
- Query key: a Redis `hash`.
- Query hash field: `request_id`.
- Query hash value: serialized Query JSON with fields such as `id`, `text`, `normalized_query`, `response`, `status`, and `first_wakeup`.

## TTL-sensitive capture

Dev context TTL is short and writes can refresh it. Capture automatically at the points that distinguish the suspected behavior:

```text
BEFORE_R1 -> AFTER_R1 -> AFTER_R2
```

Record `TYPE`, `TTL`, `HLEN`, `HKEYS`, and exact `HGET` values for the involved request IDs. Do not infer an overwrite from an empty final value alone; compare the same hash field before and after the relevant round.

For history/response diagnosis, correlate:

```text
R1 dev HTTP/SSE Dm.Text
R1 Redis Query.response after R1
R2 incoming histories.response
R1 Redis Query.response after R2
R2 Redis Query.response after R2
```

## Command boundary

The bundled tool uses read-only Redis commands: `TYPE`, `TTL`, `HLEN`, `HKEYS`, `HGET`, and `GET`. Do not broaden it to keyspace-wide scans or state mutation as part of ordinary diagnosis. A requested mutation is separate scope and must identify the dev target and exact key/field.

Use `scripts/redis_context.py` for immediate snapshots and bounded watches. See `references/OPERATIONS.md`.
