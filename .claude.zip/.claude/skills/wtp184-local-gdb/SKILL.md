---
name: wtp184-local-gdb
description: Debug a live WTP184 Dialogue V2 or V3 process interactively with GDB running on the same Linux host, using matching binaries, sources, initialization scripts, and focused breakpoints.
---

# WTP184 Local Interactive GDB

## Scope

Use this skill only for interactive, source-level debugging of a live WTP184
Dialogue V2 or V3 program when GDB and the inferior run on the same Linux host.
The primary host is `10.1.120.40`; `10.1.120.21` is also supported. Both hosts
use `/home/shared/models/`.

This skill covers focused investigation of NLU, `DialogueManager`, `FormTask`,
`FlowTask`, `SemanticMapper`, History, and request processing.

It does not cover core dumps, offline crash analysis, `gdbserver`, GDB
`target remote`, or remote-debug transport. Use `wtp184-core-debug` for core
analysis. Host access and runtime operation remain with the existing WTP184
session/operator workflow; once on the host, this GDB command runs locally.

## Known working entry point

Current V3-offline example on `10.1.120.40`:

```bash
SHELL=/bin/bash "$HOME/tools/wtp184-gdb/bin/wtp184-gdb" \
  -ix "$HOME/gdb/wtp184-cu-9531-v3_offline.gdb" \
  "$HOME/dialogue/bazel-bin/cu/server"
```

Treat every path as replaceable. Resolve the wrapper, initialization script,
binary, source tree, runtime configuration, and any breakpoint script on the
selected host. The example is not evidence that the same binary or script is
correct for V2, another V3 mode, or `10.1.120.21`.

## Establish the debug set

Before starting the inferior, establish one matching set:

```text
Dialogue version and mode
+ executable
+ source revision/tree
+ GDB initialization chain
+ runtime configuration and /home/shared/models/
+ task-specific breakpoint file
```

* Determine V2/V3 from the requested runtime and actual build/configuration;
  do not infer it from a filename alone.
* Never assume V2 and V3 share a binary merely because both use
  `bazel-bin/cu/server`.
* Canonicalize paths and record the executable build ID when one exists.
* Verify that the executable has usable debug symbols and maps the relevant
  function to the expected source file and line. Useful checks are `file`,
  `readelf -n`, GDB `info files`, `info functions <name>`, `info line <name>`,
  and `list <file>:<line>`.
* In GDB, inspect `show directories` and `show substitute-path` when source
  lookup is wrong. A resolvable symbol with mismatched source is not a valid
  debug set.
* If symbols are stripped, source does not match, or the V2/V3 identity is
  unresolved, stop and report the mismatch. Rebuilding or replacing artifacts
  is outside this skill unless separately requested.

## Initialization order

Inspect the wrapper and every relevant `.gdb` file before use, including files
reached through `source`. Keep initialization and task breakpoints conceptually
separate, and preserve existing scripts unless modification is requested.

`-ix` is GDB's early-init option under normal GDB semantics: it runs before the
inferior executable is loaded. Check whether the existing wrapper preserves or
changes that behavior. In particular, locate and reason about:

* `file` or other executable selection;
* `source` chains;
* `set breakpoint pending`;
* symbol or source breakpoints;
* `run` and commands that implicitly start the inferior.

Do not assume command-line position makes symbol-dependent commands in an
`-ix` file run after executable loading. If the working wrapper deliberately
defers them, preserve that convention. Otherwise, load or source focused
breakpoints at the established post-file point or enter them interactively.
Before `run`, use `info breakpoints` and confirm required breakpoints are
resolved or intentionally pending for a later shared-library load.

## Focused breakpoints

Inspect existing breakpoint scripts first. For example,
`wtp184-breakpoints-v2_1.gdb` is an existing V2 convention, not a V3 script by
implication.

* Prefer a task-specific `.gdb` file over accumulating commands in a shared
  script.
* Set breakpoints at the smallest relevant entry, branch, state transition, or
  dependency return point.
* Use `break <file>:<line>` or a sufficiently qualified C++ function name, then
  verify it with `info breakpoints`, `info address`, and `info line` as needed.
* Add a condition only when its expression is side-effect-free and valid in
  that frame. Never call application functions merely to filter a breakpoint.
* Avoid broad `rbreak` patterns and numerous breakpoints in hot request paths.
* Compare equivalent V2/V3 checkpoints in separate GDB runs with their own
  matching debug sets.

For a trace-only breakpoint, keep output bounded:

```gdb
break path/to/file.cc:line
condition $bpnum <side-effect-free request or state predicate>
commands
  silent
  printf "checkpoint=<fixed> state=%d\n", state
  bt 4
  continue
end
```

Print only small scalar fields needed by the investigation, disable the trace
once enough evidence is collected, and do not auto-continue when interactive
inspection is required.

## Inspect the right execution context

At every relevant stop, identify context before evaluating state:

```gdb
info threads
thread <N>
bt 8
frame <N>
info args
info locals
whatis <expr>
ptype <type-or-expr>
p <expr>
```

Record the selected thread and frame before switching, and reselect them when
returning. Use full `thread apply all bt` output only when the investigation
actually needs a process-wide thread view.

Before dereferencing a pointer, establish where it came from, whether it is
null or otherwise invalid, and whether the owning object is still alive. For
C++ objects, inspect only fields tied to the hypothesis rather than dumping the
whole object, vector, map, history, semantic result, or request payload.

Inspect values immediately before and after the relevant state change when
possible. Treat `<optimized out>`, inlined frames, unavailable memory, and
stale pointers as limitations in the evidence; do not reconstruct or guess a
value. Do not use GDB expressions that call inferior functions or otherwise
change application state. Never use `set var` unless the user explicitly asks
for a state-changing experiment.

## Minimal interactive procedure

1. Identify host, V2/V3 mode, and the matching debug set.
2. Inspect the wrapper, `-ix` ordering, initialization chain, and existing
   breakpoint scripts.
3. Locate the relevant implementation and choose minimal checkpoints.
4. Verify symbols, source mapping, and breakpoint resolution.
5. Start the existing local GDB entry point with the resolved paths and runtime
   configuration.
6. At each stop, select the correct thread and frame before inspecting focused
   arguments, locals, fields, and state transitions.
7. Keep GDB evidence separate from application logs and capture only what is
   needed to answer the investigation.
8. Report exact function and `path:line` evidence, plus any unresolved symbol,
   optimization, lifetime, or version limitation.

## Result format

Report concisely:

```text
HOST: <10.1.120.40|10.1.120.21>
DIALOGUE: <V2|V3 and mode>
DEBUG_SET: <binary/build-id, source root/revision, init and breakpoint scripts>
STOP: <thread, frame, function, path:line>
OBSERVED: <relevant before/after values and control flow>
CONCLUSION: <supported finding, hypothesis, or inconclusive>
LIMITATION: <optimized-out/mismatch/unresolved breakpoint/etc., if any>
```

Do not paste complete payloads, large container dumps, broad thread output, or
unbounded GDB transcripts into the result.
