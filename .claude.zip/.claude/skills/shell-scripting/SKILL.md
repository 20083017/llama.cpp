## Minimal Contract and Scope Discipline

When the user provides an explicit execution contract, treat it as the task boundary.

For example:

```text
Use ~/stress_test/zp_update_soak_csv_v5_2.5.sh as-is
with ~/stress_test/2w_data.csv.

Update only the local stress-test Skill.

Do not:
- audit or modify the remote script;
- inspect ~/.ssh;
- create helper scripts;
- start delegated agents;
- perform unrelated environment or security audits.

Validate only by directly running row 1 once.
```

Follow these rules:

* Prefer the smallest change that satisfies the request.
* Trust an explicitly identified working script unless the user asks to review or fix it.
* Do not expand a Skill-only task into script modification or infrastructure investigation.
* Do not inspect SSH, credentials, environment configuration, or unrelated files unless required by an observed failure.
* Do not create wrappers, helper scripts, diagnostics, or additional tooling unless necessary.
* Do not delegate simple, bounded work to additional agents.
* Perform only the validation needed to prove the requested change works.
* Escalate investigation only after the minimal validation actually fails.

A possible problem is not evidence of a problem.

Do not proactively investigate hypothetical SSH, security, compatibility, or remote-environment issues when the requested workflow already provides a direct validation path.

When the user specifies both the implementation boundary and validation command, execute that path first.
