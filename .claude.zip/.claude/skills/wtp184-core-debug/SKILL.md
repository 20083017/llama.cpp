---

name: wtp184-core-debug
description: Use validated WTP184 core-collection and GDB scripts to collect Docker core bundles, perform offline crash analysis, and map failures to source while keeping collection, analysis, and cleanup separate.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# WTP184 Core Debug

## Goal

Use this skill for WTP184 Docker core-dump collection, offline GDB analysis, and source-level crash localization.

Answer:

1. Was the core bundle collected successfully?
2. What signal terminated the process?
3. Which thread crashed?
4. What are the most relevant stack frames?
5. Can the stack be mapped to repository `path:line`?
6. Does the current evidence support a confirmed root cause?

## Validated scripts

Use the existing validated scripts:

```text
cu9530_crash_debug_bundle_2.sh
cu9530_gdb_core.sh
```

Treat each script's own `--help` output as the source of truth for its CLI, options, and invocation details.

When invocation details are needed, use:

```bash
<script> --help
```

Do not duplicate the complete CLI contract in this skill.

Do not modify these validated scripts unless the user explicitly requests a script change.

## Roles

* Core collection is a deployment-host operation owned by `wtp184-server-operator`.
* Core collection, GDB execution and bounded crash diagnosis are owned by `wtp184-server-operator`.
* The deployment host, container, and working locations are provided by the current session.
* Ordinary scoped SSH may be used when required to invoke the existing scripts or launcher.

## Core-debug flow

### 1. `core-preflight`

Confirm only what is required to start:

* the core-bundle directory is accessible;
* a core file exists;
* the GDB wrapper is available.

If the existing scripts already perform these checks, use their result instead of reimplementing the checks.

Do not run the actual GDB analysis in this phase.

### 2. `core-collect`

When a new core bundle is required, use:

```text
cu9530_crash_debug_bundle_2.sh
```

Determine its current invocation through:

```bash
cu9530_crash_debug_bundle_2.sh --help
```

The collector obtains the diagnostic resources required from the target container, including:

* core;
* runtime binary;
* required libraries;
* required debug resources;
* related diagnostic information.

The runtime binary is exported directly from the container that produced the core, so no separate binary-version matching workflow is required.

Record the bundle directory actually produced by the collector and pass it to the GDB-analysis phase.

Do not combine collection with:

* service restart;
* deployment;
* rollback;
* cleanup.

### 3. `core-gdb`

Use the validated:

```text
cu9530_gdb_core.sh
```

to perform offline GDB analysis on the bundle produced by the collector.

Determine the current invocation through:

```bash
cu9530_gdb_core.sh --help
```

Follow the script implementation and help output for:

* working directory;
* core location;
* runtime-binary location;
* library handling;
* symbol handling.

Prioritize:

* signal / termination reason;
* crashing thread;
* top relevant frames;
* WTP184 product-code call chain;
* function names;
* source `path:line`;
* symbol status.

If debug symbols are incomplete but the stack remains useful, report:

```text
PARTIAL
```

and continue analysis using the available stack evidence.

### 4. `core-gdb-summary`

When usable GDB output already exists, summarize the existing result first.

Do not rerun GDB merely to create a summary.

Prioritize:

* signal;
* crashing thread;
* relevant stack frames;
* function names;
* source `path:line`;
* symbol status.

## GDB analysis priorities

Analyze in this order:

1. signal / termination reason;
2. crashing thread;
3. top relevant frames;
4. first frame entering WTP184 product code;
5. corresponding function;
6. source `path:line`;
7. relevant call chain;
8. symbol status.

Expand to additional threads only when the failure appears related to:

* multi-threaded crashes;
* hangs;
* races or concurrency;
* lifetime problems;
* asynchronous callbacks;
* cross-thread object ownership.

Do not dump large unrelated thread sets or complete GDB output by default.

## Source analysis

When stack frames resolve to source, inspect the corresponding implementation.

Prioritize:

* crash-frame implementation;
* caller/callee relationship;
* pointer/reference lifetime;
* object ownership;
* container/iterator usage;
* asynchronous lifetime;
* thread safety;
* destructor / clear / release behavior;
* null or invalid objects;
* out-of-bounds access;
* use-after-free;
* double free;
* race conditions.

Tag important conclusions as:

```text
CODE-CONFIRMED
RUNTIME-CONFIRMED
PARTIAL
HYPOTHESIS
BLOCKED
```

Meaning:

* `CODE-CONFIRMED`: directly supported by source evidence;
* `RUNTIME-CONFIRMED`: directly supported by core/GDB evidence;
* `PARTIAL`: useful evidence exists but is incomplete;
* `HYPOTHESIS`: plausible explanation not yet directly proven;
* `BLOCKED`: required evidence is missing.

Never present a `HYPOTHESIS` as a confirmed root cause.

## Output

For successful analysis, prefer:

```text
STATUS: PASS|PARTIAL

SIGNAL:
<signal / termination reason>

CRASH_THREAD:
<thread>

TOP_FRAME:
<function + source path:line when available>

STACK:
<relevant call chain>

SYMBOLS:
<OK|PARTIAL|MISSING>

CONCLUSION:
<strongest conclusion supported by current evidence>

EVIDENCE_LEVEL:
<CODE-CONFIRMED|RUNTIME-CONFIRMED|PARTIAL|HYPOTHESIS>

NEXT_CHECK:
<one smallest next step when needed>
```

If analysis is blocked:

```text
STATUS: BLOCKED|FAIL

REASON:
<first actionable issue>

CONSEQUENCE:
<what cannot currently be concluded>

NEXT_CHECK:
<one smallest corrective or diagnostic step>

LOG:
<relevant log location when available>
```

Do not paste large raw GDB output into the final report.

## Output boundaries

Extract only the information required for crash diagnosis. Do not paste broad memory dumps or raw core contents into reports.

## Phase boundaries

Keep the workflow:

```text
Container
    ↓
Core Collector
    ↓
Core Bundle
    ├── Core
    ├── Runtime Binary
    ├── Libraries / Symbols
    └── Diagnostic Resources
    ↓
GDB Wrapper
    ↓
Backtrace
    ↓
Source Analysis
    ↓
Crash Conclusion
```

Core debugging does not automatically perform:

```text
Deployment
Service Restart
Rollback
Cleanup
Source Modification
Build
```

If the user later requests a source fix, build, deployment, or cleanup, route that work through the appropriate workflow or skill.

## Core principle

Prefer the validated scripts that already work in the environment.

Do not duplicate information exposed by the scripts through `--help`.

Do not add redundant hash validation, binary-version matching, path-identity checks, or complex preflight logic around trusted scripts and trusted core-bundle collection.

The primary job of this skill is:

```text
collect core bundle
→ obtain backtrace through the GDB wrapper
→ identify the critical crash frame
→ map it to source
→ analyze root cause
→ report an evidence-calibrated conclusion
```
