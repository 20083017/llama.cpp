#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Replay one exact two-round online/test session into dev with fresh IDs.

The script fetches exact original Post/Response evidence, preserves payload and
history values, remaps only replay IDs, consumes JSON or SSE output, and writes
one operator-selected evidence report. It is non-interactive unless
--pause-between-rounds is explicitly supplied.

Python 3.6+, standard library only.
"""

from __future__ import print_function

import argparse
import base64
import datetime as dt
import json
import os
import re
import ssl
import sys
import time
import uuid

try:
    from urllib import parse as urlparse
    from urllib import request as urlrequest
    from urllib import error as urlerror
except ImportError:
    raise


POST_RE = re.compile(
    r'handlers\.cc:348\]\s+Post request session_id=\[(.*?)\],\s*'
    r'request_id=\[(.*?)\],\s*payload=(\{.*\})\s*$'
)

RESP_RE = re.compile(
    r'handlers\.cc:(?:565|569)\]\s+Request session_id=\[(.*?)\],\s*'
    r'request_id=\[(.*?)\],\s*Response=(\{.*\})\s*$'
)
SAFE_INDEX_RE = re.compile(r"^[A-Za-z0-9._-]+$")


def compact_json(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def eprint(*args):
    print(*args, file=sys.stderr)


def positive_int(value):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise argparse.ArgumentTypeError("must be an integer")
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be greater than zero")
    return parsed


def require_text(name, value):
    if value is None or not str(value).strip():
        raise ValueError("%s is required" % name)
    return str(value).strip()


def require_http_url(name, value):
    value = require_text(name, value)
    parsed = urlparse.urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("%s must be an absolute http(s) URL" % name)
    return value.rstrip("/")


def require_index(value):
    value = require_text("--index", value)
    if not SAFE_INDEX_RE.match(value):
        raise ValueError("--index must select one bounded index")
    return value


def require_output_path(value):
    path = os.path.abspath(require_text("--output", value))
    parent = os.path.dirname(path) or os.getcwd()
    if not os.path.isdir(parent):
        raise ValueError("output directory does not exist: %s" % parent)
    if os.path.isdir(path):
        raise ValueError("output path is a directory: %s" % path)
    return path


class HttpClient(object):
    def __init__(self, user=None, password=None, insecure=False, timeout=90):
        self.user = user
        self.password = password
        self.timeout = timeout
        self.ctx = ssl._create_unverified_context() if insecure else ssl.create_default_context()

    def headers(self, content_type="application/json"):
        h = {
            "Content-Type": content_type,
            "Accept": "application/json",
            "kbn-xsrf": "true",
            "osd-xsrf": "true",
            "User-Agent": "wtp184-history-empty-replay-probe/1.0",
        }
        if self.user is not None and self.password is not None:
            raw = ("%s:%s" % (self.user, self.password)).encode("utf-8")
            h["Authorization"] = "Basic " + base64.b64encode(raw).decode("ascii")
        return h

    def request(self, url, method="GET", body=None, content_type="application/json"):
        if body is None:
            data = None
        elif isinstance(body, bytes):
            data = body
        elif isinstance(body, str):
            data = body.encode("utf-8")
        else:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")

        req = urlrequest.Request(
            url=url,
            data=data,
            headers=self.headers(content_type),
            method=method
        )
        try:
            resp = urlrequest.urlopen(req, timeout=self.timeout, context=self.ctx)
            return resp
        except urlerror.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            raise RuntimeError("HTTP %s for %s\n%s" % (exc.code, url, raw[:2000]))
        except urlerror.URLError as exc:
            raise RuntimeError("Connection failed for %s: %s" % (url, exc))


class KibanaBackend(object):
    def __init__(self, base_url, http):
        self.base_url = base_url.rstrip("/")
        self.http = http

    def search(self, index, body):
        qs = urlparse.urlencode({
            "path": "%s/_search" % index,
            "method": "POST"
        })
        url = self.base_url + "/api/console/proxy?" + qs
        resp = self.http.request(url, method="POST", body=body)
        raw = resp.read()
        resp.close()
        return json.loads(raw.decode("utf-8"))


def search_request(backend, index, request_id):
    body = {
        "size": 100,
        "track_total_hits": False,
        "_source": ["@timestamp", "message"],
        "sort": [{"@timestamp": {"order": "asc"}}],
        "query": {
            "bool": {
                "filter": [
                    {"match_phrase": {"message": request_id}},
                    {
                        "bool": {
                            "should": [
                                {"match_phrase": {"message": "handlers.cc:348"}},
                                {"match_phrase": {"message": "handlers.cc:565"}},
                                {"match_phrase": {"message": "handlers.cc:569"}}
                            ],
                            "minimum_should_match": 1
                        }
                    }
                ]
            }
        }
    }
    obj = backend.search(index, body)
    return obj.get("hits", {}).get("hits", []) or []


def parse_hits(hits, request_id):
    seen = set()
    posts = []
    responses = []

    for hit in hits:
        src = hit.get("_source") or {}
        msg = src.get("message")
        if not msg or msg in seen:
            continue
        seen.add(msg)

        m = POST_RE.search(msg)
        if m and m.group(2) == request_id:
            try:
                payload = json.loads(m.group(3))
            except Exception:
                continue
            posts.append({
                "session_id": m.group(1),
                "request_id": m.group(2),
                "payload": payload,
                "at_timestamp": src.get("@timestamp")
            })
            continue

        m = RESP_RE.search(msg)
        if m and m.group(2) == request_id:
            try:
                response = json.loads(m.group(3))
            except Exception:
                continue
            responses.append({
                "session_id": m.group(1),
                "request_id": m.group(2),
                "response": response,
                "at_timestamp": src.get("@timestamp")
            })

    return posts, responses


def choose_one(items, kind, request_id):
    if not items:
        raise RuntimeError("%s not found for request_id=%s" % (kind, request_id))

    canonical = []
    for item in items:
        comparable = dict(item)
        comparable.pop("at_timestamp", None)
        canonical.append(compact_json(comparable))
    if len(set(canonical)) != 1:
        raise RuntimeError(
            "ambiguous non-identical %s entries for request_id=%s" %
            (kind, request_id)
        )
    return items[0]


def flatten_response(response):
    payload = response.get("Payload") if isinstance(response, dict) else None
    if not isinstance(payload, dict):
        return []
    semantic = payload.get("Semantic")
    if isinstance(semantic, dict):
        semantics = [semantic]
    elif isinstance(semantic, list):
        semantics = semantic
    else:
        return []

    out = []
    for sem in semantics:
        if not isinstance(sem, dict):
            continue
        results = sem.get("Results")
        if not isinstance(results, list):
            continue
        for r in results:
            if not isinstance(r, dict):
                continue
            dm = r.get("Dm") if isinstance(r.get("Dm"), dict) else {}
            nlu = r.get("Nlu") if isinstance(r.get("Nlu"), dict) else {}
            out.append({
                "index": r.get("Index"),
                "query": sem.get("Query"),
                "sub_query": r.get("SubQuery"),
                "dm_text": dm.get("Text"),
                "domain": nlu.get("Domain"),
                "intent": nlu.get("Intent"),
                "is_rejected": r.get("IsRejected")
            })
    return out


def replay_post(url, payload, timeout, insecure):
    body = compact_json(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "text/event-stream, application/json",
        "User-Agent": "wtp184-history-empty-replay-probe/1.0"
    }
    req = urlrequest.Request(url, data=body, headers=headers, method="POST")
    ctx = ssl._create_unverified_context() if insecure else ssl.create_default_context()
    t0 = time.time()

    try:
        resp = urlrequest.urlopen(req, timeout=timeout, context=ctx)
    except Exception as exc:
        return {
            "ok": False,
            "error": "%s:%s" % (type(exc).__name__, exc),
            "elapsed_ms": round((time.time() - t0) * 1000.0, 3)
        }

    http_status = resp.getcode()
    content_type = resp.headers.get("Content-Type", "")
    events = []
    parse_errors = []

    try:
        if "text/event-stream" in content_type.lower():
            data_lines = []

            def flush():
                if not data_lines:
                    return
                text = "\n".join(data_lines)
                del data_lines[:]
                if text.strip() == "[DONE]":
                    return
                try:
                    events.append(json.loads(text))
                except Exception as exc:
                    parse_errors.append({
                        "raw": text,
                        "error": str(exc)
                    })

            while True:
                raw = resp.readline()
                if not raw:
                    break
                line = raw.decode("utf-8", "replace").rstrip("\r\n")
                if line == "":
                    flush()
                elif line.startswith("data:"):
                    value = line[5:]
                    if value.startswith(" "):
                        value = value[1:]
                    data_lines.append(value)
            flush()
        else:
            raw = resp.read().decode("utf-8", "replace")
            try:
                events.append(json.loads(raw))
            except Exception as exc:
                parse_errors.append({
                    "raw": raw,
                    "error": str(exc)
                })
    finally:
        resp.close()

    final = events[-1] if events else None
    return {
        "ok": True,
        "http_status": http_status,
        "content_type": content_type,
        "elapsed_ms": round((time.time() - t0) * 1000.0, 3),
        "event_count": len(events),
        "parse_errors": parse_errors,
        "events": events,
        "final_response": final,
        "final_semantics": flatten_response(final or {})
    }


def pause(label, replay_session_id):
    print("")
    print("=== %s ===" % label)
    print("replay_session_id=%s" % replay_session_id)
    print("Inspect Redis now using this replay_session_id.")
    try:
        input("Press ENTER to continue...")
    except EOFError:
        pass


def parse_args():
    p = argparse.ArgumentParser(
        description="Replay one exact two-round online/test session into dev."
    )
    p.add_argument(
        "--kibana",
        default=os.environ.get("KIBANA_URL"),
        help="Kibana base URL; defaults to KIBANA_URL."
    )
    p.add_argument(
        "--user",
        default=os.environ.get("KIBANA_USER"),
        help="Kibana user; defaults to KIBANA_USER."
    )
    p.add_argument("--index", required=True)
    p.add_argument("--dev-url", required=True)
    p.add_argument("--r1-request-id", required=True)
    p.add_argument("--r2-request-id", required=True)
    p.add_argument("--session-prefix", default="history_pair_replay")
    p.add_argument("--timeout", type=positive_int, default=30)
    p.add_argument("--insecure", action="store_true")
    p.add_argument("--pause-between-rounds", action="store_true")
    p.add_argument("--output", required=True)
    return p.parse_args()


def main():
    args = parse_args()

    args.kibana = require_http_url("--kibana or KIBANA_URL", args.kibana)
    args.user = require_text("--user or KIBANA_USER", args.user)
    args.index = require_index(args.index)
    args.dev_url = require_http_url("--dev-url", args.dev_url)
    args.r1_request_id = require_text("--r1-request-id", args.r1_request_id)
    args.r2_request_id = require_text("--r2-request-id", args.r2_request_id)
    args.session_prefix = require_text("--session-prefix", args.session_prefix)
    output = require_output_path(args.output)
    if args.r1_request_id == args.r2_request_id:
        raise ValueError("round request IDs must be different")

    password = os.environ.get("KIBANA_PASSWORD")
    if password is None or password == "":
        raise ValueError("KIBANA_PASSWORD is required")

    kibana_http = HttpClient(
        user=args.user,
        password=password,
        insecure=args.insecure,
        timeout=args.timeout
    )
    backend = KibanaBackend(args.kibana, kibana_http)

    r1_hits = search_request(backend, args.index, args.r1_request_id)
    r2_hits = search_request(backend, args.index, args.r2_request_id)

    r1_posts, r1_responses = parse_hits(r1_hits, args.r1_request_id)
    r2_posts, r2_responses = parse_hits(r2_hits, args.r2_request_id)

    r1_post = choose_one(r1_posts, "R1 POST", args.r1_request_id)
    r2_post = choose_one(r2_posts, "R2 POST", args.r2_request_id)
    prod_r1_resp = choose_one(r1_responses, "R1 production response", args.r1_request_id)
    prod_r2_resp = (
        choose_one(r2_responses, "R2 production response", args.r2_request_id)
        if r2_responses else None
    )

    replay_session_id = "%s_%s_%s" % (
        args.session_prefix,
        dt.datetime.now().strftime("%Y%m%d%H%M%S"),
        uuid.uuid4().hex[:8]
    )
    replay_r1_request_id = replay_session_id + "_1"
    replay_r2_request_id = replay_session_id + "_2"

    r1_payload = json.loads(json.dumps(r1_post["payload"], ensure_ascii=False))
    r2_payload = json.loads(json.dumps(r2_post["payload"], ensure_ascii=False))

    r1_payload["session_id"] = replay_session_id
    r1_payload["request_id"] = replay_r1_request_id

    r2_payload["session_id"] = replay_session_id
    r2_payload["request_id"] = replay_r2_request_id

    histories = r2_payload.get("histories")
    if not isinstance(histories, list):
        raise RuntimeError("R2 has no histories[]; unexpected for this probe case")

    remapped_history_ids = 0
    for item in histories:
        if not isinstance(item, dict):
            continue
        if item.get("id") == args.r1_request_id:
            item["id"] = replay_r1_request_id
            remapped_history_ids += 1
    if remapped_history_ids == 0:
        raise RuntimeError(
            "R2 histories[] does not reference the selected R1 request ID"
        )

    print("=== PRODUCTION EVIDENCE ===")
    print("R1 original query=%s" % r1_post["payload"].get("query"))
    print("R1 production semantics=%s" % compact_json(
        flatten_response(prod_r1_resp["response"])
    ))
    print("R2 original query=%s" % r2_post["payload"].get("query"))
    print("R2 original histories=%s" % compact_json(r2_post["payload"].get("histories")))
    print("")
    print("=== REPLAY IDS ===")
    print("session_id=%s" % replay_session_id)
    print("R1 request_id=%s" % replay_r1_request_id)
    print("R2 request_id=%s" % replay_r2_request_id)

    print("")
    print("=== REPLAY R1 ===")
    r1_result = replay_post(
        args.dev_url, r1_payload, args.timeout, args.insecure
    )
    print(compact_json({
        "ok": r1_result.get("ok"),
        "http_status": r1_result.get("http_status"),
        "elapsed_ms": r1_result.get("elapsed_ms"),
        "event_count": r1_result.get("event_count"),
        "final_semantics": r1_result.get("final_semantics"),
        "error": r1_result.get("error")
    }))

    if args.pause_between_rounds:
        pause("AFTER R1", replay_session_id)

    print("")
    print("=== REPLAY R2 ===")
    print("R2 replay histories=%s" % compact_json(r2_payload.get("histories")))
    r2_result = replay_post(
        args.dev_url, r2_payload, args.timeout, args.insecure
    )
    print(compact_json({
        "ok": r2_result.get("ok"),
        "http_status": r2_result.get("http_status"),
        "elapsed_ms": r2_result.get("elapsed_ms"),
        "event_count": r2_result.get("event_count"),
        "final_semantics": r2_result.get("final_semantics"),
        "error": r2_result.get("error")
    }))

    evidence = {
        "metadata": {
            "generated_at": dt.datetime.now().isoformat(),
            "production_index": args.index,
            "dev_url": args.dev_url,
            "replay_session_id": replay_session_id,
            "replay_r1_request_id": replay_r1_request_id,
            "replay_r2_request_id": replay_r2_request_id,
        },
        "production": {
            "r1_post": r1_post,
            "r1_response": prod_r1_resp,
            "r2_post": r2_post,
            "r2_response": prod_r2_resp,
        },
        "replay": {
            "r1_payload": r1_payload,
            "r1_result": r1_result,
            "r2_payload": r2_payload,
            "r2_result": r2_result,
        }
    }

    with open(output, "w", encoding="utf-8") as f:
        json.dump(evidence, f, ensure_ascii=False, indent=2)

    print("")
    print("DONE")
    print("output=%s" % output)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError) as exc:
        eprint("ERROR: %s" % exc)
        sys.exit(1)
