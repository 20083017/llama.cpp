#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Audit WTP184 request.histories for empty response strings and verify whether
the referenced previous server response was really empty.

Source rules:
  handlers.cc:348 -> original client POST payload (authoritative histories)
  handlers.cc:565/569 -> original server Response

The script:
  1. Scans the requested business date for POSTs containing histories.
  2. Parses the JSON payload client-side (avoids brittle ES text matching).
  3. Finds history items whose response is exactly "".
  4. For each empty item, looks up the history item's id as the previous
     request_id, across one or more indices.
  5. Fetches both previous POST and previous Response logs.
  6. Extracts Dm.Text from the previous server Response and classifies:
       VERIFIED_SERVER_EMPTY
       CLIENT_EMPTY_SERVER_NONEMPTY
       PREVIOUS_RESPONSE_NOT_FOUND
       HISTORY_ID_MISSING
       AMBIGUOUS_RESPONSE_MAPPING
  7. Writes a JSON report containing the evidence.

Python: 3.6+
Dependencies: standard library only.
"""

from __future__ import print_function

import argparse
import base64
import datetime as dt
import json
import os
import re
import ssl
import sys

try:
    from urllib import parse as urlparse
    from urllib import request as urlrequest
    from urllib import error as urlerror
except ImportError:
    raise


POST_RE = re.compile(
    r'handlers\.cc:348\]\s+Post request session_id=\[(.*?)\],\s*'
    r'request_id=\[(.*?)\],\s*payload=(\{.*\})\s*$'
)

RESP_RE = re.compile(
    r'handlers\.cc:(?:565|569)\]\s+Request session_id=\[(.*?)\],\s*'
    r'request_id=\[(.*?)\],\s*Response=(\{.*\})\s*$'
)

BUSINESS_TS_RE = re.compile(
    r'I(?P<date>\d{8})\s+(?P<time>\d{2}:\d{2}:\d{2})\.*(?P<frac>\d{1,9})'
)
SAFE_INDEX_RE = re.compile(r"^[A-Za-z0-9._,-]+$")


def eprint(*args):
    print(*args, file=sys.stderr)


def compact_json(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def positive_int(value):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise argparse.ArgumentTypeError("must be an integer")
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be greater than zero")
    return parsed


def require_text(name, value):
    if value is None or not str(value).strip():
        raise ValueError("%s is required" % name)
    return str(value).strip()


def require_http_url(name, value):
    value = require_text(name, value)
    parsed = urlparse.urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("%s must be an absolute http(s) URL" % name)
    return value.rstrip("/")


def require_business_date(value):
    value = require_text("--business-date", value)
    try:
        dt.datetime.strptime(value, "%Y%m%d")
    except ValueError:
        raise ValueError("--business-date must use YYYYMMDD")
    return value


def require_index_expression(name, value, allow_multiple=False):
    value = require_text(name, value)
    if not SAFE_INDEX_RE.match(value):
        raise ValueError("%s contains unsupported characters" % name)
    if not allow_multiple and "," in value:
        raise ValueError("%s must select one index" % name)
    if allow_multiple and any(not part for part in value.split(",")):
        raise ValueError("%s contains an empty index" % name)
    return value


def require_output_path(value):
    path = os.path.abspath(require_text("--output", value))
    parent = os.path.dirname(path) or os.getcwd()
    if not os.path.isdir(parent):
        raise ValueError("output directory does not exist: %s" % parent)
    if os.path.isdir(path):
        raise ValueError("output path is a directory: %s" % path)
    return path


def parse_business_dt(message):
    m = BUSINESS_TS_RE.search(message or "")
    if not m:
        return None
    frac = m.group("frac")
    frac = frac[:6].ljust(6, "0")
    text = "%s %s.%s" % (m.group("date"), m.group("time"), frac)
    try:
        return dt.datetime.strptime(text, "%Y%m%d %H:%M:%S.%f")
    except ValueError:
        return None


def iso(v):
    return v.strftime("%Y-%m-%dT%H:%M:%S.%f") if v else None


def parse_post(message, at_timestamp=None):
    m = POST_RE.search(message or "")
    if not m:
        return None
    try:
        payload = json.loads(m.group(3))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    return {
        "kind": "post",
        "session_id": m.group(1),
        "request_id": m.group(2),
        "payload": payload,
        "business_dt": parse_business_dt(message),
        "at_timestamp": at_timestamp,
        "message": message,
    }


def parse_response(message, at_timestamp=None):
    m = RESP_RE.search(message or "")
    if not m:
        return None
    try:
        response = json.loads(m.group(3))
    except Exception:
        return None
    if not isinstance(response, dict):
        return None
    return {
        "kind": "response",
        "session_id": m.group(1),
        "request_id": m.group(2),
        "response": response,
        "business_dt": parse_business_dt(message),
        "at_timestamp": at_timestamp,
        "message": message,
    }


def flatten_response_results(response):
    payload = response.get("Payload") if isinstance(response, dict) else None
    if not isinstance(payload, dict):
        return []
    semantic = payload.get("Semantic")
    if isinstance(semantic, dict):
        semantics = [semantic]
    elif isinstance(semantic, list):
        semantics = semantic
    else:
        return []

    out = []
    for sem in semantics:
        if not isinstance(sem, dict):
            continue
        query = sem.get("Query")
        results = sem.get("Results")
        if not isinstance(results, list):
            continue
        for result in results:
            if not isinstance(result, dict):
                continue
            dm = result.get("Dm")
            dm = dm if isinstance(dm, dict) else {}
            command = (
                dm.get("Skill", {}).get("Command", {})
                if isinstance(dm.get("Skill"), dict) else {}
            )
            text_list = command.get("TextList") if isinstance(command, dict) else None
            out.append({
                "index": result.get("Index"),
                "query": query,
                "sub_query": result.get("SubQuery"),
                "is_rejected": result.get("IsRejected"),
                "dm_text": dm.get("Text"),
                "text_list": text_list if isinstance(text_list, list) else [],
            })
    return out


def result_text_state(result):
    """
    Return True when the server result is definitely text-empty, False when
    it contains response text, and None when the representation is unclear.

    Dm.Text is the primary history-response source. TextList is also checked
    so a result is not called "empty" when the server carried text there.
    """
    dm_text = result.get("dm_text")
    text_list = result.get("text_list") or []
    nonempty_text_list = [
        x for x in text_list
        if isinstance(x, str) and x != ""
    ]

    if isinstance(dm_text, str) and dm_text != "":
        return False
    if nonempty_text_list:
        return False
    if dm_text == "" and not nonempty_text_list:
        return True
    return None


def combine_text_states(results):
    states = [result_text_state(r) for r in results]
    if any(x is False for x in states):
        return False
    if states and all(x is True for x in states):
        return True
    return None


def map_history_to_server_result(history_query, results):
    """
    Match client histories[].query to the original server response result.
    Multi-SubQuery clients can store the previous SubQuery rather than the raw
    original query, so SubQuery exact match has highest priority.
    """
    if not results:
        return {
            "mapping": "none",
            "matches": [],
            "server_empty": None
        }

    exact_sub = [r for r in results if r.get("sub_query") == history_query]
    if exact_sub:
        return {
            "mapping": "exact_sub_query",
            "matches": exact_sub,
            "server_empty": combine_text_states(exact_sub)
        }

    exact_query = [r for r in results if r.get("query") == history_query]
    if exact_query:
        # If this was a multi result response, raw Query alone cannot identify
        # which result the client put into histories.
        if len(exact_query) == 1:
            return {
                "mapping": "exact_query_single_result",
                "matches": exact_query,
                "server_empty": combine_text_states(exact_query)
            }
        return {
            "mapping": "exact_query_multi_result_ambiguous",
            "matches": exact_query,
            "server_empty": None
        }

    if len(results) == 1:
        return {
            "mapping": "single_result_fallback",
            "matches": results,
            "server_empty": combine_text_states(results)
        }

    return {
        "mapping": "ambiguous",
        "matches": results,
        "server_empty": None
    }


class HttpClient(object):
    def __init__(self, user, password, insecure=False, timeout=90,
                 kbn_version=None):
        self.user = user
        self.password = password
        self.timeout = timeout
        self.kbn_version = kbn_version
        self.ssl_context = (
            ssl._create_unverified_context()
            if insecure else ssl.create_default_context()
        )

    def headers(self, content_type="application/json"):
        raw = ("%s:%s" % (self.user, self.password)).encode("utf-8")
        h = {
            "Authorization": "Basic " + base64.b64encode(raw).decode("ascii"),
            "Content-Type": content_type,
            "Accept": "application/json",
            "kbn-xsrf": "true",
            "osd-xsrf": "true",
            "User-Agent": "wtp184-history-empty-audit/1.0",
        }
        if self.kbn_version:
            h["kbn-version"] = self.kbn_version
        return h

    def request(self, url, method="GET", body=None,
                content_type="application/json"):
        if body is None:
            data = None
        elif isinstance(body, bytes):
            data = body
        elif isinstance(body, str):
            data = body.encode("utf-8")
        else:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")

        req = urlrequest.Request(
            url=url,
            data=data,
            headers=self.headers(content_type),
            method=method
        )
        try:
            resp = urlrequest.urlopen(
                req, timeout=self.timeout, context=self.ssl_context
            )
            raw = resp.read()
            return resp.getcode(), raw
        except urlerror.HTTPError as exc:
            raw = exc.read()
            raise RuntimeError(
                "HTTP %s for %s\n%s" %
                (exc.code, url, raw.decode("utf-8", "replace")[:2000])
            )
        except urlerror.URLError as exc:
            raise RuntimeError("Connection failed for %s: %s" % (url, exc))


class KibanaBackend(object):
    def __init__(self, base_url, http):
        self.base_url = base_url.rstrip("/")
        self.http = http

    def proxy(self, path, body, content_type="application/json"):
        qs = urlparse.urlencode({"path": path, "method": "POST"})
        url = self.base_url + "/api/console/proxy?" + qs
        status, raw = self.http.request(
            url, method="POST", body=body, content_type=content_type
        )
        if status < 200 or status >= 300:
            raise RuntimeError("Kibana proxy HTTP %s" % status)
        return json.loads(raw.decode("utf-8"))

    def search(self, index, body):
        return self.proxy("%s/_search" % index, body)

    def msearch(self, queries):
        lines = []
        for index, body in queries:
            lines.append(compact_json({"index": index}))
            lines.append(compact_json(body))
        payload = "\n".join(lines) + "\n"
        return self.proxy("_msearch", payload, "application/x-ndjson")


def discover_version(kibana, http):
    try:
        status, raw = http.request(kibana.rstrip("/") + "/api/status")
        if status != 200:
            return None
        obj = json.loads(raw.decode("utf-8"))
        version = obj.get("version")
        if isinstance(version, dict) and version.get("number"):
            return str(version.get("number"))
    except Exception:
        pass
    return None


def candidate_query(business_date, size, search_after=None):
    body = {
        "size": size,
        "track_total_hits": False,
        "_source": ["@timestamp", "message"],
        "sort": [
            {"@timestamp": {"order": "asc"}},
            {"_id": {"order": "asc"}}
        ],
        "query": {
            "bool": {
                "filter": [
                    {"match_phrase": {"message": "handlers.cc:348"}},
                    {"match_phrase": {"message": "I%s" % business_date}},
                    {"match_phrase": {"message": "\"histories\""}}
                ]
            }
        }
    }
    if search_after is not None:
        body["search_after"] = search_after
    return body


def previous_request_query(request_id, size=20):
    return {
        "size": size,
        "track_total_hits": False,
        "_source": ["@timestamp", "message"],
        "sort": [
            {"@timestamp": {"order": "asc"}},
            {"_id": {"order": "asc"}}
        ],
        "query": {
            "bool": {
                "filter": [
                    {"match_phrase": {"message": request_id}},
                    {
                        "bool": {
                            "should": [
                                {"match_phrase": {"message": "handlers.cc:348"}},
                                {"match_phrase": {"message": "handlers.cc:565"}},
                                {"match_phrase": {"message": "handlers.cc:569"}}
                            ],
                            "minimum_should_match": 1
                        }
                    }
                ]
            }
        }
    }


def hits(obj):
    return obj.get("hits", {}).get("hits", []) if isinstance(obj, dict) else []


def scan_histories(backend, index, business_date, page_size, max_pages):
    search_after = None
    seen_messages = set()
    pages_scanned = 0

    stats = {
        "post_requests_with_histories": 0,
        "history_items": 0,
        "complete_id_query_response": 0,
        "missing_id": 0,
        "missing_query": 0,
        "missing_response": 0,
        "null_response": 0,
        "empty_response": 0,
        "whitespace_only_response": 0,
    }
    empty_items = []

    while pages_scanned < max_pages:
        obj = backend.search(
            index,
            candidate_query(business_date, page_size, search_after)
        )
        page = hits(obj)
        if not page:
            break
        pages_scanned += 1

        for hit in page:
            src = hit.get("_source") or {}
            message = src.get("message")
            if not message or message in seen_messages:
                continue
            seen_messages.add(message)

            post = parse_post(message, src.get("@timestamp"))
            if not post:
                continue

            histories = post.get("payload", {}).get("histories")
            if not isinstance(histories, list):
                continue

            stats["post_requests_with_histories"] += 1

            for pos, item in enumerate(histories):
                if not isinstance(item, dict):
                    continue
                stats["history_items"] += 1

                missing_id = "id" not in item
                missing_query = "query" not in item
                missing_resp = "response" not in item

                if missing_id:
                    stats["missing_id"] += 1
                if missing_query:
                    stats["missing_query"] += 1
                if missing_resp:
                    stats["missing_response"] += 1

                if not missing_id and not missing_query and not missing_resp:
                    stats["complete_id_query_response"] += 1

                if missing_resp:
                    continue

                response = item.get("response")
                if response is None:
                    stats["null_response"] += 1
                elif response == "":
                    stats["empty_response"] += 1
                    empty_items.append({
                        "current_session_id": post.get("session_id"),
                        "current_request_id": post.get("request_id"),
                        "current_query": post.get("payload", {}).get("query"),
                        "current_business_time": iso(post.get("business_dt")),
                        "current_at_timestamp": post.get("at_timestamp"),
                        "history_position": pos,
                        "history": item,
                    })
                elif isinstance(response, str) and response.strip() == "":
                    stats["whitespace_only_response"] += 1

        search_after = page[-1].get("sort")
        eprint(
            "[scan] posts_with_histories=%d history_items=%d empty=%d" %
            (
                stats["post_requests_with_histories"],
                stats["history_items"],
                stats["empty_response"]
            )
        )
        if not search_after or len(page) < page_size:
            break

    if pages_scanned >= max_pages and page and len(page) >= page_size:
        raise RuntimeError(
            "candidate scan reached --max-pages=%d; increase the explicit bound "
            "to continue" % max_pages
        )

    return stats, empty_items


def dedup_parsed_events(search_hits, request_id=None):
    seen = set()
    posts = []
    responses = []

    for h in search_hits:
        src = h.get("_source") or {}
        message = src.get("message")
        if not message or message in seen:
            continue
        seen.add(message)

        p = parse_post(message, src.get("@timestamp"))
        if p:
            if request_id is None or p.get("request_id") == request_id:
                posts.append(p)
            continue
        r = parse_response(message, src.get("@timestamp"))
        if r and (request_id is None or r.get("request_id") == request_id):
            responses.append(r)

    posts.sort(key=lambda x: (x.get("business_dt") is None,
                              x.get("business_dt") or dt.datetime.max))
    responses.sort(key=lambda x: (x.get("business_dt") is None,
                                  x.get("business_dt") or dt.datetime.max))
    return posts, responses


def choose_previous_response(responses, current_time):
    if not responses:
        return None
    if current_time is None:
        return responses[-1]

    before = [
        r for r in responses
        if r.get("business_dt") is not None and r.get("business_dt") <= current_time
    ]
    if before:
        return before[-1]

    known = [r for r in responses if r.get("business_dt") is not None]
    if known:
        return min(
            known,
            key=lambda x: abs((x.get("business_dt") - current_time).total_seconds())
        )
    return responses[-1]


def verify_empty_items(backend, response_index, empty_items, batch_size):
    by_id = {}
    ids = []
    seen = set()
    for item in empty_items:
        hid = item.get("history", {}).get("id")
        if hid and hid not in seen:
            seen.add(hid)
            ids.append(hid)

    for start in range(0, len(ids), batch_size):
        chunk = ids[start:start + batch_size]
        queries = [
            (response_index, previous_request_query(req_id))
            for req_id in chunk
        ]
        obj = backend.msearch(queries)
        responses = obj.get("responses") or []
        if len(responses) != len(chunk):
            raise RuntimeError(
                "_msearch response count mismatch: %d != %d" %
                (len(responses), len(chunk))
            )
        for req_id, res in zip(chunk, responses):
            by_id[req_id] = hits(res)
        eprint("[verify] looked_up=%d/%d" % (min(start + len(chunk), len(ids)), len(ids)))

    verified = []

    for item in empty_items:
        history = item.get("history") or {}
        hid = history.get("id")
        current_dt = None
        if item.get("current_business_time"):
            try:
                current_dt = dt.datetime.strptime(
                    item["current_business_time"], "%Y-%m-%dT%H:%M:%S.%f"
                )
            except Exception:
                pass

        out = dict(item)

        if not hid:
            out["verification_status"] = "HISTORY_ID_MISSING"
            out["previous_post"] = None
            out["previous_response"] = None
            verified.append(out)
            continue

        previous_posts, previous_responses = dedup_parsed_events(
            by_id.get(hid, []), hid
        )
        chosen = choose_previous_response(previous_responses, current_dt)

        matching_post = None
        for p in reversed(previous_posts):
            if p.get("request_id") == hid:
                matching_post = p
                break

        out["previous_post"] = None
        if matching_post:
            out["previous_post"] = {
                "session_id": matching_post.get("session_id"),
                "request_id": matching_post.get("request_id"),
                "query": matching_post.get("payload", {}).get("query"),
                "business_time": iso(matching_post.get("business_dt")),
                "at_timestamp": matching_post.get("at_timestamp"),
                "payload": matching_post.get("payload"),
            }

        if not chosen:
            out["verification_status"] = "PREVIOUS_RESPONSE_NOT_FOUND"
            out["previous_response"] = None
            verified.append(out)
            continue

        result_rows = flatten_response_results(chosen.get("response") or {})
        mapping = map_history_to_server_result(history.get("query"), result_rows)

        out["previous_response"] = {
            "session_id": chosen.get("session_id"),
            "request_id": chosen.get("request_id"),
            "business_time": iso(chosen.get("business_dt")),
            "at_timestamp": chosen.get("at_timestamp"),
            "result_mapping": mapping.get("mapping"),
            "matched_results": mapping.get("matches"),
            "all_results": result_rows,
            "raw_response": chosen.get("response"),
        }

        if mapping.get("server_empty") is True:
            out["verification_status"] = "VERIFIED_SERVER_EMPTY"
        elif mapping.get("server_empty") is False:
            out["verification_status"] = "CLIENT_EMPTY_SERVER_NONEMPTY"
        else:
            out["verification_status"] = "AMBIGUOUS_RESPONSE_MAPPING"

        verified.append(out)

    return verified


def previous_day_index(index, business_date):
    try:
        d = dt.datetime.strptime(business_date, "%Y%m%d").date()
        prev = d - dt.timedelta(days=1)
        prefix = re.sub(r'\d{4}\.\d{2}\.\d{2}$', '', index)
        if prefix != index:
            return prefix + prev.strftime("%Y.%m.%d")
    except Exception:
        pass
    return None


def parse_args():
    p = argparse.ArgumentParser(
        description="Audit empty request.histories.response and verify the "
                    "previous server response."
    )
    p.add_argument(
        "--kibana",
        default=os.environ.get("KIBANA_URL"),
        help="Kibana base URL; defaults to KIBANA_URL."
    )
    p.add_argument(
        "--user",
        default=os.environ.get("KIBANA_USER"),
        help="Kibana user; defaults to KIBANA_USER."
    )
    p.add_argument(
        "--index",
        required=True,
        help="One bounded daily index used to find client POST requests."
    )
    p.add_argument(
        "--business-date",
        required=True,
        help="Business date embedded in message, YYYYMMDD."
    )
    p.add_argument(
        "--response-index",
        default=None,
        help="Comma-separated indices used to verify previous requests. "
             "Default: previous-day index plus current index."
    )
    p.add_argument("--page-size", type=positive_int, default=500)
    p.add_argument("--max-pages", type=positive_int, default=100)
    p.add_argument("--msearch-batch-size", type=positive_int, default=25)
    p.add_argument("--timeout", type=positive_int, default=90)
    p.add_argument("--insecure", action="store_true")
    p.add_argument("--kbn-version", default=None)
    p.add_argument("--output", required=True)
    return p.parse_args()


def main():
    args = parse_args()

    args.kibana = require_http_url("--kibana or KIBANA_URL", args.kibana)
    args.user = require_text("--user or KIBANA_USER", args.user)
    args.index = require_index_expression("--index", args.index)
    args.business_date = require_business_date(args.business_date)
    output_path = require_output_path(args.output)

    password = os.environ.get("KIBANA_PASSWORD")
    if password is None or password == "":
        raise ValueError("KIBANA_PASSWORD is required")

    http = HttpClient(
        args.user, password,
        insecure=args.insecure,
        timeout=args.timeout,
        kbn_version=args.kbn_version
    )

    if not args.kbn_version:
        version = discover_version(args.kibana, http)
        if version:
            http.kbn_version = version
            eprint("[auth] Kibana version=%s" % version)

    backend = KibanaBackend(args.kibana, http)

    response_index = args.response_index
    if response_index:
        response_index = require_index_expression(
            "--response-index", response_index, allow_multiple=True
        )
    else:
        prev = previous_day_index(args.index, args.business_date)
        response_index = (
            (prev + "," + args.index) if prev else args.index
        )

    eprint("[start] candidate_index=%s" % args.index)
    eprint("[start] business_date=%s" % args.business_date)
    eprint("[start] response_index=%s" % response_index)

    stats, empty_items = scan_histories(
        backend,
        args.index,
        args.business_date,
        args.page_size,
        args.max_pages
    )

    verified = verify_empty_items(
        backend, response_index, empty_items, args.msearch_batch_size
    )

    status_counts = {}
    for item in verified:
        s = item.get("verification_status")
        status_counts[s] = status_counts.get(s, 0) + 1

    report = {
        "metadata": {
            "generated_at": dt.datetime.now().isoformat(),
            "kibana": args.kibana,
            "candidate_index": args.index,
            "business_date": args.business_date,
            "response_index": response_index,
            "request_source": "handlers.cc:348",
            "response_source": "handlers.cc:565/569",
        },
        "stats": stats,
        "verification_status_counts": status_counts,
        "empty_response_cases": verified,
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print("DONE")
    for k in [
        "post_requests_with_histories",
        "history_items",
        "complete_id_query_response",
        "missing_id",
        "missing_query",
        "missing_response",
        "null_response",
        "empty_response",
        "whitespace_only_response",
    ]:
        print("%s=%s" % (k, stats.get(k)))

    for k in sorted(status_counts):
        print("%s=%s" % (k, status_counts[k]))

    print("output=%s" % output_path)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError) as exc:
        eprint("ERROR: %s" % exc)
        sys.exit(1)
