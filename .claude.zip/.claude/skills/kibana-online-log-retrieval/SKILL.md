---
name: kibana-online-log-retrieval
description: Use for WTP184 online/test Kibana evidence retrieval, exact multi-turn reconstruction, request.histories audits, and controlled replay of an exact case into a dev endpoint.
---

# Kibana Online Log Retrieval

Read `.claude/workflows/wtp184-workflow.md` and use the current execution route and the existing `wtp184-server-operator` controls. This Skill supplies Kibana/replay-specific evidence rules; it does not create a separate approval, preflight, or validation path.

## Evidence boundary

Keep the roles distinct:

- Online/test Kibana logs are the source of original evidence.
- A user-selected dev `/zp/update` endpoint is the replay target.
- `handlers.cc:348 Post request` is the original client-request source.
- `handlers.cc:565/569 Response=` is the final server-response source.
- `dialogue.cc:849 restore query histories` is internal state, not proof of client input.

Prefer the business timestamp embedded in `message` for conversation order. Deduplicate exact duplicate ingestion before reconstruction because `@timestamp` can be delayed or duplicated.

## Exact retrieval

For a target request:

1. Resolve the exact `request_id` and `session_id` from `handlers.cc:348`.
2. Retrieve the bounded Post/Response evidence for that conversation.
3. Sort by business timestamp.
4. Walk backward to the nearest `first_wakeup=true` preceding the target.
5. Preserve every real request/response round through the target.
6. Preserve the complete original POST payload, including `histories`, `input_data`, `app_id`, `stream`, `uid`, `sid`, and wakeup state.

Use one-day indices where possible, request only needed `_source` fields, disable total-hit tracking for evidence retrieval, and avoid broad wildcard scans or scripted Elasticsearch queries unless the approved/requested diagnosis needs them.

Match current requests with exact log forms such as `request_id=[...]` or `"RequestId":"..."`. A naked request-ID substring is not exact because it can match `histories[].id`.

## Histories audit

When `histories[].response == ""`, parse the original POST JSON before classifying it. Use `histories[].id` to locate the preceding request and its `handlers.cc:565/569` response. Match `histories[].query` to the previous `SubQuery` first, then to raw `Query` only when unambiguous.

Use these result labels:

- `VERIFIED_SERVER_EMPTY`
- `CLIENT_EMPTY_SERVER_NONEMPTY`
- `PREVIOUS_RESPONSE_NOT_FOUND`
- `HISTORY_ID_MISSING`
- `AMBIGUOUS_RESPONSE_MAPPING`

## Dev replay

Replay rounds sequentially in one fresh session. Use a separate fresh session for each case.

- Generate a fresh replay `session_id` per case.
- Generate a fresh replay `request_id` per round.
- Remap only `histories[].id` references to earlier rounds in the same reconstructed case.
- Preserve `histories[].query` and `histories[].response` literally.
- Preserve the original stream mode; for SSE, consume through EOF/final `IsEnd`.
- Write evidence only to the operator-selected output path.

Use the bundled scripts described in `references/OPERATIONS.md` before creating ad-hoc queries. When dev Redis state is discriminating, use `wtp184-redis-context` immediately after the relevant replay point because context TTL is short.
