# Kibana Evidence and Dev Replay Operations

Run from the `kibana-online-log-retrieval` Skill directory, or pass absolute script/output paths. Supply environment-specific values at execution time; do not save credentials in the repository or command output.

## Environment

Bash:

```bash
export KIBANA_URL='https://<kibana-host>'
export KIBANA_USER='<kibana-user>'
export KIBANA_PASSWORD='<kibana-password>'
```

PowerShell:

```powershell
$env:KIBANA_URL = 'https://<kibana-host>'
$env:KIBANA_USER = '<kibana-user>'
$env:KIBANA_PASSWORD = '<kibana-password>'
```

## Audit empty history responses

```bash
python3 scripts/audit_empty_history_response.py \
  --index 'v2-dialogue-YYYY.MM.DD' \
  --business-date 'YYYYMMDD' \
  --output '/protected/output/history-empty-audit.json'
```

To search an explicitly bounded set of indices for referenced previous responses, add:

```bash
--response-index 'v2-dialogue-YYYY.MM.DD,v2-dialogue-YYYY.MM.DD'
```

Inspect the report's counts and classifications:

- `VERIFIED_SERVER_EMPTY`
- `CLIENT_EMPTY_SERVER_NONEMPTY`
- `PREVIOUS_RESPONSE_NOT_FOUND`
- `HISTORY_ID_MISSING`
- `AMBIGUOUS_RESPONSE_MAPPING`

## Replay one exact two-round case into dev

```bash
python3 scripts/replay_history_pair_to_dev.py \
  --index 'v2-dialogue-YYYY.MM.DD' \
  --dev-url 'http://<dev-host>:<port>/zp/update' \
  --r1-request-id '<round-1-request-id>' \
  --r2-request-id '<round-2-request-id>' \
  --output '/protected/output/replay-pair.json'
```

The script retrieves exact Post/Response evidence, generates fresh replay IDs, remaps only the second-round history reference to the fresh first-round ID, preserves history query/response values, and consumes JSON or SSE output. Add `--pause-between-rounds` only for an explicitly interactive run; agent-driven runs remain non-interactive by default.

## Query boundaries

- Prefer one daily index.
- Request only `@timestamp` and `message` unless more evidence is required.
- Use `track_total_hits=false` for evidence retrieval.
- Match current-request log forms exactly after candidate retrieval.
- Avoid Painless, runtime mappings, scripted metrics, and broad multi-day wildcard scans by default.
- Use `--insecure` only when the selected test environment explicitly requires bypassing certificate verification; report that limitation.
