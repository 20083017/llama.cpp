---
name: wtp184-worktree-cleanup
description: Classify, integrate when narrowly eligible, and remove WTP184 local Git worktrees through bounded source, target, payload, activity and common-repository-context checks.
---

# WTP184 Worktree Lifecycle

Use `.worktree-policy.yaml` `cleanup_requirements` as the single source of truth for local worktree lifecycle decisions. This Skill defines execution order only; it does not replace the canonical workflow safety model or general repository branch creation, delivery and deletion policy.

## State machine

```text
REQUEST
  -> INVENTORY
  -> CLASSIFY
  -> MANIFEST
  -> SOURCE_PRECHECK
  -> TARGET_PRECHECK_IF_NEEDED
  -> CONFLICT_PREDICT_IF_NEEDED
  -> EXACT_PAYLOAD_CLEANUP_IF_ALLOWED
  -> VERIFY_SOURCE_CLEAN
  -> RECHECK_TARGET_IF_NEEDED
  -> INTEGRATE_OR_CONFIRM
  -> VERIFY_INTEGRATED
  -> NORMAL_REMOVE
  -> REPORT
```

A target advances only while every required preceding state passes:

1. **REQUEST** — Record whether authorization comes from the current user's explicit bounded lifecycle request or an approved plan phase. Freeze its selector and permitted destructive effects. The integration target must resolve to the exact eligible local `master` worktree; any other target is `HOLD`. Cleanup-base candidates remain independent evidence for already-integrated removal. A delegate message is not authorization.
2. **INVENTORY** — From the context owning the common Git directory, resolve existing cleanup-base candidates and capture one batch inventory: all worktree porcelain metadata; exact source and target refs/HEADs; each target's staged, tracked and fully expanded untracked status; NUL-delimited ignored leaf paths from the policy's `git ls-files` command; lock/current state; and the policy's authoritative live-assignment snapshot keyed by canonical path. Never treat a collapsed ignored directory as one payload entry. Freeze path type and content identity for target untracked and ignored leaves. Only an explicitly complete primary snapshot can classify an absent path as inactive; unavailable, incomplete or unresolved activity is `HOLD`.
3. **CLASSIFY** — Classify source integration as `ALREADY_INTEGRATED`, `MERGE_REQUIRED` or `HOLD`. `ALREADY_INTEGRATED` requires the selected existing base to contain the source HEAD. `MERGE_REQUIRED` requires a committed delta on the exact policy-declared managed branch/path pair. A nonmanaged nonintegrated branch is `HOLD`. Classify every status payload as exactly `same`, `superseded`, `temp`, `unique` or `unknown`; committed deltas are never payload.
4. **MANIFEST** — Emit one frozen batch manifest. Use `SAFE/REMOVE` only for an already-integrated target passing activity, lock/current and payload checks. Use `SAFE/INTEGRATE_THEN_REMOVE` only for an inactive, clean-after-permitted-cleanup managed source whose exact selected target is presently eligible. All others are `HOLD` with the first direct proof.
5. **SOURCE_PRECHECK** — Immediately before each action, refresh authoritative activity and recheck canonical identity, branch/ref, source HEAD, lock/current state and full status against the manifest. A changed or unresolved source becomes `HOLD`; continue only independent safe actions.
6. **TARGET_PRECHECK_IF_NEEDED** — For merge actions, require exact local `master` in one known worktree owned by the primary executor, direct-mutation eligibility, the expected target HEAD, no detached or unresolved merge state, and clean tracked/staged state. Untracked and ignored target leaves are allowed only when path-disjoint from the source delta; freeze each path's type and content identity. A target failure holds target-dependent merges but not independent already-integrated removals.
7. **CONFLICT_PREDICT_IF_NEEDED** — Perform the policy-required bounded read-only merge prediction against the frozen source ref and expected target cursor. A predicted conflict is `HOLD`; do not start a merge or edit, resolve, stage or commit conflict content.
8. **EXACT_PAYLOAD_CLEANUP_IF_ALLOWED** — Only for a direct request covering cleanup, restore or remove exact frozen manifest leaf paths whose policy class permits it. Directory-level payload removal is forbidden even when every visible entry appears disposable; every descendant leaf must be independently frozen and classified. Never use a glob, `git clean`, `git reset`, stash or force removal. `unique`, `unknown` and meaningful uncommitted payload remain untouched and `HOLD`.
9. **VERIFY_SOURCE_CLEAN** — Repeat the complete policy status inventories. Any remaining staged, tracked, untracked, ignored, `unique` or `unknown` payload makes the target `HOLD`.
10. **RECHECK_TARGET_IF_NEEDED** — Immediately before merge, require the source branch ref still to equal the frozen source commit OID, then recheck target ownership, exact `master` branch, expected HEAD cursor, tracked/staged status, untracked/ignored collision set and frozen path-type/content identities, and unresolved state. Only target movement produced by a preceding topology-verified batch merge advances the expected cursor; unexplained movement or payload identity drift holds remaining target-dependent merges.
11. **INTEGRATE_OR_CONFIRM** — `REMOVE` performs no merge. `INTEGRATE_THEN_REMOVE` merges the frozen source commit OID, never a movable branch name, into exact local `master` using the policy strategy: fast-forward when ancestry permits, otherwise a normal merge commit. Never substitute squash, cherry-pick or rebase.
12. **VERIFY_INTEGRATED** — Prove the merge operand was the frozen source OID, that OID is reachable from `master`, the target has no unresolved or tracked/staged dirty merge state, every frozen untracked/ignored target path retains its exact type and content identity, and the source ref is preserved. For fast-forward, prove the old cursor is an ancestor and the result equals the frozen source OID. For a normal merge, prove exactly two parents: first the old target cursor and second the frozen source OID. Advance the batch cursor only after this topology proof passes.
13. **NORMAL_REMOVE** — Run normal, non-force `git worktree remove` only after integration is proven or was already present and the source is verified clean. Preserve its branch/ref. If integration succeeds but removal fails, report `MERGED_NOT_REMOVED`; do not undo the merge automatically.
14. **REPORT** — Group `REMOVED`, `MERGED_AND_REMOVED`, `MERGED_NOT_REMOVED`, `HOLD`, `FAILED` and `MAIN_CONTEXT_REQUIRED`. One target failure does not prevent independently safe actions allowed by the policy.

## Unexpected merge conflict

If a merge unexpectedly enters a conflict, run only `git merge --abort`. Verify the exact pre-merge target HEAD, index and status are restored. On proven restoration, mark that source `HOLD` and stop remaining target-dependent merges pending a fresh inventory; independent removal actions may continue only when their frozen safety evidence remains valid. If restoration cannot be proved, report `FAILED` and stop target-dependent actions. Never use reset or automatic conflict resolution as recovery.

## Context handoff

If isolation blocks cross-worktree inventory or mutation, do not retry there and do not classify the denial as target risk. Return one `MAIN_CONTEXT_REQUIRED` manifest containing the frozen request selector, intended target identities and required full prechecks. The primary orchestrator automatically resumes the unchanged operation with the original user request or approved-phase evidence and repeats the entire state machine in the context owning the common Git directory. The handoff does not suppress native platform permission prompts or authorize selector, target, command-class or destructive-effect expansion.

Do not create worktrees while evaluating the batch. Branch deletion remains separate from worktree removal.
