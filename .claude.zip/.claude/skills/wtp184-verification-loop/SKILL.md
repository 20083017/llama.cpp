---
name: wtp184-verification-loop
description: Validate WTP184 code, Bazel, tooling and server changes through the smallest reproducible check, compact failure evidence, bounded retries and explicit unverified risks.
---

# WTP184 Verification Loop

Inherit `.claude/workflows/wtp184-workflow.md` for route selection, approval, records and correction/material boundaries. This Skill imposes no verification phase, static check, test/build/review or report on direct-eligible work. Apply it only to validation in an approved plan or explicitly requested checks; preloading it does not authorize execution during planning.

1. Define PASS/FAIL evidence for the current approved Phase. Start with the smallest affected unit/test/target and widen only within approved acceptance and scope.
2. Preserve command, exit code and full bounded log path; report a compact actionable excerpt. Send phase/step and results to the orchestrator, which alone updates the check record and CURRENT.
3. On failure, identify the relevant code, build/toolchain, resource, environment or service cause within scope. Ordinary implementation errors remain IN_PROGRESS: the owner corrects within all six canonical boundaries, reruns the affected check and continues on PASS without new approval. Read-only agents return findings and never auto-fix.
4. Continue targeted correction/re-validation or delta review while the approved approach can reasonably satisfy acceptance within those boundaries. No fixed batch, rerun, review or generic retry count applies; preserve technical timeout/workload/safety limits. Expected RED failures follow their planned cycle. Never skip assertions or weaken acceptance to make a result pass.
5. Only a confirmed canonical Material blocker requires BLOCKED and a user decision. Return category, direct path:line/log proof, consequence, smallest correction, owner and one next check. Stop further implementation/correction dispatch. Category 7 needs evidence about the approach's inability to satisfy acceptance within the boundaries; failure counts, unavailable tools or review severity alone are insufficient.
6. After the user's decision, resume the recorded phase with completed phases and valid evidence preserved. Report remaining unverified behavior accurately. Direct-to-planned escalation preserves and attributes existing edits through the workflow's baseline procedure; it never turns them into already-approved work.
