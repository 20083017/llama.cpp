---
name: wtp184-docker-log-inspection
description: List or fixed-string search bounded files in a uniquely port-selected WTP184 container /log.
---

# WTP184 Docker Log Inspection

`wtp184-server-operator` directly invokes the canonical repository helpers resolved from this skill, never from the current working directory or `PATH`:

```bash
docker_log_helper=$(readlink -f -- "$skill_dir/../../tools/wtp184-docker-log.sh")
compact_log_helper=$(readlink -f -- "$skill_dir/../../tools/compact-log.sh")
"$docker_log_helper" list
"$docker_log_helper" search --query 'fixed text' >"$bounded_response_log"
"$compact_log_helper" "$bounded_response_log" 120 --docker-search
```

For request correlation, append `--request "$correlation_token"`; for a timestamp fragment, append `--time "$time_text"`. Keep the bounded helper response until diagnosis completes and return the compact excerpt.

The Docker helper retains its `list|search` interface, unique published-port selection, container-only `/log` scope, stdout and exit-status contract, and focused bounds; `--help` is authoritative for its options. `compact-log.sh --docker-search` decodes the helper's search data and applies WTP184 filters as a separate local post-processing step. The Docker helper transport comes from the `wtp184-server-session` shared deploy SSH contract and uses the same configured connection as GDB. Do not create or invoke a Docker-log entry launcher, and do not use ambient SSH configuration.
