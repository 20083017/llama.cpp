---

name: wtp184-bazel-linux
description: Map a changed WTP184 Linux file to its Bazel owner and bounded dependency impact, then validate the smallest GCC 4.9.3/C++11 target with compact evidence.
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

# WTP184 Bazel Linux

## Contract

For a changed source, header, generated file, library, test or binary, answer only:

1. Which Bazel package and rule own it?
2. What are that rule's direct declared dependencies?
3. Which nearest tests and requested binaries are affected?
4. Is there a Bazel dependency path from the requested binary to the changed rule?
5. What is the smallest target that proves the change compiles and links?

Bazel proves build dependency and assembly only. `somepath` does not prove runtime order, resource activation or feature selection.

## Evidence rules

* Establish the authoritative workspace and source baseline first.
* For remote/build-host acceptance, inspect and build on the authoritative Ubuntu workspace through the existing pipeline, launcher or scoped SSH.
* Do not substitute workstation Bazel results for build-host evidence.
* For explicitly local changes, evidence applies only to that checkout.
* Derive labels from BUILD files; never guess them from filenames.
* Start from the nearest `BUILD` / `BUILD.bazel`. Do not begin with an unbounded `//...` query.

## Bounded Bazel inspection

```bash
# Rules in the owning package.
bazel query --output=label_kind //path/to/package:all

# Direct owner/reference of a file, bounded to its module.
bazel query --noimplicit_deps \
  'rdeps(//path/to/module/..., //path/to/package:file.cc, 1)' \
  --output=label_kind

# Selected rule and direct declared dependencies.
bazel query --noimplicit_deps \
  'deps(//path/to/package:target, 1)' \
  --output=label_kind

# Dependency path from requested binary to changed rule.
bazel query \
  'somepath(//path/to:binary, //path/to/package:target)' \
  --output=label

# Nearest dependent tests.
bazel query \
  'kind(".*_test rule", rdeps(//path/to/module/..., //path/to/package:target))' \
  --output=label_kind
```

For headers, generated files, aliases, `filegroup`, `select()` branches or external repositories, inspect the declaring rule before widening the query. Query `@repo//...` only when directly referenced.

Use additional layers only when needed:

```bash
# Configured output.
bazel cquery //path/to/package:target --output=files

# Actual compile/link actions.
bazel aquery \
  'mnemonic("CppCompile|CppLink", deps(//path/to/package:target))' \
  --output=text
```

Use `aquery` only when compiler flags, generated inputs, `select()` resolution, include paths, link inputs or toolchain compatibility matter. Verify the actual action is compatible with GCC/G++ 4.9.3 and C++11; host `gcc --version` alone is insufficient.

## Failure handling

Stop at the first actionable failure:

* missing or misspelled target/file label;
* visibility failure;
* missing direct `deps` or include path;
* unresolved external repository;
* incompatible `select()` / platform branch;
* missing generated input;
* dependency cycle;
* undefined or duplicate linker symbol;
* GCC 4.9.3/C++11 incompatibility.

Report:

* direct `BUILD` or source `path:line` evidence;
* consequence;
* smallest owner-level correction;
* one next verification command.

Never add a broad dependency merely to hide a missing direct edge.

## Validation

1. Build or test the smallest owning target first.
2. For library/header changes, build the nearest affected binary only when needed.
3. Build `//cu:server` only when:

   * it is explicitly requested;
   * `somepath` proves the changed rule reaches it; or
   * product integration is part of acceptance.
4. Do not run `bazel clean` unless stale output/toolchain state is proven or explicitly requested.
5. Keep full output in a bounded log.

Success evidence:

* target;
* exit status;
* result.

Failure evidence:

* first actionable Bazel/compiler/linker error;
* at most 20 relevant lines;
* full log path.

## Acceptance

A changed unit is ready only when:

* owning rule is identified;
* direct BUILD dependencies are checked;
* configured output is identified when relevant;
* smallest target compiles and links;
* nearest affected tests pass when present;
* requested product impact is either proved and validated or explicitly reported as unverified.
