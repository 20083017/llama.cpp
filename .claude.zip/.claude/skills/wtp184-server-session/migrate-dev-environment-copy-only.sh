#!/usr/bin/env bash
set -Eeuo pipefail

# migrate-dev-environment-copy-only.sh
#
# Run on source server 10.1.122.21.
# COPY ONLY: never deletes source/destination data.
#
# Destination: yydh@10.1.120.40
#
# Migrates:
#   /home/daigd/workspaces
#   /home/daigd/packages
#   /home/daigd/docker_packages
#   /home/daigd/resources
#   /home/daigd/nginx
#   /home/daigd/cmake-3.31.3-linux-x86_64
#   /home/daigd/cmake-3.31.3-linux-x86_64.tar.gz
#   /home/daigd/gcc-4.9.3
#   /home/daigd/gcc-4.9.3.tar.gz
#   /home/shared/models
#
# SSH ControlMaster is used so password authentication normally happens once.

DST_HOST="10.1.120.40"
DST_USER="yydh"
SSH_PORT="22"

ITEMS=(
  "/home/daigd/workspaces"
  "/home/daigd/packages"
  "/home/daigd/docker_packages"
  "/home/daigd/resources"
  "/home/daigd/nginx"
  "/home/daigd/cmake-3.31.3-linux-x86_64"
  "/home/daigd/cmake-3.31.3-linux-x86_64.tar.gz"
  "/home/daigd/gcc-4.9.3"
  "/home/daigd/gcc-4.9.3.tar.gz"
  "/home/shared/models"
)

CHECK_ONLY=0
USE_COMPRESS=0
STRONG_CHECKSUM=0
ONLY_BASENAME=""
ALLOW_EXISTING=0

RUN_ID="$(date '+%Y%m%d-%H%M%S')"
LOG_DIR="${HOME}/migration-logs"
LOG_FILE="${LOG_DIR}/dev-env-copy-${RUN_ID}.log"

CONTROL_SOCKET="/tmp/devmig-${UID}-$$.sock"
MASTER_STARTED=0

usage() {
  cat <<'EOF'
Usage:
  ./migrate-dev-environment-copy-only.sh [options]

Options:
  --check-only          Check SSH, permissions, paths and disk space only.
  --compress            Enable rsync compression (-z).
  --checksum            Verify file contents using rsync checksum after transfer.
  --allow-existing      Allow merge into pre-existing destination directories.
                        No destination files are deleted.
  --only NAME           Transfer one item by basename, for example:
                        workspaces
                        packages
                        docker_packages
                        resources
                        nginx
                        cmake-3.31.3-linux-x86_64
                        cmake-3.31.3-linux-x86_64.tar.gz
                        gcc-4.9.3
                        gcc-4.9.3.tar.gz
                        models
  --dest-host HOST      Default: 10.1.120.40
  --dest-user USER      Default: yydh
  --ssh-port PORT       Default: 22
  -h, --help            Show help.

Safety:
  * no rm / rmdir of project data
  * no rsync --delete
  * no --remove-source-files
  * safe to rerun after interruption
EOF
}

while (($#)); do
  case "$1" in
    --check-only) CHECK_ONLY=1 ;;
    --compress) USE_COMPRESS=1 ;;
    --checksum) STRONG_CHECKSUM=1 ;;
    --allow-existing) ALLOW_EXISTING=1 ;;
    --only) ONLY_BASENAME="${2:?missing value for --only}"; shift ;;
    --dest-host) DST_HOST="${2:?missing value for --dest-host}"; shift ;;
    --dest-user) DST_USER="${2:?missing value for --dest-user}"; shift ;;
    --ssh-port) SSH_PORT="${2:?missing value for --ssh-port}"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

ts() { date '+%Y-%m-%d %H:%M:%S'; }
log() { printf '[%s] %s\n' "$(ts)" "$*"; }
die() { log "ERROR: $*"; exit 1; }

REMOTE="${DST_USER}@${DST_HOST}"

close_master() {
  if [[ "$MASTER_STARTED" -eq 1 ]]; then
    ssh -S "$CONTROL_SOCKET" -O exit "$REMOTE" >/dev/null 2>&1 || true
  fi
}
trap close_master EXIT

on_error() {
  local rc=$?
  log "FAILED: rc=${rc}, line=${BASH_LINENO[0]}, command=${BASH_COMMAND}"
  log "Log file: ${LOG_FILE}"
  exit "$rc"
}
trap on_error ERR

stage() {
  local name="$1"
  shift
  local start rc
  start="$(date +%s)"
  log "===== START: $name ====="
  set +e
  "$@"
  rc=$?
  set -e
  log "===== END: $name; rc=$rc; elapsed=$(($(date +%s)-start))s ====="
  return "$rc"
}

command -v ssh >/dev/null || die "ssh not installed"
command -v rsync >/dev/null || die "rsync not installed"

log "Run ID:      $RUN_ID"
log "Destination: $REMOTE"
log "Mode:        COPY ONLY"
log "Log:         $LOG_FILE"

log "Starting reusable SSH master connection..."
ssh \
  -M \
  -S "$CONTROL_SOCKET" \
  -o ControlPersist=900 \
  -o ConnectTimeout=10 \
  -o ServerAliveInterval=15 \
  -o ServerAliveCountMax=4 \
  -p "$SSH_PORT" \
  -fN "$REMOTE"
MASTER_STARTED=1

SSH=(ssh -S "$CONTROL_SOCKET" -o ControlMaster=no -p "$SSH_PORT")
RSYNC_SSH="ssh -S ${CONTROL_SOCKET} -o ControlMaster=no -p ${SSH_PORT}"

stage "remote identity" "${SSH[@]}" "$REMOTE" \
  "hostname; id; command -v rsync; rsync --version | head -n 1"

selected() {
  local item="$1"
  [[ -z "$ONLY_BASENAME" || "$(basename "$item")" == "$ONLY_BASENAME" ]]
}

FAILED=0

preflight_item() {
  local src="$1"
  selected "$src" || return 0

  local base parent kind size_kb
  base="$(basename "$src")"
  parent="$(dirname "$src")"

  echo
  log "----- PREFLIGHT [$base] $src -----"

  if [[ -d "$src" ]]; then
    kind="dir"
    size_kb="$(du -sk "$src" 2>/dev/null | awk '{print $1}')"
  elif [[ -f "$src" || -L "$src" ]]; then
    kind="file"
    size_kb="$(du -k "$src" 2>/dev/null | awk '{print $1}')"
  else
    log "ERROR: source does not exist: $src"
    FAILED=1
    return
  fi

  log "type=$kind size=${size_kb:-unknown} KiB"

  if [[ ! -r "$src" ]]; then
    log "ERROR: source not readable by $(id -un): $src"
    FAILED=1
    return
  fi

  local remote_out
  remote_out="$("${SSH[@]}" "$REMOTE" bash -s -- "$src" "$kind" <<'EOS'
src="$1"
kind="$2"
parent="$(dirname "$src")"

if ! mkdir -p "$parent" 2>/dev/null; then
  echo "PARENT_CREATE=no"
  [[ -e "$parent" ]] && stat -c 'PARENT_STAT=%A %a %U:%G %n' "$parent" 2>/dev/null
  exit 0
fi
echo "PARENT_CREATE=yes"

if [[ -e "$src" || -L "$src" ]]; then
  echo "EXISTS=yes"
  stat -c 'DST_STAT=%A %a %U:%G %n' "$src" 2>/dev/null || true
else
  echo "EXISTS=no"
fi

if [[ -w "$parent" && -x "$parent" ]]; then
  echo "PARENT_WRITABLE=yes"
else
  echo "PARENT_WRITABLE=no"
fi

if [[ "$kind" == "dir" && -d "$src" ]]; then
  if [[ -w "$src" && -x "$src" ]]; then
    echo "DST_WRITABLE=yes"
  else
    echo "DST_WRITABLE=no"
  fi
  if find "$src" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null | grep -q .; then
    echo "DST_NONEMPTY=yes"
  else
    echo "DST_NONEMPTY=no"
  fi
else
  echo "DST_WRITABLE=na"
  echo "DST_NONEMPTY=na"
fi

df -Pk "$parent" 2>/dev/null | awk 'NR==2 {print "FREE_KB="$4}'
EOS
)"
  printf '%s\n' "$remote_out"

  local pc pw dw exists nonempty
  pc="$(printf '%s\n' "$remote_out" | awk -F= '$1=="PARENT_CREATE"{print $2}')"
  pw="$(printf '%s\n' "$remote_out" | awk -F= '$1=="PARENT_WRITABLE"{print $2}')"
  dw="$(printf '%s\n' "$remote_out" | awk -F= '$1=="DST_WRITABLE"{print $2}')"
  exists="$(printf '%s\n' "$remote_out" | awk -F= '$1=="EXISTS"{print $2}')"
  nonempty="$(printf '%s\n' "$remote_out" | awk -F= '$1=="DST_NONEMPTY"{print $2}')"

  if [[ "$pc" != "yes" || "$pw" != "yes" ]]; then
    log "ERROR: target parent is not writable by $DST_USER: $parent"
    log "Prepare it manually on $DST_HOST; script will not sudo/chown automatically."
    FAILED=1
    return
  fi

  if [[ "$kind" == "dir" && "$exists" == "yes" && "$dw" != "yes" ]]; then
    log "ERROR: existing destination directory is not writable: $src"
    FAILED=1
    return
  fi

  if [[ "$kind" == "dir" && "$nonempty" == "yes" && "$ALLOW_EXISTING" -ne 1 ]]; then
    # Workspaces may already be the known partial migration from previous script.
    if [[ "$src" == "/home/daigd/workspaces" ]]; then
      log "INFO: workspaces already contains previous migration data; resume is allowed."
    else
      log "ERROR: destination directory is already non-empty: $src"
      log "Inspect it; if merge is intended, rerun with --allow-existing."
      FAILED=1
      return
    fi
  fi
}

for item in "${ITEMS[@]}"; do
  preflight_item "$item"
done

if [[ -n "$ONLY_BASENAME" ]]; then
  found=0
  for item in "${ITEMS[@]}"; do
    [[ "$(basename "$item")" == "$ONLY_BASENAME" ]] && found=1
  done
  [[ "$found" -eq 1 ]] || die "--only item not found in migration list: $ONLY_BASENAME"
fi

if [[ "$FAILED" -ne 0 ]]; then
  cat <<EOF

PRECHECK FAILED.
No new rsync transfer was started.

For /home/daigd/* paths, the target parent should normally be writable by yydh.
Example on target, only when those paths are dedicated to this migration:

  sudo mkdir -p /home/daigd
  sudo chown yydh:yydh /home/daigd

For models:
  sudo mkdir -p /home/shared/models
  sudo chown yydh:yydh /home/shared/models

Do not use recursive chown on existing shared/system trees without inspection.
EOF
  exit 5
fi

if [[ "$CHECK_ONLY" -eq 1 ]]; then
  log "CHECK-ONLY PASS. No data transferred."
  exit 0
fi

sync_item() {
  local src="$1"
  selected "$src" || return 0

  local base partial verify kind
  base="$(basename "$src")"
  partial=".rsync-partial-${base}"
  verify="${LOG_DIR}/verify-${base}-${RUN_ID}.txt"

  if [[ -d "$src" ]]; then
    kind="dir"
  else
    kind="file"
  fi

  echo
  log "========== COPY [$base] =========="

  local -a args=(
    -a
    --human-readable
    --info=progress2
    --stats
    --partial
    -e "$RSYNC_SSH"
  )

  if [[ "$USE_COMPRESS" -eq 1 ]]; then
    args+=(-z)
  fi

  if [[ "$kind" == "dir" ]]; then
    # Keep partial files inside destination directory for resumability.
    args+=("--partial-dir=${partial}" "--exclude=/${partial}/")

    stage "[$base] rsync pass 1" \
      rsync "${args[@]}" "$src/" "$REMOTE:$src/"

    stage "[$base] rsync pass 2" \
      rsync "${args[@]}" "$src/" "$REMOTE:$src/"
  else
    stage "[$base] rsync file" \
      rsync "${args[@]}" "$src" "$REMOTE:$(dirname "$src")/"
  fi

  : > "$verify"

  local -a verify_args=(-an --itemize-changes -e "$RSYNC_SSH")
  [[ "$STRONG_CHECKSUM" -eq 1 ]] && verify_args+=(-c)

  set +e
  if [[ "$kind" == "dir" ]]; then
    rsync "${verify_args[@]}" \
      "--exclude=/${partial}/" \
      "$src/" "$REMOTE:$src/" >"$verify" 2>&1
  else
    rsync "${verify_args[@]}" \
      "$src" "$REMOTE:$(dirname "$src")/" >"$verify" 2>&1
  fi
  rc=$?
  set -e

  [[ "$rc" -eq 0 ]] || { cat "$verify"; die "verification command failed for $src"; }
  [[ ! -s "$verify" ]] || { cat "$verify"; die "verification found differences for $src"; }

  log "[$base] VERIFY PASS"
}

for item in "${ITEMS[@]}"; do
  sync_item "$item"
done

cat <<EOF

============================================================
DEV ENV COPY COMPLETE
============================================================
Destination: ${REMOTE}

No source files were deleted.
No destination files were deleted.
Re-running is safe and incremental.

Log:
  ${LOG_FILE}

For CMake/GCC default selection, run the separate toolchain script
ON THE DESTINATION SERVER after migration.
============================================================
EOF
