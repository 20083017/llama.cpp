---

name: wtp184-server-session
description: Connects to the WTP184 Ubuntu build host and CentOS deployment host for remote source work, pipeline execution, runtime diagnosis and testing.
-----------------------------------------------------------------------------------------------------------------------------------------------------------

# WTP184 Server Session

## Environment roles

* Windows: Claude control host.
* Ubuntu `10.1.120.40`: authoritative WTP184 source, build workspace and pipeline.
* CentOS `10.1.122.21`: deployment and runtime host.
* The Ubuntu pipeline owns build, packaging, artifact sync and deployment to CentOS.

Do not overwrite, replace or synchronize the authoritative Ubuntu product workspace with workstation source.

Run the configured real pipeline on Ubuntu for remote build/deployment; do not use the Windows repository copy as a substitute.

## Execution authorization

Inherit `.claude/workflows/wtp184-workflow.md` for execution routes, approval, correction/material boundaries and records. Remote mutation, build/test, pipeline, runtime/log, deployment and service operations belonging to a development plan require its approved phase/scope before execution; invoking this Skill does not bypass that checkpoint. The workflow's sole preapproval remote exception is bounded `preapproval authoritative source discovery` on the canonical Ubuntu source host, delegated for a concrete planning fact and limited to non-mutating task-relevant source/configuration/BUILD/tests, direct dependencies and repository revision/status under `/home/daigd/dialogue`.

Covered approved operations may include:

* SSH and remote-source edits;
* logs/status/process inspection;
* pipeline `build`, `sync`, `deploy`, `all`, `status` and `smoke`;
* WTP184 container/service operations;
* requested core-debug and stress-test flows.

Do not request approval again between unchanged approved phases or ordinary corrections within the canonical boundaries. A direct-eligible task acquires no mandatory validation from this Skill. High-risk controls and Material blocker decisions remain those of the canonical workflow.

During planning, SSH is permitted only for the workflow's `preapproval authoritative source discovery`. Use the canonical Ubuntu alias and source root; resolve every inspected path remotely and require its real path to remain beneath `/home/daigd/dialogue`, explicitly allowing `/home/daigd/dialogue/third_party` and no external resolved target. Use one-shot non-interactive authentication, strict host-key verification, disabled forwarding, `RequestTTY=no`, `ControlMaster=no`, `ControlPath=none`, `ControlPersist=no`, and bounded connect/command timeouts. Allowed command classes are source/configuration/BUILD/test file reads and bounded searches plus read-only Git inspection. For Git, set `GIT_OPTIONAL_LOCKS=0`, disable filesystem monitors and pagers, use bounded pathspecs where applicable, and run diff reads with `--no-ext-diff --no-textconv`; do not invoke configured callbacks or refresh the index. Do not edit, create or delete remote files; mutate Git; build/test; run pipelines/packages; contact model/HTTP endpoints; inspect runtime/log/process/service/container state; deploy; access CentOS; expose credentials; or retain a session. Stop on alias/identity/host-key failure, ambiguous source, resolved-path escape, or required scope expansion. The orchestrator remains the only writer of planning artifacts.

## SSH

IP addresses identify WTP184 hosts; the documented SSH alias defines the SSH connection contract. WTP184 has separate documented aliases selected by operation role.

Canonical default routing when the required explicit identity override set is absent:

* build, pipeline deployment, runtime operation and tests use `new2_wtp184-server`, which must resolve exactly to `daigd@10.1.120.40`;
* direct read-only deployment configuration inspection, core and log diagnosis use `wtp184-server`, which must resolve exactly to `daigd@10.1.122.21`.

Deployment/runtime/test control continues to enter through the Ubuntu pipeline/controller. Do not reinterpret those operations as direct local CentOS sessions. The CentOS alias is the default for direct read-only configuration inspection and core/log diagnosis. For configuration questions, follow the workflow's configuration-first rule: read the selected deployment files directly, without an Ubuntu hop or Docker/helper inspection unless the user explicitly requests that inspection. Configuration edits retain the Ubuntu-to-deployment-host route.

Two WTP184 session entry modes are allowed:

1. A complete explicit host/user/port/identity/known-hosts contract. The required identity fields are `WTP184_SSH_HOST`, `WTP184_SSH_USER`, `WTP184_SSH_KEY` and `WTP184_SSH_KNOWN_HOSTS`; when any is provided, require all four and preserve the explicit contract.
2. The canonical alias for the selected operation role when all four required explicit identity fields are absent. A partial explicit contract fails closed and must not fall back to an alias or IP.

For alias mode, use OpenSSH's effective configuration (`ssh -G <alias>`) rather than reimplementing `Include` or wildcard matching. Validate exact `HostName`, `User`, `Port`, `IdentitiesOnly=yes`, every configured `IdentityFile` needed by the contract, strict host-key behavior and the effective `ProxyJump`/`ProxyCommand` state. Require readable configured identity files and a trusted host-key entry. Never read or print private-key contents or unrelated Host blocks.

Invoke the validated alias token itself, not `user@HostName` or the raw IP. Use it non-interactively with `BatchMode=yes`, `StrictHostKeyChecking=yes`, `IdentitiesOnly=yes`, forwarding disabled, password/keyboard-interactive authentication disabled, and bounded connect/command timeouts. Preserve alias-specific Port, IdentityFile and any validated ProxyJump instead of replacing them with raw-host defaults.

Pin the selected operation role, mode, alias/destination, user, HostName, port, identity mechanism, host-key mechanism and proxy state for the whole operation. SSH, SCP, RSYNC, build/deployment/runtime/test control, and core/log collection must reuse that exact resolved contract. Do not cross the Ubuntu build/control alias with the CentOS configuration-inspection/core/log alias. The Ubuntu pipeline's own server-to-server transport remains separate and unchanged.

If validation or authentication fails, stop. Do not discover or try another alias, direct/raw host, user, key, agent, password or credential variant. `MAIN_CONTEXT_REQUIRED` changes only the executor context and does not change the pinned contract.

Do not print or commit credentials, identity paths, SSH aliases outside bounded contract reporting, or private config content. Ordinary SSH may be used directly. Existing launchers or preflight commands are optional when their structured interface or diagnostic evidence is useful; they are not mandatory gates.

## Remote pipeline

Resolve server paths from this Skill rather than introducing agent-local defaults:

* project: `/home/daigd/dialogue`;
* third-party submodule: `/home/daigd/dialogue/third_party`;
* Linux server build/general pipeline (v17): `/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh`;
* Linux V3 offline deployment pipeline: `/home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh`;
* Android dialogue-API pipeline (v18): `/home/daigd/cu-dev-pipeline-v18-android-dialogue-api.sh`;
* bare Git resources: `/home/daigd/git-repos/wtp184/dialogue.git` and `/home/daigd/git-repos/wtp184/third_party.git`.

The bare repositories are source-control resources, not active build workspaces. `/home/daigd/workspaces` is retained reference data only and must not be activated.

### Authoritative Git integration

`/home/daigd/dialogue/third_party` has its own Git repository; `/home/daigd/dialogue` is the parent repository and records `third_party` as a gitlink. Inspect and verify their branches, indexes, tracked/untracked state and refs independently.

Preserve and exclude these nested refs from routine integration:

- `refs/heads/fix/archive-cu-server-prune-20260915-b607f465`
- `refs/heads/fix/cu-server-prune-20260915`

Do not automatically select either excluded ref as a source or target, and do not commit to, merge, move or delete it. Its existence alone does not make `third_party` modified. If an explicitly selected source/target or a required parent gitlink depends on an excluded ref/tip, stop and report the dependency; do not silently substitute another ref, override the exclusion or rewrite history. A later explicit approved request may revise this exclusion.

Determine nested intent from the approved request/scope, not from a dirty gitlink, nested checkout or branch existence. If intent is missing or contradicts observed state, stop for user direction.

If `third_party` is not intended to change:

1. Freeze parent target `master` and resolve its `third_party` gitlink as the expected nested commit.
2. Require the nested repository's complete `git status --porcelain` output empty and its HEAD equal that exact expected commit.
3. Require the parent feature's final tree to retain the same gitlink.
4. If the gitlink delta is uncommitted or staged, restore only the parent feature's `third_party` entry to the frozen parent-master value and verify it is absent from working-tree and index diffs. If it is already committed, create a new commit on the parent feature branch containing only the corrective gitlink delta.
5. Do not amend, rebase, reset, rewrite history, discard intended nested work or merge any nested branch. Inconsistent evidence stops for user direction.

If `third_party` is intentionally modified:

1. Require an explicitly approved nested source branch that is not excluded, and commit only its intended nested changes.
2. Freeze/predict the exact nested merge, merge the nested source into nested `master` first and verify the resulting exact nested-master tip and clean status.
3. Update the parent feature's gitlink to that exact nested-master commit and create a parent-feature commit containing only the gitlink update.
4. Freeze/predict the resulting exact parent source/master tips, then merge the parent source into parent `master` second and verify both repositories.

Use `--ff-only` when ancestry permits and an ordinary merge commit otherwise. Do not squash, cherry-pick, rebase, broad-stage, commit intended content directly on `master`, or resolve conflicts automatically unless a separately approved request changes that boundary. A predicted conflict stops before mutation. For an unexpected conflict, run only `git merge --abort`, verify restoration and report it to the user.

For local workstation Git/worktrees, continue to follow `.worktree-policy.yaml`; do not apply its local branch targets or delivery rules to these authoritative Ubuntu repositories.

For a generic release build, use this exact Ubuntu-side invocation:

```bash
PROJECT_DIR=/home/daigd/dialogue \
THIRD_PARTY_DIR=/home/daigd/dialogue/third_party \
  /bin/bash --noprofile --norc \
  /home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh build
```

For `sync`, `deploy`, `all`, `status` or `smoke`, preserve the same explicit `PROJECT_DIR` and `THIRD_PARTY_DIR` assignments and replace only the final action. The local `pipeline-build-clean` launcher command derives and validates the third-party path from the configured project before making the same explicit environment handoff.

For an explicit Linux V3 debug build, use the general v17 pipeline and authoritative source paths:

```bash
PROJECT_DIR=/home/daigd/dialogue \
THIRD_PARTY_DIR=/home/daigd/dialogue/third_party \
  /bin/bash --noprofile --norc \
  /home/daigd/cu-dev-pipeline-v17-dialogue-workspaces.sh \
  v3_debug_build
```

Deploy the current validated V3 debug package to the Linux V3 offline runtime through the offline pipeline. Preserve the explicit empty assignment exactly; this script uses `${REMOTE_AUTO_BUILD:-...}`, so an unset or empty value selects its canonical `/home/daigd/packages/auto_build_offline_v3.sh` deployment helper rather than disabling deployment:

```bash
PROJECT_DIR=/home/daigd/dialogue \
THIRD_PARTY_DIR=/home/daigd/dialogue/third_party \
REMOTE_AUTO_BUILD= \
bash /home/daigd/cu-dev-pipeline-v17-dialogue-workspaces_offline.sh \
  v3_debug_deploy
```

`v3_debug_deploy --dry-run` must report `build=never` and `deployment=sync+managed_deploy+verify+smoke`. Here, `build=never` means no Ubuntu Bazel/package build; the selected remote helper still performs the managed offline runtime deployment on the target host.

| Action | Linux target/selection | Profile | Artifact pointer | Deployment |
| --- | --- | --- | --- | --- |
| `v3_debug_build` | authoritative `/home/daigd/dialogue`, `//cu:server`, `--define=dialogue_pipeline_v3=true` | `dbg`, no strip, `-O0`, `-g`, frame pointers | `/home/daigd/packages/server-v3/debug/LATEST` | never |
| `v3_debug_deploy` | validated existing V3 debug package; no Ubuntu build | existing debug package | `/home/daigd/packages/server-v3/debug/LATEST` | offline pipeline sync, managed port-9530 deploy using `auto_build_offline_v3.sh`, exact binary/version verification and bounded smoke |
| `v3_release_build` | same V3 server selection | `opt`, stripped package | `/home/daigd/packages/server-v3/release/LATEST` | never |
| `v3_build` | compatibility alias for V3 release | `opt`, stripped package | `/home/daigd/packages/server-v3/release/LATEST` | never |

The three V3 build actions pin the authoritative project and its nested third-party tree, use V3-specific logs/metadata and profile-neutral `server-v3.<timestamp>-<git>` artifact/version names in the existing debug/release folders, and do not replace generic `/home/daigd/packages/server/LATEST`. The clean V3 server link excludes legacy NLU/ONNX Runtime while retaining its actually selected package closure. Those build actions never call sync, deploy, service, HTTP or workload paths. The offline pipeline's `v3_debug_deploy` performs no Ubuntu build: it fails closed unless the V3 debug pointer, executable and metadata prove the expected V3/debug `//cu:server`, freezes the validated artifact name/SHA/size, fails on pointer or artifact drift before mutation, intentionally mirrors that package into the target generic `packages/server/` staging directory, invokes the offline V3 deployment helper and performs exact binary/version verification plus bounded smoke. An explicit empty `REMOTE_AUTO_BUILD=` selects that pipeline's canonical offline helper through shell default expansion; it does not disable the target deployment step. Use `bash` because the server pipeline file is not required to have executable mode.

Build/validation target and Query-history ownership are platform-specific:

- Linux V2 and Linux V3 use `//cu:server`; Linux V3 Query records continue through configured ContextManager/Redis APIs.
- Android V2 and Android V3 use `//cu:libdialogue_api.so`; Android V3 requires the configured LocalContextManager and stores raw serialized Query payloads through it, with a thin process-local adapter owning request order/generation/capacity policy. Query records retain their configured positive TTL; LocalContextManager's source-compatible `kNeverExpires` type is a finite one-week lifetime renewed only by successful writes.
- Turn/Task/context uses the same configured ContextManager instance on each platform. A successful package build is not runtime Redis, server-process or Android-device evidence.

Primary product target:

`//cu:server`

Select the action that matches the request:

* `build`: build/package `//cu:server` through the optimized, stripped release profile;
* `debug_build`: build/package `//cu:server` with Bazel `dbg`, no stripping, `-fno-omit-frame-pointer`, effective `-O0` and explicit `-g`; ordinary debug with no ASan instrumentation;
* `asan_build`: build/package `//cu:server` with Bazel `dbg`, no stripping and project `--config=asan`; build only, with no sync or deployment;
* `release_build`: build/package the default Linux `//cu:server` selection with Bazel `opt` and stripping;
* `v3_debug_build`: build/package Linux V3 `//cu:server` with Bazel `dbg`, no stripping, `-O0`, `-g` and frame pointers; never deploy;
* `v3_debug_deploy`: through the offline pipeline, validate and deploy the existing V3 debug pointer with explicit empty `REMOTE_AUTO_BUILD`, which selects the canonical offline helper; never run an Ubuntu build or consume generic `LATEST`;
* `v3_release_build`: build/package Linux V3 `//cu:server` with Bazel `opt` and a stripped package; never deploy;
* `v3_build`: compatibility alias for `v3_release_build`; never deploy;
* `sync`: sync current local `LATEST` and metadata;
* `deploy`: sync current `LATEST`, deploy it to the managed dev slot and verify postconditions;
* `debug_all`: debug build followed by the existing deploy pipeline;
* `release_all`: release build followed by the existing deploy pipeline;
* `test_2w_non_stream`: exact-once 20,000-row aggregate-JSON test;
* `test_multi_round`: one serial histories case, selected by `WTP184_HISTORY_CASE_ID`;
* `test_2w_stream`: exact-once 20,000-row bounded-SSE test;
* `all`: legacy/default-profile build followed by the existing deploy pipeline;
* `status` / `smoke`: inspect the current deployment.

Generic `build`, `debug_build`, `release_build`, `debug_all` and `release_all` use the canonical, hash-validated shared-library set under `/home/daigd/packages/lib`, including `libstdc++.so.6.0.26` and the compatible package-local `libgcc_s.so.1`. The pipeline exposes only its selected SONAME view to target link/resolution checks; it must not export the complete directory through global `LD_LIBRARY_PATH`. GCC/G++ 4.9.3 and the CentOS 7 sysroot remain the compiler/header/libc baseline. ASan and legacy/default `all` remain outside this package-library profile contract.

Every build/all/test alias that documents `--dry-run`, including the four Linux V3 commands, must return before Bazel, packaging, sync, deployment, HTTP, monitor or workload execution. `debug_build` and the build stage of `debug_all` share the ordinary debug flags above. `asan_build` is build-only and there is no ASan all/deploy shortcut. `deploy` already includes sync, so `debug_all` and `release_all` call only build plus `deploy_pipeline` and never perform a duplicate explicit sync. Standalone generic `deploy` uses whichever profile the generic current `LATEST` metadata records. Only the offline pipeline's `v3_debug_deploy` may consume the Ubuntu V3 debug pointer. It leaves Ubuntu generic `LATEST` unchanged and intentionally updates the target generic staging `LATEST`, matching other deploys.

A short command does not preauthorize a deployment or workload. Apply the canonical execution route to each requested operation, preserve exact-once/no-automatic-retry test semantics, and report workload acceptance rather than treating exit status alone as semantic PASS.

Do not infer deployment success from build success.

### Android dialogue-API builds

Use the v18 pipeline only for Android `//cu:libdialogue_api.so` build and packaging. Keep the v17 pipeline above as the canonical Linux `//cu:server` build/deployment path.

Use this exact environment-safe invocation shape, replacing only the selected Android action and operator message when another matrix entry is requested. Omit `--clean` only when an incremental build is intentionally sufficient:

```bash
LC_ALL=C \
PROJECT_DIR="$HOME/dialogue" \
THIRD_PARTY_DIR="$HOME/dialogue/third_party" \
/bin/bash --noprofile --norc \
  "$HOME/cu-dev-pipeline-v18-android-dialogue-api.sh" \
  android_v3_debug_build \
  --android-ndk "$HOME/workspaces/android-ndk-r20b" \
  --android-abi arm64-v8a \
  --android-api 21 \
  --clean \
  --message "Android V3 debug libdialogue_api.so"
```

Select the action by requested dialogue version and profile:

| Action | Dialogue selection | Bazel profile | Strip policy |
| --- | --- | --- | --- |
| `android_v2_debug_build` | explicit `--define=dialogue_pipeline_v3=false`; V3 manager edge excluded | `dbg` with effective `-O0`, `-g` and frame pointers | `never` |
| `android_v2_release_build` | explicit `--define=dialogue_pipeline_v3=false`; V3 manager edge excluded | `opt` | `always` |
| `android_v3_debug_build` | exactly one effective `--define=dialogue_pipeline_v3=true`; V3 manager edge enabled | `dbg` with effective `-O0`, `-g` and frame pointers | `never` |
| `android_v3_release_build` | exactly one effective `--define=dialogue_pipeline_v3=true`; V3 manager edge enabled | `opt` | `always` |
| `android_build` | compatibility alias for Android V2 release | `opt` | `always` |

Explicit matrix actions identify `v2|v3` and `debug|release` in build logs and metadata. V2 matrix artifact names retain their profile tags. V3 artifact/version names are profile-neutral: `libdialogue_api-android-v3-<ABI>-api<API>.<timestamp>-<git8>.so`; the stable library remains `libdialogue_api.so`. V3 profiles share the artifact root: an occupied artifact, `.meta` or `.runtime` identity is rejected without replacement or pointer advancement. Their profile pointers are `LATEST-v2-debug`, `LATEST-v2-release`, `LATEST-v3-debug` and `LATEST-v3-release`. Compatibility `android_build` retains its legacy artifact naming and `LATEST` pointer while also maintaining `LATEST-v2-release`.

Metadata records the target, dialogue version, profile, configured define selection, compilation/strip modes, NDK revision, ABI/API, Git revision, artifact SHA-256 and size, and packaged libc++ runtime status. Use `--dry-run` only to inspect the resolved Android version/profile and distinguishing Bazel flags; it exits before build/package work and is not build evidence. These Android actions are build/package only: they do not sync, deploy, restart a service or operate a device. A successful cross-build is not Android runtime proof. Report the exact action/command, exit status, configured V2/V3 selection, artifact path/SHA/profile, and Android runtime as unverified unless it was actually executed on an approved Android target.

Pipeline-owned temporary cleanup, release rotation and failure restoration are ordinary pipeline behavior.

## Core-debug / Stress-test

Use `wtp184-core-debug` for core diagnosis.

Use `wtp184-stress-test` for stress testing.

Execute these flows when covered by the canonical route and any required plan approval, without routine per-phase confirmation.

Do not affect unrelated services, containers or processes, and do not perform unbounded load or cleanup.

## Result

Return the host role, action, exit status and primary result. On failure, use the canonical ordinary-correction/material classification and return the relevant evidence; an ordinary command failure alone does not require a user decision.

Include one next action only when useful.
