---
name: wtp184-stress-test
description: Run unified single, duration/exact-once CSV, delegated multi-round history, or bounded multigroup WTP184 tests with existing remote scripts.
---

# WTP184 Stress Test

## Existing remote files

- Unified single/CSV/histories entrypoint: `~/stress_test/zp_update_soak_csv_v5_2.5.sh`
- CSV cases: `~/stress_test/2w_data.csv`
- CSV query column: `query`
- Multi-round comparator delegated by the entrypoint: `~/stress_test/compare_histories_9999_9530_py36_full.py`
- Multi-round cases: `~/stress_test/history_replay_cases_verified_full.json`

Use the unified entrypoint directly for the three modes below. Do not generate another wrapper or automatically retry requests/turns.

The canonical build-host pipeline exposes these exact shortcuts to the same entrypoint:

```text
test_2w_non_stream [--dry-run]
test_multi_round [--dry-run]
test_2w_stream [--dry-run]
```

- `test_2w_non_stream`: full 20,000-row `--exact-once --stream false` contract below.
- `test_2w_stream`: full 20,000-row `--exact-once --stream true` contract below.
- `test_multi_round`: one serial histories case with `--force-stream-false`; override the bounded default through `WTP184_HISTORY_CASE_ID`.

Dry-run prints the resolved Bash argument array and exits before HTTP, SSH monitoring, core/runtime collection or workload reports. Shortcut availability does not bypass the canonical planned-operation route for consequential 20k or histories execution. On real runs, preserve the same acceptance accounting and never relaunch automatically after a failure or uncertain timeout.

## Shared request modes

Single and CSV stress accept:

```text
--stream false   aggregate JSON; default
--stream true    bounded SSE data events
```

`-O` remains the single-case dataset-row offset and never selects streaming. The request contains the configured synthetic session, CSV `query`, `app_id`, `firstWakeUp`, microphone input, `debug`, and the selected boolean `stream` value.

Non-stream success requires HTTP 200, `Header.Code=0`, and `Payload.Semantic`. Stream success additionally requires `text/event-stream`, valid bounded `data:` JSON events, `Header.Stream=true`, and terminal `Header.IsEnd=true`; this deployment completes by connection close and does not require a separate `[DONE]` marker.

## Adaptive diagnostic fast-fail

When an approved diagnosis defines an ordered set of stress cells and an evidence-based stop condition, treat the listed matrix as a maximum workload rather than a requirement to launch every cell.

- Finish the currently launched exact-once cell and preserve its complete accounting before evaluating an ordinary diagnostic stop.
- After each completed cell, correlate its report and bounded runtime evidence. Do not start later cells once the approved first discriminating cause or exclusion criterion is established.
- Record every skipped cell and the retained evidence that made it unnecessary.
- Never use diagnostic fast-fail to truncate ordinary exact-once accounting, retry failed rows, relaunch a completed or uncertain cell, convert partial accounting to PASS, or weaken request/time/size/breaker/core safeguards.
- An active cell may be stopped immediately only for a safety condition, material boundary or existing runner breaker. Retain and report its partial accounting and do not relaunch it automatically.
- If the instrumentation or correlation key is missing and later cells would be non-diagnostic, stop before adding load and return that evidence to the orchestrator.

This adaptive rule applies only when the approved plan names the cell order, maximum requests and discriminating stop criteria. It does not make a routine 20,000-row exact-once run optional or authorize an unplanned subset.

## Opt-in diagnostic request/response trace

For an approved bounded raw-output comparison, stress exact-once mode accepts:

```text
--trace-request-id-prefix PREFIX
```

The prefix must contain only 1-64 ASCII letters, digits, underscores or hyphens. When present, the runner:

- assigns deterministic top-level `request_id` values as `<PREFIX>-rNNNNNN`, keyed by selected dataset row;
- preserves ordinary `results.tsv`, `request_errors.tsv`, accounting and success classification unchanged;
- writes owner-only `diagnostic_trace.jsonl` in the generated report directory;
- records dataset row, request ID, response `Header.RequestId`, synthetic query, HTTP/application status, final semantic value/presence, runner success/category and error;
- never activates in single, duration or histories mode and never writes the sidecar without the explicit option.

Use this only with an approved protected-evidence flow. Treat query and semantic fields as raw diagnostic data: do not copy them into ordinary logs, plan/check/CURRENT or an unprotected summary. Reconcile request ID and response `Header.RequestId` exactly before joining with server-side capture. A missing, duplicate or mismatched ID invalidates exact comparison; do not infer row alignment or replay automatically.

## Single-case test

Default to row `1`, one request, and non-stream mode unless the user supplies another row/mode. Do not retry automatically:

```bash
cd ~/stress_test
./zp_update_soak_csv_v5_2.5.sh \
  --mode single \
  --stream "${WTP184_STREAM_MODE:-false}" \
  --session-prefix "${WTP184_SESSION_PREFIX:-wtp184_single}" \
  -f ~/stress_test/2w_data.csv \
  -S "${WTP184_DATASET_ROW:-1}" \
  -O 0 \
  -n 1 \
  -m "${WTP184_MONITOR_SSH:?}" \
  -P 9530
```

Return command exit status, stream mode, selected row, success and categorized failure counts, container/PID/core stability result, and report path.

## CSV stress

### Exact-once full dataset

Use this for the 20,000-row test. It requires `-m USER@HOST` and refuses traffic unless the pre-run container/PID/core-capture contract is ready. It dispatches every selected row once through a bounded worker queue; worker completion order may differ from CSV order, but row identity/accounting is retained. It does not retry failed rows:

```bash
cd ~/stress_test
./zp_update_soak_csv_v5_2.5.sh \
  --mode stress \
  --exact-once \
  --stream "${WTP184_STREAM_MODE:-false}" \
  --session-prefix "${WTP184_SESSION_PREFIX:-wtp184_2w}" \
  -f ~/stress_test/2w_data.csv \
  -c "${WTP184_CONCURRENCY:-4}" \
  -R 1 \
  -r 30 \
  -C 3 \
  -T 10 \
  --max-response-bytes 1048576 \
  -E 20 \
  -B 200 \
  -m "${WTP184_MONITOR_SSH:?}" \
  -P 9530
```

Run the full dataset only when explicitly requested. `WTP184_STREAM_MODE=true` selects the requested streaming 20k test; `false` selects aggregate responses.

Exact-once PASS requires all 20,000 rows dispatched, completed, and accounted once, with zero business, transport, parser, incomplete-stream, oversized-response, core, PID, and container-stability failures. Return those counts, `dataset_validation`, runtime result, exit status, and report paths. Exit status `0` alone is not semantic PASS.

### Duration mode

Without `--exact-once`, stress mode cycles the selected full/resume/window dataset until `-d SEC`. Use duration mode only when the user requests a timed soak. Preserve the same stream, timeout, breaker, session, report, and no-retry contracts:

```bash
cd ~/stress_test
./zp_update_soak_csv_v5_2.5.sh \
  --mode stress \
  --stream "${WTP184_STREAM_MODE:-false}" \
  --session-prefix "${WTP184_SESSION_PREFIX:-wtp184_soak}" \
  -f ~/stress_test/2w_data.csv \
  -c "${WTP184_CONCURRENCY:-4}" \
  -d "${WTP184_DURATION_SECONDS:-60}" \
  -R 1 \
  -r 10 \
  -C 3 \
  -T 10 \
  --max-response-bytes 1048576 \
  -E 20 \
  -B 200 \
  -m "${WTP184_MONITOR_SSH:?}" \
  -P 9530
```

On any stress non-PASS, return the first actionable error and the generated `summary.txt`, `request_errors.tsv`, `results.tsv`, `case_map.tsv`, and core snapshot paths that exist.

## Multi-round history comparison

Use the unified entrypoint; it delegates directly to the existing comparator without rewriting case order, payloads, histories, or session behavior. Default to `C005_case1_car_info_tire_pressure` unless the user supplies another case ID:

```bash
cd ~/stress_test
./zp_update_soak_csv_v5_2.5.sh \
  --mode histories \
  --case-id "${WTP184_HISTORY_CASE_ID:-C005_case1_car_info_tire_pressure}" \
  --cases ~/stress_test/history_replay_cases_verified_full.json \
  --url-9999 http://10.1.122.21:9999/zp/update \
  --url-9530 http://10.1.122.21:9530/zp/update \
  --force-stream-false
```

Turns remain serial and the comparator retains fresh-per-case-per-environment sessions plus replace-session-id-only payload behavior. Return selected case ID, both URLs, wrapper/comparator exit status, final comparison result, per-side failure/difference summary, and printed `rounds.csv`, `cases.csv`, and `result.json` paths. Exit status `0` proves command completion only; report semantic equivalence only when comparator output establishes it.

## Bounded multigroup multi-turn matrix

When the user explicitly requests the existing multigroup multi-turn comparison, `wtp184-server-operator` runs the authoritative wrapper directly, with its existing bounded defaults unless explicitly overridden:

```bash
~/stress_test/compare_9999_9530_case_history_matrix_v6.sh
```

The wrapper performs four runs sequentially:

1. port `9999`, `t1`
2. port `9530`, `t1`
3. port `9999`, `t4`
4. port `9530`, `t4`

Within every group, turns are serial. In each `t4` run, groups execute concurrently and use distinct sessions. The primary internal-concurrency comparison is `9530` `t1` versus `t4`; the equivalent `9999` comparison is the control. Treat cross-port comparisons as secondary.

`request_trace.jsonl` uses correlation tokens matching `corr-[0-9a-f]{24}`. A wrapper exit status of `0` does not establish semantic equivalence: inspect matrix and diff summaries. Use the reported `$OUT_ROOT/port_*` and `$OUT_ROOT/diffs` paths.

Only for differing cases, correlate server evidence through the canonical Docker-log Skill and compact each saved response. Preserve each Docker helper exit status before compaction; post-processing never replaces it. Return the wrapper exit status, matrix/diff summaries, primary/control outcomes, and report paths.

This workload can reveal cross-session or group-concurrency effects. It cannot prove or disprove overlapping same-session lost updates because turns are serial within each group and concurrent groups use distinct sessions.
